





<!DOCTYPE HTML>
<html lang="en">
<head>

<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-GG9C02THQ7"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag("js", new Date());

  gtag("config", "G-GG9C02THQ7");
</script>

<script src="https://www.google.com/recaptcha/api.js" async defer></script><meta charset="UTF-8">
<meta name="robots" content="index, follow">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SAS_INTRO_L106</title>

    <link rel="stylesheet" href="/styles/mycsg.css">
    <script src="/scripts/mycsg.js"></script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.11.1/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/fixedcolumns/3.3.3/js/dataTables.fixedColumns.min.js"></script>

    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/2.0.8/css/dataTables.dataTables.css">

    <link rel="stylesheet" type="text/css" href="/styles/prism.css">
    <script src="/scripts/prism.js" data-manual></script>
    <script src="/vendor/tinymce/tinymce_6.1.2/tinymce.min.js" referrerpolicy="origin"></script>
  <script>
   if (window.tinymce) {
     const presentationTemplates = [{"title":"LD","description":"Adds a four-row lesson description scaffold for presentation mode.","content":"<table style=\"width: 96%; margin: 0 auto; border-collapse: collapse;\"><tr><td style=\"background: #dff3e6; border: 1px solid #000000; text-align: center; font-size: 24px; font-weight: 700; padding: 14px 18px;\">Background</td></tr><tr><td style=\"border: 1px solid #000000; padding: 14px 18px;\"><ul><li>Add the background point here</li></ul></td></tr><tr><td style=\"background: #FBEEB8; border: 1px solid #000000; text-align: center; font-size: 24px; font-weight: 700; padding: 14px 18px;\">What is covered in this lesson</td></tr><tr><td style=\"border: 1px solid #000000; padding: 14px 18px;\"><ul><li>Add the lesson coverage point here</li></ul></td></tr></table><p></p>"}];

     tinymce.init({
       selector: '.myeditablelessondiv',
       plugins: 'table autoresize autosave codesample preview wordcount code emoticons link image lists advlist media insertdatetime template visualblocks help',
       toolbar: 'template | undo redo | styles | hr | forecolor backcolor | bold italic | numlist bullist | alignleft aligncenter alignright alignjustify | outdent indent | link image media| code | visualblocks',
       templates: presentationTemplates
     });
   }
 </script>
    <style>
    .csg-site-navbar {
      padding-top: 0.15rem !important;
      padding-bottom: 0.15rem !important;
    }
    .csg-site-navbar .navbar-brand {
      font-weight: 700;
      margin-right: 1rem;
      white-space: nowrap;
    }
    .csg-site-navbar .nav-link {
      padding: 0.45rem 0.55rem !important;
      font-size: 0.92rem;
      white-space: nowrap;
    }
    .csg-site-navbar .dropdown-toggle,
    .csg-site-navbar .dropdown-item,
    .csg-site-navbar .badge,
    .csg-site-navbar .csg-days,
    .csg-site-navbar .csg-exp {
      white-space: nowrap;
    }
    /* Bell dropdown — shared styles for both bell instances (one outside the
       collapse for mobile/tablet, one inside the right-side ul for desktop). */
    .csg-bell-nav .csg-bell-toggle {
      position: relative;
      display: inline-flex;
      align-items: center;
      color: rgba(255,255,255,0.85);
      padding: 0.45rem 0.6rem;
    }
    .csg-bell-nav .csg-bell-toggle:hover,
    .csg-bell-nav .csg-bell-toggle:focus { color: #fff; }
    .csg-bell-nav .csg-bell-badge {
      display: none; /* JS sets inline-block when unread > 0 */
      position: absolute;
      top: 1px;
      right: -2px;
      font-size: 0.62rem;
      padding: 1px 5px;
      border-radius: 999px;
      line-height: 1;
    }
    .csg-bell-nav .csg-bell-menu {
      min-width: 340px;
      max-width: min(92vw, 400px);
      max-height: 480px;
      overflow: auto;
    }

    /* Outside-collapse bell — visible on mobile/tablet only. Sits between the
       brand and the hamburger toggler. */
    .csg-bell-outside {
      display: flex;
      align-items: center;
      margin-left: auto;
      flex-shrink: 0;
    }
    @media (max-width: 1399.98px) {
      .csg-bell-outside { margin-right: 0.4rem; }
    }
    @media (min-width: 1400px) {
      .csg-bell-outside { display: none !important; }
    }

    /* Inside-collapse bell — visible on desktop only. Sits in the right-side ul
       just before the Hi-user greeting. Hidden on mobile so opening the
       hamburger does not surface a duplicate bell. */
    .csg-bell-inside { display: none; }
    @media (min-width: 1400px) {
      .csg-bell-inside { display: list-item; }
    }
    .csg-site-navbar .navbar-nav {
      align-items: center;
    }
    .csg-site-navbar .navbar-collapse {
      min-width: 0;
    }
    @media (max-width: 1399.98px) {
      .csg-site-navbar.navbar-expand-csg > .container,
      .csg-site-navbar.navbar-expand-csg > .container-fluid {
        padding-left: 0;
        padding-right: 0;
      }
      .csg-site-navbar.navbar-expand-csg .navbar-toggler {
        display: block;
      }
      .csg-site-navbar.navbar-expand-csg .navbar-collapse {
        display: none !important;
        width: 100%;
        margin-top: 0.45rem;
        padding-top: 0.55rem;
        border-top: 1px solid rgba(255,255,255,0.08);
      }
      .csg-site-navbar.navbar-expand-csg .navbar-collapse.show {
        display: block !important;
      }
      .csg-site-navbar.navbar-expand-csg .navbar-nav,
      .csg-site-navbar.navbar-expand-csg .nav.navbar-nav {
        width: 100%;
        align-items: stretch;
      }
      .csg-site-navbar.navbar-expand-csg .navbar-nav .nav-link,
      .csg-site-navbar.navbar-expand-csg .nav.navbar-nav .nav-link {
        width: 100%;
        padding-left: 0 !important;
        padding-right: 0 !important;
      }
      .csg-site-navbar.navbar-expand-csg .navbar-nav.mr-auto {
        margin-right: 0 !important;
      }
      .csg-site-navbar.navbar-expand-csg .navbar-right.ml-auto {
        margin-left: 0 !important;
      }
      .csg-site-navbar.navbar-expand-csg .dropdown-menu {
        position: static !important;
        float: none;
        width: 100%;
        margin-top: 0.25rem;
      }
      .csg-site-navbar.navbar-expand-csg .csg-bell-nav.dropdown {
        position: relative;
      }
      .csg-site-navbar.navbar-expand-csg .csg-bell-nav .dropdown-menu.csg-bell-menu {
        position: fixed !important;
        top: 56px !important;
        right: 8px !important;
        left: 8px !important;
        transform: none !important;
        width: auto;
        min-width: 0;
        max-height: min(70vh, 480px);
        margin-top: 0.35rem;
        z-index: 1040;
      }
    }
    @media (min-width: 1400px) {
      .csg-site-navbar.navbar-expand-csg {
        flex-flow: row nowrap;
        justify-content: flex-start;
      }
      .csg-site-navbar.navbar-expand-csg .navbar-toggler {
        display: none;
      }
      .csg-site-navbar.navbar-expand-csg .navbar-collapse {
        display: flex !important;
        flex-basis: auto;
      }
      .csg-site-navbar.navbar-expand-csg .navbar-nav {
        flex-direction: row;
      }
      .csg-site-navbar.navbar-expand-csg .dropdown-menu {
        position: absolute;
      }
    }
   
    .resizeable-column {
      resize: horizontal; /* Allow the user to resize horizontally */
      overflow: auto; /* Add scrollbars if the content overflows */
    }
        
		.frame {
			height: 500px; /* adjust height as needed */
			   
    hr { 
      margin: 0em;
    } 

    input[type="radio"] {
      -ms-transform: scale(1.5); /* IE 9 */
      -webkit-transform: scale(1.5); /* Chrome, Safari, Opera */
      transform: scale(1.5);
      margin: 10;
    }

    input[type="checkbox"] {
      -ms-transform: scale(1.5); /* IE 9 */
      -webkit-transform: scale(1.5); /* Chrome, Safari, Opera */
      transform: scale(1.5);
    }
        
    .answer_explanation_toggle_wrapper    
    {
            
    }    
    #answer_explanation 
    {
        margin-top: 0px;  
        margin-bottom: 30px; 
        background: gray;
        width: auto; height: 50px;
    }
    .buttontags {
      border-radius: 100px; /* Adjust the value to control the roundness of the corners */
      opacity: 0.1; /* Adjust the value to control the greyed-out appearance */
      pointer-events: none; /* Disable pointer events to make the button non-clickable */
    }

    <style>
  /* Custom striped table colors */
  .table-striped-concepts tbody tr:nth-of-type(odd) {
    background-color: #f8f9fa; /* Light gray color */
  }
  
  .table-striped-concepts tbody tr:nth-of-type(even) {
    background-color: goldenyellow; /* Dark gray color */
  }
</style>

    </style>

    <script>
    $( "button.crf-sdtm-anno-toggle" ).click(function() {
       $( this ).next(".crf-sdtm-anno-toggle").toggle();

    });
        </script>
</head>
<body>

<div class="container-fluid sticky-top m-0 p-0">
  <div class="row h-5 p-0 m-0 d-flex-row">
    <div class="col-12 bg-dark p-0 m-0">

    <nav class="navbar navbar-expand-csg csg-site-navbar bg-dark navbar-dark p-0 px-3 m-0">
    <a class="navbar-brand" href="/index.php">mycsg.in</a>
    <div class="csg-bell-nav csg-bell-outside dropdown">
  <a class="csg-bell-toggle nav-link" href="#" data-toggle="dropdown" role="button"
     aria-haspopup="true" aria-expanded="false" aria-label="Notifications">
    <i class="fas fa-bell"></i>
    <span class="csg-bell-badge badge badge-danger">0</span>
  </a>
  <div class="csg-bell-menu dropdown-menu dropdown-menu-right p-0">
    <div class="px-3 py-2 d-flex justify-content-between align-items-center border-bottom" style="background:#f8fafc;">
      <strong class="small text-dark">Notifications</strong>
      <span class="d-inline-flex align-items-center" style="gap:10px;">
        <button type="button" class="csg-bell-mark-all btn btn-link btn-sm p-0" style="font-size:.75rem;">Mark all read</button>
        <button type="button" class="csg-bell-close btn btn-link btn-sm p-0 text-muted" aria-label="Close notifications" title="Close" style="font-size:1rem;line-height:1;">&times;</button>
      </span>
    </div>
    <div class="csg-bell-list">
      <div class="px-3 py-3 text-muted text-center small">Loading&hellip;</div>
    </div>
    <div class="border-top px-3 py-2 d-flex justify-content-between align-items-center" style="background:#f8fafc;">
      <a href="/notifications_inbox.php" class="small">Open inbox</a>
      <label class="small mb-0 text-dark" style="font-size:.75rem;cursor:pointer;">
        <input type="checkbox" class="csg-bell-email-optin"> Email me
      </label>
    </div>
  </div></div>
    <button class="navbar-toggler center" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="collapsibleNavbar">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item">   <a class="nav-link" href="/sas.php">SAS</a>  </li>
    <li class="nav-item">   <a class="nav-link" href="/sasnr2.php">SASnR</a>  </li>
     <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="clinicalProgrammingDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        Clinical Programming
        </a>
        <div class="dropdown-menu" aria-labelledby="clinicalProgrammingDropdown">
        <a class="dropdown-item" href="/crfs/">CRFs</a>
        <a class="dropdown-item" href="/sdtm.php">SDTM</a>
        <a class="dropdown-item" href="/adam.php">ADaM</a>
        <a class="dropdown-item" href="/tfl.php">TFL</a>
        <a class="dropdown-item" href="/tasks.php">Tasks</a>
        <a class="dropdown-item" href="/macros.php">Macros</a>
        </div>
    </li>
    <li class="nav-item">   <a class="nav-link" href="/qna.php">QnA</a>  </li>
    <li class="nav-item">   <a class="nav-link" href="/quiz.php">Quizzes</a>  </li>
    <li class="nav-item">   <a class="nav-link" href="/resources.php">Resources</a>  </li>
    <li class="nav-item">   <a class="nav-link" href="/disclaimer.php">Disclaimer</a>  </li>
    <li class="nav-item">   <a class="nav-link" href="/contact%20us.php">Contact Us</a>  </li>
    <li class="nav-item">
      <a class="nav-link d-flex align-items-center justify-content-start" href="/training.php">
        <span>Training</span>
      </a>
    </li>
    
    
    </ul>
    <ul class="nav navbar-nav navbar-right ml-auto">
      <li class="nav-item dropdown csg-bell-nav csg-bell-inside">
  <a class="csg-bell-toggle nav-link" href="#" data-toggle="dropdown" role="button"
     aria-haspopup="true" aria-expanded="false" aria-label="Notifications">
    <i class="fas fa-bell"></i>
    <span class="csg-bell-badge badge badge-danger">0</span>
  </a>
  <div class="csg-bell-menu dropdown-menu dropdown-menu-right p-0">
    <div class="px-3 py-2 d-flex justify-content-between align-items-center border-bottom" style="background:#f8fafc;">
      <strong class="small text-dark">Notifications</strong>
      <span class="d-inline-flex align-items-center" style="gap:10px;">
        <button type="button" class="csg-bell-mark-all btn btn-link btn-sm p-0" style="font-size:.75rem;">Mark all read</button>
        <button type="button" class="csg-bell-close btn btn-link btn-sm p-0 text-muted" aria-label="Close notifications" title="Close" style="font-size:1rem;line-height:1;">&times;</button>
      </span>
    </div>
    <div class="csg-bell-list">
      <div class="px-3 py-3 text-muted text-center small">Loading&hellip;</div>
    </div>
    <div class="border-top px-3 py-2 d-flex justify-content-between align-items-center" style="background:#f8fafc;">
      <a href="/notifications_inbox.php" class="small">Open inbox</a>
      <label class="small mb-0 text-dark" style="font-size:.75rem;cursor:pointer;">
        <input type="checkbox" class="csg-bell-email-optin"> Email me
      </label>
    </div>
  </div></li>
<li class="nav-item d-flex align-items-center">
  <a class="nav-link d-flex align-items-center" title="Ravi">
    
    <span style="max-width:120px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:inline-block;">Hi Ravi!</span>
  </a>
</li><style>
/* tiny pulse dot next to the ACCESS pill */
.csg-pulse {
  position: relative; display:inline-block; width:8px; height:8px; border-radius:50%;
  margin-left:6px; background: #ffcc00;
}
.csg-pulse::after {
  content:""; position:absolute; left:50%; top:50%; width:8px; height:8px; border-radius:50%;
  transform: translate(-50%,-50%); box-shadow: 0 0 0 0 rgba(255,204,0,.6); animation: csg-pulse 1.8s infinite;
}
@keyframes csg-pulse { 0%{box-shadow:0 0 0 0 rgba(255,204,0,.6);} 70%{box-shadow:0 0 0 10px rgba(255,204,0,0);} 100%{box-shadow:0 0 0 0 rgba(255,204,0,0);} }
/* row layout inside dropdown */
.csg-row { display:flex; align-items:center; justify-content:space-between; gap:.75rem; padding:.25rem .25rem; }
.csg-left { display:flex; align-items:center; gap:.5rem; min-width: 0; }
.csg-tag { font-size:.75rem; padding:.25rem .5rem; border-radius:.5rem; }
.csg-days { font-weight:700; white-space:nowrap; }
.csg-exp { font-size:.8rem; color:#6c757d; white-space:nowrap; }
.csg-divider { margin:.25rem 0; }
.csg-preview-nav .dropdown-toggle::after { margin-left:.35rem; }
.csg-preview-menu { min-width: 180px; }
.csg-preview-menu .dropdown-item.active,
.csg-preview-menu .dropdown-item:active {
  background:#ffc107;
  color:#212529;
}
.csg-preview-menu .dropdown-item:hover {
  background:#f8f9fa;
  color:#212529;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
  var previewRoot = document.getElementById('csgPreviewMenu');
  if (!previewRoot) return;

  var toggle = document.getElementById('csgPreviewToggle');
  var menu = previewRoot.querySelector('.csg-preview-menu');
  var closeBtn = previewRoot.querySelector('.csg-preview-close');
  var isOpen = false;

  function openMenu() {
    if (!menu || !toggle) return;
    previewRoot.classList.add('show');
    menu.classList.add('show');
    toggle.classList.add('show');
    toggle.setAttribute('aria-expanded', 'true');
    isOpen = true;
  }

  function closeMenu() {
    if (!menu || !toggle) return;
    previewRoot.classList.remove('show');
    menu.classList.remove('show');
    toggle.classList.remove('show');
    toggle.setAttribute('aria-expanded', 'false');
    isOpen = false;
  }

  previewRoot.addEventListener('mouseenter', openMenu);

  toggle.addEventListener('click', function(e) {
    e.preventDefault();
    if (isOpen) {
      closeMenu();
    } else {
      openMenu();
    }
  });

  if (closeBtn) {
    closeBtn.addEventListener('click', function(e) {
      e.preventDefault();
      closeMenu();
    });
  }

  document.addEventListener('click', function(e) {
    if (!previewRoot.contains(e.target)) {
      closeMenu();
    }
  });

  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
      closeMenu();
    }
  });
});
</script>


<li class="nav-item dropdown d-flex align-items-center">
  <a class="nav-link dropdown-toggle d-flex align-items-center"
     href="#" id="csgAccessMenu"
     role="button"
     data-bs-toggle="dropdown"       
     data-toggle="dropdown"          
     data-bs-boundary="viewport"      
     data-boundary="viewport"         
     data-bs-offset="0,8"             
     aria-expanded="false">
    <span class="badge bg-warning text-dark">ACCESS</span>
    <span class="csg-pulse"></span>
  </a>

  <div class="dropdown-menu dropdown-menu-end dropdown-menu-right p-2"
       aria-labelledby="csgAccessMenu"
       style="min-width: 320px; max-width: min(92vw, 420px); overflow-wrap:anywhere;">

        <div class="csg-row">
          <div class="csg-left">
            <span class="csg-tag badge bg-primary">SAS Sub</span>
            <span class="csg-exp">expires <strong>11 Jun 2026</strong></span>
          </div>
          <div class="csg-days text-success">27d</div>
        </div><div class="dropdown-divider csg-divider"></div>
        <div class="csg-row">
          <div class="csg-left">
            <span class="csg-tag badge bg-success">R Recs</span>
            <span class="csg-exp">expires <strong>11 Jun 2026</strong></span>
          </div>
          <div class="csg-days text-success">27d</div>
        </div>
        <div class="dropdown-divider csg-divider"></div>
        <div class="px-1 text-muted" style="font-size:.75rem;">As of 16 May 2026, 20:24 IST</div>
      </div>
    </li>  
      <li class="nav-item">
        <a class="nav-link" href="/logout.php">Log out</a>
      </li>
      </ul>
    </div>
    </div>
    </nav>
    

</div>

</div>



<script>
(function () {
  var bells = document.querySelectorAll(".csg-bell-nav");
  if (!bells.length) return;

  function $all(sel) { return document.querySelectorAll(sel); }
  function escH(s) { var d = document.createElement("div"); d.textContent = String(s == null ? "" : s); return d.innerHTML; }
  function relTime(iso) {
    if (!iso) return "";
    var d = new Date(iso);
    if (isNaN(d.getTime())) return "";
    var s = Math.max(0, (Date.now() - d.getTime()) / 1000);
    if (s < 60) return "just now";
    if (s < 3600) return Math.floor(s/60) + "m ago";
    if (s < 86400) return Math.floor(s/3600) + "h ago";
    if (s < 86400*7) return Math.floor(s/86400) + "d ago";
    return d.toLocaleDateString();
  }

  function renderItems(items) {
    var html;
    if (!items || !items.length) {
      html = "<div class=\"px-3 py-4 text-muted text-center small\">You're all caught up.</div>";
    } else {
      html = items.slice(0, 10).map(function (n) {
        var bodyTrunc = (n.body_html || "").replace(/<[^>]+>/g, " ").trim();
        if (bodyTrunc.length > 140) bodyTrunc = bodyTrunc.slice(0, 140) + "…";
        var link = n.link || "";
        var clickAction = link ? ("data-link=\"" + escH(link) + "\"") : "";
        var color = n.color || "#6b7280";
        var icon = n.icon || "fa-bell";
        var dim = n.is_dismissed ? "opacity:0.55;" : "";
        return ""
          + "<div class=\"csg-bell-row\" data-id=\"" + escH(n.id) + "\" " + clickAction + " "
          + "style=\"display:flex;gap:10px;padding:10px 14px;border-bottom:1px solid #eef2f6;cursor:pointer;" + dim + "\">"
          + "  <div style=\"width:28px;height:28px;border-radius:50%;background:" + color + ";color:#fff;display:flex;align-items:center;justify-content:center;flex-shrink:0;\">"
          + "    <i class=\"fas " + escH(icon) + "\" style=\"font-size:.75rem;\"></i>"
          + "  </div>"
          + "  <div style=\"flex:1;min-width:0;\">"
          + "    <div style=\"font-weight:600;font-size:.83rem;color:#0f172a;\">" + escH(n.title) + "</div>"
          + "    <div style=\"color:#64748b;font-size:.78rem;line-height:1.3;\">" + escH(bodyTrunc) + "</div>"
          + "    <div style=\"color:#94a3b8;font-size:.7rem;margin-top:2px;\">"
          + "      <span class=\"csg-bell-pill\" style=\"background:" + color + "22;color:" + color + ";padding:1px 6px;border-radius:999px;font-weight:600;margin-right:6px;\">" + escH(n.type_label || n.type || "Update") + "</span>"
          + "      " + escH(relTime(n.created_at))
          + "    </div>"
          + "  </div>"
          + (n.is_dismissed ? "" : "  <button type=\"button\" class=\"btn btn-link p-0 csg-bell-dismiss\" title=\"Mark read\" style=\"color:#94a3b8;font-size:.85rem;align-self:flex-start;\">&times;</button>")
          + "</div>";
      }).join("");
    }
    $all(".csg-bell-list").forEach(function (el) { el.innerHTML = html; });
  }

  function setBadge(n) {
    var show = n && n > 0;
    var text = !show ? "0" : (n > 99 ? "99+" : String(n));
    $all(".csg-bell-badge").forEach(function (el) {
      el.style.display = show ? "inline-block" : "none";
      el.textContent = text;
    });
  }

  function setOptin(checked) {
    $all(".csg-bell-email-optin").forEach(function (el) { el.checked = !!checked; });
  }

  function refresh() {
    fetch("/notifications_api.php?action=list&limit=10", { credentials: "same-origin" })
      .then(function (r) { return r.json(); })
      .then(function (res) {
        if (!res || !res.ok) {
          $all(".csg-bell-list").forEach(function (el) {
            el.innerHTML = "<div class=\"px-3 py-3 text-muted text-center small\">Failed to load.</div>";
          });
          return;
        }
        setBadge(res.unread || 0);
        setOptin(res.email_optin);
        renderItems(res.items || []);
      })
      .catch(function () {
        $all(".csg-bell-list").forEach(function (el) {
          el.innerHTML = "<div class=\"px-3 py-3 text-muted text-center small\">Network error.</div>";
        });
      });
  }
  window.csgRefreshBell = refresh;

  // Click handler on every list (delegation)
  $all(".csg-bell-list").forEach(function (list) {
    list.addEventListener("click", function (e) {
      var dismissBtn = e.target.closest(".csg-bell-dismiss");
      var row = e.target.closest(".csg-bell-row");
      if (!row) return;
      var id = row.getAttribute("data-id") || "";

      if (dismissBtn) {
        e.preventDefault(); e.stopPropagation();
        var fd = new FormData();
        fd.append("action", "dismiss");
        fd.append("id", id);
        fetch("/notifications_api.php", { method: "POST", body: fd, credentials: "same-origin" })
          .then(function (r) { return r.json(); })
          .then(function (res) { if (res && res.ok) { setBadge(res.unread || 0); refresh(); } });
        return;
      }

      var link = row.getAttribute("data-link");
      var fd2 = new FormData();
      fd2.append("action", "dismiss");
      fd2.append("id", id);
      if (navigator.sendBeacon) {
        navigator.sendBeacon("/notifications_api.php", fd2);
      } else {
        fetch("/notifications_api.php", { method: "POST", body: fd2, credentials: "same-origin", keepalive: true }).catch(function () {});
      }
      if (link) window.location.href = link;
    });
  });

  $all(".csg-bell-close").forEach(function (btn) {
    btn.addEventListener("click", function (e) {
      e.preventDefault();
      e.stopPropagation();
      var nav = btn.closest(".csg-bell-nav");
      var toggle = nav ? nav.querySelector(".csg-bell-toggle") : null;
      if (toggle && window.jQuery && window.jQuery.fn && window.jQuery.fn.dropdown) {
        window.jQuery(toggle).dropdown("hide");
      } else {
        var menu = nav ? nav.querySelector(".csg-bell-menu") : null;
        if (menu) menu.classList.remove("show");
        if (toggle) toggle.setAttribute("aria-expanded", "false");
      }
    });
  });

  $all(".csg-bell-mark-all").forEach(function (btn) {
    btn.addEventListener("click", function (e) {
      e.preventDefault();
      var fd = new FormData();
      fd.append("action", "dismiss_all");
      fetch("/notifications_api.php", { method: "POST", body: fd, credentials: "same-origin" })
        .then(function (r) { return r.json(); })
        .then(function () { refresh(); });
    });
  });

  $all(".csg-bell-email-optin").forEach(function (cb) {
    cb.addEventListener("change", function () {
      var fd = new FormData();
      fd.append("action", "set_email_optin");
      fd.append("optin", cb.checked ? "1" : "0");
      setOptin(cb.checked); // sync the other instance immediately
      fetch("/notifications_api.php", { method: "POST", body: fd, credentials: "same-origin" });
    });
  });

  refresh();
})();
</script>
<div class="bg-warning p-1" style="position:sticky;top:0;z-index:100;display:flex;align-items:center;"><a class="btn btn-sm btn-secondary" href="./sas.php?concept=INTRO">&larr; Introduction to SAS</a><strong style="flex:1;text-align:center;">Introduction to SAS - part 06 - Variable labels, dataset labels, and display formats</strong></div><style>
/* --- csg_ads shared layout --- */
/* App-shell: only .csg-center-col (and mobile interstitial) scrolls.
   Containing document (including iframe documents) must not add its own scroll. */
html, body {
  height: 100% !important;
  margin: 0 !important;
  overflow: hidden !important;
}
.csg-adwrap {
  --csg-ad-col-width: clamp(200px, 20vw, 320px);
  --csg-center-max: none;
  --csg-adwrap-bg: #e8ecf1;
  --csg-center-padding: 20px 28px;
  display: flex;
  overflow: hidden;
  background: var(--csg-adwrap-bg);
}
.csg-ad-col {
  flex: 0 0 var(--csg-ad-col-width);
  overflow: hidden;
  padding: 16px 8px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
}
.csg-ad-label {
  font-size: 9px;
  color: #b0b8c4;
  text-transform: uppercase;
  letter-spacing: 0.12em;
  align-self: stretch;
  text-align: center;
  visibility: hidden;
}
.csg-ad-col.is-filled .csg-ad-label { visibility: visible; }
.csg-center-col {
  flex: 1;
  min-width: 0;
  min-height: 100%;
  max-width: var(--csg-center-max);
  overflow-y: auto;
  padding: var(--csg-center-padding);
  background: #ffffff;
  box-shadow: 0 0 0 1px rgba(0,0,0,0.06), 0 0 40px rgba(0,0,0,0.16);
  position: relative;
  z-index: 2;
}
@media (max-width: 991.98px) {
  .csg-ad-col { display: none; }
  .csg-center-col { padding: 16px 14px; box-shadow: none; }
}
/* --- csg_ads mobile interstitial --- */
.csg-interstitial-overlay {
  position: fixed;
  inset: 0;
  z-index: 9999;
  background: rgba(0,0,0,0.88);
  display: none;
  align-items: center;
  justify-content: center;
  padding: 16px;
}
.csg-interstitial-card {
  width: 100%;
  max-width: 380px;
  background: #111;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 8px 32px rgba(0,0,0,0.6);
}
.csg-interstitial-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 8px 12px;
  border-bottom: 1px solid rgba(255,255,255,0.08);
}
.csg-interstitial-ad-label {
  font-size: 10px;
  color: #666;
  text-transform: uppercase;
  letter-spacing: 0.1em;
}
.csg-interstitial-skip {
  background: rgba(255,255,255,0.08);
  border: 1px solid rgba(255,255,255,0.12);
  color: #aaa;
  border-radius: 4px;
  padding: 4px 10px;
  font-size: 12px;
  cursor: default;
}
.csg-interstitial-skip:not(:disabled) {
  cursor: pointer;
  background: rgba(255,255,255,0.18);
  color: #fff;
  border-color: rgba(255,255,255,0.3);
}
</style><style>.sas-lesson-iframe { flex:1; min-width:0; height:100%; border:none; display:block; }</style><script async src='https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-7309667479757182' crossorigin='anonymous'></script><script>
(function() {
  function setH() {
    var el = document.getElementById("sas-lesson-wrap");
    if (!el) return;
    var top = el.getBoundingClientRect().top;
    var vh  = window.innerHeight || document.documentElement.clientHeight;
    // Leave room for the fixed site footer (footer.php, id='pagefooter') when present.
    // Absent on iframe documents — in that case footerH is 0.
    var footer  = document.getElementById('pagefooter');
    var footerH = footer ? footer.offsetHeight : 0;
    el.style.height = Math.max(300, vh - top - footerH) + 'px';
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', setH);
  } else {
    setH();
  }
  window.addEventListener('load', setH);
  window.addEventListener('resize', setH);
  setTimeout(setH, 600);
})();
</script><div class='csg-adwrap' id='sas-lesson-wrap'><iframe id='sasLessonFrame' class='sas-lesson-iframe' src='SAS/SAS_INTRO/SAS_INTRO_L106/SAS_INTRO_L106_master.html'></iframe></div>        <script>
        (function () {
          var frame = document.getElementById('sasLessonFrame');
          if (!frame) return;

          function slugify(text) {
            return (text || '')
              .toLowerCase()
              .replace(/[^\w\s-]/g, '')
              .trim()
              .replace(/\s+/g, '-')
              .slice(0, 80) || 'section';
          }

          function buildToc() {
            var doc;
            try { doc = frame.contentDocument || frame.contentWindow.document; } catch (e) { return; }
            if (!doc || !doc.body) return;

            // Avoid double-injection if user navigates within iframe
            if (doc.getElementById('sas-toc')) return;

            // Top-level headings only. Exclude modal titles and hidden nodes.
            var headings = Array.prototype.slice.call(doc.querySelectorAll('h1'))
              .filter(function (h) {
                if (h.closest && (h.closest('.modal') || h.closest('[aria-hidden="true"]'))) return false;
                var txt = (h.textContent || '').trim();
                return txt.length > 0;
              });

            if (headings.length < 2) return;

            var usedIds = {};
            var items = headings.map(function (h) {
              var id = h.id;
              if (!id) {
                var base = slugify(h.textContent || '');
                id = base;
                var i = 2;
                while (doc.getElementById(id) || usedIds[id]) { id = base + '-' + i; i++; }
                h.id = id;
              }
              usedIds[id] = true;
              return { id: id, text: (h.textContent || '').trim() };
            });

            var toc = doc.createElement('nav');
            toc.id = 'sas-toc';
            toc.setAttribute('aria-label', 'Lesson contents');
            toc.style.cssText = [
              'margin: 10px auto 16px',
              'padding: 10px 14px',
              'border: 1px solid #dfe3e8',
              'border-left: 4px solid #21A95B',
              'border-radius: 6px',
              'background: #f8fafc',
              'font-family: inherit',
              'font-size: 14px',
              'max-width: 960px'
            ].join(';');

            var header = doc.createElement('div');
            header.style.cssText = 'display:flex;align-items:center;justify-content:space-between;gap:8px;cursor:pointer;user-select:none;';
            var title = doc.createElement('strong');
            title.textContent = 'Contents';
            title.style.cssText = 'color:#1f2937;';
            var toggle = doc.createElement('span');
            toggle.textContent = 'Hide';
            toggle.style.cssText = 'color:#2563eb;font-size:12px;';
            header.appendChild(title);
            header.appendChild(toggle);

            var list = doc.createElement('ol');
            list.style.cssText = 'margin:8px 0 0;padding-left:22px;line-height:1.6;';

            items.forEach(function (item) {
              var li = doc.createElement('li');
              var a = doc.createElement('a');
              a.href = '#' + item.id;
              a.textContent = item.text;
              a.style.cssText = 'color:#1d4ed8;text-decoration:none;';
              a.addEventListener('mouseenter', function () { a.style.textDecoration = 'underline'; });
              a.addEventListener('mouseleave', function () { a.style.textDecoration = 'none'; });
              li.appendChild(a);
              list.appendChild(li);
            });

            header.addEventListener('click', function () {
              var hidden = list.style.display === 'none';
              list.style.display = hidden ? '' : 'none';
              toggle.textContent = hidden ? 'Hide' : 'Show';
            });

            toc.appendChild(header);
            toc.appendChild(list);
            doc.body.insertBefore(toc, doc.body.firstChild);

            // Floating "Back to top" button — visible after scrolling ~400px.
            if (!doc.getElementById('sas-toc-top')) {
              var topBtn = doc.createElement('button');
              topBtn.id = 'sas-toc-top';
              topBtn.type = 'button';
              topBtn.setAttribute('aria-label', 'Back to top');
              topBtn.innerHTML = '&uarr; Top';
              topBtn.style.cssText = [
                'position: fixed',
                'right: 18px',
                'bottom: 22px',
                'z-index: 9999',
                'padding: 8px 14px',
                'border: 0',
                'border-radius: 999px',
                'background: #21A95B',
                'color: #fff',
                'font: 600 13px/1 inherit',
                'cursor: pointer',
                'box-shadow: 0 4px 14px rgba(0,0,0,0.18)',
                'opacity: 0',
                'pointer-events: none',
                'transition: opacity 0.2s ease'
              ].join(';');
              topBtn.addEventListener('click', function () {
                var scroller = doc.scrollingElement || doc.documentElement || doc.body;
                if (scroller && typeof scroller.scrollTo === 'function') {
                  scroller.scrollTo({ top: 0, behavior: 'smooth' });
                } else {
                  (doc.documentElement || doc.body).scrollTop = 0;
                }
              });
              doc.body.appendChild(topBtn);

              var onScroll = function () {
                var y = (doc.scrollingElement || doc.documentElement || doc.body).scrollTop || 0;
                if (y > 400) {
                  topBtn.style.opacity = '1';
                  topBtn.style.pointerEvents = 'auto';
                } else {
                  topBtn.style.opacity = '0';
                  topBtn.style.pointerEvents = 'none';
                }
              };
              (frame.contentWindow || window).addEventListener('scroll', onScroll, { passive: true });
              onScroll();
            }
          }

          frame.addEventListener('load', buildToc);
          // Handle case where iframe is already loaded before script runs
          try {
            if (frame.contentDocument && frame.contentDocument.readyState === 'complete') {
              buildToc();
            }
          } catch (e) {}
        })();
        </script>
        <div class='container-fluid page-footer-container p-0 m-0' id='pagefooter' style="position: fixed; bottom: 0; width: 100%;">
    <!-- Footer -->
    <footer class="text-center text-lg-start bg-light text-muted">

        <!-- Section: Links -->
        
        <!-- Copyright -->
        <div class="text-center p-2" style="background-color: rgba(0, 0, 0, 0.05);">
            &copy; 2014&ndash;2026 Copyright:
            <a class="text-reset fw-bold" href="https://mycsg.in">www.mycsg.in</a>
        </div>
        <!-- Copyright -->
        
    </footer>
    <!-- Footer -->
</div>
</body>
</html>
