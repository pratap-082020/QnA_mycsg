(function() {
    'use strict';
    var aa = typeof Object.create == "function" ? Object.create : function(a) {
            function b() {}
            b.prototype = a;
            return new b
        },
        k = typeof Object.defineProperties == "function" ? Object.defineProperty : function(a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a
        };

    function ba(a) {
        a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
        for (var b = 0; b < a.length; ++b) {
            var c = a[b];
            if (c && c.Math == Math) return c
        }
        throw Error("Cannot find global object");
    }
    var l = ba(this),
        p = typeof Symbol === "function" && typeof Symbol("x") === "symbol",
        q = {},
        t = {};

    function u(a, b, c) {
        if (!c || a != null) {
            c = t[b];
            if (c == null) return a[b];
            c = a[c];
            return c !== void 0 ? c : a[b]
        }
    }

    function w(a, b, c) {
        if (b) a: {
            var d = a.split(".");a = d.length === 1;
            var f = d[0],
                g;!a && f in q ? g = q : g = l;
            for (f = 0; f < d.length - 1; f++) {
                var e = d[f];
                if (!(e in g)) break a;
                g = g[e]
            }
            d = d[d.length - 1];c = p && c === "es6" ? g[d] : null;b = b(c);b != null && (a ? k(q, d, {
                configurable: !0,
                writable: !0,
                value: b
            }) : b !== c && (t[d] === void 0 && (a = Math.random() * 1E9 >>> 0, t[d] = p ? l.Symbol(d) : "$jscp$" + a + "$" + d), k(g, t[d], {
                configurable: !0,
                writable: !0,
                value: b
            })))
        }
    }
    var x;
    if (p && typeof Object.setPrototypeOf == "function") x = Object.setPrototypeOf;
    else {
        var z;
        a: {
            var ca = {
                    a: !0
                },
                da = {};
            try {
                da.__proto__ = ca;
                z = da.a;
                break a
            } catch (a) {}
            z = !1
        }
        x = z ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    var ea = x;

    function A(a, b) {
        a.prototype = aa(b.prototype);
        a.prototype.constructor = a;
        if (ea) ea(a, b);
        else
            for (var c in b)
                if (c != "prototype")
                    if (Object.defineProperties) {
                        var d = Object.getOwnPropertyDescriptor(b, c);
                        d && Object.defineProperty(a, c, d)
                    } else a[c] = b[c];
        a.ga = b.prototype
    }

    function fa(a) {
        var b = 0;
        return function() {
            return b < a.length ? {
                done: !1,
                value: a[b++]
            } : {
                done: !0
            }
        }
    }

    function B(a) {
        var b = typeof q.Symbol != "undefined" && u(q.Symbol, "iterator") && a[u(q.Symbol, "iterator")];
        if (b) return b.call(a);
        if (typeof a.length == "number") return {
            next: fa(a)
        };
        throw Error(String(a) + " is not an iterable or ArrayLike");
    }

    function C(a) {
        return ha(a, a)
    }

    function ha(a, b) {
        a.raw = b;
        Object.freeze && (Object.freeze(a), Object.freeze(b));
        return a
    }
    var ia = p && typeof u(Object, "assign") == "function" ? u(Object, "assign") : function(a, b) {
        if (a == null) throw new TypeError("No nullish arg");
        a = Object(a);
        for (var c = 1; c < arguments.length; c++) {
            var d = arguments[c];
            if (d)
                for (var f in d) Object.prototype.hasOwnProperty.call(d, f) && (a[f] = d[f])
        }
        return a
    };
    w("Object.assign", function(a) {
        return a || ia
    }, "es6");

    function ja(a) {
        if (!(a instanceof Object)) throw new TypeError("Iterator result " + a + " is not an object");
    }

    function D() {
        this.B = !1;
        this.u = null;
        this.j = void 0;
        this.g = 1;
        this.m = this.A = 0;
        this.H = this.i = null
    }

    function E(a) {
        if (a.B) throw new TypeError("Generator is already running");
        a.B = !0
    }
    D.prototype.G = function(a) {
        this.j = a
    };

    function F(a, b) {
        a.i = {
            V: b,
            W: !0
        };
        a.g = a.A || a.m
    }
    D.prototype.getNextAddressJsc = function() {
        return this.g
    };
    D.prototype.getYieldResultJsc = function() {
        return this.j
    };
    D.prototype.return = function(a) {
        this.i = {
            return: a
        };
        this.g = this.m
    };
    D.prototype["return"] = D.prototype.return;
    D.prototype.ba = function(a) {
        this.i = {
            v: a
        };
        this.g = this.m
    };
    D.prototype.jumpThroughFinallyBlocks = D.prototype.ba;
    D.prototype.h = function(a, b) {
        this.g = b;
        return {
            value: a
        }
    };
    D.prototype.yield = D.prototype.h;
    D.prototype.ea = function(a, b) {
        a = B(a);
        var c = a.next();
        ja(c);
        if (c.done) this.j = c.value, this.g = b;
        else return this.u = a, this.h(c.value, b)
    };
    D.prototype.yieldAll = D.prototype.ea;
    D.prototype.v = function(a) {
        this.g = a
    };
    D.prototype.jumpTo = D.prototype.v;
    D.prototype.I = function() {
        this.g = 0
    };
    D.prototype.jumpToEnd = D.prototype.I;
    D.prototype.C = function(a, b) {
        this.A = a;
        b != void 0 && (this.m = b)
    };
    D.prototype.setCatchFinallyBlocks = D.prototype.C;
    D.prototype.da = function(a) {
        this.A = 0;
        this.m = a || 0
    };
    D.prototype.setFinallyBlock = D.prototype.da;
    D.prototype.J = function(a, b) {
        this.g = a;
        this.A = b || 0
    };
    D.prototype.leaveTryBlock = D.prototype.J;
    D.prototype.F = function(a) {
        this.A = a || 0;
        a = this.i.V;
        this.i = null;
        return a
    };
    D.prototype.enterCatchBlock = D.prototype.F;
    D.prototype.P = function(a, b, c) {
        c ? this.H[c] = this.i : this.H = [this.i];
        this.A = a || 0;
        this.m = b || 0
    };
    D.prototype.enterFinallyBlock = D.prototype.P;
    D.prototype.ca = function(a, b) {
        b = this.H.splice(b || 0)[0];
        (b = this.i = this.i || b) ? b.W ? this.g = this.A || this.m : b.v != void 0 && this.m < b.v ? (this.g = b.v, this.i = null) : this.g = this.m: this.g = a
    };
    D.prototype.leaveFinallyBlock = D.prototype.ca;
    D.prototype.aa = function(a) {
        return new G(a)
    };
    D.prototype.forIn = D.prototype.aa;

    function G(a) {
        this.i = a;
        this.g = [];
        for (var b in a) this.g.push(b);
        this.g.reverse()
    }
    G.prototype.h = function() {
        for (; this.g.length > 0;) {
            var a = this.g.pop();
            if (a in this.i) return a
        }
        return null
    };
    G.prototype.getNext = G.prototype.h;

    function ka(a) {
        this.g = new D;
        this.h = a
    }

    function la(a, b) {
        E(a.g);
        var c = a.g.u;
        if (c) return H(a, "return" in c ? c["return"] : function(d) {
            return {
                value: d,
                done: !0
            }
        }, b, a.g.return);
        a.g.return(b);
        return I(a)
    }

    function H(a, b, c, d) {
        try {
            var f = b.call(a.g.u, c);
            ja(f);
            if (!f.done) return a.g.B = !1, f;
            var g = f.value
        } catch (e) {
            return a.g.u = null, F(a.g, e), I(a)
        }
        a.g.u = null;
        d.call(a.g, g);
        return I(a)
    }

    function I(a) {
        for (; a.g.g;) try {
            var b = a.h(a.g);
            if (b) return a.g.B = !1, {
                value: b.value,
                done: !1
            }
        } catch (c) {
            a.g.j = void 0, F(a.g, c)
        }
        a.g.B = !1;
        if (a.g.i) {
            b = a.g.i;
            a.g.i = null;
            if (b.W) throw b.V;
            return {
                value: b.return,
                done: !0
            }
        }
        return {
            value: void 0,
            done: !0
        }
    }

    function ma(a) {
        this.next = function(b) {
            E(a.g);
            a.g.u ? b = H(a, a.g.u.next, b, a.g.G) : (a.g.G(b), b = I(a));
            return b
        };
        this.throw = function(b) {
            E(a.g);
            a.g.u ? b = H(a, a.g.u["throw"], b, a.g.G) : (F(a.g, b), b = I(a));
            return b
        };
        this.return = function(b) {
            return la(a, b)
        };
        this[u(q.Symbol, "iterator")] = function() {
            return this
        }
    }

    function na(a) {
        function b(d) {
            return a.next(d)
        }

        function c(d) {
            return a.throw(d)
        }
        return new q.Promise(function(d, f) {
            function g(e) {
                e.done ? d(e.value) : q.Promise.resolve(e.value).then(b, c).then(g, f)
            }
            g(a.next())
        })
    }

    function J(a) {
        return na(new ma(new ka(a)))
    }

    function oa() {
        for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
        return b
    }
    w("globalThis", function(a) {
        return a || l
    }, "es_2020");
    w("Symbol", function(a) {
        function b(g) {
            if (this instanceof b) throw new TypeError("Symbol is not a constructor");
            return new c(d + (g || "") + "_" + f++, g)
        }

        function c(g, e) {
            this.g = g;
            k(this, "description", {
                configurable: !0,
                writable: !0,
                value: e
            })
        }
        if (a) return a;
        c.prototype.toString = function() {
            return this.g
        };
        var d = "jscomp_symbol_" + (Math.random() * 1E9 >>> 0) + "_",
            f = 0;
        return b
    }, "es6");
    w("Symbol.iterator", function(a) {
        if (a) return a;
        a = (0, q.Symbol)("Symbol.iterator");
        k(Array.prototype, a, {
            configurable: !0,
            writable: !0,
            value: function() {
                return pa(fa(this))
            }
        });
        return a
    }, "es6");

    function pa(a) {
        a = {
            next: a
        };
        a[u(q.Symbol, "iterator")] = function() {
            return this
        };
        return a
    }
    w("Promise", function(a) {
        function b(e) {
            this.h = 0;
            this.i = void 0;
            this.g = [];
            this.A = !1;
            var h = this.j();
            try {
                e(h.resolve, h.reject)
            } catch (m) {
                h.reject(m)
            }
        }

        function c() {
            this.g = null
        }

        function d(e) {
            return e instanceof b ? e : new b(function(h) {
                h(e)
            })
        }
        if (a) return a;
        c.prototype.h = function(e) {
            if (this.g == null) {
                this.g = [];
                var h = this;
                this.i(function() {
                    h.m()
                })
            }
            this.g.push(e)
        };
        var f = l.setTimeout;
        c.prototype.i = function(e) {
            f(e, 0)
        };
        c.prototype.m = function() {
            for (; this.g && this.g.length;) {
                var e = this.g;
                this.g = [];
                for (var h = 0; h < e.length; ++h) {
                    var m =
                        e[h];
                    e[h] = null;
                    try {
                        m()
                    } catch (n) {
                        this.j(n)
                    }
                }
            }
            this.g = null
        };
        c.prototype.j = function(e) {
            this.i(function() {
                throw e;
            })
        };
        b.prototype.j = function() {
            function e(n) {
                return function(r) {
                    m || (m = !0, n.call(h, r))
                }
            }
            var h = this,
                m = !1;
            return {
                resolve: e(this.H),
                reject: e(this.m)
            }
        };
        b.prototype.H = function(e) {
            if (e === this) this.m(new TypeError("A Promise cannot resolve to itself"));
            else if (e instanceof b) this.J(e);
            else {
                a: switch (typeof e) {
                    case "object":
                        var h = e != null;
                        break a;
                    case "function":
                        h = !0;
                        break a;
                    default:
                        h = !1
                }
                h ? this.G(e) : this.u(e)
            }
        };
        b.prototype.G = function(e) {
            var h = void 0;
            try {
                h = e.then
            } catch (m) {
                this.m(m);
                return
            }
            typeof h == "function" ? this.P(h, e) : this.u(e)
        };
        b.prototype.m = function(e) {
            this.B(2, e)
        };
        b.prototype.u = function(e) {
            this.B(1, e)
        };
        b.prototype.B = function(e, h) {
            if (this.h != 0) throw Error("Cannot settle(" + e + ", " + h + "): Promise already settled in state" + this.h);
            this.h = e;
            this.i = h;
            this.h === 2 && this.I();
            this.F()
        };
        b.prototype.I = function() {
            var e = this;
            f(function() {
                if (e.C()) {
                    var h = l.console;
                    typeof h !== "undefined" && h.error(e.i)
                }
            }, 1)
        };
        b.prototype.C =
            function() {
                if (this.A) return !1;
                var e = l.CustomEvent,
                    h = l.Event,
                    m = l.dispatchEvent;
                if (typeof m === "undefined") return !0;
                typeof e === "function" ? e = new e("unhandledrejection", {
                    cancelable: !0
                }) : typeof h === "function" ? e = new h("unhandledrejection", {
                    cancelable: !0
                }) : (e = l.document.createEvent("CustomEvent"), e.initCustomEvent("unhandledrejection", !1, !0, e));
                e.promise = this;
                e.reason = this.i;
                return m(e)
            };
        b.prototype.F = function() {
            if (this.g != null) {
                for (var e = 0; e < this.g.length; ++e) g.h(this.g[e]);
                this.g = null
            }
        };
        var g = new c;
        b.prototype.J =
            function(e) {
                var h = this.j();
                e.M(h.resolve, h.reject)
            };
        b.prototype.P = function(e, h) {
            var m = this.j();
            try {
                e.call(h, m.resolve, m.reject)
            } catch (n) {
                m.reject(n)
            }
        };
        b.prototype.then = function(e, h) {
            function m(v, y) {
                return typeof v == "function" ? function(Q) {
                    try {
                        n(v(Q))
                    } catch (R) {
                        r(R)
                    }
                } : y
            }
            var n, r, S = new b(function(v, y) {
                n = v;
                r = y
            });
            this.M(m(e, n), m(h, r));
            return S
        };
        b.prototype.catch = function(e) {
            return this.then(void 0, e)
        };
        b.prototype.M = function(e, h) {
            function m() {
                switch (n.h) {
                    case 1:
                        e(n.i);
                        break;
                    case 2:
                        h(n.i);
                        break;
                    default:
                        throw Error("Unexpected state: " +
                            n.h);
                }
            }
            var n = this;
            this.g == null ? g.h(m) : this.g.push(m);
            this.A = !0
        };
        b.resolve = d;
        b.reject = function(e) {
            return new b(function(h, m) {
                m(e)
            })
        };
        b.race = function(e) {
            return new b(function(h, m) {
                for (var n = B(e), r = n.next(); !r.done; r = n.next()) d(r.value).M(h, m)
            })
        };
        b.all = function(e) {
            var h = B(e),
                m = h.next();
            return m.done ? d([]) : new b(function(n, r) {
                function S(Q) {
                    return function(R) {
                        v[Q] = R;
                        y--;
                        y == 0 && n(v)
                    }
                }
                var v = [],
                    y = 0;
                do v.push(void 0), y++, d(m.value).M(S(v.length - 1), r), m = h.next(); while (!m.done)
            })
        };
        return b
    }, "es6");
    w("Array.from", function(a) {
        return a ? a : function(b, c, d) {
            c = c != null ? c : function(h) {
                return h
            };
            var f = [],
                g = typeof q.Symbol != "undefined" && u(q.Symbol, "iterator") && b[u(q.Symbol, "iterator")];
            if (typeof g == "function") {
                b = g.call(b);
                for (var e = 0; !(g = b.next()).done;) f.push(c.call(d, g.value, e++))
            } else
                for (g = b.length, e = 0; e < g; e++) f.push(c.call(d, b[e], e));
            return f
        }
    }, "es6");
    w("Promise.allSettled", function(a) {
        function b(d) {
            return {
                status: "fulfilled",
                value: d
            }
        }

        function c(d) {
            return {
                status: "rejected",
                reason: d
            }
        }
        return a ? a : function(d) {
            var f = this;
            d = u(Array, "from").call(Array, d, function(g) {
                return f.resolve(g).then(b, c)
            });
            return f.all(d)
        }
    }, "es_2020");
    /*

     Copyright Google LLC
     SPDX-License-Identifier: Apache-2.0
    */
    var qa = q.globalThis.trustedTypes,
        K;

    function ra() {
        var a = null;
        if (!qa) return a;
        try {
            var b = function(c) {
                return c
            };
            a = qa.createPolicy("goog#html", {
                createHTML: b,
                createScript: b,
                createScriptURL: b
            })
        } catch (c) {}
        return a
    };

    function L(a) {
        this.g = a
    }
    L.prototype.toString = function() {
        return this.g + ""
    };

    function M(a) {
        var b;
        K === void 0 && (K = ra());
        a = (b = K) ? b.createScriptURL(a) : a;
        return new L(a)
    }

    function sa(a) {
        if (a instanceof L) return a.g;
        throw Error("");
    };

    function N(a) {
        var b = oa.apply(1, arguments);
        if (b.length === 0) return M(a[0]);
        for (var c = a[0], d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return M(c)
    };
    var ta = C(["https://www.google.com/recaptcha/api2/aframe"]),
        ua = N(ta);

    function va(a, b) {
        a.src = sa(b);
        var c;
        b = a.ownerDocument;
        b = b === void 0 ? document : b;
        var d;
        b = (d = (c = b).querySelector) == null ? void 0 : d.call(c, "script[nonce]");
        (c = b == null ? "" : b.nonce || b.getAttribute("nonce") || "") && a.setAttribute("nonce", c)
    };

    function O(a, b, c) {
        typeof a.addEventListener === "function" && a.addEventListener(b, c, !1)
    };

    function wa(a, b) {
        var c = !1;
        c = c === void 0 ? !1 : c;
        return new q.Promise(function(d, f) {
            function g() {
                e.onload = null;
                e.onerror = null;
                var h;
                (h = e.parentElement) == null || h.removeChild(e)
            }
            var e = b.document.createElement("script");
            e.onload = function() {
                g();
                d()
            };
            e.onerror = function() {
                g();
                f(7)
            };
            e.type = "text/javascript";
            va(e, a);
            c && b.document.readyState !== "complete" ? O(b, "load", function() {
                b.document.body.appendChild(e)
            }) : b.document.body.appendChild(e)
        })
    }

    function xa(a, b) {
        var c = window;
        return new q.Promise(function(d) {
            b === void 0 && (b = c.document.createElement("iframe"));
            b.addEventListener("load", function() {
                d(b)
            });
            b.src = sa(a).toString();
            b.width = "0";
            b.height = "0";
            b.style.display = "none";
            c.document.body.appendChild(b)
        })
    };

    function ya(a) {
        return new q.Promise(function(b) {
            setTimeout(function() {
                return void b(void 0)
            }, a)
        })
    }

    function za(a) {
        a = a === void 0 ? document : a;
        return a.createElement("img")
    };
    var Aa = C(["https://ep1.adtrafficquality.google/bg/", ".js"]),
        Ba = C(["https://pagead2.googlesyndication.com/bg/", ".js"]);

    function P(a, b, c, d) {
        var f = window;
        f = f === void 0 ? window : f;
        this.U = b;
        this.h = f;
        this.o = c === void 0 ? 0 : c;
        this.i = (d === void 0 ? 0 : d) ? N(Aa, encodeURIComponent(a)) : N(Ba, encodeURIComponent(a))
    }

    function Ca(a) {
        return J(function(b) {
            switch (b.g) {
                case 1:
                    return b.h(Da(a), 2);
                case 2:
                    return b.h(Ea(a), 3);
                case 3:
                    if (!(a.o > 0)) {
                        b.v(4);
                        break
                    }
                    return b.h(ya(a.o), 4);
                case 4:
                    return b.return(Fa(a))
            }
        })
    }

    function Da(a) {
        var b;
        return J(function(c) {
            b = document.createElement("iframe");
            b.style.display = "none";
            document.body.appendChild(b);
            if (!b.contentWindow) throw 3;
            a.h = b.contentWindow;
            return c.return(wa(a.i, a.h))
        })
    }

    function Ea(a) {
        return new q.Promise(function(b, c) {
            a.h.botguard && a.h.botguard.bg ? a.g = new a.h.botguard.bg(a.U, b) : c(5)
        })
    }
    P.prototype.snapshotSync = function() {
        var a = void 0;
        if (this.g && this.g.invoke && (this.g.invoke(function(b) {
                a = b
            }, !1), a)) return a;
        throw 6;
    };

    function Fa(a) {
        return new q.Promise(function(b, c) {
            a.g && a.g.invoke ? a.g.invoke(function(d) {
                b(d)
            }, !0) : c(6)
        })
    };

    function T(a) {
        return a === void 0 || a === "0" ? !1 : !0
    }

    function Ga() {
        var a = window.GoogleGcLKhOms;
        if (a && a.length > 0 && (a = a.shift())) {
            a: {
                var b = a._ctx_;
                switch (b) {
                    case "pt":
                    case "cr":
                        break a;
                    default:
                        b = ""
                }
            }
            a: {
                var c = a._st_;
                switch (c) {
                    case "env":
                    case "int":
                        break a;
                    default:
                        c = "env"
                }
            }
            b = {
                context: b,
                L: a._bgv_,
                K: a._bgp_,
                T: a._li_,
                N: a._jk_,
                O: c,
                o: a._dl_,
                R: a._g2_,
                l: T(a._atqg_),
                Z: T(a._sic_)
            };a._rc_ !== void 0 && (b = u(Object, "assign").call(Object, {}, b, {
                S: a._rc_
            }));a._wvp_ !== void 0 && (b = u(Object, "assign").call(Object, {}, b, {
                D: T(a._wvp_)
            }));
            return b
        }
    }

    function Ha() {
        var a = window;
        if (a.GoogleDX5YKUSk) return a.GoogleDX5YKUSk[0];
        var b = new q.Promise(function(c) {
            a.GoogleDX5YKUSk = [b, c]
        });
        return b
    }

    function Ia() {
        return window.GoogleGcLKhOms === void 0 ? 13 : 1
    };

    function U(a, b) {
        this.h = a;
        this.l = b
    }

    function Ja(a, b) {
        U.call(this, a, b);
        var c = this;
        this.g = !1;
        var d = new MessageChannel;
        this.port = d.port1;
        this.i = new q.Promise(function(f) {
            c.port.onmessage = function() {
                f()
            };
            var g = b ? "https://ep2.adtrafficquality.google" : "https://tpc.googlesyndication.com";
            c.h.postMessage("GoogleBasRYoCJlVEB", g.indexOf("https:") === -1 ? "http:" + g : g, [d.port2])
        })
    }
    A(Ja, U);

    function Ka(a, b) {
        return J(function(c) {
            return c.g == 1 ? c.h(a.i, 2) : c.return(new q.Promise(function(d, f) {
                var g = new MessageChannel;
                g.port1.onmessage = function(e) {
                    g.port1.close();
                    Array.isArray(e.data) ? d(e.data) : f(9)
                };
                a.port.postMessage(b, [g.port2])
            }))
        })
    }

    function La(a, b) {
        var c;
        return J(function(d) {
            if (d.g == 1) return d.C(2), d.h(Ka(a, [1, b.fa, b.U, b.o]), 4);
            if (d.g != 2) return c = d.j, d.return({
                response: c[0],
                error: c[1]
            });
            d.F();
            return d.return({
                error: 9
            })
        })
    }

    function Ma() {
        U.apply(this, arguments);
        this.g = !0
    }
    A(Ma, U);
    /*

     Copyright The Closure Library Authors.
     SPDX-License-Identifier: Apache-2.0
    */
    function Na(a, b) {
        Oa(a, b === void 0 ? null : b)
    }

    function Oa(a, b) {
        var c = window,
            d = !1;
        d = d === void 0 ? !1 : d;
        c.google_image_requests || (c.google_image_requests = []);
        var f = za(c.document);
        if (b) {
            var g = function(e) {
                b && b(e);
                typeof f.removeEventListener === "function" && f.removeEventListener("load", g, !1);
                typeof f.removeEventListener === "function" && f.removeEventListener("error", g, !1)
            };
            O(f, "load", g);
            O(f, "error", g)
        }
        d && (f.attributionSrc = "");
        f.src = a;
        c.google_image_requests.push(f)
    };

    function Pa(a) {
        this.url = (this.l = a) ? "https://ep1.adtrafficquality.google/pagead/gen_204?id=sodar2&v=254" : "https://pagead2.googlesyndication.com/pagead/gen_204?id=sodar2&v=254"
    }

    function V(a, b, c) {
        a.url += "&" + b + "=" + encodeURIComponent(c.toString())
    }

    function Qa(a, b, c) {
        var d = new Pa(b === void 0 ? !1 : b.l),
            f = b === void 0 || b.R !== "0";
        c !== !1 && f || (d.url = d.l ? "https://ep1.adtrafficquality.google/pagead/sodar?id=sodar2&v=254" : "https://pagead2.googlesyndication.com/pagead/sodar?id=sodar2&v=254");
        V(d, "t", a);
        b && (V(d, "li", b.T), V(d, b.context === "cr" && b.O === "int" ? "bgai" : "jk", b.N));
        return d
    }

    function Ra(a) {
        return new q.Promise(function(b) {
            Na(a, function() {
                b()
            })
        })
    }

    function W(a, b, c, d) {
        b = Qa(1, b);
        V(b, "e", a);
        c && V(b, "ds", c);
        d !== void 0 && V(b, "lat", String(d));
        return Ra(b.url)
    }

    function Sa(a, b, c, d) {
        var f = Qa(2, a, b !== void 0);
        b !== void 0 ? V(f, "bg", b) : c !== void 0 && V(f, "wvpt", c);
        d !== void 0 && V(f, "lat", String(d));
        return f.url.length > 6E4 ? W(4, a) : Ra(f.url)
    };
    var X = {},
        Ta = (X["internal-error"] = -1, X["non-recoverable-error"] = -2, X["api-disabled-by-application"] = -3, X["invalid-argument"] = -4, X["token-provider-invalid"] = -5, X);

    function Ua() {
        this.D = !1
    }
    var Va;

    function Y() {
        Va || (Va = new Ua);
        return Va
    }

    function Wa(a) {
        var b;
        return J(function(c) {
            if (c.g == 1) return c.C(2), c.h(window.android.webview.getExperimentalMediaIntegrityTokenProvider({
                cloudProjectNumber: 187810013193
            }), 4);
            if (c.g != 2) return a.h = c.j, a.g = void 0, c.J(0);
            b = c.F();
            a.g = Xa(b);
            c.I()
        })
    }

    function Ya(a, b) {
        var c, d;
        return J(function(f) {
            switch (f.g) {
                case 1:
                    return Za() && a.D ? f.h(a.i, 2) : f.return();
                case 2:
                    if (!a.h) return a.g === void 0 && (a.g = 100), f.return();
                    c = {};
                    f.C(3);
                    return f.h(a.h.requestToken(b), 5);
                case 5:
                    c.Y = f.j;
                    f.J(4);
                    break;
                case 3:
                    d = f.F(), c.X = Xa(d);
                case 4:
                    return f.return(c)
            }
        })
    }

    function Xa(a) {
        var b = 0;
        a.mediaIntegrityErrorName ? b || (b = Ta[a.mediaIntegrityErrorName]) : a.code && (b = a.code());
        return b
    }

    function Za() {
        return window.android && window.android.webview && window.android.webview.getExperimentalMediaIntegrityTokenProvider
    };

    function $a() {
        var a = this;
        this.promise = new q.Promise(function(b, c) {
            a.resolve = b;
            a.reject = c
        })
    };

    function Z(a) {
        this.config = a;
        this.o = 0;
        this.l = !1;
        this.o = Number(this.config.o) || 0;
        this.l = a.l
    }

    function ab(a) {
        return J(function(b) {
            if (b.g == 1) {
                if (bb(a)) throw 7;
                a.g = new P(a.config.L, a.config.K, a.o, a.l);
                return b.h(Da(a.g), 2)
            }
            return b.h(Ea(a.g), 0)
        })
    }
    Z.prototype.snapshotSync = function() {
        if (this.g) return this.g.snapshotSync()
    };

    function cb(a) {
        return J(function(b) {
            if (b.g == 1) {
                var c = b.h;
                if (bb(a)) var d = db(a);
                else a.g = new P(a.config.L, a.config.K, a.o, a.config.l), d = Ca(a.g);
                return c.call(b, d, 2)
            }
            a.j = b.j;
            return a.j ? b.h(Sa(a.config, a.j), 0) : b.v(0)
        })
    }

    function eb(a) {
        var b, c, d;
        return J(function(f) {
            switch (f.g) {
                case 1:
                    if (!Y().D) return f.return();
                    b = Date.now();
                    return f.h(Ya(Y(), a.config.N), 2);
                case 2:
                    if (c = f.j) {
                        f.v(3);
                        break
                    }
                    Y();
                    if (Za() === void 0) {
                        f.v(4);
                        break
                    }
                    return f.h(W(17, a.config, "ftpe=" + String(Y().g)), 4);
                case 4:
                    return f.return();
                case 3:
                    return d = Date.now() - b, c.Y ? f.h(Sa(a.config, void 0, c.Y, d), 0) : c.X ? f.h(W(16, a.config, "ftpe=" + String(Y().g) + ",ptb=" + String(c.X), d), 0) : f.h(W(18, a.config, "ftpe=" + String(Y().g), d), 0)
            }
        })
    }

    function fb(a, b) {
        function c(g) {
            g && g.data !== null && g.origin === "https://www.google.com" && g.source != null && g.source === b.contentWindow && (a.h = "id=sodar2&v=254", a.config && (a.h += "&li=" + encodeURIComponent(a.config.T.toString()), a.h += "&" + (a.config.context === "cr" ? "bgai" : "jk") + "=" + encodeURIComponent(a.config.N.toString()), g.source.postMessage(JSON.stringify({
                id: "sodar",
                params: a.h
            }), "https://www.google.com"), d.removeEventListener("message", c, !1)), f.resolve())
        }
        var d = window,
            f = new $a;
        d.addEventListener("message",
            c, !1);
        return f.promise
    }

    function gb(a) {
        var b, c, d, f;
        return J(function(g) {
            if (g.g == 1) {
                if (a.config.S !== "y") return g.return();
                b = window.document.createElement("iframe");
                c = xa(ua, b);
                d = fb(a, b);
                return g.h(q.Promise.all([c, d]), 2)
            }
            f = g.j;
            if (f[0].contentWindow === null) throw 15;
            g.I()
        })
    }

    function hb(a) {
        return J(function(b) {
            return b.h(u(q.Promise, "allSettled").call(q.Promise, [cb(a), gb(a), eb(a)]), 0)
        })
    }

    function bb(a) {
        return a.config.Z || window.location.host === (a.l ? "ep2.adtrafficquality.google" : "tpc.googlesyndication.com") || a.config.O === "int" ? !1 : !0
    }

    function db(a) {
        var b, c, d;
        return J(function(f) {
            if (f.g == 1) return b = M((a.l ? "https://ep2.adtrafficquality.google/sodar/" : "https://tpc.googlesyndication.com/sodar/") + "sodar2/254/runner.html"), f.h(xa(b), 2);
            if (f.g != 4) {
                c = f.j;
                if (!c.contentWindow) throw 3;
                var g = c.contentWindow;
                var e = a.l;
                g = window.hasOwnProperty("MessageChannel") ? new Ja(g, e) : new Ma(g, e);
                a.i = g;
                return a.i.g ? (g = a.config, e = g.l ? "https://ep2.adtrafficquality.google" : "https://tpc.googlesyndication.com", e = e.indexOf("https:") === -1 ? "http:" + e : e, a.i.h.postMessage(JSON.stringify([g.context,
                    g.L, g.K, g.T, g.N, g.O, g.S === void 0 ? "n" : g.S, g.o === void 0 ? "0" : g.o, g.R === void 0 ? "1" : g.R, g.l === void 0 ? "0" : g.l ? "1" : "0", g.Z ? "1" : "0"
                ]), e), f.return(void 0)) : f.h(La(a.i, {
                    fa: a.config.L,
                    U: a.config.K,
                    o: a.o,
                    l: a.config.l
                }), 4)
            }
            d = f.j;
            c.parentNode && c.parentNode.removeChild(c);
            if (d.error) throw d.error;
            return f.return(d.response)
        })
    };

    function ib() {
        Z.apply(this, arguments)
    }
    A(ib, Z);
    ib.prototype.init = function() {
        var a = this,
            b;
        return J(function(c) {
            if (c.g == 1) {
                if (a.config.O === "env") return c.h(hb(a), 0);
                b = window;
                return b.GoogleA13IjpGc ? c.return() : c.h(ab(a), 4)
            }
            b.GoogleA13IjpGc = a;
            return c.v(0)
        })
    };

    function jb() {
        Z.apply(this, arguments)
    }
    A(jb, Z);
    jb.prototype.init = function() {
        var a = this;
        return J(function(b) {
            return b.h(hb(a), 0)
        })
    };

    function kb(a, b) {
        if (typeof a === "number") b = W(a, b);
        else {
            var c = Qa(3, b);
            V(c, "c", "init");
            var d = a.toString();
            a.name && d.indexOf(a.name) == -1 && (d += ": " + a.name);
            a.message && d.indexOf(a.message) == -1 && (d += ": " + a.message);
            if (a.stack) a: {
                a = a.stack;
                var f = d;
                try {
                    a.indexOf(f) == -1 && (a = f + "\n" + a);
                    for (var g; a != g;) g = a, a = a.replace(RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"), "$1");
                    d = a.replace(RegExp("\n *", "g"), "\n");
                    break a
                } catch (e) {
                    d = f;
                    break a
                }
                d = void 0
            }
            V(c, "ex", d);
            b = c.url.length > 6E4 ? W(11, b) : Ra(c.url)
        }
        return b
    }

    function lb(a) {
        if (a.D === !0) {
            Y().D = !0;
            var b = Y();
            Za() && b.D && (b.i = Wa(b))
        }
        switch (a.context) {
            case "pt":
                a = new jb(a);
                break;
            case "cr":
                a = new ib(a);
                break;
            default:
                throw 2;
        }
        if (!window.postMessage && bb(a)) throw 8;
        return a.init()
    };
    (function() {
        var a = Ga();
        try {
            return a ? lb(a) : q.Promise.race([Ha(), new q.Promise(function(b, c) {
                setTimeout(function() {
                    c(Ia())
                }, 5E3)
            })]).then(function() {
                a = Ga();
                if (!a) throw Ia();
                return lb(a)
            }, function(b) {
                return kb(b, a)
            })
        } catch (b) {
            return kb(b, a)
        }
    })();
}).call(this);