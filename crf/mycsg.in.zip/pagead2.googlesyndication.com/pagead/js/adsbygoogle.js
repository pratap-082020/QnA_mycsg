(function(sttc) {
    'use strict';
    var aa = Object.defineProperty,
        ba = globalThis,
        ca = typeof Symbol === "function" && typeof Symbol("x") === "symbol",
        da = {},
        ea = {};

    function fa(a, b, c) {
        if (!c || a != null) {
            c = ea[b];
            if (c == null) return a[b];
            c = a[c];
            return c !== void 0 ? c : a[b]
        }
    }

    function ha(a, b, c) {
        if (b) a: {
            var d = a.split(".");a = d.length === 1;
            var e = d[0],
                f;!a && e in da ? f = da : f = ba;
            for (e = 0; e < d.length - 1; e++) {
                var g = d[e];
                if (!(g in f)) break a;
                f = f[g]
            }
            d = d[d.length - 1];c = ca && c === "es6" ? f[d] : null;b = b(c);b != null && (a ? aa(da, d, {
                configurable: !0,
                writable: !0,
                value: b
            }) : b !== c && (ea[d] === void 0 && (a = Math.random() * 1E9 >>> 0, ea[d] = ca ? ba.Symbol(d) : "$jscp$" + a + "$" + d), aa(f, ea[d], {
                configurable: !0,
                writable: !0,
                value: b
            })))
        }
    }
    ha("Symbol.dispose", function(a) {
        return a ? a : Symbol("Symbol.dispose")
    }, "es_next");
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    var q = this || self;

    function ia(a, b) {
        var c = ja("CLOSURE_FLAGS");
        a = c && c[a];
        return a != null ? a : b
    }

    function ja(a) {
        a = a.split(".");
        for (var b = q, c = 0; c < a.length; c++)
            if (b = b[a[c]], b == null) return null;
        return b
    }

    function ka(a) {
        var b = typeof a;
        return b != "object" ? b : a ? Array.isArray(a) ? "array" : b : "null"
    }

    function la(a) {
        var b = typeof a;
        return b == "object" && a != null || b == "function"
    }

    function ma(a) {
        return Object.prototype.hasOwnProperty.call(a, na) && a[na] || (a[na] = ++oa)
    }
    var na = "closure_uid_" + (Math.random() * 1E9 >>> 0),
        oa = 0;

    function pa(a, b, c) {
        return a.call.apply(a.bind, arguments)
    }

    function qa(a, b, c) {
        if (!a) throw Error();
        if (arguments.length > 2) {
            var d = Array.prototype.slice.call(arguments, 2);
            return function() {
                var e = Array.prototype.slice.call(arguments);
                Array.prototype.unshift.apply(e, d);
                return a.apply(b, e)
            }
        }
        return function() {
            return a.apply(b, arguments)
        }
    }

    function ra(a, b, c) {
        ra = Function.prototype.bind && Function.prototype.bind.toString().indexOf("native code") != -1 ? pa : qa;
        return ra.apply(null, arguments)
    }

    function sa(a, b, c) {
        a = a.split(".");
        c = c || q;
        for (var d; a.length && (d = a.shift());) a.length || b === void 0 ? c[d] && c[d] !== Object.prototype[d] ? c = c[d] : c = c[d] = {} : c[d] = b
    };

    function ta(a) {
        q.setTimeout(() => {
            throw a;
        }, 0)
    };

    function ua(a) {
        return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
    }

    function va(a, b) {
        var c = 0;
        a = ua(String(a)).split(".");
        b = ua(String(b)).split(".");
        var d = Math.max(a.length, b.length);
        for (let g = 0; c == 0 && g < d; g++) {
            var e = a[g] || "",
                f = b[g] || "";
            do {
                e = /(\d*)(\D*)(.*)/.exec(e) || ["", "", "", ""];
                f = /(\d*)(\D*)(.*)/.exec(f) || ["", "", "", ""];
                if (e[0].length == 0 && f[0].length == 0) break;
                c = wa(e[1].length == 0 ? 0 : parseInt(e[1], 10), f[1].length == 0 ? 0 : parseInt(f[1], 10)) || wa(e[2].length == 0, f[2].length == 0) || wa(e[2], f[2]);
                e = e[3];
                f = f[3]
            } while (c == 0)
        }
        return c
    }

    function wa(a, b) {
        return a < b ? -1 : a > b ? 1 : 0
    };
    var xa = ia(610401301, !1),
        za = ia(748402147, !0);

    function Aa() {
        var a = q.navigator;
        return a && (a = a.userAgent) ? a : ""
    }
    var Ca;
    const Da = q.navigator;
    Ca = Da ? Da.userAgentData || null : null;

    function Ea(a) {
        if (!xa || !Ca) return !1;
        for (let b = 0; b < Ca.brands.length; b++) {
            let {
                brand: c
            } = Ca.brands[b];
            if (c && c.indexOf(a) != -1) return !0
        }
        return !1
    }

    function r(a) {
        return Aa().indexOf(a) != -1
    };

    function Fa() {
        return xa ? !!Ca && Ca.brands.length > 0 : !1
    }

    function Ga() {
        return Fa() ? !1 : r("Trident") || r("MSIE")
    }

    function Ha() {
        return Fa() ? Ea("Chromium") : (r("Chrome") || r("CriOS")) && !(Fa() ? 0 : r("Edge")) || r("Silk")
    }

    function Ia(a) {
        var b = {};
        a.forEach(c => {
            b[c[0]] = c[1]
        });
        return c => b[c.find(d => d in b)] || ""
    }

    function Ja() {
        var a = Aa();
        if (Ga()) {
            var b = /rv: *([\d\.]*)/.exec(a);
            if (b && b[1]) a = b[1];
            else {
                b = "";
                var c = /MSIE +([\d\.]+)/.exec(a);
                if (c && c[1])
                    if (a = /Trident\/(\d.\d)/.exec(a), c[1] == "7.0")
                        if (a && a[1]) switch (a[1]) {
                            case "4.0":
                                b = "8.0";
                                break;
                            case "5.0":
                                b = "9.0";
                                break;
                            case "6.0":
                                b = "10.0";
                                break;
                            case "7.0":
                                b = "11.0"
                        } else b = "7.0";
                        else b = c[1];
                a = b
            }
            return a
        }
        c = RegExp("([A-Z][\\w ]+)/([^\\s]+)\\s*(?:\\((.*?)\\))?", "g");
        b = [];
        for (var d; d = c.exec(a);) b.push([d[1], d[2], d[3] || void 0]);
        a = Ia(b);
        return (Fa() ? 0 : r("Opera")) ? a(["Version",
            "Opera"
        ]) : (Fa() ? 0 : r("Edge")) ? a(["Edge"]) : (Fa() ? Ea("Microsoft Edge") : r("Edg/")) ? a(["Edg"]) : r("Silk") ? a(["Silk"]) : Ha() ? a(["Chrome", "CriOS", "HeadlessChrome"]) : (a = b[2]) && a[1] || ""
    };

    function Ka(a, b) {
        if (typeof a === "string") return typeof b !== "string" || b.length != 1 ? -1 : a.indexOf(b, 0);
        for (let c = 0; c < a.length; c++)
            if (c in a && a[c] === b) return c;
        return -1
    }

    function La(a, b) {
        var c = a.length,
            d = [],
            e = 0,
            f = typeof a === "string" ? a.split("") : a;
        for (let g = 0; g < c; g++)
            if (g in f) {
                let h = f[g];
                b.call(void 0, h, g, a) && (d[e++] = h)
            }
        return d
    }

    function Ma(a, b) {
        var c = a.length,
            d = Array(c),
            e = typeof a === "string" ? a.split("") : a;
        for (let f = 0; f < c; f++) f in e && (d[f] = b.call(void 0, e[f], f, a));
        return d
    }

    function Na(a, b) {
        var c = a.length,
            d = typeof a === "string" ? a.split("") : a;
        for (let e = 0; e < c; e++)
            if (e in d && b.call(void 0, d[e], e, a)) return !0;
        return !1
    }

    function Oa(a, b) {
        a: {
            var c = a.length;
            let d = typeof a === "string" ? a.split("") : a;
            for (--c; c >= 0; c--)
                if (c in d && b.call(void 0, d[c], c, a)) {
                    b = c;
                    break a
                }
            b = -1
        }
        return b < 0 ? null : typeof a === "string" ? a.charAt(b) : a[b]
    }

    function Pa(a, b) {
        return Ka(a, b) >= 0
    }

    function Qa(a) {
        var b = a.length;
        if (b > 0) {
            let c = Array(b);
            for (let d = 0; d < b; d++) c[d] = a[d];
            return c
        }
        return []
    };

    function Sa(a) {
        Sa[" "](a);
        return a
    }
    Sa[" "] = function() {};
    let Ta = null;

    function Ua(a) {
        var b = [];
        Va(a, function(c) {
            b.push(c)
        });
        return b
    }

    function Va(a, b) {
        function c(e) {
            for (; d < a.length;) {
                let f = a.charAt(d++),
                    g = Ta[f];
                if (g != null) return g;
                if (!/^[\s\xa0]*$/.test(f)) throw Error("Unknown base64 encoding at char: " + f);
            }
            return e
        }
        Wa();
        for (var d = 0;;) {
            let e = c(-1),
                f = c(0),
                g = c(64),
                h = c(64);
            if (h === 64 && e === -1) break;
            b(e << 2 | f >> 4);
            g != 64 && (b(f << 4 & 240 | g >> 2), h != 64 && b(g << 6 & 192 | h))
        }
    }

    function Wa() {
        if (!Ta) {
            Ta = {};
            var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""),
                b = ["+/=", "+/", "-_=", "-_.", "-_"];
            for (let c = 0; c < 5; c++) {
                let d = a.concat(b[c].split(""));
                for (let e = 0; e < d.length; e++) {
                    let f = d[e];
                    Ta[f] === void 0 && (Ta[f] = e)
                }
            }
        }
    };

    function Xa(a, b) {
        a.__closure__error__context__984382 || (a.__closure__error__context__984382 = {});
        a.__closure__error__context__984382.severity = b
    };
    let Ya = void 0,
        Za;

    function $a(a) {
        if (Za) throw Error("");
        Za = b => {
            q.setTimeout(() => {
                a(b)
            }, 0)
        }
    }

    function ab(a) {
        if (Za) try {
            Za(a)
        } catch (b) {
            throw b.cause = a, b;
        }
    }

    function bb(a) {
        a = Error(a);
        Xa(a, "warning");
        ab(a);
        return a
    };

    function cb(a, b = !1) {
        return b && Symbol.for && a ? Symbol.for(a) : a != null ? Symbol(a) : Symbol()
    }
    var db = cb(),
        eb = cb(),
        fb = cb(),
        gb = cb("m_m", !0);
    const u = cb("jas", !0);
    var hb;
    const ib = [];
    ib[u] = 7;
    hb = Object.freeze(ib);

    function jb(a) {
        if (4 & a) return 512 & a ? 512 : 1024 & a ? 1024 : 0
    }

    function kb(a) {
        a[u] |= 32;
        return a
    };
    var lb = {};

    function mb(a, b) {
        return b === void 0 ? a.i !== nb && !!(2 & (a.C[u] | 0)) : !!(2 & b) && a.i !== nb
    }
    const nb = {};
    var pb = Object.freeze({}),
        qb = Object.freeze({});

    function rb(a) {
        a.Gc = !0;
        return a
    };
    var sb = rb(a => typeof a === "number"),
        w = rb(a => typeof a === "string"),
        tb = rb(a => typeof a === "boolean"),
        ub = rb(a => typeof a === "function"),
        vb = rb(a => Array.isArray(a));

    function wb() {
        return rb(a => vb(a) ? a.every(b => sb(b)) : !1)
    };

    function xb(a) {
        if (w(a)) {
            if (!/^\s*(?:-?[1-9]\d*|0)?\s*$/.test(a)) throw Error(String(a));
        } else if (sb(a) && !Number.isSafeInteger(a)) throw Error(String(a));
        return BigInt(a)
    }
    var Ab = rb(a => a >= yb && a <= zb);
    const yb = BigInt(Number.MIN_SAFE_INTEGER),
        zb = BigInt(Number.MAX_SAFE_INTEGER);
    let Bb = 0,
        Cb = 0;

    function Db(a) {
        var b = a >>> 0;
        Bb = b;
        Cb = (a - b) / 4294967296 >>> 0
    }

    function Eb(a) {
        if (a < 0) {
            Db(-a);
            a = Bb;
            var b = Cb;
            b = ~b;
            a ? a = ~a + 1 : b += 1;
            let [c, d] = [a, b];
            Bb = c >>> 0;
            Cb = d >>> 0
        } else Db(a)
    }

    function Fb(a, b) {
        b >>>= 0;
        a >>>= 0;
        var c;
        b <= 2097151 ? c = "" + (4294967296 * b + a) : c = "" + (BigInt(b) << BigInt(32) | BigInt(a));
        return c
    }

    function Gb() {
        var a = Bb,
            b = Cb,
            c;
        b & 2147483648 ? c = "" + (BigInt(b | 0) << BigInt(32) | BigInt(a >>> 0)) : c = Fb(a, b);
        return c
    };

    function Hb(a, b = `unexpected value ${a}!`) {
        throw Error(b);
    };
    const Jb = typeof BigInt === "function" ? BigInt.asIntN : void 0,
        Kb = Number.isSafeInteger,
        Lb = Number.isFinite,
        Mb = Math.trunc;

    function Nb(a) {
        if (a == null || typeof a === "number") return a;
        if (a === "NaN" || a === "Infinity" || a === "-Infinity") return Number(a)
    }

    function Ob(a) {
        if (a != null && typeof a !== "boolean") throw Error(`Expected boolean but got ${ka(a)}: ${a}`);
        return a
    }
    const Pb = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;

    function Qb(a) {
        switch (typeof a) {
            case "bigint":
                return !0;
            case "number":
                return Lb(a);
            case "string":
                return Pb.test(a);
            default:
                return !1
        }
    }

    function Rb(a) {
        if (!Lb(a)) throw bb("enum");
        return a | 0
    }

    function Sb(a) {
        return a == null ? a : Lb(a) ? a | 0 : void 0
    }

    function Tb(a) {
        if (typeof a !== "number") throw bb("int32");
        if (!Lb(a)) throw bb("int32");
        return a | 0
    }

    function Ub(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return Lb(a) ? a | 0 : void 0
    }

    function Vb(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return Lb(a) ? a >>> 0 : void 0
    }

    function Wb(a) {
        if (!Qb(a)) throw bb("int64");
        switch (typeof a) {
            case "string":
                return Xb(a);
            case "bigint":
                return xb(Jb(64, a));
            default:
                return Yb(a)
        }
    }

    function Zb(a) {
        a = Mb(a);
        if (!Kb(a)) {
            Eb(a);
            var b = Bb,
                c = Cb;
            if (a = c & 2147483648) b = ~b + 1 >>> 0, c = ~c >>> 0, b == 0 && (c = c + 1 >>> 0);
            let d = c * 4294967296 + (b >>> 0);
            b = Number.isSafeInteger(d) ? d : Fb(b, c);
            a = typeof b === "number" ? a ? -b : b : a ? "-" + b : b
        }
        return a
    }

    function Xb(a) {
        var b = Mb(Number(a));
        if (Kb(b)) return xb(b);
        b = a.indexOf(".");
        b !== -1 && (a = a.substring(0, b));
        return xb(Jb(64, BigInt(a)))
    }

    function Yb(a) {
        Kb(a) ? a = xb(Zb(a)) : (a = Mb(a), Kb(a) ? a = String(a) : (Eb(a), a = Gb()), a = xb(a));
        return a
    }

    function $b(a) {
        var b = typeof a;
        if (a == null) return a;
        if (b === "bigint") return xb(Jb(64, a));
        if (Qb(a)) return b === "string" ? Xb(a) : Yb(a)
    }

    function ac(a) {
        if (typeof a !== "string") throw Error();
        return a
    }

    function bc(a) {
        if (a != null && typeof a !== "string") throw Error();
        return a
    }

    function x(a) {
        return a == null || typeof a === "string" ? a : void 0
    }

    function cc(a, b, c, d) {
        if (a != null && a[gb] === lb) return a;
        if (!Array.isArray(a)) return c ? d & 2 ? b[db] || (b[db] = dc(b)) : new b : void 0;
        c = a[u] | 0;
        d = c | d & 32 | d & 2;
        d !== c && (a[u] = d);
        return new b(a)
    }

    function dc(a) {
        a = new a;
        var b = a.C;
        b[u] |= 34;
        return a
    };

    function ec(a) {
        return a
    };

    function fc(a, b, c, d) {
        var e = d !== void 0;
        d = !!d;
        var f = [],
            g = a.length,
            h = 4294967295,
            k = !1,
            p = !!(b & 64),
            n = p ? b & 128 ? 0 : -1 : void 0;
        if (!(b & 1)) {
            var m = g && a[g - 1];
            m != null && typeof m === "object" && m.constructor === Object ? (g--, h = g) : m = void 0;
            !p || b & 128 || e || (k = !0, h = (hc ? ? ec)(h - n, n, a, m, void 0) + n)
        }
        b = void 0;
        for (e = 0; e < g; e++) {
            let l = a[e];
            if (l != null && (l = c(l, d)) != null)
                if (p && e >= h) {
                    let t = e - n;
                    (b ? ? (b = {}))[t] = l
                } else f[e] = l
        }
        if (m)
            for (let l in m) {
                if (!Object.prototype.hasOwnProperty.call(m, l)) continue;
                a = m[l];
                if (a == null || (a = c(a, d)) == null) continue;
                g = +l;
                let t;
                p && !Number.isNaN(g) && (t = g + n) < h ? f[t] = a : (b ? ? (b = {}))[l] = a
            }
        b && (k ? f.push(b) : f[h] = b);
        return f
    }

    function ic(a) {
        switch (typeof a) {
            case "number":
                return Number.isFinite(a) ? a : "" + a;
            case "bigint":
                return Ab(a) ? Number(a) : "" + a;
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (Array.isArray(a)) {
                    let b = a[u] | 0;
                    return a.length === 0 && b & 1 ? void 0 : fc(a, b, ic)
                }
                if (a != null && a[gb] === lb) return y(a);
                return
        }
        return a
    }
    var jc = typeof structuredClone != "undefined" ? structuredClone : a => fc(a, 0, ic);
    let hc;

    function y(a) {
        a = a.C;
        return fc(a, a[u] | 0, ic)
    };

    function kc(a, b, c, d = 0) {
        if (a == null) {
            var e = 32;
            c ? (a = [c], e |= 128) : a = [];
            b && (e = e & -16760833 | (b & 1023) << 14)
        } else {
            if (!Array.isArray(a)) throw Error("narr");
            e = a[u] | 0;
            if (za && 1 & e) throw Error("rfarr");
            2048 & e && !(2 & e) && lc();
            if (e & 256) throw Error("farr");
            if (e & 64) return (e | d) !== e && (a[u] = e | d), a;
            if (c && (e |= 128, c !== a[0])) throw Error("mid");
            a: {
                c = a;e |= 64;
                var f = c.length;
                if (f) {
                    var g = f - 1;
                    let k = c[g];
                    if (k != null && typeof k === "object" && k.constructor === Object) {
                        b = e & 128 ? 0 : -1;
                        g -= b;
                        if (g >= 1024) throw Error("pvtlmt");
                        for (var h in k) {
                            if (!Object.prototype.hasOwnProperty.call(k,
                                    h)) continue;
                            f = +h;
                            if (f < g) c[f + b] = k[h], delete k[h];
                            else break
                        }
                        e = e & -16760833 | (g & 1023) << 14;
                        break a
                    }
                }
                if (b) {
                    h = Math.max(b, f - (e & 128 ? 0 : -1));
                    if (h > 1024) throw Error("spvt");
                    e = e & -16760833 | (h & 1023) << 14
                }
            }
        }
        a[u] = e | 64 | d;
        return a
    }

    function lc() {
        if (za) throw Error("carr");
        if (fb != null) {
            var a = Ya ? ? (Ya = {});
            var b = a[fb] || 0;
            b >= 5 || (a[fb] = b + 1, a = Error(), Xa(a, "incident"), Za ? ab(a) : ta(a))
        }
    };

    function nc(a, b) {
        if (typeof a !== "object") return a;
        if (Array.isArray(a)) {
            var c = a[u] | 0;
            a.length === 0 && c & 1 ? a = void 0 : c & 2 || (!b || 4096 & c || 16 & c ? a = oc(a, c, !1, b && !(c & 16)) : (a[u] |= 34, c & 4 && Object.freeze(a)));
            return a
        }
        if (a != null && a[gb] === lb) return b = a.C, c = b[u] | 0, mb(a, c) ? a : pc(a, b, c) ? qc(a, b) : oc(b, c)
    }

    function qc(a, b, c) {
        a = new a.constructor(b);
        c && (a.i = nb);
        a.B = nb;
        return a
    }

    function oc(a, b, c, d) {
        d ? ? (d = !!(34 & b));
        a = fc(a, b, nc, d);
        d = 32;
        c && (d |= 2);
        b = b & 16769217 | d;
        a[u] = b;
        return a
    }

    function rc(a) {
        var b = a.C,
            c = b[u] | 0;
        return mb(a, c) ? pc(a, b, c) ? qc(a, b, !0) : new a.constructor(oc(b, c, !1)) : a
    }

    function sc(a) {
        var b = a.C,
            c = b[u] | 0;
        return mb(a, c) ? a : pc(a, b, c) ? qc(a, b) : new a.constructor(oc(b, c, !0))
    }

    function tc(a) {
        if (a.i !== nb) return !1;
        var b = a.C;
        b = oc(b, b[u] | 0);
        b[u] |= 2048;
        a.C = b;
        a.i = void 0;
        a.B = void 0;
        return !0
    }

    function uc(a) {
        if (!tc(a) && mb(a, a.C[u] | 0)) throw Error();
    }

    function vc(a, b) {
        b === void 0 && (b = a[u] | 0);
        b & 32 && !(b & 4096) && (a[u] = b | 4096)
    }

    function pc(a, b, c) {
        return c & 2 ? !0 : c & 32 && !(c & 4096) ? (b[u] = c | 2, a.i = nb, !0) : !1
    };
    const wc = xb(0),
        xc = {};

    function A(a, b, c, d, e) {
        b = yc(a.C, b, c, e);
        if (b !== null || d && a.B !== nb) return b
    }

    function yc(a, b, c, d) {
        if (b === -1) return null;
        var e = b + (c ? 0 : -1),
            f = a.length - 1;
        if (!(f < 1 + (c ? 0 : -1))) {
            if (e >= f) {
                var g = a[f];
                if (g != null && typeof g === "object" && g.constructor === Object) {
                    c = g[b];
                    var h = !0
                } else if (e === f) c = g;
                else return
            } else c = a[e];
            if (d && c != null) {
                d = d(c);
                if (d == null) return d;
                if (!Object.is(d, c)) return h ? g[b] = d : a[e] = d, d
            }
            return c
        }
    }

    function zc(a, b, c) {
        uc(a);
        var d = a.C;
        B(d, d[u] | 0, b, c);
        return a
    }

    function B(a, b, c, d) {
        var e = c + -1,
            f = a.length - 1;
        if (f >= 0 && e >= f) {
            let g = a[f];
            if (g != null && typeof g === "object" && g.constructor === Object) return g[c] = d, b
        }
        if (e <= f) return a[e] = d, b;
        d !== void 0 && (f = (b ? ? (b = a[u] | 0)) >> 14 & 1023 || 536870912, c >= f ? d != null && (a[f + -1] = {
            [c]: d
        }) : a[e] = d);
        return b
    }

    function Ac(a, b, c) {
        a = a.C;
        return Bc(a, a[u] | 0, b, c) !== void 0
    }

    function C(a) {
        return a === pb ? 2 : 4
    }

    function Cc(a, b, c, d, e) {
        var f = a.C,
            g = f[u] | 0;
        d = mb(a, g) ? 1 : d;
        e = !!e || d === 3;
        d === 2 && tc(a) && (f = a.C, g = f[u] | 0);
        a = Dc(f, b);
        var h = a === hb ? 7 : a[u] | 0,
            k = Ec(h, g);
        var p = 4 & k ? !1 : !0;
        if (p) {
            4 & k && (a = [...a], h = 0, k = Fc(k, g), g = B(f, g, b, a));
            let n = 0,
                m = 0;
            for (; n < a.length; n++) {
                let l = c(a[n]);
                l != null && (a[m++] = l)
            }
            m < n && (a.length = m);
            c = (k | 4) & -513;
            k = c &= -1025;
            k &= -4097
        }
        k !== h && (a[u] = k, 2 & k && Object.freeze(a));
        return a = Gc(a, k, f, g, b, d, p, e)
    }

    function Gc(a, b, c, d, e, f, g, h) {
        var k = b;
        f === 1 || (f !== 4 ? 0 : 2 & b || !(16 & b) && 32 & d) ? Hc(b) || (b |= !a.length || g && !(4096 & b) || 32 & d && !(4096 & b || 16 & b) ? 2 : 256, b !== k && (a[u] = b), Object.freeze(a)) : (f === 2 && Hc(b) && (a = [...a], k = 0, b = Fc(b, d), d = B(c, d, e, a)), Hc(b) || (h || (b |= 16), b !== k && (a[u] = b)));
        2 & b || !(4096 & b || 16 & b) || vc(c, d);
        return a
    }

    function Dc(a, b) {
        a = yc(a, b);
        return Array.isArray(a) ? a : hb
    }

    function Ec(a, b) {
        2 & b && (a |= 2);
        return a | 1
    }

    function Hc(a) {
        return !!(2 & a) && !!(4 & a) || !!(256 & a)
    }

    function Ic(a, b, c, d) {
        uc(a);
        var e = a.C,
            f = e[u] | 0;
        if (c == null) return B(e, f, b), a;
        var g = c === hb ? 7 : c[u] | 0,
            h = g,
            k = Hc(g),
            p = k || Object.isFrozen(c);
        k || (g = 0);
        p || (c = [...c], h = 0, g = Fc(g, f), p = !1);
        g |= 5;
        k = jb(g) ? ? 1024;
        g |= k;
        for (let n = 0; n < c.length; n++) {
            let m = c[n],
                l = d(m, k);
            Object.is(m, l) || (p && (c = [...c], h = 0, g = Fc(g, f), p = !1), c[n] = l)
        }
        g !== h && (p && (c = [...c], g = Fc(g, f)), c[u] = g);
        B(e, f, b, c);
        return a
    }

    function Jc(a, b, c, d) {
        uc(a);
        var e = a.C;
        B(e, e[u] | 0, b, (d === "0" ? Number(c) === 0 : c === d) ? void 0 : c);
        return a
    }

    function Kc(a, b, c, d) {
        uc(a);
        var e = a.C,
            f = e[u] | 0;
        if (d == null) {
            var g = Lc(e);
            if (Mc(g, e, f, c) === b) g.set(c, 0);
            else return a
        } else {
            g = Lc(e);
            let h = Mc(g, e, f, c);
            h !== b && (h && (f = B(e, f, h)), g.set(c, b))
        }
        B(e, f, b, d);
        return a
    }

    function Nc(a, b, c) {
        return Oc(a, b) === c ? c : -1
    }

    function Oc(a, b) {
        a = a.C;
        return Mc(Lc(a), a, void 0, b)
    }

    function Lc(a) {
        return a[eb] ? ? (a[eb] = new Map)
    }

    function Mc(a, b, c, d) {
        var e = a.get(d);
        if (e != null) return e;
        e = 0;
        for (let f = 0; f < d.length; f++) {
            let g = d[f];
            yc(b, g) != null && (e !== 0 && (c = B(b, c, e)), e = g)
        }
        a.set(d, e);
        return e
    }

    function Pc(a, b, c) {
        uc(a);
        a = a.C;
        var d = a[u] | 0,
            e = yc(a, c),
            f = void 0 === qb;
        b = cc(e, b, !f, d);
        if (!f || b) return b = rc(b), e !== b && (d = B(a, d, c, b), vc(a, d)), b
    }

    function Bc(a, b, c, d) {
        var e = !1;
        d = yc(a, d, void 0, f => {
            var g = cc(f, c, !1, b);
            e = g !== f && g != null;
            return g
        });
        if (d != null) return e && !mb(d) && vc(a, b), d
    }

    function Qc(a) {
        var b = Rc;
        a = a.C;
        return Bc(a, a[u] | 0, b, 4) || b[db] || (b[db] = dc(b))
    }

    function D(a, b, c) {
        var d = a.C,
            e = d[u] | 0;
        b = Bc(d, e, b, c);
        if (b == null) return b;
        e = d[u] | 0;
        if (!mb(a, e)) {
            let f = rc(b);
            f !== b && (tc(a) && (d = a.C, e = d[u] | 0), b = f, e = B(d, e, c, b), vc(d, e))
        }
        return b
    }

    function E(a, b, c, d) {
        var e = a.C,
            f = e;
        e = e[u] | 0;
        var g = mb(a, e),
            h = g ? 1 : d;
        d = h === 3;
        var k = !g;
        (h === 2 || k) && tc(a) && (f = a.C, e = f[u] | 0);
        a = Dc(f, c);
        var p = a === hb ? 7 : a[u] | 0,
            n = Ec(p, e);
        if (g = !(4 & n)) {
            var m = a,
                l = e;
            let t = !!(2 & n);
            t && (l |= 2);
            let v = !t,
                z = !0,
                N = 0,
                ya = 0;
            for (; N < m.length; N++) {
                let Ra = cc(m[N], b, !1, l);
                if (Ra instanceof b) {
                    if (!t) {
                        let ob = mb(Ra);
                        v && (v = !ob);
                        z && (z = ob)
                    }
                    m[ya++] = Ra
                }
            }
            ya < N && (m.length = ya);
            n |= 4;
            n = z ? n & -4097 : n | 4096;
            n = v ? n | 8 : n & -9
        }
        n !== p && (a[u] = n, 2 & n && Object.freeze(a));
        if (k && !(8 & n || !a.length && (h === 1 || (h !== 4 ? 0 : 2 & n || !(16 & n) && 32 &
                e)))) {
            Hc(n) && (a = [...a], n = Fc(n, e), e = B(f, e, c, a));
            b = a;
            k = n;
            for (p = 0; p < b.length; p++) m = b[p], n = rc(m), m !== n && (b[p] = n);
            k |= 8;
            n = k = b.length ? k | 4096 : k & -4097;
            a[u] = n
        }
        return a = Gc(a, n, f, e, c, h, g, d)
    }

    function Sc(a) {
        a == null && (a = void 0);
        return a
    }

    function F(a, b, c) {
        c = Sc(c);
        zc(a, b, c);
        c && !mb(c) && vc(a.C);
        return a
    }

    function G(a, b, c, d) {
        d = Sc(d);
        Kc(a, b, c, d);
        d && !mb(d) && vc(a.C);
        return a
    }

    function Tc(a, b, c) {
        uc(a);
        var d = a.C,
            e = d[u] | 0;
        if (c == null) return B(d, e, b), a;
        var f = c === hb ? 7 : c[u] | 0,
            g = f,
            h = Hc(f),
            k = h || Object.isFrozen(c),
            p = !0,
            n = !0;
        for (let l = 0; l < c.length; l++) {
            var m = c[l];
            h || (m = mb(m), p && (p = !m), n && (n = m))
        }
        h || (f = p ? 13 : 5, f = n ? f & -4097 : f | 4096);
        k && f === g || (c = [...c], g = 0, f = Fc(f, e));
        f !== g && (c[u] = f);
        e = B(d, e, b, c);
        2 & f || !(4096 & f || 16 & f) || vc(d, e);
        return a
    }

    function Fc(a, b) {
        return a = (2 & b ? a | 2 : a & -3) & -273
    }

    function Uc(a, b) {
        uc(a);
        a = Cc(a, 4, x, 2, !0);
        var c = jb(a === hb ? 7 : a[u] | 0) ? ? 1024;
        if (Array.isArray(b)) {
            var d = b.length;
            for (let e = 0; e < d; e++) a.push(ac(b[e], c))
        } else
            for (d of b) a.push(ac(d, c))
    }

    function Vc(a, b) {
        return A(a, b, void 0, void 0, $b)
    }

    function Wc(a, b, c) {
        a = A(a, b, void 0, c);
        return a == null || typeof a === "boolean" ? a : typeof a === "number" ? !!a : void 0
    }

    function Xc(a, b, c) {
        return Ub(A(a, b, void 0, c))
    }

    function H(a, b) {
        return Wc(a, b) ? ? !1
    }

    function I(a, b) {
        return Xc(a, b) ? ? 0
    }

    function Yc(a, b) {
        return A(a, b, void 0, void 0, Nb) ? ? 0
    }

    function J(a, b) {
        return x(A(a, b)) ? ? ""
    }

    function K(a, b) {
        return Sb(A(a, b)) ? ? 0
    }

    function Zc(a, b, c) {
        return K(a, Nc(a, c, b))
    }

    function $c(a, b, c, d) {
        return D(a, b, Nc(a, d, c))
    }

    function ad(a, b) {
        return x(A(a, b, void 0, xc))
    }

    function bd(a, b) {
        return Sb(A(a, b, void 0, xc))
    }

    function cd(a, b, c) {
        return zc(a, b, c == null ? c : Tb(c))
    }

    function dd(a, b, c) {
        return Jc(a, b, c == null ? c : Tb(c), 0)
    }

    function ed(a, b, c) {
        return Jc(a, b, c == null ? c : Wb(c), "0")
    }

    function fd(a, b) {
        var c = performance.now();
        if (c != null && typeof c !== "number") throw Error(`Value of float/double field must be a number, found ${typeof c}: ${c}`);
        Jc(a, b, c, 0)
    }

    function gd(a, b, c) {
        return zc(a, b, bc(c))
    }

    function hd(a, b, c) {
        return Jc(a, b, bc(c), "")
    }

    function id(a, b, c) {
        return zc(a, b, c == null ? c : Rb(c))
    }

    function jd(a, b, c) {
        return Jc(a, b, c == null ? c : Rb(c), 0)
    }

    function kd(a, b, c, d) {
        return Kc(a, b, c, d == null ? d : Rb(d))
    };

    function ld(a) {
        return sc(a)
    }
    var L = class {
        constructor(a) {
            this.C = kc(a, void 0, void 0, 2048)
        }
        toJSON() {
            return y(this)
        }
        u() {
            return JSON.stringify(y(this))
        }
    };
    L.prototype[gb] = lb;

    function md(a, b) {
        if (b == null) return new a;
        if (!Array.isArray(b)) throw Error();
        if (Object.isFrozen(b) || Object.isSealed(b) || !Object.isExtensible(b)) throw Error();
        return new a(kb(b))
    };

    function nd(a) {
        return () => a[db] || (a[db] = dc(a))
    }

    function od(a) {
        return b => {
            if (b == null || b == "") b = new a;
            else {
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error("dnarr");
                b = new a(kb(b))
            }
            return b
        }
    };
    var pd = class extends L {};
    var qd = class extends L {};

    function rd(a, b) {
        if (a)
            for (let c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    };

    function sd(a) {
        try {
            var b;
            if (b = !!a && a.location.href != null) a: {
                try {
                    Sa(a.foo);
                    b = !0;
                    break a
                } catch (c) {}
                b = !1
            }
            return b
        } catch {
            return !1
        }
    }

    function td(a) {
        return sd(a.top) ? a.top : null
    };

    function ud(a) {
        return function() {
            return !a.apply(this, arguments)
        }
    }

    function vd(a) {
        var b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    }

    function wd(a) {
        var b = a;
        return function() {
            if (b) {
                let c = b;
                b = null;
                c()
            }
        }
    };

    function xd() {
        return xa && Ca ? Ca.mobile : !yd() && (r("iPod") || r("iPhone") || r("Android") || r("IEMobile"))
    }

    function yd() {
        return xa && Ca ? !Ca.mobile && (r("iPad") || r("Android") || r("Silk")) : r("iPad") || r("Android") && !r("Mobile") || r("Silk")
    };
    /* 
     
     Copyright Google LLC 
     SPDX-License-Identifier: Apache-2.0 
    */
    let zd = globalThis.trustedTypes,
        Ad;

    function Bd() {
        var a = null;
        if (!zd) return a;
        try {
            let b = c => c;
            a = zd.createPolicy("goog#html", {
                createHTML: b,
                createScript: b,
                createScriptURL: b
            })
        } catch (b) {}
        return a
    };
    var Cd = class {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g + ""
        }
    };

    function Dd(a) {
        var b;
        Ad === void 0 && (Ad = Bd());
        a = (b = Ad) ? b.createScriptURL(a) : a;
        return new Cd(a)
    }

    function Ed(a) {
        if (a instanceof Cd) return a.g;
        throw Error("");
    };
    var Fd = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;

    function Gd(a = document) {
        a = a.querySelector ? .("script[nonce]");
        return a == null ? "" : a.nonce || a.getAttribute("nonce") || ""
    };
    const Hd = "alternate author bookmark canonical cite help icon license modulepreload next prefetch dns-prefetch prerender preconnect preload prev search subresource".split(" ");

    function Id(a) {
        return String(a).replace(/\-([a-z])/g, function(b, c) {
            return c.toUpperCase()
        })
    };
    var Jd = vd(() => xd() ? 2 : yd() ? 1 : 0);

    function Kd() {
        if (!globalThis.crypto) return Math.random();
        try {
            let a = new Uint32Array(1);
            globalThis.crypto.getRandomValues(a);
            return a[0] / 65536 / 65536
        } catch (a) {
            return Math.random()
        }
    };
    let Ld, Md = 64;

    function Nd() {
        try {
            return Ld ? ? (Ld = new Uint32Array(64)), Md >= 64 && (crypto.getRandomValues(Ld), Md = 0), Ld[Md++]
        } catch (a) {
            return Math.floor(Math.random() * 2 ** 32)
        }
    };

    function Od(a, b) {
        if (!sb(a.goog_pvsid)) try {
            let c = Nd() + (Nd() & 2 ** 21 - 1) * 2 ** 32;
            Object.defineProperty(a, "goog_pvsid", {
                value: c,
                configurable: !1
            })
        } catch (c) {
            b.qa({
                methodName: 784,
                ya: c
            })
        }
        a = Number(a.goog_pvsid);
        (!a || a <= 0) && b.qa({
            methodName: 784,
            ya: Error(`Invalid correlator, ${a}`)
        });
        return a || -1
    };

    function Pd(a, ...b) {
        if (b.length === 0) return Dd(a[0]);
        var c = a[0];
        for (let d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return Dd(c)
    }

    function Qd(a, b) {
        a = Ed(a).toString();
        var c = a.split(/[?#]/),
            d = /[?]/.test(a) ? "?" + c[1] : "";
        return Rd(c[0], d, /[#]/.test(a) ? "#" + (d ? c[2] : c[1]) : "", b)
    }

    function Rd(a, b, c, d) {
        function e(g, h) {
            g != null && (Array.isArray(g) ? g.forEach(k => e(k, h)) : (b += f + encodeURIComponent(h) + "=" + encodeURIComponent(g), f = "&"))
        }
        var f = b.length ? "&" : "?";
        d.constructor === Object && (d = Object.entries(d));
        Array.isArray(d) ? d.forEach(g => e(g[1], g[0])) : d.forEach(e);
        return Dd(a + b + c)
    };

    function Sd(a, b) {
        var c = Td("SCRIPT", a);
        c.src = Ed(b);
        (b = Gd(c.ownerDocument)) && c.setAttribute("nonce", b);
        (a = a.getElementsByTagName("script")[0]) && a.parentNode && a.parentNode.insertBefore(c, a)
    }

    function Ud(a, b) {
        return b.getComputedStyle ? b.getComputedStyle(a, null) : a.currentStyle
    }
    var Vd = /^([0-9.]+)px$/,
        Wd = /^(-?[0-9.]{1,30})$/;

    function Xd(a) {
        if (!Wd.test(a)) return null;
        a = Number(a);
        return isNaN(a) ? null : a
    }

    function Yd(a) {
        return (a = Vd.exec(a)) ? +a[1] : null
    }
    var Zd = a => {
        rd({
            display: "none"
        }, (b, c) => {
            a.style.setProperty(c, b, "important")
        })
    };

    function $d() {
        var a = M(ae).i(be.g, be.defaultValue),
            b = O.document;
        if (a.length && b.head)
            for (let c of a) a: {
                if (!c || !b.head) break a;a = Td("META");b.head.appendChild(a);a.httpEquiv = "origin-trial";a.content = c
            }
    }
    var ce = a => Od(a, {
        qa: () => {}
    });

    function Td(a, b = document) {
        return b.createElement(String(a).toLowerCase())
    };
    let de = [];

    function ee() {
        var a = de;
        de = [];
        for (let b of a) try {
            b()
        } catch {}
    };

    function fe(a, b) {
        this.width = a;
        this.height = b
    }
    fe.prototype.aspectRatio = function() {
        return this.width / this.height
    };
    fe.prototype.isEmpty = function() {
        return !(this.width * this.height)
    };
    fe.prototype.ceil = function() {
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    fe.prototype.floor = function() {
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    fe.prototype.round = function() {
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    fe.prototype.scale = function(a, b) {
        this.width *= a;
        this.height *= typeof b === "number" ? b : a;
        return this
    };

    function ge(a, b) {
        var c = {};
        for (let d in a) b.call(void 0, a[d], d, a) && (c[d] = a[d]);
        return c
    }

    function he(a, b) {
        for (let c in a)
            if (b.call(void 0, a[c], c, a)) return !0;
        return !1
    }

    function ie(a) {
        var b = [],
            c = 0;
        for (let d in a) b[c++] = a[d];
        return b
    };

    function je(a, b) {
        b = String(b);
        a.contentType === "application/xhtml+xml" && (b = b.toLowerCase());
        return a.createElement(b)
    }

    function ke(a) {
        this.g = a || q.document || document
    }
    ke.prototype.contains = function(a, b) {
        return a && b ? a == b || a.contains(b) : !1
    };

    function le(a, b, c) {
        typeof a.addEventListener === "function" && a.addEventListener(b, c, !1)
    }

    function me(a, b, c) {
        return typeof a.removeEventListener === "function" ? (a.removeEventListener(b, c, !1), !0) : !1
    }

    function ne(a) {
        var b = oe;
        b.readyState === "complete" || b.readyState === "interactive" ? (de.push(a), de.length === 1 && (window.Promise ? Promise.resolve().then(ee) : (a = window.setImmediate, ub(a) ? a(ee) : setTimeout(ee, 0)))) : b.addEventListener("DOMContentLoaded", a)
    };

    function pe(a, b, c = null, d = !1, e = !1) {
        qe(a, b, c, d, e)
    }

    function qe(a, b, c, d, e = !1) {
        a.google_image_requests || (a.google_image_requests = []);
        var f = Td("IMG", a.document);
        if (c || d) {
            let g = h => {
                c && c(h);
                if (d) {
                    h = a.google_image_requests;
                    let k = Ka(h, f);
                    k >= 0 && Array.prototype.splice.call(h, k, 1)
                }
                me(f, "load", g);
                me(f, "error", g)
            };
            le(f, "load", g);
            le(f, "error", g)
        }
        e && (f.attributionSrc = "");
        f.src = b;
        a.google_image_requests.push(f)
    }

    function re(a, b) {
        var c = `https://pagead2.googlesyndication.com/pagead/gen_204?id=${b}`;
        rd(a, (d, e) => {
            if (d || d === 0) c += `&${e}=${encodeURIComponent(String(d))}`
        });
        se(c)
    }

    function se(a) {
        var b = window;
        b.fetch ? b.fetch(a, {
            keepalive: !0,
            credentials: "include",
            redirect: "follow",
            method: "get",
            mode: "no-cors"
        }) : pe(b, a, void 0, !1, !1)
    };
    var oe = document,
        O = window;
    let te = null;
    var ue = (a, b = []) => {
        var c = !1;
        q.google_logging_queue || (c = !0, q.google_logging_queue = []);
        q.google_logging_queue.push([a, b]);
        if (a = c) {
            if (te == null) {
                te = !1;
                try {
                    let d = td(q);
                    d && d.location.hash.indexOf("google_logging") !== -1 && (te = !0)
                } catch (d) {}
            }
            a = te
        }
        a && Sd(q.document, Pd `https://pagead2.googlesyndication.com/pagead/js/logging_library.js`)
    };

    function ve(a) {
        return !!(a.error && a.meta && a.id)
    }
    var we = class {
        constructor(a, b) {
            this.error = a;
            this.meta = {};
            this.context = b.context;
            this.msg = b.message || "";
            this.id = b.id || "jserror"
        }
    };

    function xe(a) {
        return new we(a, {
            message: ye(a)
        })
    }

    function ye(a) {
        var b = a.toString();
        a.name && b.indexOf(a.name) == -1 && (b += ": " + a.name);
        a.message && b.indexOf(a.message) == -1 && (b += ": " + a.message);
        if (a.stack) a: {
            a = a.stack;
            var c = b;
            try {
                a.indexOf(c) == -1 && (a = c + "\n" + a);
                let d;
                for (; a != d;) d = a, a = a.replace(RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"), "$1");
                b = a.replace(RegExp("\n *", "g"), "\n");
                break a
            } catch (d) {
                b = c;
                break a
            }
            b = void 0
        }
        return b
    };
    const ze = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)");
    var Ae = class {
            constructor(a, b) {
                this.g = a;
                this.i = b
            }
        },
        Be = class {
            constructor(a, b, c) {
                this.url = a;
                this.l = b;
                this.g = !!c;
                this.depth = null
            }
        };
    let Ce = null;

    function De() {
        var a = window;
        if (Ce === null) {
            Ce = "";
            try {
                let b = "";
                try {
                    b = a.top.location.hash
                } catch (c) {
                    b = a.location.hash
                }
                if (b) {
                    let c = b.match(/\bdeid=([\d,]+)/);
                    Ce = c ? c[1] : ""
                }
            } catch (b) {}
        }
        return Ce
    };

    function Ee() {
        var a = q.performance;
        return a && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : Date.now()
    }

    function Fe() {
        var a = q.performance;
        return a && a.now ? a.now() : null
    };
    var Ge = class {
        constructor(a, b) {
            var c = Fe() || Ee();
            this.label = a;
            this.type = b;
            this.value = c;
            this.duration = 0;
            this.taskId = this.slotId = void 0;
            this.uniqueId = Math.random()
        }
    };
    const He = q.performance,
        Je = !!(He && He.mark && He.measure && He.clearMarks),
        Ke = vd(() => {
            var a;
            if (a = Je) a = De(), a = !!a.indexOf && a.indexOf("1337") >= 0;
            return a
        });

    function Le(a) {
        a && He && Ke() && (He.clearMarks(`goog_${a.label}_${a.uniqueId}_start`), He.clearMarks(`goog_${a.label}_${a.uniqueId}_end`))
    }

    function Me(a) {
        a.g = !1;
        if (a.events !== a.i.google_js_reporting_queue) {
            if (Ke()) {
                var b = a.events;
                let c = b.length;
                b = typeof b === "string" ? b.split("") : b;
                for (let d = 0; d < c; d++) d in b && Le.call(void 0, b[d])
            }
            a.events.length = 0
        }
    }
    var Ne = class {
        constructor(a) {
            this.events = [];
            this.i = a || q;
            var b = null;
            a && (a.google_js_reporting_queue = a.google_js_reporting_queue || [], this.events = a.google_js_reporting_queue, b = a.google_measure_js_timing);
            this.g = Ke() || (b != null ? b : Math.random() < 1)
        }
        start(a, b) {
            if (!this.g) return null;
            a = new Ge(a, b);
            b = `goog_${a.label}_${a.uniqueId}_start`;
            He && Ke() && He.mark(b);
            return a
        }
        end(a) {
            if (this.g && sb(a.value)) {
                a.duration = (Fe() || Ee()) - a.value;
                var b = `goog_${a.label}_${a.uniqueId}_end`;
                He && Ke() && He.mark(b);
                !this.g || this.events.length >
                    2048 || this.events.push(a)
            }
        }
    };

    function Oe(a, b) {
        var c = {};
        c[a] = b;
        return [c]
    }

    function Pe(a, b, c, d, e) {
        var f = [];
        rd(a, (g, h) => {
            (g = Qe(g, b, c, d, e)) && f.push(`${h}=${g}`)
        });
        return f.join(b)
    }

    function Qe(a, b, c, d, e) {
        if (a == null) return "";
        b = b || "&";
        c = c || ",$";
        w(c) && (c = c.split(""));
        if (a instanceof Array) {
            if (d || (d = 0), d < c.length) {
                let f = [];
                for (let g = 0; g < a.length; g++) f.push(Qe(a[g], b, c, d + 1, e));
                return f.join(c[d])
            }
        } else if (typeof a === "object") return e || (e = 0), e < 2 ? encodeURIComponent(Pe(a, b, c, d, e + 1)) : "...";
        return encodeURIComponent(String(a))
    }

    function Re(a) {
        var b = 1;
        for (let c in a.i) c.length > b && (b = c.length);
        return 3997 - b - a.j.length - 1
    }

    function Se(a, b, c) {
        b = "https://" + b + c;
        var d = Re(a) - c.length;
        if (d < 0) return "";
        a.g.sort((f, g) => f - g);
        c = null;
        var e = "";
        for (let f = 0; f < a.g.length; f++) {
            let g = a.g[f],
                h = a.i[g];
            for (let k = 0; k < h.length; k++) {
                if (!d) {
                    c = c == null ? g : c;
                    break
                }
                let p = Pe(h[k], a.j, ",$");
                if (p) {
                    p = e + p;
                    if (d >= p.length) {
                        d -= p.length;
                        b += p;
                        e = a.j;
                        break
                    }
                    c = c == null ? g : c
                }
            }
        }
        a = "";
        c != null && (a = `${e}trn=${c}`);
        return b + a
    }
    var Te = class {
        constructor() {
            this.j = "&";
            this.i = {};
            this.u = 0;
            this.g = []
        }
    };
    const Ue = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$"),
        Ve = /#|$/;

    function We(a, b) {
        var c = a.search(Ve);
        a: {
            var d = 0;
            for (var e = b.length;
                (d = a.indexOf(b, d)) >= 0 && d < c;) {
                var f = a.charCodeAt(d - 1);
                if (f == 38 || f == 63)
                    if (f = a.charCodeAt(d + e), !f || f == 61 || f == 38 || f == 35) break a;
                d += e + 1
            }
            d = -1
        }
        if (d < 0) return null;
        e = a.indexOf("&", d);
        if (e < 0 || e > c) e = c;
        d += b.length + 1;
        return decodeURIComponent(a.slice(d, e !== -1 ? e : 0).replace(/\+/g, " "))
    };
    var Ze = class {
        constructor(a = null) {
            this.H = Xe;
            this.j = a;
            this.i = null;
            this.A = !1;
            this.G = this.K
        }
        N(a) {
            this.G = a
        }
        B(a) {
            this.i = a
        }
        O(a) {
            this.A = a
        }
        g(a, b, c) {
            try {
                if (this.j && this.j.g) {
                    var d = this.j.start(a.toString(), 3);
                    var e = b();
                    this.j.end(d)
                } else e = b()
            } catch (f) {
                b = !0;
                try {
                    Le(d), b = this.G(a, xe(f), void 0, c)
                } catch (g) {
                    this.K(217, g)
                }
                if (b) window.console ? .error ? .(f);
                else throw f;
            }
            return e
        }
        u(a, b) {
            return (...c) => this.g(a, () => b.apply(void 0, c))
        }
        K(a, b, c, d, e) {
            e = e || "jserror";
            var f = void 0;
            try {
                let Ba = new Te;
                var g = Ba;
                g.g.push(1);
                g.i[1] =
                    Oe("context", a);
                ve(b) || (b = xe(b));
                g = b;
                if (g.msg) {
                    b = Ba;
                    var h = g.msg.substring(0, 512);
                    b.g.push(2);
                    b.i[2] = Oe("msg", h)
                }
                var k = g.meta || {};
                h = k;
                if (this.i) try {
                    this.i(h)
                } catch (V) {}
                if (d) try {
                    d(h)
                } catch (V) {}
                d = Ba;
                k = [k];
                d.g.push(3);
                d.i[3] = k;
                var p;
                if (!(p = l)) {
                    d = q;
                    k = [];
                    h = null;
                    do {
                        var n = d;
                        if (sd(n)) {
                            var m = n.location.href;
                            h = n.document && n.document.referrer || null
                        } else m = h, h = null;
                        k.push(new Be(m || "", n));
                        try {
                            d = n.parent
                        } catch (V) {
                            d = null
                        }
                    } while (d && n !== d);
                    for (let V = 0, Xg = k.length - 1; V <= Xg; ++V) k[V].depth = Xg - V;
                    n = q;
                    if (n.location && n.location.ancestorOrigins &&
                        n.location.ancestorOrigins.length === k.length - 1)
                        for (m = 1; m < k.length; ++m) {
                            let V = k[m];
                            V.url || (V.url = n.location.ancestorOrigins[m - 1] || "", V.g = !0)
                        }
                    p = k
                }
                var l = p;
                let Ib = new Be(q.location.href, q, !1);
                p = null;
                let mc = l.length - 1;
                for (n = mc; n >= 0; --n) {
                    var t = l[n];
                    !p && ze.test(t.url) && (p = t);
                    if (t.url && !t.g) {
                        Ib = t;
                        break
                    }
                }
                t = null;
                let Ie = l.length && l[mc].url;
                Ib.depth !== 0 && Ie && (t = l[mc]);
                f = new Ae(Ib, t);
                if (f.i) {
                    l = Ba;
                    var v = f.i.url || "";
                    l.g.push(4);
                    l.i[4] = Oe("top", v)
                }
                var z = {
                    url: f.g.url || ""
                };
                if (f.g.url) {
                    let V = f.g.url.match(Ue);
                    var N =
                        V[1],
                        ya = V[3],
                        Ra = V[4];
                    v = "";
                    N && (v += N + ":");
                    ya && (v += "//", v += ya, Ra && (v += ":" + Ra));
                    var ob = v
                } else ob = "";
                N = Ba;
                z = [z, {
                    url: ob
                }];
                N.g.push(5);
                N.i[5] = z;
                Ye(this.H, e, Ba, this.A, c)
            } catch (Ba) {
                try {
                    Ye(this.H, e, {
                        context: "ecmserr",
                        rctx: a,
                        msg: ye(Ba),
                        url: f ? .g.url ? ? ""
                    }, this.A, c)
                } catch (Ib) {}
            }
            return !0
        }
        ta(a, b) {
            b.catch(c => {
                c = c ? c : "unknown rejection";
                this.K(a, c instanceof Error ? c : Error(c), void 0, this.i || void 0)
            })
        }
    };
    var $e = class extends L {},
        af = [2, 3, 4];
    var bf = class extends L {},
        cf = [3, 4, 5],
        df = [6, 7];
    var ef = class extends L {},
        ff = [4, 5];

    function gf(a, b) {
        var c = E(a, bf, 2, C());
        if (!c.length) return hf(a, b);
        a = K(a, 1);
        if (a === 1) return c = gf(c[0], b), c.success ? {
            success: !0,
            value: !c.value
        } : c;
        c = Ma(c, d => gf(d, b));
        switch (a) {
            case 2:
                return c.find(d => d.success && !d.value) ? ? c.find(d => !d.success) ? ? {
                    success: !0,
                    value: !0
                };
            case 3:
                return c.find(d => d.success && d.value) ? ? c.find(d => !d.success) ? ? {
                    success: !0,
                    value: !1
                };
            default:
                return {
                    success: !1,
                    U: 3
                }
        }
    }

    function hf(a, b) {
        var c = Oc(a, cf);
        a: {
            switch (c) {
                case 3:
                    var d = Zc(a, 3, cf);
                    break a;
                case 4:
                    d = Zc(a, 4, cf);
                    break a;
                case 5:
                    d = Zc(a, 5, cf);
                    break a
            }
            d = void 0
        }
        if (!d) return {
            success: !1,
            U: 2
        };
        b = (b = b[c]) && b[d];
        if (!b) return {
            success: !1,
            property: d,
            ia: c,
            U: 1
        };
        try {
            var e = Cc(a, 8, x, C());
            var f = b(...e)
        } catch (g) {
            return {
                success: !1,
                property: d,
                ia: c,
                U: 2
            }
        }
        e = K(a, 1);
        if (e === 4) return {
            success: !0,
            value: !!f
        };
        if (e === 5) return {
            success: !0,
            value: f != null
        };
        if (e === 12) a = J(a, Nc(a, df, 7));
        else a: {
            switch (c) {
                case 4:
                    a = Yc(a, Nc(a, df, 6));
                    break a;
                case 5:
                    a = J(a,
                        Nc(a, df, 7));
                    break a
            }
            a = void 0
        }
        if (a == null) return {
            success: !1,
            property: d,
            ia: c,
            U: 3
        };
        if (e === 6) return {
            success: !0,
            value: f === a
        };
        if (e === 9) return {
            success: !0,
            value: f != null && va(String(f), a) === 0
        };
        if (f == null) return {
            success: !1,
            property: d,
            ia: c,
            U: 4
        };
        switch (e) {
            case 7:
                c = f < a;
                break;
            case 8:
                c = f > a;
                break;
            case 12:
                c = w(a) && w(f) && (new RegExp(a)).test(f);
                break;
            case 10:
                c = f != null && va(String(f), a) === -1;
                break;
            case 11:
                c = f != null && va(String(f), a) === 1;
                break;
            default:
                return {
                    success: !1,
                    U: 3
                }
        }
        return {
            success: !0,
            value: c
        }
    }

    function jf(a, b) {
        return a ? b ? gf(a, b) : {
            success: !1,
            U: 1
        } : {
            success: !0,
            value: !0
        }
    };

    function kf(a) {
        return Cc(a, 4, x, C())
    }
    var Rc = class extends L {};
    var lf = class extends L {
        getValue() {
            return D(this, Rc, 2)
        }
    };
    var mf = class extends L {},
        nf = od(mf),
        of = [1, 2, 3, 6, 7, 8];
    var pf = class extends L {};

    function qf(a, b) {
        try {
            let c = d => [{
                [d.Ha]: d.Fa
            }];
            return JSON.stringify([a.filter(d => d.ra).map(c), y(b), a.filter(d => !d.ra).map(c)])
        } catch (c) {
            return rf(c, b), ""
        }
    }

    function rf(a, b) {
        try {
            re({
                m: ye(a instanceof Error ? a : Error(String(a))),
                b: K(b, 1) || null,
                v: J(b, 2) || null
            }, "rcs_internal")
        } catch (c) {}
    }

    function sf(a) {
        if (a.B) {
            var b = a.j,
                c = Set;
            var d = Cc(a.j, 3, Ub, C());
            c = [...(new c([...d, ...a.B()]))];
            Ic(b, 3, c, Tb)
        }
        return sc(a.j)
    }
    var tf = class {
        constructor(a, b, c) {
            this.B = c;
            c = new pf;
            a = jd(c, 1, a);
            this.j = hd(a, 2, b)
        }
    };

    function uf(a) {
        var b = new CompressionStream("gzip"),
            c = (new Response(b.readable)).arrayBuffer(),
            d = b.writable.getWriter(),
            e = typeof a === "string" ? (new TextEncoder).encode(a) : a;
        return d.ready.then(() => d.write(e)).then(() => d.close()).then(() => c).then(f => new Uint8Array(f))
    };
    var vf = class extends L {
        getWidth() {
            return I(this, 3)
        }
        getHeight() {
            return I(this, 4)
        }
    };
    var wf = class extends L {};

    function xf(a, b) {
        return zc(a, 1, b == null ? b : Wb(b))
    }

    function yf(a, b) {
        return zc(a, 2, b == null ? b : Wb(b))
    }
    var zf = class extends L {
        getWidth() {
            return Vc(this, 1) ? ? wc
        }
        getHeight() {
            return Vc(this, 2) ? ? wc
        }
    };
    var Af = class extends L {};
    var Bf = class extends L {};
    var Cf = class extends L {};

    function Df(a) {
        var b = new Ef;
        return jd(b, 1, a)
    }
    var Ef = class extends L {},
        Ff = [5, 6, 7, 8, 9, 10, 11, 12, 13, 14];
    var Gf = class extends L {};
    var Hf = class extends L {
        getValue() {
            return K(this, 1)
        }
    };
    var If = class extends L {
        getContentUrl() {
            return J(this, 4)
        }
    };
    var Jf = class extends L {};

    function Kf(a) {
        return Pc(a, Jf, 3)
    }
    var Lf = class extends L {};
    var Mf = class extends L {
        getContentUrl() {
            return J(this, 1)
        }
    };
    var Nf = class extends L {};
    var Of = class extends L {};
    var Pf = class extends L {},
        Qf = [4, 5, 6, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24];
    var Rf = class extends L {};

    function Sf(a, b) {
        return jd(a, 1, b)
    }

    function Tf(a, b) {
        return jd(a, 2, b)
    }
    var Uf = class extends L {};
    var Vf = class extends L {},
        Wf = [1, 2];

    function Xf(a, b) {
        return F(a, 1, b)
    }

    function Yf(a, b) {
        return Tc(a, 2, b)
    }

    function Zf(a, b) {
        return Ic(a, 4, b, Tb)
    }

    function $f(a, b) {
        return Tc(a, 5, b)
    }

    function ag(a, b) {
        return jd(a, 6, b)
    }
    var bg = class extends L {};
    var cg = class extends L {},
        dg = [1, 2, 3, 4, 6];
    var eg = class extends L {};

    function fg(a) {
        var b = new gg;
        return G(b, 4, hg, a)
    }
    var gg = class extends L {
            getTagSessionCorrelator() {
                return Vc(this, 2) ? ? wc
            }
        },
        hg = [4, 5, 7, 8, 9];
    var ig = class extends L {};

    function jg() {
        var a = kg();
        a = rc(a);
        return hd(a, 1, lg())
    }
    var mg = class extends L {};
    var ng = class extends L {};
    var og = class extends L {
        getTagSessionCorrelator() {
            return Vc(this, 1) ? ? wc
        }
    };
    var pg = class extends L {},
        qg = [1, 7],
        rg = [4, 6, 8];
    class sg extends tf {
        constructor() {
            super(...arguments)
        }
    }

    function tg(a, ...b) {
        ug(a, ...b.map(c => ({
            ra: !0,
            Ha: 3,
            Fa: y(c)
        })))
    }

    function vg(a, ...b) {
        ug(a, ...b.map(c => ({
            ra: !0,
            Ha: 4,
            Fa: y(c)
        })))
    }

    function wg(a, ...b) {
        ug(a, ...b.map(c => ({
            ra: !0,
            Ha: 7,
            Fa: y(c)
        })))
    }
    var xg = class extends sg {};

    function yg(a, b) {
        globalThis.fetch(a, {
            method: "POST",
            body: b,
            keepalive: b.length < 65536,
            credentials: "omit",
            mode: "no-cors",
            redirect: "follow"
        }).catch(() => {})
    }

    function zg(a, b, c = 1, d = !1) {
        var e = typeof CompressionStream === "function";
        typeof document !== "undefined" && document.visibilityState !== "hidden" && d && e ? uf(b).then(f => {
            yg(`${a}?e=${c===1?5:6}`, f)
        }).catch(() => {
            yg(`${a}?e=${c}`, b)
        }) : yg(`${a}?e=${c}`, b)
    };

    function ug(a, ...b) {
        try {
            a.H && qf(a.g.concat(b), sf(a)).length >= 65536 && Ag(a), a.u && !a.A && (a.A = !0, Bg(a.u, () => {
                Ag(a)
            })), a.g.push(...b), a.g.length >= a.G && Ag(a), a.g.length && a.i === null && (a.i = setTimeout(() => {
                Ag(a)
            }, a.O))
        } catch (c) {
            rf(c, sf(a))
        }
    }

    function Ag(a) {
        a.i !== null && (clearTimeout(a.i), a.i = null);
        if (a.g.length) {
            var b = qf(a.g, sf(a));
            a.N("https://pagead2.googlesyndication.com/pagead/ping", b, 1, !1);
            a.g = []
        }
    }
    var Cg = class extends xg {
            constructor(a, b, c, d, e, f, g) {
                super(a, b, g);
                this.N = zg;
                this.O = c;
                this.G = d;
                this.H = e;
                this.u = f;
                this.g = [];
                this.i = null;
                this.A = !1
            }
        },
        Dg = class extends Cg {
            constructor(a, b, c = 1E3, d = 100, e = !1, f, g) {
                super(a, b, c, d, e && !0, f, g)
            }
        };

    function Eg(a, b) {
        var c = Date.now();
        c = Number.isFinite(c) ? Math.round(c) : 0;
        b = ed(b, 1, c);
        c = ce(window);
        b = ed(b, 2, c);
        return ed(b, 6, a.B)
    }

    function Fg(a, b, c, d, e, f) {
        if (a.j) {
            var g = Tf(Sf(new Uf, b), c);
            b = ag(Yf(Xf($f(Zf(new bg, d), e), g), a.g.slice()), f);
            b = fg(b);
            vg(a.i, Eg(a, b));
            if (f === 1 || f === 3 || f === 4 && !a.g.some(h => K(h, 1) === K(g, 1) && K(h, 2) === c)) a.g.push(g), a.g.length > 100 && a.g.shift()
        }
    }

    function Gg(a, b, c, d) {
        if (a.j) {
            var e = new Rf;
            b = cd(e, 1, b);
            c = cd(b, 2, c);
            d = id(c, 3, d);
            c = new gg;
            d = G(c, 8, hg, d);
            vg(a.i, Eg(a, d))
        }
    }

    function Hg(a, b, c, d, e) {
        if (a.j) {
            var f = new ef;
            b = F(f, 1, b);
            c = id(b, 2, c);
            d = cd(c, 3, d);
            if (e.ia === void 0) kd(d, 4, ff, e.U);
            else switch (e.ia) {
                case 3:
                    c = new $e;
                    c = kd(c, 2, af, e.property);
                    e = id(c, 1, e.U);
                    G(d, 5, ff, e);
                    break;
                case 4:
                    c = new $e;
                    c = kd(c, 3, af, e.property);
                    e = id(c, 1, e.U);
                    G(d, 5, ff, e);
                    break;
                case 5:
                    c = new $e, c = kd(c, 4, af, e.property), e = id(c, 1, e.U), G(d, 5, ff, e)
            }
            e = new gg;
            e = G(e, 9, hg, d);
            vg(a.i, Eg(a, e))
        }
    }
    var Ig = class {
        constructor(a, b, c, d = new Dg(6, "unknown", b)) {
            this.B = a;
            this.u = c;
            this.i = d;
            this.g = [];
            this.j = a > 0 && Kd() < 1 / a
        }
    };
    var M = a => {
        var b = "Ca";
        if (a.Ca && a.hasOwnProperty(b)) return a.Ca;
        b = new a;
        return a.Ca = b
    };
    var Jg = class {
        constructor() {
            this.T = {
                [3]: {},
                [4]: {},
                [5]: {}
            }
        }
    };
    var Kg = /^true$/.test("false");

    function Lg(a, b) {
        switch (b) {
            case 1:
                return Zc(a, 1, of );
            case 2:
                return Zc(a, 2, of );
            case 3:
                return Zc(a, 3, of );
            case 6:
                return Zc(a, 6, of );
            case 8:
                return Zc(a, 8, of );
            default:
                return null
        }
    }

    function Mg(a, b) {
        if (!a) return null;
        switch (b) {
            case 1:
                return H(a, 1);
            case 7:
                return J(a, 3);
            case 2:
                return Yc(a, 2);
            case 3:
                return J(a, 3);
            case 6:
                return kf(a);
            case 8:
                return kf(a);
            default:
                return null
        }
    }
    const Ng = vd(() => {
        if (!Kg) return {};
        try {
            var a = window;
            try {
                var b = a.sessionStorage.getItem("GGDFSSK")
            } catch {
                b = null
            }
            if (b) return JSON.parse(b)
        } catch {}
        return {}
    });

    function Og(a, b, c, d = 0) {
        M(Pg).j[d] = M(Pg).j[d] ? .add(b) ? ? (new Set).add(b);
        var e = Ng();
        if (e[b] != null) return e[b];
        b = Qg(d)[b];
        if (!b) return c;
        b = nf(JSON.stringify(b));
        b = Rg(b);
        a = Mg(b, a);
        return a != null ? a : c
    }

    function Rg(a) {
        var b = M(Jg).T;
        if (b && Oc(a, of ) !== 8) {
            let c = Oa(E(a, lf, 5, C()), d => {
                d = jf(D(d, bf, 1), b);
                return d.success && d.value
            });
            if (c) return c.getValue() ? ? null
        }
        return D(a, Rc, 4) ? ? null
    }
    class Pg {
        constructor() {
            this.i = {};
            this.u = [];
            this.j = {};
            this.g = new Map
        }
    }

    function Sg(a, b = !1, c) {
        return !!Og(1, a, b, c)
    }

    function Tg(a, b = 0, c) {
        a = Number(Og(2, a, b, c));
        return isNaN(a) ? b : a
    }

    function Ug(a, b = "", c) {
        a = Og(3, a, b, c);
        return w(a) ? a : b
    }

    function Vg(a, b = [], c) {
        a = Og(6, a, b, c);
        return Array.isArray(a) ? a : b
    }

    function Wg(a, b = [], c) {
        a = Og(8, a, b, c);
        return Array.isArray(a) ? a : b
    }

    function Qg(a) {
        return M(Pg).i[a] || (M(Pg).i[a] = {})
    }

    function Yg(a, b) {
        var c = Qg(b);
        rd(a, (d, e) => {
            if (c[e]) {
                var f = d = nf(JSON.stringify(d)),
                    g = Nc(d, of , 8);
                Sb(A(f, g)) != null && (g = nf(JSON.stringify(c[e])), f = Pc(d, Rc, 4), g = kf(Qc(g)), Uc(f, g));
                c[e] = y(d)
            } else c[e] = d
        })
    }

    function Zg(a, b, c, d, e = !1) {
        var f = [],
            g = [];
        for (let m of b) {
            b = Qg(m);
            for (let l of a) {
                var h = Oc(l, of );
                let t = Lg(l, h);
                if (!t) continue;
                a: {
                    var k = t;
                    var p = h,
                        n = M(Pg).g.get(m) ? .get(t) ? .slice(0) ? ? [];
                    let v = new cg;
                    switch (p) {
                        case 1:
                            kd(v, 1, dg, k);
                            break;
                        case 2:
                            kd(v, 2, dg, k);
                            break;
                        case 3:
                            kd(v, 3, dg, k);
                            break;
                        case 6:
                            kd(v, 4, dg, k);
                            break;
                        case 8:
                            kd(v, 6, dg, k);
                            break;
                        default:
                            k = void 0;
                            break a
                    }
                    Ic(v, 5, n, Tb);k = v
                }
                k && M(Pg).j[m] ? .has(t) && f.push(k);
                h === 8 && b[t] ? (k = nf(JSON.stringify(b[t])), h = Pc(l, Rc, 4), k = kf(Qc(k)), Uc(h, k)) : k && M(Pg).g.get(m) ? .has(t) &&
                    g.push(k);
                e || (h = t, k = m, p = d, n = M(Pg), n.g.has(k) || n.g.set(k, new Map), n.g.get(k).has(h) || n.g.get(k).set(h, []), p && n.g.get(k).get(h).push(p));
                b[t] = y(l)
            }
        }
        if (f.length || g.length) a = d ? ? void 0, c.j && c.u && (d = new eg, f = Tc(d, 2, f), g = Tc(f, 3, g), a && dd(g, 1, a), f = new gg, g = G(f, 7, hg, g), vg(c.i, Eg(c, g)))
    }

    function $g(a, b) {
        b = Qg(b);
        for (let c of a) {
            a = nf(JSON.stringify(c));
            let d = Oc(a, of );
            (a = Lg(a, d)) && (b[a] || (b[a] = c))
        }
    }

    function ah() {
        return Object.keys(M(Pg).i).map(a => Number(a))
    }

    function bh(a) {
        M(Pg).u.includes(a) || Yg(Qg(4), a)
    };

    function P(a, b, c) {
        c.hasOwnProperty(a) || Object.defineProperty(c, String(a), {
            value: b
        })
    }

    function ch(a, b, c) {
        return b[a] || c
    }

    function dh(a) {
        P(5, Sg, a);
        P(6, Tg, a);
        P(7, Ug, a);
        P(8, Vg, a);
        P(17, Wg, a);
        P(13, $g, a);
        P(15, bh, a)
    }

    function eh(a) {
        P(4, b => {
            M(Jg).T = b
        }, a);
        P(9, (b, c) => {
            var d = M(Jg);
            d.T[3][b] == null && (d.T[3][b] = c)
        }, a);
        P(10, (b, c) => {
            var d = M(Jg);
            d.T[4][b] == null && (d.T[4][b] = c)
        }, a);
        P(11, (b, c) => {
            var d = M(Jg);
            d.T[5][b] == null && (d.T[5][b] = c)
        }, a);
        P(14, b => {
            var c = M(Jg);
            for (let d of [3, 4, 5]) Object.assign(c.T[d], b[d])
        }, a)
    }

    function fh(a) {
        a.hasOwnProperty("init-done") || Object.defineProperty(a, "init-done", {
            value: !0
        })
    };

    function gh(a, b, c) {
        a.i = ch(1, b, () => {});
        a.j = (d, e) => ch(2, b, () => [])(d, c, e);
        a.u = d => ch(3, b, () => [])(d ? ? c);
        a.g = d => {
            ch(16, b, () => {})(d, c)
        }
    }
    class hh {
        i() {}
        g() {}
        j() {
            return []
        }
        u() {
            return []
        }
    }

    function ih(a) {
        return M(hh).u(a)
    };

    function Ye(a, b, c, d = !1, e) {
        if ((d ? a.g : Math.random()) < (e || .01)) try {
            let f;
            c instanceof Te ? f = c : (f = new Te, rd(c, (h, k) => {
                var p = f,
                    n = p.u++;
                h = Oe(k, h);
                p.g.push(n);
                p.i[n] = h
            }));
            let g = Se(f, a.domain, a.path + b + "&");
            g && pe(q, g)
        } catch (f) {}
    }

    function jh(a, b) {
        b >= 0 && b <= 1 && (a.g = b)
    }
    var kh = class {
        constructor() {
            this.domain = "pagead2.googlesyndication.com";
            this.path = "/pagead/gen_204?id=";
            this.g = Math.random()
        }
    };
    let Xe, lh;
    const mh = new Ne(window);
    (function(a) {
        Xe = a ? ? new kh;
        typeof window.google_srt !== "number" && (window.google_srt = Math.random());
        jh(Xe, window.google_srt);
        lh = new Ze(mh);
        lh.B(() => {});
        lh.O(!0);
        window.document.readyState === "complete" ? window.google_measure_js_timing || Me(mh) : mh.g && le(window, "load", () => {
            window.google_measure_js_timing || Me(mh)
        })
    })();

    function nh(a = q) {
        var b = a.context || a.AMP_CONTEXT_DATA;
        if (!b) try {
            b = a.parent.context || a.parent.AMP_CONTEXT_DATA
        } catch {}
        return b ? .pageViewId && b ? .canonicalUrl ? b : null
    }

    function oh(a = nh()) {
        return a ? sd(a.master) ? a.master : null : null
    };
    var ph = a => {
            a = oh(nh(a)) || a;
            a.google_unique_id = (a.google_unique_id || 0) + 1;
            return a.google_unique_id
        },
        qh = a => {
            a = a.google_unique_id;
            return sb(a) ? a : 0
        },
        rh = a => {
            if (!a) return "";
            a = a.toLowerCase();
            a.substring(0, 3) != "ca-" && (a = "ca-" + a);
            return a
        };
    let sh = (new Date).getTime();
    var th = {
        mc: 0,
        lc: 1,
        hc: 2,
        ac: 3,
        jc: 4,
        bc: 5,
        kc: 6,
        ec: 7,
        fc: 8,
        Zb: 9,
        dc: 10,
        nc: 11
    };
    var uh = {
        qc: 0,
        rc: 1,
        oc: 2
    };

    function vh(a) {
        if (a.g != 0) throw Error("Already resolved/rejected.");
    }
    var yh = class {
        constructor() {
            this.i = new wh(this);
            this.g = 0
        }
        resolve(a) {
            vh(this);
            this.g = 1;
            this.u = a;
            xh(this.i)
        }
        reject(a) {
            vh(this);
            this.g = 2;
            this.j = a;
            xh(this.i)
        }
    };

    function xh(a) {
        switch (a.g.g) {
            case 0:
                break;
            case 1:
                a.i && a.i(a.g.u);
                break;
            case 2:
                a.j && a.j(a.g.j);
                break;
            default:
                throw Error("Unhandled deferred state.");
        }
    }
    var wh = class {
        constructor(a) {
            this.g = a
        }
        then(a, b) {
            if (this.i) throw Error("Then functions already set.");
            this.i = a;
            this.j = b;
            xh(this)
        }
    };
    var zh = class {
        constructor(a) {
            this.g = a.slice(0)
        }
        forEach(a) {
            this.g.forEach((b, c) => void a(b, c, this))
        }
        filter(a) {
            return new zh(La(this.g, a))
        }
        apply(a) {
            return new zh(a(this.g.slice(0)))
        }
        sort(a) {
            return new zh(this.g.slice(0).sort(a))
        }
        get(a) {
            return this.g[a]
        }
        add(a) {
            var b = this.g.slice(0);
            b.push(a);
            return new zh(b)
        }
    };

    function Ah(a, b) {
        var c = [],
            d = a.length;
        for (let e = 0; e < d; e++) c.push(a[e]);
        c.forEach(b, void 0)
    };
    var Ch = class {
        constructor() {
            this.g = {};
            this.i = {}
        }
        set(a, b) {
            var c = Bh(a);
            this.g[c] = b;
            this.i[c] = a
        }
        get(a, b) {
            a = Bh(a);
            return this.g[a] !== void 0 ? this.g[a] : b
        }
        clear() {
            this.g = {};
            this.i = {}
        }
    };

    function Bh(a) {
        return a instanceof Object ? String(ma(a)) : a + ""
    };

    function Dh(a) {
        return new Eh({
            value: a
        }, null)
    }

    function Fh(a) {
        return new Eh(null, a)
    }

    function Gh(a) {
        try {
            return Dh(a())
        } catch (b) {
            return Fh(b)
        }
    }

    function Hh(a) {
        return a.g != null ? a.getValue() : null
    }

    function Ih(a, b) {
        a.g != null && b(a.getValue());
        return a
    }

    function Jh(a, b) {
        a.g != null || b(a.i);
        return a
    }
    var Eh = class {
        constructor(a, b) {
            this.g = a;
            this.i = b
        }
        getValue() {
            return this.g.value
        }
        map(a) {
            return this.g != null ? (a = a(this.getValue()), a instanceof Eh ? a : Dh(a)) : this
        }
    };
    var Kh = class {
        constructor(a) {
            this.g = new Ch;
            if (a)
                for (let b = 0; b < a.length; ++b) this.add(a[b])
        }
        add(a) {
            this.g.set(a, !0)
        }
        contains(a) {
            return this.g.g[Bh(a)] !== void 0
        }
    };
    var Lh = class {
        constructor() {
            this.g = new Ch
        }
        set(a, b) {
            var c = this.g.get(a);
            c || (c = new Kh, this.g.set(a, c));
            c.add(b)
        }
    };
    var Mh = class extends L {
        getId() {
            return ad(this, 3)
        }
    };
    var Nh = class {
        constructor({
            ub: a,
            tc: b,
            Fc: c,
            Qb: d
        }) {
            this.g = b;
            this.u = new zh(a || []);
            this.j = d;
            this.i = c
        }
    };

    function Oh(a) {
        var b = a.length;
        if (b === 0) return 0;
        var c = 305419896;
        for (let d = 0; d < b; d++) c ^= (c << 5) + (c >> 2) + a.charCodeAt(d) & 4294967295;
        return c > 0 ? c : 4294967296 + c
    };
    const Qh = a => {
            var b = [],
                c = a.u;
            c && c.g.length && b.push({
                da: "a",
                ha: Ph(c)
            });
            a.g != null && b.push({
                da: "as",
                ha: a.g
            });
            a.i != null && b.push({
                da: "i",
                ha: String(a.i)
            });
            a.j != null && b.push({
                da: "rp",
                ha: String(a.j)
            });
            b.sort(function(d, e) {
                return d.da.localeCompare(e.da)
            });
            b.unshift({
                da: "t",
                ha: "aa"
            });
            return b
        },
        Ph = a => {
            a = a.g.slice(0).map(Rh);
            a = JSON.stringify(a);
            return Oh(a)
        },
        Rh = a => {
            var b = {};
            x(A(a, 7)) != null && (b.q = ad(a, 7));
            Xc(a, 2) != null && (b.o = Xc(a, 2, xc));
            Xc(a, 5) != null && (b.p = Xc(a, 5, xc));
            return b
        };

    function Sh(a) {
        return bd(a, 2)
    }
    var Th = class extends L {
        setLocation(a) {
            return id(this, 1, a)
        }
    };

    function Uh(a) {
        var b = [].slice.call(arguments).filter(ud(e => e === null));
        if (!b.length) return null;
        var c = [],
            d = {};
        b.forEach(e => {
            c = c.concat(e.ab || []);
            d = Object.assign(d, e.mb)
        });
        return new Vh(c, d)
    }

    function Wh(a) {
        switch (a) {
            case 1:
                return new Vh(null, {
                    google_ad_semantic_area: "mc"
                });
            case 2:
                return new Vh(null, {
                    google_ad_semantic_area: "h"
                });
            case 3:
                return new Vh(null, {
                    google_ad_semantic_area: "f"
                });
            case 4:
                return new Vh(null, {
                    google_ad_semantic_area: "s"
                });
            default:
                return null
        }
    }

    function Xh(a) {
        if (a == null) var b = null;
        else {
            b = Vh;
            var c = Qh(a);
            a = [];
            for (let d of c) c = String(d.ha), a.push(d.da + "." + (c.length <= 20 ? c : c.slice(0, 19) + "_"));
            b = new b(null, {
                google_placement_id: a.join("~")
            })
        }
        return b
    }
    var Vh = class {
        constructor(a, b) {
            this.ab = a;
            this.mb = b
        }
    };
    var Yh = new Vh(["google-auto-placed"], {
        google_reactive_ad_format: 40,
        google_tag_origin: "qs"
    });
    var Zh = od(class extends L {});

    function $h(a) {
        return D(a, Mh, 1)
    }

    function ai(a) {
        return bd(a, 2)
    }
    var bi = class extends L {};
    var ci = class extends L {};
    var di = class extends L {};

    function ei(a) {
        if (a.nodeType != 1) var b = !1;
        else if (b = a.tagName == "INS") a: {
            b = ["adsbygoogle-placeholder"];
            var c = a.className ? a.className.split(/\s+/) : [];a = {};
            for (let d = 0; d < c.length; ++d) a[c[d]] = !0;
            for (c = 0; c < b.length; ++c)
                if (!a[b[c]]) {
                    b = !1;
                    break a
                }
            b = !0
        }
        return b
    };

    function fi(a, b, c) {
        switch (c) {
            case 0:
                b.parentNode && b.parentNode.insertBefore(a, b);
                break;
            case 3:
                if (c = b.parentNode) {
                    let d = b.nextSibling;
                    if (d && d.parentNode != c)
                        for (; d && d.nodeType == 8;) d = d.nextSibling;
                    c.insertBefore(a, d)
                }
                break;
            case 1:
                b.insertBefore(a, b.firstChild);
                break;
            case 2:
                b.appendChild(a)
        }
        ei(b) && (b.setAttribute("data-init-display", b.style.display), b.style.display = "block")
    };
    var Q = class {
            constructor(a, b = !1) {
                this.g = a;
                this.defaultValue = b
            }
        },
        R = class {
            constructor(a, b = 0) {
                this.g = a;
                this.defaultValue = b
            }
        },
        gi = class {
            constructor(a, b = []) {
                this.g = a;
                this.defaultValue = b
            }
        };
    var hi = new R(619278254, 10),
        ii = new Q(1397),
        ji = new R(1359),
        ki = new R(1358),
        li = new Q(1360),
        mi = new R(1357),
        ni = new Q(1345),
        oi = new R(1130, 100),
        pi = new R(1340, .2),
        qi = new R(1338, .3),
        ri = new R(1339, .3),
        si = new Q(1337),
        ti = new class {
            constructor(a, b = "") {
                this.g = a;
                this.defaultValue = b
            }
        }(14),
        ui = new Q(1342, !0),
        vi = new Q(1344),
        wi = new Q(1399),
        xi = new R(1400),
        yi = new Q(316),
        zi = new Q(313),
        Ai = new Q(369),
        Bi = new Q(45751075),
        Ci = new Q(828567904, !0),
        Di = new gi(45736067, "ca-pub-7178919035426667 ca-pub-6430486603399192 ca-pub-6217516951440692 ca-pub-3269777183832488 ca-pub-4286071012672876 ca-pub-6893876361346206 ca-pub-6865079278713445 ca-pub-6062692039613877 ca-pub-8700401253704627 ca-pub-7409460644561046 ca-pub-1807333429605702 ca-pub-4414232724432396 ca-pub-8878716159434368 ca-pub-1725310704471587 ca-pub-7286478979881995 ca-pub-5420212072167331 ca-pub-3001544606526418 ca-pub-7647808421428026 ca-pub-6109939056400055 ca-pub-6907038225839490 ca-pub-6462695325264077 ca-pub-9260533539525355 ca-pub-9284205722386242 ca-pub-0636857377230346 ca-pub-9067164180551135 ca-pub-9649286969563355 ca-pub-6150993149788596 ca-pub-0085763304086106".split(" ")),
        Ei = new class {
            constructor(a, b = []) {
                this.g = a;
                this.defaultValue = b
            }
        }(683929765),
        Fi = new Q(839747468, !0),
        Gi = new Q(506914611),
        Hi = new R(9604),
        Ii = new R(717888910),
        Ji = new R(9605),
        Ki = new R(717888911),
        Li = new R(9606),
        Mi = new R(717888912),
        Ni = new R(9603, 4),
        Oi = new Q(711741274),
        Pi = new Q(662101537),
        Qi = new Q(834350237),
        Ri = new R(1079, 5),
        be = new gi(1934, ["AlK2UR5SkAlj8jjdEc9p3F3xuFYlF6LYjAML3EOqw1g26eCwWPjdmecULvBH5MVPoqKYrOfPhYVL71xAXI1IBQoAAAB8eyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3NTgwNjcxOTksImlzU3ViZG9tYWluIjp0cnVlfQ==",
            "Amm8/NmvvQfhwCib6I7ZsmUxiSCfOxWxHayJwyU1r3gRIItzr7bNQid6O8ZYaE1GSQTa69WwhPC9flq/oYkRBwsAAACCeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3NTgwNjcxOTksImlzU3ViZG9tYWluIjp0cnVlfQ==", "A9nrunKdU5m96PSN1XsSGr3qOP0lvPFUB2AiAylCDlN5DTl17uDFkpQuHj1AFtgWLxpLaiBZuhrtb2WOu7ofHwEAAACKeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiQUlQcm9tcHRBUElNdWx0aW1vZGFsSW5wdXQiLCJleHBpcnkiOjE3NzQzMTA0MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9",
            "A93bovR+QVXNx2/38qDbmeYYf1wdte9EO37K9eMq3r+541qo0byhYU899BhPB7Cv9QqD7wIbR1B6OAc9kEfYCA4AAACQeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiQUlQcm9tcHRBUElNdWx0aW1vZGFsSW5wdXQiLCJleHBpcnkiOjE3NzQzMTA0MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9", "A1S5fojrAunSDrFbD8OfGmFHdRFZymSM/1ss3G+NEttCLfHkXvlcF6LGLH8Mo5PakLO1sCASXU1/gQf6XGuTBgwAAACQeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXRhZ3NlcnZpY2VzLmNvbTo0NDMiLCJmZWF0dXJlIjoiQUlQcm9tcHRBUElNdWx0aW1vZGFsSW5wdXQiLCJleHBpcnkiOjE3NzQzMTA0MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9"
        ]),
        Si = new Q(84);
    var ae = class {
        constructor() {
            var a = {};
            this.j = (b, c) => a[b] != null ? a[b] : c;
            this.B = (b, c) => a[b] != null ? a[b] : c;
            this.g = (b, c) => a[b] != null ? a[b] : c;
            this.i = (b, c) => a[b] != null ? a[b] : c;
            this.u = (b, c) => a[b] != null ? c.concat(a[b]) : c;
            this.A = () => {}
        }
    };

    function S(a) {
        return M(ae).j(a.g, a.defaultValue)
    }

    function T(a) {
        return M(ae).B(a.g, a.defaultValue)
    };

    function Ti(a, b) {
        var c = e => {
                e = Ui(e);
                return e == null ? !1 : 0 < e
            },
            d = e => {
                e = Ui(e);
                return e == null ? !1 : 0 > e
            };
        switch (b) {
            case 0:
                return {
                    init: Vi(a.previousSibling, c),
                    ma: e => Vi(e.previousSibling, c),
                    sa: 0
                };
            case 2:
                return {
                    init: Vi(a.lastChild, c),
                    ma: e => Vi(e.previousSibling, c),
                    sa: 0
                };
            case 3:
                return {
                    init: Vi(a.nextSibling, d),
                    ma: e => Vi(e.nextSibling, d),
                    sa: 3
                };
            case 1:
                return {
                    init: Vi(a.firstChild, d),
                    ma: e => Vi(e.nextSibling, d),
                    sa: 3
                }
        }
        throw Error("Un-handled RelativePosition: " + b);
    }

    function Ui(a) {
        return a.hasOwnProperty("google-ama-order-assurance") ? a["google-ama-order-assurance"] : null
    }

    function Vi(a, b) {
        return a && b(a) ? a : null
    };
    var Wi = {
        overlays: 1,
        interstitials: 2,
        vignettes: 2,
        inserts: 3,
        immersives: 4,
        list_view: 5,
        full_page: 6,
        side_rails: 7
    };

    function Xi(a) {
        a = a.document;
        var b = {};
        a && (b = a.compatMode == "CSS1Compat" ? a.documentElement : a.body);
        return b || {}
    }

    function U(a) {
        return Xi(a).clientWidth ? ? void 0
    };

    function Yi(a, b) {
        do {
            let c = Ud(a, b);
            if (c && c.position === "fixed") return !1
        } while (a = a.parentElement);
        return !0
    }

    function Zi(a, b, c) {
        var d;
        return a.style && !!a.style[c] && Yd(a.style[c]) || (d = Ud(a, b)) && !!d[c] && Yd(d[c]) || null
    }

    function $i(a, b) {
        try {
            let c = b.document.documentElement.getBoundingClientRect(),
                d = a.getBoundingClientRect();
            return {
                x: d.left - c.left,
                y: d.top - c.top
            }
        } catch (c) {
            return null
        }
    }

    function aj(a, b) {
        return (a = $i(a, b)) ? a.y : 0
    }

    function bj(a, b) {
        return aj(a, b) < Xi(b).clientHeight - 100
    }

    function cj(a, b) {
        var c = Zi(b, a, "height");
        if (c) return c;
        var d = b.style.height;
        b.style.height = "inherit";
        c = Zi(b, a, "height");
        b.style.height = d;
        if (c) return c;
        c = Infinity;
        do(d = b.style && Yd(b.style.height)) && (c = Math.min(c, d)), (d = Zi(b, a, "maxHeight")) && (c = Math.min(c, d)); while (b.parentElement && (b = b.parentElement) && b.tagName !== "HTML");
        return c
    };

    function dj(a, b) {
        var c;
        return a.style && a.style.zIndex || (c = Ud(a, b)) && c.zIndex || null
    };
    var ej = {
        google_ad_channel: !0,
        google_ad_client: !0,
        google_ad_host: !0,
        google_ad_host_channel: !0,
        google_adtest: !0,
        google_tag_for_child_directed_treatment: !0,
        google_tag_for_age_treatment: !0,
        google_tag_for_under_age_of_consent: !0,
        google_tag_partner: !0,
        google_restrict_data_processing: !0,
        google_page_url: !0,
        google_debug_params: !0,
        google_adbreak_test: !0,
        google_ad_frequency_hint: !0,
        google_admob_interstitial_slot: !0,
        google_admob_rewarded_slot: !0,
        google_admob_ads_only: !0,
        google_ad_start_delay_hint: !0,
        google_max_ad_content_rating: !0,
        google_traffic_source: !0,
        google_overlays: !0,
        google_privacy_treatments: !0,
        google_special_category_data: !0,
        google_ad_intent_query: !0,
        google_ad_intent_rs_token: !0,
        google_ad_intents_format: !0,
        google_ad_intents_in_drawer_format: !0,
        google_ad_intents_encoded_verticals4_ids: !0,
        google_ad_intents_encoded_browseonomy_ids: !0,
        google_ad_intents_ad_position: !0
    };
    const fj = RegExp("(^| )adsbygoogle($| )");

    function gj(a, b) {
        for (let c = 0; c < b.length; c++) {
            let d = b[c],
                e = Id(d.property);
            a[e] = d.value
        }
    };
    var hj = class extends L {
        g() {
            return Vc(this, 1)
        }
    };
    var ij = class extends L {};
    var jj = class extends L {};
    var kj = class extends L {};
    var lj = class extends L {};
    var mj = class extends L {
            getName() {
                return ad(this, 4)
            }
        },
        nj = [1, 2, 3];
    var oj = class extends L {};
    var pj = class extends L {};
    var qj = class extends L {};
    var sj = class extends L {
            g() {
                return $c(this, qj, 2, rj)
            }
        },
        rj = [1, 2];
    var tj = class extends L {
        g() {
            return D(this, sj, 3)
        }
    };
    var uj = class extends L {},
        vj = od(uj);

    function wj(a) {
        var b = [];
        Ah(a.getElementsByTagName("p"), function(c) {
            xj(c) >= 100 && b.push(c)
        });
        return b
    }

    function xj(a) {
        if (a.nodeType == 3) return a.length;
        if (a.nodeType != 1 || a.tagName == "SCRIPT") return 0;
        var b = 0;
        Ah(a.childNodes, function(c) {
            b += xj(c)
        });
        return b
    }

    function yj(a) {
        return a.length == 0 || isNaN(a[0]) ? a : "\\" + (30 + parseInt(a[0], 10)) + " " + a.substring(1)
    }

    function zj(a, b) {
        if (a.g == null) return b;
        switch (a.g) {
            case 1:
                return b.slice(1);
            case 2:
                return b.slice(0, b.length - 1);
            case 3:
                return b.slice(1, b.length - 1);
            case 0:
                return b;
            default:
                throw Error("Unknown ignore mode: " + a.g);
        }
    }

    function Aj(a, b) {
        var c = [];
        try {
            c = b.querySelectorAll(a.u)
        } catch (d) {}
        if (!c.length) return [];
        b = Qa(c);
        b = zj(a, b);
        typeof a.i === "number" && (c = a.i, c < 0 && (c += b.length), b = c >= 0 && c < b.length ? [b[c]] : []);
        if (typeof a.j === "number") {
            c = [];
            for (let d = 0; d < b.length; d++) {
                let e = wj(b[d]),
                    f = a.j;
                f < 0 && (f += e.length);
                f >= 0 && f < e.length && c.push(e[f])
            }
            b = c
        }
        return b
    }
    var Bj = class {
        constructor(a, b, c, d) {
            this.u = a;
            this.i = b;
            this.j = c;
            this.g = d
        }
        toString() {
            return JSON.stringify({
                nativeQuery: this.u,
                occurrenceIndex: this.i,
                paragraphIndex: this.j,
                ignoreMode: this.g
            })
        }
    };
    var Cj = class {
        constructor() {
            this.i = Pd `https://pagead2.googlesyndication.com/pagead/js/err_rep.js`
        }
        K(a, b, c = .01, d = "jserror") {
            if (Math.random() > c) return !1;
            ve(b) || (b = new we(b, {
                context: a,
                id: d
            }));
            q.google_js_errors = q.google_js_errors || [];
            q.google_js_errors.push(b);
            q.error_rep_loaded || (Sd(q.document, this.i), q.error_rep_loaded = !0);
            return !1
        }
        g(a, b) {
            try {
                return b()
            } catch (c) {
                if (!this.K(a, c, .01, "jserror")) throw c;
            }
        }
        u(a, b) {
            return (...c) => this.g(a, () => b.apply(void 0, c))
        }
        ta(a, b) {
            b.catch(c => {
                c = c ? c : "unknown rejection";
                this.K(a, c instanceof Error ? c : Error(c), void 0)
            })
        }
    };

    function Dj(a, b) {
        b = b.google_js_reporting_queue = b.google_js_reporting_queue || [];
        b.length < 2048 && b.push(a)
    }

    function Ej(a, b, c, d, e = !1) {
        var f = d || window,
            g = typeof queueMicrotask !== "undefined";
        return function(...h) {
            e && g && queueMicrotask(() => {
                f.google_rum_task_id_counter = f.google_rum_task_id_counter || 1;
                f.google_rum_task_id_counter += 1
            });
            var k = Fe(),
                p = 3;
            try {
                var n = b.apply(this, h)
            } catch (m) {
                p = 13;
                if (!c) throw m;
                c(a, m)
            } finally {
                f.google_measure_js_timing && k && Dj({
                    label: a.toString(),
                    value: k,
                    duration: (Fe() || 0) - k,
                    type: p,
                    ...(e && g && {
                        taskId: f.google_rum_task_id_counter = f.google_rum_task_id_counter || 1
                    })
                }, f)
            }
            return n
        }
    }

    function Fj(a, b) {
        return Ej(a, b, (c, d) => {
            (new Cj).K(c, d)
        }, void 0, !1)
    };

    function Gj(a, b, c) {
        return Ej(a, b, void 0, c, !0).apply()
    }

    function Hj(a) {
        if (!a) return null;
        var b = ad(a, 7);
        if (ad(a, 1) || a.getId() || Cc(a, 4, x, C()).length > 0) {
            var c = a.getId(),
                d = ad(a, 1),
                e = Cc(a, 4, x, C());
            b = Xc(a, 2, xc);
            var f = Xc(a, 5, xc);
            a = Ij(bd(a, 6));
            let g = "";
            d && (g += d);
            c && (g += "#" + yj(c));
            if (e)
                for (c = 0; c < e.length; c++) g += "." + yj(e[c]);
            b = (e = g) ? new Bj(e, b, f, a) : null
        } else b = b ? new Bj(b, Xc(a, 2, xc), Xc(a, 5, xc), Ij(bd(a, 6))) : null;
        return b
    }
    const Jj = {
        1: 1,
        2: 2,
        3: 3,
        0: 0
    };

    function Ij(a) {
        return a == null ? a : Jj[a]
    }
    const Kj = {
        1: 0,
        2: 1,
        3: 2,
        4: 3
    };

    function Lj(a) {
        return a.google_ama_state = a.google_ama_state || {}
    }

    function Mj(a) {
        a = Lj(a);
        return a.optimization = a.optimization || {}
    };
    var Nj = a => {
        switch (bd(a, 8)) {
            case 1:
            case 2:
                if (a == null) var b = null;
                else b = D(a, Mh, 1), b == null ? b = null : (a = bd(a, 2), b = a == null ? null : new Nh({
                    ub: [b],
                    Qb: a
                }));
                return b != null ? Dh(b) : Fh(Error("Missing dimension when creating placement id"));
            case 3:
                return Fh(Error("Missing dimension when creating placement id"));
            default:
                return b = "Invalid type: " + bd(a, 8), Fh(Error(b))
        }
    };
    var Oj = od(class extends L {});

    function lg() {
        return "m202605130101"
    };
    var Pj = nd(ig);
    var kg = nd(mg);

    function Qj(a, b) {
        return b(a) ? a : void 0
    }

    function Rj(a, b, c, d, e) {
        c = c instanceof we ? c.error : c;
        var f = new pg,
            g = new og;
        try {
            var h = ce(window);
            ed(g, 1, h)
        } catch (l) {}
        try {
            var k = ih();
            Ic(g, 2, k, Tb)
        } catch (l) {}
        try {
            hd(g, 3, window.document.URL)
        } catch (l) {}
        h = F(f, 2, g);
        k = new ng;
        b = jd(k, 1, b);
        try {
            var p = w(c ? .name) ? c.name : "Unknown error";
            hd(b, 2, p)
        } catch (l) {}
        try {
            var n = w(c ? .message) ? c.message : `Caught ${c}`;
            hd(b, 3, n)
        } catch (l) {}
        try {
            var m = w(c ? .stack) ? c.stack : Error().stack;
            m && Ic(b, 4, m.split(/\n\s*/), ac)
        } catch (l) {}
        p = G(h, 1, qg, b);
        if (e) {
            n = 0;
            switch (e.errSrc) {
                case "LCC":
                    n = 1;
                    break;
                case "PVC":
                    n = 2
            }
            m = jg();
            b = Qj(e.shv, w);
            m = hd(m, 2, b);
            n = jd(m, 6, n);
            m = Pj();
            m = rc(m);
            b = Qj(e.es, wb());
            m = Ic(m, 1, b, Tb);
            m = sc(m);
            n = F(n, 4, m);
            m = Qj(e.client, w);
            n = gd(n, 3, m);
            m = Qj(e.slotname, w);
            n = hd(n, 7, m);
            e = Qj(e.tag_origin, w);
            e = hd(n, 8, e);
            e = sc(e)
        } else e = ld(jg());
        e = G(p, 6, rg, e);
        d = ed(e, 5, d ? ? 1);
        tg(a, d)
    };
    var Tj = class {
        constructor() {
            this.g = Sj
        }
    };

    function Sj() {
        return {
            Nb: Nd() + (Nd() & 2 ** 21 - 1) * 2 ** 32,
            Ab: Number.MAX_SAFE_INTEGER
        }
    };
    var Wj = class {
        constructor(a = !1) {
            var b = Uj;
            this.G = Vj;
            this.A = a;
            this.H = b;
            this.i = null;
            this.j = this.K
        }
        N(a) {
            this.j = a
        }
        B(a) {
            this.i = a
        }
        O() {}
        g(a, b, c) {
            try {
                var d = b()
            } catch (e) {
                b = this.A;
                try {
                    b = this.j(a, xe(e), void 0, c)
                } catch (f) {
                    this.K(217, f)
                }
                if (b) window.console ? .error ? .(e);
                else throw e;
            }
            return d
        }
        u(a, b) {
            return (...c) => this.g(a, () => b.apply(void 0, c))
        }
        ta(a, b) {
            b.catch(c => {
                c = c ? c : "unknown rejection";
                this.K(a, c instanceof Error ? c : Error(c), void 0, void 0)
            })
        }
        K(a, b, c, d) {
            try {
                let g = c === void 0 ? 1 / this.H : c === 0 ? 0 : 1 / c;
                var e = (new Tj).g();
                if (g > 0 && e.Nb * g <= e.Ab) {
                    var f = this.G;
                    c = {};
                    if (this.i) try {
                        this.i(c)
                    } catch (h) {}
                    if (d) try {
                        d(c)
                    } catch (h) {}
                    Rj(f, a, b, g, c)
                }
            } catch (g) {}
            return this.A
        }
    };
    var W = class extends Error {
        constructor(a = "") {
            super();
            this.name = "TagError";
            this.message = a ? "adsbygoogle.push() error: " + a : "";
            Error.captureStackTrace ? Error.captureStackTrace(this, W) : this.stack = Error().stack || ""
        }
    };
    let Vj, Xj, Yj, Zj, Uj;
    const ak = new Ne(q);

    function bk(a) {
        a != null && (q.google_measure_js_timing = a);
        q.google_measure_js_timing || Me(ak)
    }(function(a, b, c = !0) {
        ({
            Pb: Uj,
            Eb: Yj
        } = ck());
        Xj = a || new kh;
        jh(Xj, Yj);
        Vj = b || new Dg(2, lg(), 1E3, void 0, void 0, void 0, ih);
        Zj = new Wj(c);
        q.document.readyState === "complete" ? bk() : ak.g && le(q, "load", () => {
            bk()
        })
    })();

    function dk(a, b, c) {
        return Zj.g(a, b, c)
    }

    function ek(a, b) {
        return Zj.u(a, b)
    }

    function fk(a, b) {
        Zj.ta(a, b)
    }

    function gk(a, b, c = .01) {
        var d = ih();
        !b.eid && d.length && (b.eid = d.toString());
        Ye(Xj, a, b, !0, c)
    }

    function hk(a, b, c = Uj, d, e) {
        return Zj.K(a, b, c, d, e)
    }

    function ik(a, b, c = Uj, d, e) {
        return (ve(b) ? b.msg || ye(b.error) : ye(b)).indexOf("TagError") === 0 ? ((ve(b) ? b.error : b).pbr = !0, !1) : hk(a, b, c, d, e)
    }

    function ck() {
        if (sb(q.google_srt)) {
            var a = q.google_srt;
            var b = q.google_srt === 0 ? 1 : .01
        } else a = Math.random(), b = .01;
        return {
            Pb: b,
            Eb: a
        }
    };

    function jk(a) {
        try {
            var b = a.localStorage.getItem("google_auto_fc_cmp_setting") || null
        } catch (d) {
            b = null
        }
        var c = b;
        return c ? Gh(() => Oj(c)) : Dh(null)
    };

    function kk() {
        if (lk) return lk;
        var a = oh() || window;
        var b = a.google_persistent_state_async;
        return b != null && typeof b == "object" && b.S != null && typeof b.S == "object" ? lk = b : a.google_persistent_state_async = lk = new mk
    }

    function nk(a) {
        return ok[a] || `google_ps_${a}`
    }

    function pk(a, b, c) {
        b = nk(b);
        a = a.S;
        var d = a[b];
        return d === void 0 ? (a[b] = c(), a[b]) : d
    }

    function qk(a, b, c) {
        return pk(a, b, () => c)
    }
    var mk = class {
            constructor() {
                this.S = {}
            }
        },
        lk = null;
    const ok = {
        [8]: "google_prev_ad_formats_by_region",
        [9]: "google_prev_ad_slotnames_by_region"
    };

    function rk(a) {
        this.g = a || {
            cookie: ""
        }
    }
    rk.prototype.set = function(a, b, c) {
        var d = !1;
        if (typeof c === "object") {
            var e = c.sameSite;
            d = c.secure || !1;
            var f = c.domain || void 0;
            var g = c.path || void 0;
            var h = c.Kb
        }
        if (/[;=\s]/.test(a)) throw Error('Invalid cookie name "' + a + '"');
        if (/[;\r\n]/.test(b)) throw Error('Invalid cookie value "' + b + '"');
        h === void 0 && (h = -1);
        this.g.cookie = a + "=" + b + (f ? ";domain=" + f : "") + (g ? ";path=" + g : "") + (h < 0 ? "" : h == 0 ? ";expires=" + (new Date(1970, 1, 1)).toUTCString() : ";expires=" + (new Date(Date.now() + h * 1E3)).toUTCString()) + (d ? ";secure" : "") + (e != null ?
            ";samesite=" + e : "")
    };
    rk.prototype.get = function(a, b) {
        var c = a + "=",
            d = (this.g.cookie || "").split(";");
        for (let e = 0, f; e < d.length; e++) {
            f = ua(d[e]);
            if (f.lastIndexOf(c, 0) == 0) return f.slice(c.length);
            if (f == a) return ""
        }
        return b
    };
    rk.prototype.isEmpty = function() {
        return !this.g.cookie
    };
    rk.prototype.clear = function() {
        var a = (this.g.cookie || "").split(";"),
            b = [],
            c = [];
        for (let f = 0; f < a.length; f++) {
            var d = ua(a[f]);
            var e = d.indexOf("=");
            e == -1 ? (b.push(""), c.push(d)) : (b.push(d.substring(0, e)), c.push(d.substring(e + 1)))
        }
        for (c = b.length - 1; c >= 0; c--) a = b[c], this.get(a), this.set(a, "", {
            Kb: 0,
            path: void 0,
            domain: void 0
        })
    };

    function sk(a, b = window) {
        if (H(a, 5)) try {
            return b.localStorage
        } catch {}
        return null
    };

    function tk(a) {
        var b = new uk;
        return zc(b, 5, Ob(a))
    }
    var uk = class extends L {};

    function vk() {
        this.B = this.B;
        this.i = this.i
    }
    vk.prototype.B = !1;
    vk.prototype.dispose = function() {
        this.B || (this.B = !0, this.G())
    };
    vk.prototype[fa(Symbol, "dispose")] = function() {
        this.dispose()
    };

    function wk(a, b) {
        a.B ? b() : (a.i || (a.i = []), a.i.push(b))
    }
    vk.prototype.G = function() {
        if (this.i)
            for (; this.i.length;) this.i.shift()()
    };

    function xk(a) {
        a.addtlConsent === void 0 || w(a.addtlConsent) || (a.addtlConsent = void 0);
        a.gdprApplies === void 0 || tb(a.gdprApplies) || (a.gdprApplies = void 0);
        return a.tcString !== void 0 && !w(a.tcString) || a.listenerId !== void 0 && !sb(a.listenerId) ? 2 : a.cmpStatus && a.cmpStatus !== "error" ? 0 : 3
    }

    function yk(a) {
        if (a.gdprApplies === !1) return !0;
        a.internalErrorState === void 0 && (a.internalErrorState = xk(a));
        return a.cmpStatus === "error" || a.internalErrorState !== 0 ? a.internalBlockOnErrors ? (re({
            e: String(a.internalErrorState)
        }, "tcfe"), !1) : !0 : a.cmpStatus !== "loaded" || a.eventStatus !== "tcloaded" && a.eventStatus !== "useractioncomplete" ? !1 : !0
    }

    function zk(a) {
        if (a.g) return a.g;
        a: {
            let d = a.j;
            for (let e = 0; e < 50; ++e) {
                try {
                    var b = !(!d.frames || !d.frames.__tcfapiLocator)
                } catch {
                    b = !1
                }
                if (b) {
                    b = d;
                    break a
                }
                b: {
                    try {
                        let f = d.parent;
                        if (f && f !== d) {
                            var c = f;
                            break b
                        }
                    } catch {}
                    c = null
                }
                if (!(d = c)) break
            }
            b = null
        }
        a.g = b;
        return a.g
    }

    function Ak(a, b, c, d) {
        c || (c = () => {});
        var e = a.j;
        typeof e.__tcfapi === "function" ? (a = e.__tcfapi, a(b, 2, c, d)) : zk(a) ? (Bk(a), e = ++a.H, a.A[e] = c, a.g && a.g.postMessage({
            __tcfapiCall: {
                command: b,
                version: 2,
                callId: e,
                parameter: d
            }
        }, "*")) : c({}, !1)
    }

    function Bk(a) {
        if (!a.u) {
            var b = c => {
                try {
                    var d = (w(c.data) ? JSON.parse(c.data) : c.data).__tcfapiReturn;
                    a.A[d.callId](d.returnValue, d.success)
                } catch (e) {}
            };
            a.u = b;
            le(a.j, "message", b)
        }
    }
    var Ck = class extends vk {
        constructor(a) {
            var b = {};
            super();
            this.g = null;
            this.A = {};
            this.H = 0;
            this.u = null;
            this.j = a;
            this.ja = b.ja ? ? 500;
            this.xa = b.xa ? ? !1
        }
        G() {
            this.A = {};
            this.u && (me(this.j, "message", this.u), delete this.u);
            delete this.A;
            delete this.j;
            delete this.g;
            super.G()
        }
        addEventListener(a) {
            var b = {
                    internalBlockOnErrors: this.xa
                },
                c = wd(() => {
                    a(b)
                }),
                d = 0;
            this.ja !== -1 && (d = setTimeout(() => {
                b.tcString = "tcunavailable";
                b.internalErrorState = 1;
                c()
            }, this.ja));
            var e = (f, g) => {
                clearTimeout(d);
                f ? (b = f, b.internalErrorState = xk(b),
                    b.internalBlockOnErrors = this.xa, g && b.internalErrorState === 0 || (b.tcString = "tcunavailable", g || (b.internalErrorState = 3))) : (b.tcString = "tcunavailable", b.internalErrorState = 3);
                a(b)
            };
            try {
                Ak(this, "addEventListener", e)
            } catch (f) {
                b.tcString = "tcunavailable", b.internalErrorState = 3, d && (clearTimeout(d), d = 0), c()
            }
        }
        removeEventListener(a) {
            a && a.listenerId && Ak(this, "removeEventListener", null, a.listenerId)
        }
    };
    var Hk = ({
            l: a,
            ca: b,
            ja: c,
            yb: d,
            na: e = !1,
            oa: f = !1
        }) => {
            b = Dk({
                l: a,
                ca: b,
                na: e,
                oa: f
            });
            b.g != null || b.i.message != "tcunav" ? d(b) : Ek(a, c).then(g => g.map(Fk)).then(g => g.map(h => Gk(a, h))).then(d)
        },
        Dk = ({
            l: a,
            ca: b,
            na: c = !1,
            oa: d = !1
        }) => {
            if (!Ik({
                    l: a,
                    ca: b,
                    na: c,
                    oa: d
                })) return Gk(a, tk(!0));
            b = kk();
            return (b = qk(b, 24)) ? Gk(a, Fk(b)) : Fh(Error("tcunav"))
        };

    function Ik({
        l: a,
        ca: b,
        na: c,
        oa: d
    }) {
        if (d = !d) d = new Ck(a), d = typeof d.j.__tcfapi === "function" || zk(d) != null;
        if (!d) {
            if (c = !c) {
                if (b) {
                    a = jk(a);
                    if (a.g != null)
                        if ((a = a.getValue()) && Sb(A(a, 1)) != null) b: switch (a = K(a, 1), a) {
                            case 1:
                                a = !0;
                                break b;
                            default:
                                throw Error("Unhandled AutoGdprFeatureStatus: " + a);
                        } else a = !1;
                        else hk(806, a.i), a = !1;
                    b = !a
                }
                c = b
            }
            d = c
        }
        return d ? !0 : !1
    }

    function Ek(a, b) {
        return Promise.race([Jk(), Kk(a, b)])
    }

    function Jk() {
        return (new Promise(a => {
            var b = kk();
            a = {
                resolve: a
            };
            var c = qk(b, 25, []);
            c.push(a);
            b.S[nk(25)] = c
        })).then(Lk)
    }

    function Kk(a, b) {
        return new Promise(c => {
            a.setTimeout(c, b, Fh(Error("tcto")))
        })
    }

    function Lk(a) {
        return a ? Dh(a) : Fh(Error("tcnull"))
    }

    function Fk(a) {
        var b = {};
        if (yk(a))
            if (a.gdprApplies === !1) a = !0;
            else if (a.tcString === "tcunavailable") a = !b.fb;
        else if ((b.fb || a.gdprApplies !== void 0 || b.wc) && (b.fb || w(a.tcString) && a.tcString.length)) {
            b: {
                if (a.publisher && a.publisher.restrictions && (b = a.publisher.restrictions["1"], b !== void 0)) {
                    b = b["755"];
                    break b
                }
                b = void 0
            }
            b === 0 ? a = !1 : a.purpose && a.vendor ? (b = a.vendor.consents, (b = !(!b || !b["755"])) && a.purposeOneTreatment && a.publisherCC === "CH" ? a = !0 : (b && (a = a.purpose.consents, b = !(!a || !a["1"])), a = b)) : a = !0
        }
        else a = !0;
        else a = !1;
        return tk(a)
    }

    function Gk(a, b) {
        return (a = sk(b, a)) ? Dh(a) : Fh(Error("unav"))
    };
    var Mk = (a, b) => {
        var c = [],
            d = a;
        for (a = () => {
                c.push({
                    anchor: d.anchor,
                    position: d.position
                });
                return d.anchor == b.anchor && d.position == b.position
            }; d;) {
            switch (d.position) {
                case 1:
                    if (a()) return c;
                    d.position = 2;
                case 2:
                    if (a()) return c;
                    if (d.anchor.firstChild) {
                        d = {
                            anchor: d.anchor.firstChild,
                            position: 1
                        };
                        continue
                    } else d.position = 3;
                case 3:
                    if (a()) return c;
                    d.position = 4;
                case 4:
                    if (a()) return c
            }
            for (; d && !d.anchor.nextSibling && d.anchor.parentNode != d.anchor.ownerDocument.body;) {
                d = {
                    anchor: d.anchor.parentNode,
                    position: 3
                };
                if (a()) return c;
                d.position = 4;
                if (a()) return c
            }
            d && d.anchor.nextSibling ? d = {
                anchor: d.anchor.nextSibling,
                position: 1
            } : d = null
        }
        return c
    };

    function Nk(a, b) {
        var c = new Lh,
            d = new Kh;
        b.forEach(e => {
            if ($c(e, kj, 1, nj)) {
                e = $c(e, kj, 1, nj);
                if (D(e, bi, 1) && $h(D(e, bi, 1)) && D(e, bi, 2) && $h(D(e, bi, 2))) {
                    let g = Ok(a, $h(D(e, bi, 1))),
                        h = Ok(a, $h(D(e, bi, 2)));
                    if (g && h)
                        for (var f of Mk({
                                anchor: g,
                                position: ai(D(e, bi, 1))
                            }, {
                                anchor: h,
                                position: ai(D(e, bi, 2))
                            })) c.set(ma(f.anchor), f.position)
                }
                D(e, bi, 3) && $h(D(e, bi, 3)) && (f = Ok(a, $h(D(e, bi, 3)))) && c.set(ma(f), ai(D(e, bi, 3)))
            } else $c(e, lj, 2, nj) ? Pk(a, $c(e, lj, 2, nj), c) : $c(e, jj, 3, nj) && Qk(a, $c(e, jj, 3, nj), d)
        });
        return new Rk(c, d)
    }
    var Rk = class {
        constructor(a, b) {
            this.i = a;
            this.g = b
        }
    };
    const Pk = (a, b, c) => {
            D(b, bi, 2) ? (b = D(b, bi, 2), (a = Ok(a, $h(b))) && c.set(ma(a), ai(b))) : D(b, Mh, 1) && (a = Sk(a, D(b, Mh, 1))) && a.forEach(d => {
                d = ma(d);
                c.set(d, 1);
                c.set(d, 4);
                c.set(d, 2);
                c.set(d, 3)
            })
        },
        Qk = (a, b, c) => {
            D(b, Mh, 1) && (a = Sk(a, D(b, Mh, 1))) && a.forEach(d => {
                c.add(ma(d))
            })
        },
        Ok = (a, b) => (a = Sk(a, b)) && a.length > 0 ? a[0] : null,
        Sk = (a, b) => (b = Hj(b)) ? Aj(b, a) : null;
    var Tk = class {
        constructor() {
            var a = Math.random;
            this.g = Math.floor(a() * 2 ** 52);
            this.i = 0
        }
    };

    function Uk(a, b, c) {
        switch (c) {
            case 2:
            case 3:
                break;
            case 1:
            case 4:
                b = b.parentElement;
                break;
            default:
                throw Error("Unknown RelativePosition: " + c);
        }
        for (c = []; b;) {
            if (Vk(b)) return !0;
            if (a.g.has(b)) break;
            c.push(b);
            b = b.parentElement
        }
        c.forEach(d => a.g.add(d));
        return !1
    }

    function Wk(a) {
        a = Xk(a);
        return a.has("all") || a.has("after")
    }

    function Yk(a) {
        a = Xk(a);
        return a.has("all") || a.has("before")
    }

    function Xk(a) {
        return (a = a && a.getAttribute("data-no-auto-ads")) ? new Set(a.split("|")) : new Set
    }

    function Vk(a) {
        var b = Xk(a);
        return a && (a.tagName === "AUTO-ADS-EXCLUSION-AREA" || b.has("inside") || b.has("all"))
    }
    var Zk = class {
        constructor() {
            this.g = new Set;
            this.i = new Tk
        }
    };

    function $k(a, b) {
        if (!a) return !1;
        a = Ud(a, b);
        if (!a) return !1;
        a = a.cssFloat || a.styleFloat;
        return a == "left" || a == "right"
    }

    function al(a) {
        for (a = a.previousSibling; a && a.nodeType != 1;) a = a.previousSibling;
        return a ? a : null
    }

    function bl(a) {
        return !!a.nextSibling || !!a.parentNode && bl(a.parentNode)
    };

    function cl(a = []) {
        var b = Date.now();
        return La(a, c => b - c < 6E5)
    }

    function dl(a) {
        try {
            let b = a.getItem("__lsa__");
            if (!b) return [];
            let c;
            try {
                c = JSON.parse(b)
            } catch (d) {}
            if (!Array.isArray(c) || Na(c, d => !Number.isInteger(d))) return a.removeItem("__lsa__"), [];
            c = cl(c);
            c.length || a ? .removeItem("__lsa__");
            return c
        } catch (b) {
            return null
        }
    };

    function el(a = null) {
        ({
            googletag: a
        } = a ? ? window);
        return a ? .apiReady ? a : void 0
    };

    function fl(a) {
        return {
            sc: gl(a),
            uc: X(a, "body ins.adsbygoogle"),
            rb: hl(a),
            sb: X(a, ".google-auto-placed"),
            tb: il(a),
            Bb: jl(a),
            yc: kl(a),
            Hc: ll(a),
            Mb: ml(a),
            xc: X(a, "div.googlepublisherpluginad"),
            Xb: X(a, "html > ins.adsbygoogle")
        }
    }

    function kl(a) {
        return nl(a) || X(a, "div[id^=div-gpt-ad]")
    }

    function nl(a) {
        var b = el(a);
        return b ? La(Ma(b.pubads().getSlots(), c => a.document.getElementById(c.getSlotElementId())), c => c != null) : null
    }

    function X(a, b) {
        return Qa(a.document.querySelectorAll(b))
    }

    function il(a) {
        return X(a, "ins.adsbygoogle[data-anchor-status]")
    }

    function hl(a) {
        return X(a, "iframe[id^=aswift_],iframe[id^=google_ads_frame]")
    }

    function ll(a) {
        return X(a, "ins.adsbygoogle[data-ad-format=autorelaxed]")
    }

    function jl(a) {
        return kl(a).concat(X(a, "iframe[id^=google_ads_iframe]"))
    }

    function ml(a) {
        return X(a, "div.trc_related_container,div.OUTBRAIN,div[id^=rcjsload],div[id^=ligatusframe],div[id^=crt-],iframe[id^=cto_iframe],div[id^=yandex_], div[id^=Ya_sync],iframe[src*=adnxs],div.advertisement--appnexus,div[id^=apn-ad],div[id^=amzn-native-ad],iframe[src*=amazon-adsystem],iframe[id^=ox_],iframe[src*=openx],img[src*=openx],div[class*=adtech],div[id^=adtech],iframe[src*=adtech],div[data-content-ad-placement=true],div.wpcnt div[id^=atatags-]")
    }

    function gl(a) {
        return X(a, "ins.adsbygoogle-ablated-ad-slot")
    }

    function ol(a) {
        return a.filter(b => !b.querySelector('[data-google-ad-efd="true"]'))
    }

    function pl(a) {
        var b = [];
        for (let c of a) {
            a = !0;
            for (let d = 0; d < b.length; d++) {
                let e = b[d];
                if (e.contains(c)) {
                    a = !1;
                    break
                }
                if (c.contains(e)) {
                    a = !1;
                    b[d] = c;
                    break
                }
            }
            a && b.push(c)
        }
        return b
    };

    function ql(a, b) {
        if (a.u) return !0;
        a.u = !0;
        var c = E(a.j, di, 1, C());
        a.i = 0;
        var d = rl(a.N);
        var e = a.g,
            f = H(a.j, 36),
            g = a.H,
            h;
        try {
            var k = (h = e.localStorage.getItem("google_ama_settings")) ? Zh(h) : null
        } catch (z) {
            k = null
        }
        h = k !== null && H(k, 2);
        k = Lj(e);
        h && (k.eatf = !0, ue(7, [!0, 0, !1]));
        b: {
            h = {
                Gb: !1,
                Hb: !1,
                Cb: !0
            };
            var p = X(e, ".google-auto-placed");
            let z = il(e),
                N = ll(e),
                ya = jl(e),
                Ra = ml(e),
                ob = gl(e),
                Ba = X(e, "div.googlepublisherpluginad"),
                Ib = X(e, "html > ins.adsbygoogle");
            var n = [].concat(...hl(e), ...X(e, "body ins.adsbygoogle")),
                m = [];h.Cb &&
            (m = m.concat(X(e, "ins.adsbygoogle[data-ad-hi]")));
            for (let [mc, Ie] of [
                    [h.Ac, p],
                    [h.Gb, z],
                    [h.Dc, N],
                    [h.Bc, ya],
                    [h.Ec, Ra],
                    [h.zc, ob],
                    [h.Cc, Ba],
                    [h.Hb, Ib]
                ]) p = Ie,
            mc === !1 ? m = m.concat(p) : n = n.concat(p);n = pl(n);m = pl(m);n = n.slice(0);
            for (l of m)
                for (m = 0; m < n.length; m++)(l.contains(n[m]) || n[m].contains(l)) && n.splice(m, 1);
            var l = n;l = h.vc ? ol(l) : l;h = Xi(e).clientHeight;
            for (m = 0; m < l.length; m++)
                if (!(l[m].getBoundingClientRect().top > h)) {
                    l = !0;
                    break b
                }
            l = !1
        }
        if (l) var t = k.eatfAbg = !0;
        else if (S(Bi) && f) {
            e = Dk({
                l: e,
                ca: g
            });
            if (f = e.g != null) {
                e =
                    Hh(e);
                if (!(f = e == null)) {
                    try {
                        e.setItem("__storage_test__", "__storage_test__");
                        var v = e.getItem("__storage_test__");
                        e.removeItem("__storage_test__");
                        t = v === "__storage_test__"
                    } catch (z) {
                        t = !1
                    }
                    f = !t
                }
                t = f ? null : dl(e);
                v = T(hi);
                f = !(t ? .length && Math.floor((Date.now() - Math.max(...t)) / 6E4) <= v)
            }
            t = f
        } else t = !1;
        if (t) return !0;
        t = new Kh([2]);
        for (v = 0; v < c.length; v++) {
            a: {
                e = a;g = c[v];f = v;k = b;
                (l = !D(g, Th, 4)) || (l = t, h = l.contains, m = D(g, Th, 4), m = bd(m, 1), l = !h.call(l, m));
                if (l || bd(g, 8) !== 1 || !sl(g, d)) {
                    e = null;
                    break a
                }
                e.i++;
                if (k = tl(e, g, k, d)) l =
                    Lj(e.g),
                l.numAutoAdsPlaced || (l.numAutoAdsPlaced = 0),
                (h = !D(g, Mh, 1)) || (g = D(g, Mh, 1), h = Xc(g, 5) == null),
                h || (l.numPostPlacementsPlaced ? l.numPostPlacementsPlaced++ : l.numPostPlacementsPlaced = 1),
                l.placed == null && (l.placed = []),
                l.numAutoAdsPlaced++,
                l.placed.push({
                    index: f,
                    element: k.ka
                }),
                ue(7, [!1, e.i, !0]);e = k
            }
            if (e) return !0
        }
        ue(7, [!1, a.i, !1]);
        return !1
    }

    function tl(a, b, c, d) {
        if (!sl(b, d) || Sb(A(b, 8)) != 1) return null;
        d = D(b, Mh, 1);
        if (!d) return null;
        d = Hj(d);
        if (!d) return null;
        d = Aj(d, a.g.document);
        if (d.length == 0) return null;
        d = d[0];
        var e = bd(b, 2);
        e = Kj[e];
        e = e === void 0 ? null : e;
        var f;
        if (!(f = e == null)) {
            a: {
                f = a.g;
                switch (e) {
                    case 0:
                        f = $k(al(d), f);
                        break a;
                    case 3:
                        f = $k(d, f);
                        break a;
                    case 2:
                        var g = d.lastChild;
                        f = $k(g ? g.nodeType == 1 ? g : al(g) : null, f);
                        break a
                }
                f = !1
            }
            if (c = !f && !(!c && e == 2 && !bl(d))) c = e == 1 || e == 2 ? d : d.parentNode,
            c = !(c && !ei(c) && c.offsetWidth <= 0);f = !c
        }
        if (!(c = f)) {
            c = a.A;
            f = bd(b,
                2);
            g = c.i;
            var h = ma(d);
            g = g.g.get(h);
            if (!(g = g ? g.contains(f) : !1)) a: {
                if (c.g.contains(ma(d))) switch (f) {
                    case 2:
                    case 3:
                        g = !0;
                        break a;
                    default:
                        g = !1;
                        break a
                }
                for (f = d.parentElement; f;) {
                    if (c.g.contains(ma(f))) {
                        g = !0;
                        break a
                    }
                    f = f.parentElement
                }
                g = !1
            }
            c = g
        }
        if (!c) {
            c = a.G;
            g = bd(b, 2);
            a: switch (g) {
                case 1:
                    f = Wk(d.previousElementSibling) || Yk(d);
                    break a;
                case 4:
                    f = Wk(d) || Yk(d.nextElementSibling);
                    break a;
                case 2:
                    f = Yk(d.firstElementChild);
                    break a;
                case 3:
                    f = Wk(d.lastElementChild);
                    break a;
                default:
                    throw Error("Unknown RelativePosition: " +
                        g);
            }
            g = Uk(c, d, g);
            c = c.i;
            gk("ama_exclusion_zone", {
                typ: f ? g ? "siuex" : "siex" : g ? "suex" : "noex",
                cor: c.g,
                num: c.i++,
                dvc: Jd()
            }, .1);
            c = f || g
        }
        if (c) return null;
        f = D(b, ci, 3);
        c = {};
        f && (c.pb = ad(f, 1), c.Ya = ad(f, 2), c.zb = !!Wc(f, 3, xc));
        f = D(b, Th, 4) && Sh(D(b, Th, 4)) ? Sh(D(b, Th, 4)) : null;
        f = Wh(f);
        g = Xc(b, 12) != null ? Xc(b, 12, xc) : null;
        g = g == null ? null : new Vh(null, {
            google_ml_rank: g
        });
        b = ul(a, b);
        b = Uh(a.B, f, g, b);
        f = a.g;
        a = a.O;
        h = f.document;
        var k = c.zb || !1;
        g = je((new ke(h)).g, "DIV");
        var p = g.style;
        p.width = "100%";
        p.height = "auto";
        p.clear = k ? "both" : "none";
        k = g.style;
        k.textAlign = "center";
        c.Ob && gj(k, c.Ob);
        h = je((new ke(h)).g, "INS");
        k = h.style;
        k.display = "block";
        k.margin = "auto";
        k.backgroundColor = "transparent";
        c.pb && (k.marginTop = c.pb);
        c.Ya && (k.marginBottom = c.Ya);
        c.qb && gj(k, c.qb);
        g.appendChild(h);
        c = {
            Aa: g,
            ka: h
        };
        c.ka.setAttribute("data-ad-format", "auto");
        g = [];
        if (h = b && b.ab) c.Aa.className = h.join(" ");
        h = c.ka;
        h.className = "adsbygoogle";
        h.setAttribute("data-ad-client", a);
        g.length && h.setAttribute("data-ad-channel", g.join("+"));
        a: {
            try {
                var n = c.Aa;
                if (S(zi)) {
                    {
                        let z = Ti(d,
                            e);
                        if (z.init) {
                            var m = z.init;
                            for (d = m; d = z.ma(d);) m = d;
                            var l = {
                                anchor: m,
                                position: z.sa
                            }
                        } else l = {
                            anchor: d,
                            position: e
                        }
                    }
                    n["google-ama-order-assurance"] = 0;
                    fi(n, l.anchor, l.position)
                } else fi(n, d, e);
                b: {
                    var t = c.ka;t.dataset.adsbygoogleStatus = "reserved";t.className += " adsbygoogle-noablate";n = {
                        element: t
                    };
                    var v = b && b.mb;
                    if (t.hasAttribute("data-pub-vars")) {
                        try {
                            v = JSON.parse(t.getAttribute("data-pub-vars"))
                        } catch (z) {
                            break b
                        }
                        t.removeAttribute("data-pub-vars")
                    }
                    v && (n.params = v);
                    (f.adsbygoogle = f.adsbygoogle || []).push(n)
                }
            } catch (z) {
                (t =
                    c.Aa) && t.parentNode && (v = t.parentNode, v.removeChild(t), ei(v) && (v.style.display = v.getAttribute("data-init-display") || "none"));
                t = !1;
                break a
            }
            t = !0
        }
        return t ? c : null
    }

    function ul(a, b) {
        return Hh(Jh(Nj(b).map(Xh), c => {
            Lj(a.g).exception = c
        }))
    }
    var vl = class {
        constructor(a, b, c, d, e, f = !1) {
            this.g = a;
            this.O = b;
            this.j = c;
            this.B = e || null;
            this.H = f;
            (this.N = d) ? (a = a.document, d = E(d, mj, 5, C()), d = Nk(a, d)) : d = Nk(a.document, []);
            this.A = d;
            this.G = new Zk;
            this.i = 0;
            this.u = !1
        }
    };

    function rl(a) {
        var b = {};
        a && Cc(a, 6, Sb, C()).forEach(c => {
            b[c] = !0
        });
        return b
    }

    function sl(a, b) {
        return a && Ac(a, Th, 4) && b[Sh(D(a, Th, 4))] ? !1 : !0
    };
    var wl = class extends L {};
    var xl = class extends L {};
    var yl = class {
        constructor(a) {
            this.exception = a
        }
    };

    function zl(a, b) {
        try {
            var c = a.i,
                d = c.resolve,
                e = a.g;
            Lj(e.g);
            E(e.j, di, 1, C());
            d.call(c, new yl(b))
        } catch (f) {
            a.i.reject(f)
        }
    }
    var Al = class {
        constructor(a, b, c) {
            this.j = a;
            this.g = b;
            this.i = c
        }
        start() {
            this.u()
        }
        u() {
            try {
                switch (this.j.document.readyState) {
                    case "complete":
                    case "interactive":
                        ql(this.g, !0);
                        zl(this);
                        break;
                    default:
                        ql(this.g, !1) ? zl(this) : this.j.setTimeout(ra(this.u, this), 100)
                }
            } catch (a) {
                zl(this, a)
            }
        }
    };
    var Bl = class extends L {
        getVersion() {
            return I(this, 2)
        }
    };

    function Cl(a) {
        return Ua(a.length % 4 !== 0 ? a + "A" : a).map(b => b.toString(2).padStart(8, "0")).join("")
    }

    function Dl(a) {
        if (!/^[0-1]+$/.test(a)) throw Error(`Invalid input [${a}] not a bit string.`);
        return parseInt(a, 2)
    }

    function El(a) {
        if (!/^[0-1]+$/.test(a)) throw Error(`Invalid input [${a}] not a bit string.`);
        var b = [1, 2, 3, 5],
            c = 0;
        for (let d = 0; d < a.length - 1; d++) b.length <= d && b.push(b[d - 1] + b[d - 2]), c += parseInt(a[d], 2) * b[d];
        return c
    };

    function Fl(a) {
        var b = Cl(a),
            c = Dl(b.slice(0, 6));
        a = Dl(b.slice(6, 12));
        var d = new Bl;
        c = dd(d, 1, c);
        a = dd(c, 2, a);
        b = b.slice(12);
        c = Dl(b.slice(0, 12));
        d = [];
        var e = b.slice(12).replace(/0+$/, "");
        for (let k = 0; k < c; k++) {
            if (e.length === 0) throw Error(`Found ${k} of ${c} sections [${d}] but reached end of input [${b}]`);
            var f = Dl(e[0]) === 0;
            e = e.slice(1);
            var g = Gl(e, b),
                h = d.length === 0 ? 0 : d[d.length - 1];
            h = El(g) + h;
            e = e.slice(g.length);
            if (f) {
                d.push(h);
                continue
            }
            f = Gl(e, b);
            g = El(f);
            for (let p = 0; p <= g; p++) d.push(h + p);
            e = e.slice(f.length)
        }
        if (e.length >
            0) throw Error(`Found ${c} sections [${d}] but has remaining input [${e}], entire input [${b}]`);
        return Ic(a, 3, d, Tb)
    }

    function Gl(a, b) {
        var c = a.indexOf("11");
        if (c === -1) throw Error(`Expected section bitstring but not found in [${a}] part of [${b}]`);
        return a.slice(0, c + 2)
    };
    var Hl = ie(th).map(a => Number(a)),
        Il = ie(uh).map(a => Number(a));

    function Jl() {
        var a = new Kl;
        return ed(a, 1, 0)
    }

    function Ll(a) {
        var b = Number;
        var c = A(a, 1, void 0, void 0, $b),
            d = typeof c;
        c != null && (d === "bigint" ? c = String(Jb(64, c)) : Qb(c) ? d === "string" ? (d = Mb(Number(c)), Kb(d) ? c = String(d) : (d = c.indexOf("."), d !== -1 && (c = c.substring(0, d)), d = c.length, (c[0] === "-" ? d < 20 || d === 20 && c <= "-9223372036854775808" : d < 19 || d === 19 && c <= "9223372036854775807") || (c.length < 16 ? Eb(Number(c)) : (c = BigInt(c), Bb = Number(c & BigInt(4294967295)) >>> 0, Cb = Number(c >> BigInt(32) & BigInt(4294967295))), c = Gb()))) : c = Zb(c) : c = void 0);
        b = b(c ? ? "0");
        a = I(a, 2);
        return new Date(b *
            1E3 + a / 1E6)
    }
    var Kl = class extends L {};

    function Ml(a) {
        if (a != null) return Nl(a)
    }

    function Nl(a) {
        return Ab(a) ? Number(a) : String(a)
    };

    function Y(a, b) {
        if (a.g + b > a.i.length) throw Error(`Requested length ${b} is past end of string.`);
        var c = a.i.substring(a.g, a.g + b);
        a.g += b;
        return parseInt(c, 2)
    }

    function Ol(a) {
        var b = () => {
            var c = Y(a, 6);
            if (c > 25 || c < 0) throw Error(`Invalid character code, expected in range [0,25], got: ${c}`);
            return String.fromCharCode(97 + c)
        };
        return b() + b()
    }

    function Pl(a) {
        for (var b = Y(a, 12), c = []; b--;) {
            var d = !!Y(a, 1) === !0,
                e = Y(a, 16);
            if (d)
                for (d = Y(a, 16); e <= d; e++) c.push(e);
            else c.push(e)
        }
        c.sort((f, g) => f - g);
        return c
    }

    function Ql(a, b, c) {
        var d = [];
        for (let e = 0; e < b; e++)
            if (Y(a, 1)) {
                let f = e + 1;
                if (c && c.indexOf(f) === -1) throw Error(`ID: ${f} is outside of allowed values!`);
                d.push(f)
            }
        return d
    }

    function Rl(a) {
        var b = Y(a, 16);
        if (!!Y(a, 1) === !0) {
            a = Pl(a);
            for (let c of a)
                if (c > b) throw Error(`ID ${c} is past MaxVendorId ${b}!`);
            return a
        }
        return Ql(a, b)
    }
    var Sl = class {
        constructor(a) {
            this.i = a;
            this.g = 0;
            if (/[^01]/.test(this.i)) throw Error(`Input bitstring ${this.i} is malformed!`);
        }
        skip(a) {
            this.g += a
        }
    };
    var Tl = class extends L {
        g() {
            return x(A(this, 2)) != null
        }
    };
    var Ul = class extends L {
        g() {
            return x(A(this, 2)) != null
        }
    };
    var Vl = class extends L {};
    var Wl = od(class extends L {});

    function Xl(a) {
        a = Yl(a);
        try {
            var b = a ? Wl(a) : null
        } catch (c) {
            b = null
        }
        return b ? D(b, Vl, 4) || null : null
    }

    function Yl(a) {
        a = a ? .location ? .origin !== "null" ? (new rk(a)).get("FCCDCF", "") : "";
        if (a)
            if (a.startsWith("%")) try {
                var b = decodeURIComponent(a)
            } catch (c) {
                b = null
            } else b = a;
            else b = null;
        return b
    };
    ie(th).map(a => Number(a));
    ie(uh).map(a => Number(a));

    function Zl(a) {
        a.__tcfapiPostMessageReady || $l(new am(a))
    }

    function $l(a) {
        a.g = b => {
            var c = typeof b.data === "string";
            try {
                var d = c ? JSON.parse(b.data) : b.data
            } catch (f) {
                return
            }
            var e = d.__tcfapiCall;
            e && (e.command === "ping" || e.command === "addEventListener" || e.command === "removeEventListener") && (0, a.l.__tcfapi)(e.command, e.version, (f, g) => {
                var h = {};
                h.__tcfapiReturn = e.command === "removeEventListener" ? {
                    success: f,
                    callId: e.callId
                } : {
                    returnValue: f,
                    success: g,
                    callId: e.callId
                };
                f = c ? JSON.stringify(h) : h;
                b.source && typeof b.source.postMessage === "function" && b.source.postMessage(f, b.origin);
                return f
            }, e.parameter)
        };
        a.l.addEventListener("message", a.g);
        a.l.__tcfapiPostMessageReady = !0
    }
    var am = class {
        constructor(a) {
            this.l = a
        }
    };

    function bm(a) {
        a.__uspapiPostMessageReady || cm(new dm(a))
    }

    function cm(a) {
        a.g = b => {
            var c = typeof b.data === "string";
            try {
                var d = c ? JSON.parse(b.data) : b.data
            } catch (f) {
                return
            }
            var e = d.__uspapiCall;
            e && e.command === "getUSPData" && a.l.__uspapi(e.command, e.version, (f, g) => {
                var h = {};
                h.__uspapiReturn = {
                    returnValue: f,
                    success: g,
                    callId: e.callId
                };
                f = c ? JSON.stringify(h) : h;
                b.source && typeof b.source.postMessage === "function" && b.source.postMessage(f, b.origin);
                return f
            })
        };
        a.l.addEventListener("message", a.g);
        a.l.__uspapiPostMessageReady = !0
    }
    var dm = class {
        constructor(a) {
            this.l = a;
            this.g = null
        }
    };
    var em = class extends L {};
    var fm = od(class extends L {
        g() {
            return x(A(this, 1)) != null
        }
    });

    function gm(a, b) {
        try {
            let c = a.split("."),
                d = Ua(c[0]).map(g => g.toString(2).padStart(8, "0")).join(""),
                e = new Sl(d);
            a = {
                tcString: a ? ? void 0,
                gdprApplies: b
            };
            e.skip(78);
            a.cmpId = Y(e, 12);
            a.cmpVersion = Y(e, 12);
            e.skip(30);
            a.tcfPolicyVersion = Y(e, 6);
            a.isServiceSpecific = !!Y(e, 1);
            a.useNonStandardStacks = !!Y(e, 1);
            a.specialFeatureOptins = hm(Ql(e, 12, Il), Il);
            a.purpose = {
                consents: hm(Ql(e, 24, Hl), Hl),
                legitimateInterests: hm(Ql(e, 24, Hl), Hl)
            };
            a.purposeOneTreatment = !!Y(e, 1);
            a.publisherCC = Ol(e);
            a.vendor = {
                consents: hm(Rl(e), null),
                legitimateInterests: hm(Rl(e),
                    null)
            };
            let f = im(c);
            f && (a.vendor.disclosedVendors = f);
            return a
        } catch (c) {
            return null
        }
    }

    function im(a) {
        a.shift();
        for (let b of a)
            if (a = Ua(b).map(c => c.toString(2).padStart(8, "0")).join(""), a = new Sl(a), Y(a, 3) === 1) return hm(Rl(a), null)
    }

    function hm(a, b) {
        var c = {};
        if (Array.isArray(b) && b.length !== 0)
            for (let d of b) c[d] = a.indexOf(d) !== -1;
        else
            for (let d of a) c[d] = !0;
        delete c[0];
        return c
    };

    function jm(a, b) {
        function c(m) {
            if (m.length < 10) return null;
            var l = h(m.slice(0, 4));
            l = k(l);
            m = h(m.slice(6, 10));
            m = p(m);
            return "1" + l + m + "N"
        }

        function d(m) {
            if (m.length < 10) return null;
            var l = h(m.slice(0, 6));
            l = k(l);
            m = h(m.slice(6, 10));
            m = p(m);
            return "1" + l + m + "N"
        }

        function e(m) {
            if (m.length < 12) return null;
            var l = h(m.slice(0, 6));
            l = k(l);
            m = h(m.slice(8, 12));
            m = p(m);
            return "1" + l + m + "N"
        }

        function f(m) {
            if (m.length < 18) return null;
            var l = h(m.slice(0, 8));
            l = k(l);
            m = h(m.slice(12, 18));
            m = p(m);
            return "1" + l + m + "N"
        }

        function g(m) {
            if (m.length < 10) return null;
            var l = h(m.slice(0, 6));
            l = k(l);
            m = h(m.slice(6, 10));
            m = p(m);
            return "1" + l + m + "N"
        }

        function h(m) {
            var l = [],
                t = 0;
            for (let v = 0; v < m.length / 2; v++) l.push(Dl(m.slice(t, t + 2))), t += 2;
            return l
        }

        function k(m) {
            return m.every(l => l === 1) ? "Y" : "N"
        }

        function p(m) {
            return m.some(l => l === 1) ? "Y" : "N"
        }
        if (a.length === 0) return null;
        a = a.split(".");
        if (a.length > 2) return null;
        a = Cl(a[0]);
        var n = Dl(a.slice(0, 6));
        a = a.slice(6);
        if (n !== 1) return null;
        switch (b) {
            case 8:
                return c(a);
            case 10:
            case 12:
            case 9:
                return d(a);
            case 11:
                return e(a);
            case 7:
                return f(a);
            case 13:
                return g(a);
            default:
                return null
        }
    };

    function km(a, b) {
        var c = a.document,
            d = () => {
                if (!a.frames[b])
                    if (c.body) {
                        let e = Td("IFRAME", c);
                        e.style.display = "none";
                        e.style.width = "0px";
                        e.style.height = "0px";
                        e.style.border = "none";
                        e.style.zIndex = "-1000";
                        e.style.left = "-1000px";
                        e.style.top = "-1000px";
                        e.name = b;
                        c.body.appendChild(e)
                    } else a.setTimeout(d, 5)
            };
        d()
    };

    function lm(a) {
        O === O.top && (a = new mm(a), nm(a), om(a))
    }

    function nm(a) {
        !a.j || a.l.__uspapi || a.l.frames.__uspapiLocator || (a.l.__uspapiManager = "fc", km(a.l, "__uspapiLocator"), sa("__uspapi", (b, c, d) => {
            typeof d === "function" && b === "getUSPData" && (b = a.i.j(), d({
                version: 1,
                uspString: b ? a.j : "1---"
            }, !0))
        }, a.l), bm(a.l))
    }

    function om(a) {
        !a.tcString || a.l.__tcfapi || a.l.frames.__tcfapiLocator || (a.l.__tcfapiManager = "fc", km(a.l, "__tcfapiLocator"), a.l.__tcfapiEventListeners = a.l.__tcfapiEventListeners || [], sa("__tcfapi", (b, c, d, e) => {
            if (typeof d === "function")
                if (c && (c > 2.3 || c <= 1)) d(null, !1);
                else {
                    var f = a.l.__tcfapiEventListeners;
                    c = a.i.g();
                    switch (b) {
                        case "ping":
                            d({
                                gdprApplies: c,
                                cmpLoaded: !0,
                                cmpStatus: "loaded",
                                displayStatus: "disabled",
                                apiVersion: "2.3",
                                cmpVersion: 2,
                                cmpId: 300
                            });
                            break;
                        case "addEventListener":
                            b = f.push(d) - 1;
                            a.tcString ?
                                (e = gm(a.tcString, c), e.addtlConsent = a.g != null ? a.g : void 0, e.cmpStatus = "loaded", e.eventStatus = "tcloaded", b != null && (e.listenerId = b), b = e) : b = null;
                            d(b, !0);
                            break;
                        case "removeEventListener":
                            e !== void 0 && f[e] ? (f[e] = null, d(!0)) : d(!1);
                            break;
                        case "getInAppTCData":
                        case "getVendorList":
                            d(null, !1);
                            break;
                        case "getTCData":
                            d(null, !1)
                    }
                }
        }, a.l), Zl(a.l))
    }

    function pm(a) {
        if (!a ? .g() || J(a, 1).length === 0 || E(a, em, 2, C()).length === 0) return null;
        var b = J(a, 1);
        try {
            var c = Fl(b.split("~")[0]);
            var d = b.includes("~") ? b.split("~").slice(1) : []
        } catch (e) {
            return null
        }
        a = E(a, em, 2, C()).reduce((e, f) => {
            var g = qm(e);
            g = Vc(g, 1) ? ? wc;
            g = Nl(g);
            var h = qm(f);
            h = Vc(h, 1) ? ? wc;
            return g > Nl(h) ? e : f
        });
        c = Cc(c, 3, Ub, C()).indexOf(I(a, 1));
        return c === -1 || c >= d.length ? null : {
            uspString: jm(d[c], I(a, 1)),
            za: Ll(qm(a))
        }
    }

    function rm(a) {
        a = a.find(b => b && K(b, 1) === 13);
        if (a ? .g()) try {
            return fm(J(a, 2))
        } catch (b) {}
        return null
    }

    function qm(a) {
        return Ac(a, Kl, 2) ? D(a, Kl, 2) : Jl()
    }
    var mm = class {
        constructor(a) {
            var b = O;
            this.l = b;
            this.i = a;
            a = Yl(this.l.document);
            try {
                var c = a ? Wl(a) : null
            } catch (e) {
                c = null
            }(a = c) ? (c = D(a, Ul, 5) || null, a = E(a, Tl, 7, C()), a = rm(a ? ? []), c = {
                Za: c,
                eb: a
            }) : c = {
                Za: null,
                eb: null
            };
            a = c;
            c = pm(a.eb);
            a = a.Za;
            if (a ? .g() && J(a, 2).length !== 0) {
                var d = Ac(a, Kl, 1) ? D(a, Kl, 1) : Jl();
                a = {
                    uspString: J(a, 2),
                    za: Ll(d)
                }
            } else a = null;
            this.j = a && c ? c.za > a.za ? c.uspString : a.uspString : a ? a.uspString : c ? c.uspString : null;
            this.tcString = (c = Xl(b.document)) && x(A(c, 1)) != null ? J(c, 1) : null;
            this.g = (b = Xl(b.document)) && x(A(b,
                2)) != null ? J(b, 2) : null
        }
    };

    function sm(a) {
        a = Number((a.charCodeAt(0) - 43 & -3 ? "0" : "") + a + ".");
        return Number.isInteger(a) ? a : void 0
    };
    const tm = {
        google_ad_channel: !0,
        google_ad_host: !0
    };

    function um(a, b) {
        a.location.href && a.location.href.substring && (b.url = a.location.href.substring(0, 200));
        gk("ama", b, .01)
    }

    function vm(a) {
        var b = {};
        rd(tm, (c, d) => {
            a.hasOwnProperty(d) && (b[d] = a[d])
        });
        return b
    };

    function wm(a) {
        var b = /[a-zA-Z0-9._~-]/,
            c = /%[89a-zA-Z]./;
        return a.replace(/(%[a-zA-Z0-9]{2})/g, d => {
            if (!d.match(c)) {
                let e = decodeURIComponent(d);
                if (e.match(b)) return e
            }
            return d.toUpperCase()
        })
    }

    function xm(a) {
        var b = "",
            c = /[/%?&=]/;
        for (let d = 0; d < a.length; ++d) {
            let e = a[d];
            b = e.match(c) ? b + e : b + encodeURIComponent(e)
        }
        return b
    };

    function ym(a) {
        a = Cc(a, 2, Sb, C());
        if (!a) return !1;
        for (let b = 0; b < a.length; b++)
            if (a[b] == 1) return !0;
        return !1
    }

    function zm(a, b) {
        a = xm(wm(a.location.pathname)).replace(/(^\/)|(\/$)/g, "");
        var c = Oh(a),
            d = Am(a);
        return b.find(e => {
            if (Ac(e, ij, 7)) {
                var f = D(e, ij, 7);
                f = Vb(A(f, 1, void 0, xc))
            } else f = Vb(A(e, 1, void 0, xc));
            Ac(e, ij, 7) ? (e = D(e, ij, 7), e = bd(e, 2)) : e = 2;
            if (!sb(f)) return !1;
            switch (e) {
                case 1:
                    return f == c;
                case 2:
                    return d[f] || !1
            }
            return !1
        }) || null
    }

    function Am(a) {
        for (var b = {};;) {
            b[Oh(a)] = !0;
            if (!a) return b;
            a = a.substring(0, a.lastIndexOf("/"))
        }
    };

    function Z(a) {
        return a.google_ad_modifications = a.google_ad_modifications || {}
    }

    function Bm(a) {
        a = Z(a);
        var b = a.space_collapsing || "none";
        return a.had_ads_ablation ? {
            Va: !0,
            Vb: b,
            Wa: a.ablation_viewport_offset
        } : null
    }

    function Cm(a) {
        a = Z(a);
        a.had_ads_ablation = !0;
        a.space_collapsing = "slot";
        a.ablation_viewport_offset = 1
    }

    function Dm(a) {
        Z(O).allow_second_reactive_tag = a
    }

    function Em() {
        var a = Z(window);
        a.afg_slotcar_vars || (a.afg_slotcar_vars = {});
        return a.afg_slotcar_vars
    };

    function Fm(a) {
        return Z(a) ? .head_tag_slot_vars ? .google_ad_host ? ? Gm(a)
    }

    function Gm(a) {
        return a.document ? .querySelector('meta[name="google-adsense-platform-account"]') ? .getAttribute("content") ? ? null
    };
    const Hm = [2, 7, 1];

    function Im(a, b, c, d = "") {
        return b === 1 && c && (Jm(a, d, c) ? .H() ? ? !1) ? !0 : Km(a, d, e => Na(E(e, pd, 2, C()), f => bd(f, 1) === b), !!c ? .g() ? .g())
    }

    function Lm(a, b) {
        var c = td(O) || O;
        return Mm(c, a) ? !0 : Km(O, "", d => Na(Cc(d, 3, Sb, C()), e => e === a), b)
    }

    function Mm(a, b) {
        a = (a = (a = a.location && a.location.hash) && a.match(/forced_clientside_labs=([\d,]+)/)) && a[1];
        return !!a && Pa(a.split(","), b.toString())
    }

    function Km(a, b, c, d) {
        a = td(a) || a;
        var e = Nm(a, d);
        b && (b = rh(String(b)));
        return he(e, (f, g) => Object.prototype.hasOwnProperty.call(e, g) && (!b || b === g) && c(f))
    }

    function Nm(a, b) {
        a = Om(a, b);
        var c = {};
        rd(a, (d, e) => {
            try {
                let f = md(qd, jc(d));
                c[e] = f
            } catch (f) {}
        });
        return c
    }

    function Om(a, b) {
        a = Dk({
            l: a,
            ca: b
        });
        return a.g != null ? Pm(a.getValue()) : {}
    }

    function Pm(a) {
        try {
            let b = a.getItem("google_adsense_settings");
            if (!b) return {};
            let c = JSON.parse(b);
            return c !== Object(c) ? {} : ge(c, (d, e) => Object.prototype.hasOwnProperty.call(c, e) && w(e) && Array.isArray(d))
        } catch (b) {
            return {}
        }
    }

    function Qm(a, b) {
        var c = [];
        a = Fm(q) ? Hm : (a = Jm(q, a, b) ? .ea()) ? [...Cc(a, 3, Sb, C())] : Hm;
        a.includes(1) || c.push(1);
        a.includes(2) || c.push(2);
        a.includes(7) || c.push(7);
        return c
    }

    function Jm(a, b, c) {
        if (!b) return null;
        var d = Rm(c) ? .j(),
            e = Rm(c) ? .g() ? .g();
        b = b ? ? "";
        d = d ? ? "";
        e = e ? ? "";
        var f = J(c, 17) || "";
        return d === b || e === b && a.location.host && f === a.location.host ? Rm(c) : null
    };

    function Sm(a, b, c, d) {
        Tm(new Um(a, b, c, d))
    }

    function Tm(a) {
        var b = !!a.X.g() ? .g();
        Jh(Ih(Dk({
            l: a.l,
            ca: b
        }), c => {
            Vm(a, c, !0)
        }), () => {
            Wm(a)
        })
    }

    function Vm(a, b, c) {
        Jh(Ih(Xm(b), d => {
            Ym("ok");
            a.g(d, {
                fromLocalStorage: !0
            })
        }), () => {
            var d = a.l;
            try {
                b.removeItem("google_ama_config")
            } catch (e) {
                um(d, {
                    lserr: 1
                })
            }
            c ? Wm(a) : a.g(null, null)
        })
    }

    function Wm(a) {
        Jh(Ih(Zm(a), b => {
            a.g(b, {
                fromPABGSettings: !0
            })
        }), () => {
            $m(a)
        })
    }

    function Xm(a) {
        if (S(yi)) var b = null;
        else try {
            b = a.getItem("google_ama_config")
        } catch (d) {
            b = null
        }
        try {
            var c = b ? vj(b) : null
        } catch (d) {
            c = null
        }
        return (a = (a = c) ? (Ml(D(a, hj, 3) ? .g()) ? ? 0) > Date.now() ? a : null : null) ? Dh(a) : Fh(Error("invlocst"))
    }

    function Zm(a) {
        if (Fm(a.l) && !H(a.X, 22)) return Fh(Error("invtag"));
        if (a = (a = Jm(a.l, a.i, a.X) ? .O()) && E(a, di, 1, C()).length > 0 ? a : null) {
            var b = new uj;
            var c = E(a, di, 1, C());
            b = Tc(b, 1, c);
            c = E(a, oj, 2, C());
            b = Tc(b, 7, c);
            a = H(a, 4);
            a = zc(b, 36, Ob(a));
            a = Dh(a)
        } else a = Fh(Error("invtag"));
        return a
    }

    function $m(a) {
        var b = !!a.X.g() ? .g();
        Hk({
            l: a.l,
            ca: b,
            ja: 50,
            yb: c => {
                an(a, c)
            }
        })
    }

    function an(a, b) {
        Jh(Ih(b, c => {
            Vm(a, c, !1)
        }), c => {
            Ym(c.message);
            a.g(null, null)
        })
    }

    function Ym(a) {
        gk("abg::amalserr", {
            status: a,
            guarding: "true",
            timeout: 50,
            rate: .01
        }, .01)
    }
    class Um {
        constructor(a, b, c, d) {
            this.l = a;
            this.X = b;
            this.i = c;
            this.g = d
        }
    };

    function bn(a, b, c, d, e) {
        var f = cn;
        try {
            let g = zm(a, E(c, oj, 7, C()));
            if (g && ym(g)) {
                if (x(A(g, 4))) {
                    let p = new Vh(null, {
                        google_package: x(A(g, 4))
                    });
                    d = Uh(d, p)
                }
                let h = f(a, b, c, g, d, e);
                b = () => {
                    Gj(1E3, () => {
                        var p = new yh;
                        (new Al(a, h, p)).start();
                        return p.i
                    }, a).then(() => {
                        um(a, {
                            atf: 1
                        })
                    }, p => {
                        (a.google_ama_state = a.google_ama_state || {}).exception = p;
                        um(a, {
                            atf: 0
                        })
                    })
                };
                let k = S(wi) ? T(xi) : null;
                k != null ? setTimeout(b, k) : b()
            }
        } catch (g) {
            um(a, {
                atf: -1
            })
        }
    }

    function cn(a, b, c, d, e, f) {
        return new vl(a, b, c, d, e, f)
    };

    function dn() {
        var a = M(ae).u(Ei.g, Ei.defaultValue);
        return a.length ? a.join("~") : void 0
    };

    function en(a, b) {
        if (!a) return !1;
        a = a.hash;
        if (!a || !a.indexOf) return !1;
        if (a.indexOf(b) != -1) return !0;
        var c = "";
        for (let d of b.split("_")) c += d.substring(0, 2);
        b = c;
        return b != "go" && a.indexOf(b) != -1 ? !0 : !1
    };
    var fn = {
        rectangle: 1,
        horizontal: 2,
        vertical: 4
    };

    function gn(a, b) {
        var c = ["width", "height"];
        for (let e = 0; e < c.length; e++) {
            let f = "google_ad_" + c[e];
            if (!b.hasOwnProperty(f)) {
                var d = Yd(a[c[e]]);
                d = d === null ? null : Math.round(d);
                d != null && (b[f] = d)
            }
        }
    }

    function hn(a, b) {
        return !((Wd.test(b.google_ad_width) || Vd.test(a.style.width)) && (Wd.test(b.google_ad_height) || Vd.test(a.style.height)))
    }

    function jn(a, b, c, d, e) {
        if (a !== a.top) return td(a) ? 3 : 16;
        if (!(U(a) < 488)) return 4;
        if (!(a.innerHeight >= a.innerWidth)) return 5;
        var f = U(a);
        if (!f || (f - c) / f > d) a = 6;
        else {
            if (c = e.google_full_width_responsive !== "true") a: {
                c = b.parentElement;
                for (b = U(a); c; c = c.parentElement) {
                    d = Ud(c, a);
                    if (!d) continue;
                    if ((e = Yd(d.width)) && !(e >= b) && d.overflow !== "visible") {
                        c = !0;
                        break a
                    }
                }
                c = !1
            }
            a = c ? 7 : !0
        }
        return a
    }

    function kn(a, b, c, d) {
        var e = jn(b, c, a, T(ri), d);
        e !== !0 ? a = e : d.google_full_width_responsive === "true" || Yi(c, b) ? (b = U(b), a = b - a, a = b && a >= 0 ? !0 : b ? a < -10 ? 11 : a < 0 ? 14 : 12 : 10) : a = 9;
        return a
    }

    function ln(a, b, c) {
        a = a.style;
        b === "rtl" ? a.marginRight = c : a.marginLeft = c
    }

    function mn(a, b) {
        if (b.nodeType === 3) return /\S/.test(b.data);
        if (b.nodeType === 1) {
            if (/^(script|style)$/i.test(b.nodeName)) return !1;
            let c;
            try {
                c = Ud(b, a)
            } catch (d) {}
            return !c || c.display !== "none" && !(c.position === "absolute" && (c.visibility === "hidden" || c.visibility === "collapse"))
        }
        return !1
    }

    function nn(a, b, c) {
        a = $i(b, a);
        return c === "rtl" ? -a.x : a.x
    }

    function on(a, b) {
        var c;
        c = (c = b.parentElement) ? (c = Ud(c, a)) ? c.direction : "" : "";
        if (c) {
            var d = b.style;
            d.border = d.borderStyle = d.outline = d.outlineStyle = d.transition = "none";
            d.borderSpacing = d.padding = "0";
            ln(b, c, "0px");
            d.width = `${U(a)}px`;
            if (nn(a, b, c) !== 0) {
                ln(b, c, "0px");
                var e = nn(a, b, c);
                ln(b, c, `${-1*e}px`);
                a = nn(a, b, c);
                a !== 0 && a !== e && ln(b, c, `${e/(a-e)*e}px`)
            }
            d.zIndex = "30"
        }
    };

    function pn() {
        var a = {};
        M(ae).g(ti.g, ti.defaultValue) && (a.bust = M(ae).g(ti.g, ti.defaultValue));
        return a
    };
    class qn {
        constructor() {
            this.promise = new Promise((a, b) => {
                this.resolve = a;
                this.reject = b
            })
        }
    };

    function rn() {
        var {
            promise: a,
            resolve: b
        } = new qn;
        return {
            promise: a,
            resolve: b
        }
    };

    function sn(a = () => {}) {
        q.google_llp || (q.google_llp = {});
        var b = q.google_llp,
            c = b[7];
        if (c) return c;
        c = rn();
        b[7] = c;
        a();
        return c
    }

    function tn(a) {
        return sn(() => {
            Sd(q.document, a)
        }).promise
    };
    Array.from({
        length: 11
    }, (a, b) => b / 10);
    var un = class {
        constructor() {
            this.i = this.j = 1;
            this.g = new Map;
            this.isDrawerVisible = !1
        }
        takeNextPageEventIndex() {
            return this.j++
        }
        takeNextAnnotationEntryId() {
            return this.i++
        }
        getTermUsageCount(a) {
            return this.g.get(a) ? ? 0
        }
        incrementTermUsageCount(a) {
            var b = this.g.get(a) ? ? 0;
            this.g.set(a, b + 1)
        }
    };

    function vn(a) {
        a.google_reactive_ads_global_state ? (a.google_reactive_ads_global_state.sideRailProcessedFixedElements == null && (a.google_reactive_ads_global_state.sideRailProcessedFixedElements = new Set), a.google_reactive_ads_global_state.sideRailAvailableSpace == null && (a.google_reactive_ads_global_state.sideRailAvailableSpace = new Map), a.google_reactive_ads_global_state.sideRailPlasParam == null && (a.google_reactive_ads_global_state.sideRailPlasParam = new Map), a.google_reactive_ads_global_state.sideRailMutationCallbacks ==
            null && (a.google_reactive_ads_global_state.sideRailMutationCallbacks = []), a.google_reactive_ads_global_state.adIntentsPageState == null && (a.google_reactive_ads_global_state.adIntentsPageState = new un)) : a.google_reactive_ads_global_state = new wn;
        return a.google_reactive_ads_global_state
    }
    var wn = class {
            constructor() {
                this.wasPlaTagProcessed = !1;
                this.wasReactiveAdConfigReceived = {};
                this.adCount = {};
                this.wasReactiveAdVisible = {};
                this.stateForType = {};
                this.reactiveTypeEnabledInAsfe = {};
                this.wasReactiveTagRequestSent = !1;
                this.reactiveTypeDisabledByPublisher = {};
                this.tagSpecificState = {};
                this.messageValidationEnabled = !1;
                this.floatingAdsStacking = new xn;
                this.sideRailProcessedFixedElements = new Set;
                this.sideRailAvailableSpace = new Map;
                this.sideRailPlasParam = new Map;
                this.sideRailMutationCallbacks = [];
                this.clickTriggeredInterstitialMayBeDisplayed = !1;
                this.adIntentsPageState = new un
            }
        },
        xn = class {
            constructor() {
                this.maxZIndexRestrictions = {};
                this.nextRestrictionId = 0;
                this.maxZIndexListeners = []
            }
        };

    function yn(a) {
        if (q.google_apltlad || a.google_ad_intent_query || a.google_ad_intents_format) return null;
        var b = a.google_loader_used !== "sd" && (q.top == q ? 0 : sd(q.top) ? 1 : 2) === 1;
        if (q !== q.top && !b || !a.google_ad_client) return null;
        q.google_apltlad = !0;
        b = {
            enable_page_level_ads: {
                pltais: !0
            },
            google_ad_client: a.google_ad_client
        };
        var c = b.enable_page_level_ads;
        rd(a, (d, e) => {
            ej[e] && e !== "google_ad_client" && (c[e] = d)
        });
        c.google_pgb_reactive = 7;
        c.asro = S(Gi);
        T(Ii) && (c.aiact = T(Ii));
        T(Ki) && (c.aicct = T(Ki));
        T(Mi) && (c.ailct = T(Mi));
        c.aiactd = T(Hi);
        c.aicctd = T(Ji);
        c.ailctd = T(Li);
        c.aimartd = T(Ni);
        c.aiof = dn();
        if ("google_ad_section" in a || "google_ad_region" in a) c.google_ad_section = a.google_ad_section || a.google_ad_region;
        return b
    };

    function zn(a, b) {
        Z(O).ama_ran_on_page || Gj(1001, () => {
            An(new Bn(a, b))
        }, q)
    }

    function An(a) {
        Sm(a.l, a.X, a.g.google_ad_client || "", (b, c) => {
            var d = a.l,
                e = a.g,
                f = a.X;
            Z(O).ama_ran_on_page || b && Cn(d, e, b, c, f)
        })
    }
    class Bn {
        constructor(a, b) {
            this.l = q;
            this.g = a;
            this.X = b
        }
    }

    function Cn(a, b, c, d, e) {
        d && (Lj(a).configSourceInAbg = d);
        Ac(c, tj, 24) && (d = Mj(a), d.availableAbg = !0, d.ablationFromStorage = !!D(c, tj, 24) ? .g() ? .g());
        if (la(b.enable_page_level_ads) && b.enable_page_level_ads.google_pgb_reactive === 7) {
            if (!zm(a, E(c, oj, 7, C()))) {
                gk("amaait", {
                    value: "true"
                });
                return
            }
            gk("amaait", {
                value: "false"
            })
        }
        Z(O).ama_ran_on_page = !0;
        D(c, tj, 24) ? .g() ? .g() && (Mj(a).ablatingThisPageview = !0, Cm(a));
        ue(3, [y(c)]);
        var f = b.google_ad_client || "";
        b = vm(la(b.enable_page_level_ads) ? b.enable_page_level_ads : {});
        var g =
            Uh(Yh, new Vh(null, b));
        dk(782, () => {
            bn(a, f, c, g, e.g() ? .g())
        })
    };
    var Dn = function(a) {
        return b => {
            b = JSON.parse(b);
            if (!Array.isArray(b)) throw Error("Expected jspb data to be an array, got " + ka(b) + ": " + b);
            b[u] |= 34;
            return new a(b)
        }
    }(class extends L {});
    async function En(a, b) {
        try {
            let c = await globalThis.fetch(Qd(Pd `https://pagead2.googlesyndication.com/getconfig/abg_config`, new Map([
                ["client", a],
                ["plah", b],
                ["ama_t", "adsense"], ...Object.entries(pn())
            ])).toString(), {
                method: "GET",
                credentials: "omit"
            });
            if (!c.ok) throw Error(`Fetch failed with status: ${c.status}`);
            let d = await c.text();
            if (!d) throw Error("AbgConfig endpoint returned empty response.");
            try {
                return Dn(d)
            } catch (e) {
                throw Error(`Error deserializing config: ${e instanceof Error?e.message:String(e)}`);
            }
        } catch (c) {
            throw c;
        }
    };

    function Fn(a, b) {
        a = a.document;
        for (var c = void 0, d = 0; !c || a.getElementById(c + "_host");) c = "aswift_" + d++;
        a = c;
        c = Number(b.google_ad_width || 0);
        b = Number(b.google_ad_height || 0);
        d = document.createElement("div");
        d.id = a + "_host";
        var e = d.style;
        e.border = "none";
        e.height = `${b}px`;
        e.width = `${c}px`;
        e.margin = "0px";
        e.padding = "0px";
        e.position = "relative";
        e.visibility = "visible";
        e.backgroundColor = "transparent";
        e.display = "inline-block";
        return {
            Fb: a,
            Yb: d
        }
    };
    var Gn = {
        "120x90": !0,
        "160x90": !0,
        "180x90": !0,
        "200x90": !0,
        "468x15": !0,
        "728x15": !0
    };

    function Hn(a, b) {
        if (b == 15) {
            if (a >= 728) return 728;
            if (a >= 468) return 468
        } else if (b == 90) {
            if (a >= 200) return 200;
            if (a >= 180) return 180;
            if (a >= 160) return 160;
            if (a >= 120) return 120
        }
        return null
    };

    function In(a, b) {
        for (var c = [], d = 0; b && d < 25; ++d) {
            var e = void 0;
            e = (e = b.nodeType !== 9 && b.id) ? "/" + e : "";
            a: {
                if (b && b.nodeName && b.parentElement) {
                    var f = b.nodeName.toString().toLowerCase();
                    let g = b.parentElement.childNodes,
                        h = 0;
                    for (let k = 0; k < g.length; ++k) {
                        let p = g[k];
                        if (p.nodeName && p.nodeName.toString().toLowerCase() === f) {
                            if (b === p) {
                                f = "." + h;
                                break a
                            }++h
                        }
                    }
                }
                f = ""
            }
            c.push((b.nodeName && b.nodeName.toString().toLowerCase()) + e + f);
            b = b.parentElement
        }
        b = c.join();
        c = [];
        if (a) try {
            let g = a.parent;
            for (d = 0; g && g !== a && d < 25; ++d) {
                let h = g.frames;
                for (e = 0; e < h.length; ++e)
                    if (a === h[e]) {
                        c.push(e);
                        break
                    }
                a = g;
                g = a.parent
            }
        } catch (g) {}
        return Oh(`${b}:${c.join()}`).toString()
    };
    var Jn = class extends L {
        getVersion() {
            return J(this, 2)
        }
    };

    function Kn(a, b) {
        return gd(a, 2, b)
    }

    function Ln(a, b) {
        return gd(a, 3, b)
    }

    function Mn(a, b) {
        return gd(a, 4, b)
    }

    function Nn(a, b) {
        return gd(a, 5, b)
    }

    function On(a, b) {
        return gd(a, 9, b)
    }

    function Pn(a, b) {
        return Tc(a, 10, b)
    }

    function Qn(a, b) {
        return zc(a, 11, Ob(b))
    }

    function Rn(a, b) {
        return gd(a, 1, b)
    }

    function Sn(a, b) {
        return zc(a, 7, Ob(b))
    }
    var Tn = class extends L {};
    const Un = "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(" ");

    function Vn() {
        var a = O;
        if (typeof a.navigator ? .userAgentData ? .getHighEntropyValues !== "function") return null;
        var b = a.google_tag_data ? ? (a.google_tag_data = {});
        if (b.uach_promise) return b.uach_promise;
        a = a.navigator.userAgentData.getHighEntropyValues(Un).then(c => {
            b.uach ? ? (b.uach = c);
            return c
        });
        return b.uach_promise = a
    }

    function Wn(a) {
        return Qn(Pn(Nn(Kn(Rn(Mn(Sn(On(Ln(new Tn, a.architecture || ""), a.bitness || ""), a.mobile || !1), a.model || ""), a.platform || ""), a.platformVersion || ""), a.uaFullVersion || ""), a.fullVersionList ? .map(b => {
            var c = new Jn;
            c = gd(c, 1, b.brand);
            return gd(c, 2, b.version)
        }) || []), a.wow64 || !1)
    }

    function Xn() {
        return Vn() ? .then(a => Wn(a)) ? ? null
    };

    function Yn(a, b) {
        b.google_ad_host || (a = Gm(a)) && (b.google_ad_host = a)
    }

    function Zn(a, b) {
        a.google_sa_queue = a.google_sa_queue || [];
        a.google_sa_impl ? b() : a.google_sa_queue.push(b)
    }

    function $n() {
        var a = td(q);
        a && (a = vn(a), a.tagSpecificState[1] || (a.tagSpecificState[1] = {
            debugCard: null,
            debugCardRequested: !1
        }))
    }

    function ao() {
        var a = Xn();
        a != null && a.then(b => {
            O.google_user_agent_client_hint = b.u()
        });
        $d()
    }

    function bo(a) {
        var b = a.google_ad_output,
            c = a.google_ad_format,
            d = a.google_ad_width || 0,
            e = a.google_ad_height || 0;
        c || b !== "html" && b != null || (c = `${d}x${e}`);
        b = !a.google_ad_slot || a.google_override_format || !Gn[a.google_ad_width + "x" + a.google_ad_height] && a.google_loader_used === "aa";
        c = c && b ? c.toLowerCase() : "";
        a.google_ad_format = c
    }

    function co(a, b) {
        b = [b.google_ad_slot, b.google_ad_format, b.google_ad_type, b.google_ad_width, b.google_ad_height];
        for (var c = [], d = 0; a && d < 25; a = a.parentNode, ++d) a.nodeType === 9 ? c.push("") : c.push(a.id);
        (a = c.join()) && b.push(a);
        return Oh(b.join(":")).toString()
    }

    function eo(a) {
        return (a = a ? .getAttribute("data-override-ady")) ? sm(a) : void 0
    }

    function fo(a) {
        return (a = a ? .getAttribute("data-override-adx")) ? sm(a) : void 0
    };
    var go = class {
        constructor(a, b) {
            this.F = a;
            this.height = b
        }
        g(a) {
            return a > 300 && this.height > 300 ? this.F : Math.min(1200, Math.round(a))
        }
    };
    var ho = class extends go {
        i() {}
    };

    function io(a) {
        return b => !!(b.D() & a)
    }
    var jo = class extends ho {
        constructor(a, b, c, d = !1) {
            super(a, b);
            this.u = c;
            this.j = d
        }
        D() {
            return this.u
        }
        Ea() {
            return this.j
        }
        i(a, b, c) {
            c.style.height = `${this.height}px`;
            b.rpe = !0
        }
    };
    const ko = {
            image_stacked: 1 / 1.91,
            image_sidebyside: 1 / 3.82,
            mobile_banner_image_sidebyside: 1 / 3.82,
            pub_control_image_stacked: 1 / 1.91,
            pub_control_image_sidebyside: 1 / 3.82,
            pub_control_image_card_stacked: 1 / 1.91,
            pub_control_image_card_sidebyside: 1 / 3.74,
            pub_control_text: 0,
            pub_control_text_card: 0
        },
        lo = {
            image_stacked: 80,
            image_sidebyside: 0,
            mobile_banner_image_sidebyside: 0,
            pub_control_image_stacked: 80,
            pub_control_image_sidebyside: 0,
            pub_control_image_card_stacked: 85,
            pub_control_image_card_sidebyside: 0,
            pub_control_text: 80,
            pub_control_text_card: 80
        },
        mo = {
            pub_control_image_stacked: 100,
            pub_control_image_sidebyside: 200,
            pub_control_image_card_stacked: 150,
            pub_control_image_card_sidebyside: 250,
            pub_control_text: 100,
            pub_control_text_card: 150
        };

    function no(a) {
        var b = 0;
        a.P && b++;
        a.L && b++;
        a.M && b++;
        if (b < 3) return {
            ba: "Tags data-matched-content-ui-type, data-matched-content-columns-num and data-matched-content-rows-num should be set together."
        };
        b = a.P.split(",");
        var c = a.M.split(",");
        a = a.L.split(",");
        if (b.length !== c.length || b.length !== a.length) return {
            ba: 'Lengths of parameters data-matched-content-ui-type, data-matched-content-columns-num and data-matched-content-rows-num must match. Example: \n data-matched-content-rows-num="4,2"\ndata-matched-content-columns-num="1,6"\ndata-matched-content-ui-type="image_stacked,image_card_sidebyside"'
        };
        if (b.length >
            2) return {
            ba: `The parameter length of attribute data-matched-content-ui-type, data-matched-content-columns-num and data-matched-content-rows-num is too long. At most 2 parameters for each attribute are needed: one for mobile and one for desktop, while you are providing ${b.length} parameters. Example: ${'\n data-matched-content-rows-num="4,2"\ndata-matched-content-columns-num="1,6"\ndata-matched-content-ui-type="image_stacked,image_card_sidebyside"'}.`
        };
        var d = [],
            e = [];
        for (let g = 0; g < b.length; g++) {
            var f =
                Number(c[g]);
            if (Number.isNaN(f) || f === 0) return {
                ba: `Wrong value '${c[g]}' for data-matched-content-rows-num.`
            };
            d.push(f);
            f = Number(a[g]);
            if (Number.isNaN(f) || f === 0) return {
                ba: `Wrong value '${a[g]}' for data-matched-content-columns-num.`
            };
            e.push(f)
        }
        return {
            M: d,
            L: e,
            ib: b
        }
    }

    function oo(a) {
        return a >= 1200 ? {
            width: 1200,
            height: 600
        } : a >= 850 ? {
            width: a,
            height: Math.floor(a * .5)
        } : a >= 550 ? {
            width: a,
            height: Math.floor(a * .6)
        } : a >= 468 ? {
            width: a,
            height: Math.floor(a * .7)
        } : {
            width: a,
            height: Math.floor(a * 3.44)
        }
    }

    function po(a, b) {
        return a * ko[b] + lo[b]
    }

    function qo(a, b, c, d) {
        b = Math.floor(po((a - 8 * b - 8) / b, d) * c + 8 * c + 8);
        return a > 1500 ? {
            width: 0,
            height: 0,
            Tb: `Calculated slot width is too large: ${a}`
        } : b > 1500 ? {
            width: 0,
            height: 0,
            Tb: `Calculated slot height is too large: ${b}`
        } : {
            width: a,
            height: b
        }
    }

    function ro(a, b) {
        var c = a - 8 - 8;
        --b;
        return {
            width: a,
            height: Math.floor(c / 1.91 + 70) + Math.floor(po(c, "mobile_banner_image_sidebyside") * b + 8 * b + 8)
        }
    };
    const so = Sa("script");
    var to = class {
        constructor(a, b, c = null, d = null, e = null, f = null, g = null, h = null, k = null, p = null, n = null, m = null) {
            this.G = a;
            this.aa = b;
            this.D = c;
            this.g = d;
            this.H = e;
            this.I = f;
            this.V = g;
            this.u = h;
            this.B = k;
            this.i = p;
            this.j = n;
            this.A = m
        }
        size() {
            return this.aa
        }
    };
    const uo = ["google_content_recommendation_ui_type", "google_content_recommendation_columns_num", "google_content_recommendation_rows_num"];
    var vo = class extends ho {
        constructor(a, b) {
            super(a, b)
        }
        g(a) {
            return Math.min(1200, Math.max(this.F, Math.round(a)))
        }
    };

    function wo(a, b) {
        xo(a, b);
        if (b.google_content_recommendation_ui_type === "pedestal" && !S(ii)) return new to(9, new vo(a, Math.floor(a * 2.189)));
        if (S(li)) {
            var c = xd(),
                d = T(mi),
                e = T(ki),
                f = T(ji);
            a < 468 ? c ? (a = ro(a, d), a = {
                Z: a.width,
                Y: a.height,
                L: 1,
                M: d,
                P: "mobile_banner_image_sidebyside"
            }) : (a = qo(a, 1, d, "image_sidebyside"), a = {
                Z: a.width,
                Y: a.height,
                L: 1,
                M: d,
                P: "image_sidebyside"
            }) : (a = oo(a), e === 1 && (a.height = Math.floor(a.height * .5)), a = {
                Z: a.width,
                Y: a.height,
                L: f,
                M: e,
                P: "image_stacked"
            })
        } else S(ii) ? (d = oo(a), e = 4, f = 2, a < 468 && (e = 1, f =
            6, d = {
                width: a,
                height: Math.floor(po(a, "image_stacked") * f + 8 * f + 8)
            }), a = {
            Z: d.width,
            Y: d.height,
            L: e,
            M: f,
            P: "image_stacked"
        }) : (d = xd(), a < 468 ? d ? (a = ro(a, 12), a = {
            Z: a.width,
            Y: a.height,
            L: 1,
            M: 12,
            P: "mobile_banner_image_sidebyside"
        }) : (a = oo(a), a = {
            Z: a.width,
            Y: a.height,
            L: 1,
            M: 13,
            P: "image_sidebyside"
        }) : (a = oo(a), a = {
            Z: a.width,
            Y: a.height,
            L: 4,
            M: 2,
            P: "image_stacked"
        }));
        yo(b, a);
        return new to(9, new vo(a.Z, a.Y))
    }

    function zo(a, b) {
        xo(a, b); {
            let f = no({
                M: b.google_content_recommendation_rows_num,
                L: b.google_content_recommendation_columns_num,
                P: b.google_content_recommendation_ui_type
            });
            if (f.ba) a = {
                Z: 0,
                Y: 0,
                L: 0,
                M: 0,
                P: "image_stacked",
                ba: f.ba
            };
            else {
                var c = f.ib.length === 2 && a >= 468 ? 1 : 0;
                var d = f.ib[c];
                d = d.indexOf("pub_control_") === 0 ? d : "pub_control_" + d;
                var e = mo[d];
                let g = f.L[c];
                for (; a / g < e && g > 1;) g--;
                e = g;
                c = f.M[c];
                a = qo(a, e, c, d);
                a = {
                    Z: a.width,
                    Y: a.height,
                    L: e,
                    M: c,
                    P: d
                }
            }
        }
        if (a.ba) throw new W(a.ba);
        yo(b, a);
        return new to(9, new vo(a.Z, a.Y))
    }

    function xo(a, b) {
        if (a <= 0) throw new W(`Invalid responsive width from Matched Content slot ${b.google_ad_slot}: ${a}. Please ensure to put this Matched Content slot into a non-zero width div container.`);
    }

    function yo(a, b) {
        a.google_content_recommendation_ui_type = b.P;
        a.google_content_recommendation_columns_num = b.L;
        a.google_content_recommendation_rows_num = b.M
    };
    var Ao = class extends ho {
        constructor(a, b) {
            super(a, b)
        }
        g() {
            return this.F
        }
        i(a, b, c) {
            on(a, c);
            c.style.height = `${this.height}px`;
            b.rpe = !0
        }
    };
    const Bo = {
        "image-top": a => a <= 600 ? 284 + (a - 250) * .414 : 429,
        "image-middle": a => a <= 500 ? 196 - (a - 250) * .13 : 164 + (a - 500) * .2,
        "image-side": a => a <= 500 ? 205 - (a - 250) * .28 : 134 + (a - 500) * .21,
        "text-only": a => a <= 500 ? 187 - .228 * (a - 250) : 130,
        "in-article": a => a <= 420 ? a / 1.2 : a <= 460 ? a / 1.91 + 130 : a <= 800 ? a / 4 : 200
    };
    var Co = class extends ho {
        constructor(a, b) {
            super(a, b)
        }
        g() {
            return Math.min(1200, this.F)
        }
    };

    function Do(a, b, c, d, e) {
        var f = e.google_ad_layout || "image-top";
        if (f === "in-article") {
            var g = a;
            if (e.google_full_width_responsive === "false") a = g;
            else if (a = jn(b, c, g, T(pi), e), a !== !0) e.gfwrnwer = a, a = g;
            else if (a = U(b))
                if (e.google_full_width_responsive_allowed = !0, c.parentElement) {
                    b: {
                        g = c;
                        for (let h = 0; h < 100 && g.parentElement; ++h) {
                            let k = g.parentElement.childNodes;
                            for (let p = 0; p < k.length; ++p) {
                                let n = k[p];
                                if (n !== g && mn(b, n)) break b
                            }
                            g = g.parentElement;
                            g.style.width = "100%";
                            g.style.height = "auto"
                        }
                    }
                    on(b, c)
                }
            else a = g;
            else a = g
        }
        if (a <
            250) throw new W(`Fluid responsive ads must be at least 250px wide: availableWidth=${a}`);
        a = Math.min(1200, Math.floor(a));
        if (d && f !== "in-article") {
            f = Math.ceil(d);
            if (f < 50) throw new W(`Fluid responsive ads must be at least 50px tall: height=${f}`);
            return new to(11, new ho(a, f))
        }
        if (f !== "in-article" && (d = e.google_ad_layout_key)) {
            f = `${d}`;
            if (d = (c = f.match(/([+-][0-9a-z]+)/g)) && c.length)
                for (b = [], e = 0; e < d; e++) b.push(parseInt(c[e], 36) / 1E3);
            else b = null;
            if (!b) throw new W(`Invalid data-ad-layout-key value: ${f}`);
            f = (a + -725) / 1E3;
            c = 0;
            d = 1;
            e = b.length;
            for (g = 0; g < e; g++) c += b[g] * d, d *= f;
            f = Math.ceil(c * 1E3 - -725 + 10);
            if (isNaN(f)) throw new W(`Invalid height: height=${f}`);
            if (f < 50) throw new W(`Fluid responsive ads must be at least 50px tall: height=${f}`);
            if (f > 1200) throw new W(`Fluid responsive ads must be at most 1200px tall: height=${f}`);
            return new to(11, new ho(a, f))
        }
        d = Bo[f];
        if (!d) throw new W("Invalid data-ad-layout value: " + f);
        c = bj(c, b);
        b = U(b);
        b = f !== "in-article" || c || a !== b ? Math.ceil(d(a)) : Math.ceil(d(a) * 1.25);
        return new to(11,
            f === "in-article" ? new Co(a, b) : new ho(a, b))
    };
    var Eo = [{
            F: 970,
            height: 90,
            D: 2
        }, {
            F: 728,
            height: 90,
            D: 2
        }, {
            F: 468,
            height: 60,
            D: 2
        }, {
            F: 336,
            height: 280,
            D: 1
        }, {
            F: 320,
            height: 100,
            D: 2
        }, {
            F: 320,
            height: 50,
            D: 2
        }, {
            F: 300,
            height: 600,
            D: 4
        }, {
            F: 300,
            height: 250,
            D: 1
        }, {
            F: 250,
            height: 250,
            D: 1
        }, {
            F: 234,
            height: 60,
            D: 2
        }, {
            F: 200,
            height: 200,
            D: 1
        }, {
            F: 180,
            height: 150,
            D: 1
        }, {
            F: 160,
            height: 600,
            D: 4
        }, {
            F: 125,
            height: 125,
            D: 1
        }, {
            F: 120,
            height: 600,
            D: 4
        }, {
            F: 120,
            height: 240,
            D: 4
        }, {
            F: 120,
            height: 120,
            D: 1,
            Ea: !0
        }].map(a => new jo(a.F, a.height, a.D, a.Ea ? ? !1)),
        Fo = [6, 12, 3, 0, 7, 14, 1, 8, 10, 4, 15, 2, 11, 5, 13, 9, 16].map(a => Eo[a]);
    const Go = 2 / 3;

    function Ho(a) {
        return b => b.F <= a
    }

    function Io(a) {
        return b => b.height <= a
    }

    function Jo(a, b) {
        return b.wa && b.Da ? Math.max(250, Xi(a).clientHeight * Go) : 250
    }

    function Ko(a, b, c) {
        var d = c.Jb && bj(b, a),
            e = Jo(a, {
                wa: c.wa,
                Da: c.Da
            });
        return f => !(d && f.height >= e)
    };

    function Lo(a) {
        return b => {
            for (let c = a.length - 1; c >= 0; --c)
                if (!a[c](b)) return !1;
            return !0
        }
    }

    function Mo(a, b) {
        var c = Fo.length,
            d = null;
        for (let e = 0; e < c; ++e) {
            let f = Fo[e];
            if (a(f)) {
                if (b == null || b(f)) return f;
                d === null && (d = f)
            }
        }
        return d
    };

    function No(a, b, c, d, e) {
        e.google_full_width_responsive === "false" ? c = {
            J: a,
            I: 1
        } : b === "autorelaxed" && e.google_full_width_responsive || Oo(b) || e.google_ad_resize ? (b = kn(a, c, d, e), c = b !== !0 ? {
            J: a,
            I: b
        } : {
            J: U(c) || a,
            I: !0
        }) : c = {
            J: a,
            I: 2
        };
        var {
            J: f,
            I: g
        } = c;
        return g !== !0 ? {
            J: a,
            I: g
        } : d.parentElement ? {
            J: f,
            I: g
        } : {
            J: a,
            I: g
        }
    }

    function Po(a, b, c, d, e) {
        var {
            J: f,
            I: g
        } = dk(247, () => No(a, b, c, d, e)), h = g === !0, k = Yd(d.style.width), p = Yd(d.style.height), {
            aa: n,
            V: m,
            D: l,
            hb: t
        } = Qo(f, b, c, d, e, h);
        h = Ro(b, l);
        var v, z = (v = Zi(d, c, "marginLeft")) ? `${v}px` : "",
            N = (v = Zi(d, c, "marginRight")) ? `${v}px` : "";
        v = dj(d, c) || "";
        return new to(h, n, l, null, t, g, m, z, N, p, k, v)
    }

    function Oo(a) {
        return a === "auto" || /^((^|,) *(horizontal|vertical|rectangle) *)+$/.test(a)
    }

    function Qo(a, b, c, d, e, f) {
        b = So(c, a, b);
        var g = U(c) < 488,
            h = g ? Yi(d, c) : void 0,
            k = [Ho(a), io(b)];
        S(ui) || k.push(Ko(c, d, {
            Jb: g,
            wa: !(!h || !bj(d, c)),
            Da: qh(c) === 0
        }));
        e.google_max_responsive_height != null && k.push(Io(e.google_max_responsive_height));
        g = [l => !l.Ea()];
        if (h) {
            let l = cj(c, d);
            g.push(Io(l))
        }
        var p = Mo(Lo(k), Lo(g));
        if (!p) throw new W(`No slot size for availableWidth=${a}`);
        var {
            aa: n,
            V: m
        } = dk(248, () => {
            var l;
            a: if (f) {
                if (e.gfwrnh && (l = Yd(e.gfwrnh))) {
                    l = {
                        aa: new Ao(a, l),
                        V: !0
                    };
                    break a
                }
                if (e.google_resizing_allowed || e.google_full_width_responsive ===
                    "true") l = Infinity;
                else {
                    l = d;
                    let v = Infinity;
                    do {
                        var t = Zi(l, c, "height");
                        t && (v = Math.min(v, t));
                        (t = Zi(l, c, "maxHeight")) && (v = Math.min(v, t))
                    } while (l.parentElement && (l = l.parentElement) && l.tagName !== "HTML");
                    l = v
                }!(S(si) && l <= a * 2) && (l = Math.min(a, l), l < a * .5 || l < 100) && (l = a);
                l = {
                    aa: new Ao(a, Math.floor(l)),
                    V: l < a ? 102 : !0
                }
            } else l = {
                aa: p,
                V: 100
            };
            return l
        });
        return e.google_ad_layout === "in-article" ? {
            aa: To(a, c, d, n, e),
            V: !1,
            D: b,
            hb: h
        } : {
            aa: n,
            V: m,
            D: b,
            hb: h
        }
    }

    function Ro(a, b) {
        if (a === "auto") return 1;
        switch (b) {
            case 2:
                return 2;
            case 1:
                return 3;
            case 4:
                return 4;
            case 3:
                return 5;
            case 6:
                return 6;
            case 5:
                return 7;
            case 7:
                return 8;
            default:
                throw Error("bad mask");
        }
    }

    function So(a, b, c) {
        if (c === "auto") c = Math.min(1200, U(a)), b = b / c <= .25 ? 4 : 3;
        else {
            b = 0;
            for (let d in fn) c.indexOf(d) !== -1 && (b |= fn[d])
        }
        return b
    }

    function To(a, b, c, d, e) {
        var f = e.google_ad_height || Zi(c, b, "height");
        b = Do(a, b, c, f, e).size();
        return b.F * b.height > a * d.height ? new jo(b.F, b.height, 1) : d
    };

    function Uo(a, b, c, d, e) {
        var f;
        (f = U(b)) ? U(b) < 488 ? b.innerHeight >= b.innerWidth ? (e.google_full_width_responsive_allowed = !0, on(b, c), f = {
            J: f,
            I: !0
        }) : f = {
            J: a,
            I: 5
        } : f = {
            J: a,
            I: 4
        }: f = {
            J: a,
            I: 10
        };
        var {
            J: g,
            I: h
        } = f;
        if (h !== !0 || a === g) return new to(12, new ho(a, d), null, null, !0, h, 100);
        var {
            aa: k,
            V: p,
            D: n
        } = Qo(g, "auto", b, c, e, !0);
        return new to(1, k, n, 2, !0, h, p)
    };

    function Vo(a) {
        var b = a.google_ad_format;
        if (b === "autorelaxed") {
            a: {
                if (a.google_content_recommendation_ui_type !== "pedestal")
                    for (let c of uo)
                        if (a[c] != null) {
                            a = !0;
                            break a
                        }
                a = !1
            }
            return a ? 9 : 5
        }
        if (Oo(b)) return 1;
        if (b === "link") return 4;
        if (b === "fluid") return a.google_ad_layout === "in-article" ? (Wo(a), 1) : 8;
        if (a.google_reactive_ad_format === 27) return Wo(a), 1
    }

    function Xo(a, b, c, d, e = !1) {
        var f = b.offsetWidth || (c.google_ad_resize || e) && Zi(b, d, "width") || c.google_ad_width || 0;
        a === 4 && (c.google_ad_format = "auto", a = 1);
        e = (e = Yo(a, f, b, c, d)) ? e : Po(f, c.google_ad_format, d, b, c);
        e.size().i(d, c, b);
        e.D != null && (c.google_responsive_formats = e.D);
        e.H != null && (c.google_safe_for_responsive_override = e.H);
        e.I != null && (e.I === !0 ? c.google_full_width_responsive_allowed = !0 : (c.google_full_width_responsive_allowed = !1, c.gfwrnwer = e.I));
        e.V != null && e.V !== !0 && (c.gfwrnher = e.V);
        d = e.j || c.google_ad_width;
        d != null && (c.google_resizing_width = d);
        d = e.i || c.google_ad_height;
        d != null && (c.google_resizing_height = d);
        d = e.size().g(f);
        var g = e.size().height;
        c.google_ad_width = d;
        c.google_ad_height = g;
        var h = e.size();
        c.google_ad_format = `${h.g(f)}x${h.height}`;
        c.google_responsive_auto_format = e.G;
        e.g != null && (c.armr = e.g);
        c.google_ad_resizable = !0;
        c.google_override_format = 1;
        c.google_loader_features_used = 128;
        e.I === !0 && (c.gfwrnh = `${e.size().height}px`);
        e.u != null && (c.gfwroml = e.u);
        e.B != null && (c.gfwromr = e.B);
        e.i != null && (c.gfwroh =
            e.i);
        e.j != null && (c.gfwrow = e.j);
        e.A != null && (c.gfwroz = e.A);
        f = td(window) || window;
        en(f.location, "google_responsive_dummy_ad") && (Pa([1, 2, 3, 4, 5, 6, 7, 8], e.G) || e.g === 1) && e.g !== 2 && (f = JSON.stringify({
            googMsgType: "adpnt",
            key_value: [{
                key: "qid",
                value: "DUMMY_AD"
            }]
        }), c.dash = `<${so}>window.top.postMessage('${f}', '*'); 
          </${so}> 
          <div id="dummyAd" style="width:${d}px;height:${g}px; 
            background:#ddd;border:3px solid #f00;box-sizing:border-box; 
            color:#000;"> 
            <p>Requested size:${d}x${g}</p> 
            <p>Rendered size:${d}x${g}</p> 
          </div>`);
        a !== 1 && (a = e.size().height, b.style.height = `${a}px`)
    }

    function Yo(a, b, c, d, e) {
        var f = d.google_ad_height || Zi(c, e, "height") || 0;
        switch (a) {
            case 5:
                let {
                    J: g,
                    I: h
                } = dk(247, () => No(b, d.google_ad_format, e, c, d));
                h === !0 && b !== g && on(e, c);
                h === !0 ? d.google_full_width_responsive_allowed = !0 : (d.google_full_width_responsive_allowed = !1, d.gfwrnwer = h);
                return wo(g, d);
            case 9:
                return S(ii) ? wo(b, d) : zo(b, d);
            case 8:
                return Do(b, e, c, f, d);
            case 10:
                return Uo(b, e, c, f, d)
        }
    }

    function Wo(a) {
        a.google_ad_format = "auto";
        a.armr = 3
    };

    function Zo(a, b) {
        a.google_resizing_allowed = !0;
        a.google_ad_format = "auto";
        a.iaaso = !0;
        a.armr = b
    };

    function $o(a, b) {
        var c = td(b);
        if (c) {
            c = U(c);
            let d = Ud(a, b) || {},
                e = d.direction;
            if (d.width === "0px" && d.cssFloat !== "none") return -1;
            if (e === "ltr" && c) return Math.floor(Math.min(1200, c - a.getBoundingClientRect().left));
            if (e === "rtl" && c) return a = b.document.body.getBoundingClientRect().right - a.getBoundingClientRect().right, Math.floor(Math.min(1200, c - a - Math.floor((c - b.document.body.clientWidth) / 2)))
        }
        return -1
    };

    function ap(a, b) {
        switch (a) {
            case "google_reactive_ad_format":
                return a = parseInt(b, 10), isNaN(a) ? 0 : a;
            default:
                return b
        }
    }

    function bp(a, b) {
        if (a.getAttribute("src")) {
            var c = a.getAttribute("src") || "";
            let d = We(c, "client");
            d && (b.google_ad_client = ap("google_ad_client", d));
            (c = We(c, "host")) && (b.google_ad_host = ap("google_ad_host", c))
        }
        for (let d of a.attributes) /data-/.test(d.name) && (a = ua(d.name.replace("data-matched-content", "google_content_recommendation").replace("data", "google").replace(/-/g, "_")), b.hasOwnProperty(a) || (c = ap(a, d.value), c !== null && (b[a] = c)));
        b.google_ad_intents_format && !b.google_ad_intent_query && (b.google_reactive_ad_format =
            40)
    }

    function cp(a) {
        if (S(Fi) && Number(a.google_ad_intents_in_drawer_format) === 1) switch (Number(a.google_ad_intents_format)) {
            case 4:
                return 22;
            case 5:
                return 25;
            default:
                return 21
        }
        switch (Number(a.google_ad_intents_format)) {
            case 4:
                return 18;
            case 5:
                return 23;
            default:
                return 17
        }
    }

    function dp(a, b) {
        if (a = nh(a)) switch (a.data && a.data.autoFormat) {
            case "rspv":
                return 13;
            case "mcrspv":
                return 15;
            default:
                return 14
        } else {
            if (b.google_ad_intents_format)
                if (b.google_ad_intent_query) b = cp(b);
                else a: switch (Number(b.google_ad_intents_format)) {
                    case 4:
                        b = 20;
                        break a;
                    case 5:
                        b = 24;
                        break a;
                    default:
                        b = 19
                } else b = 12;
            return b
        }
    }

    function ep(a, b, c, d) {
        bp(a, b);
        if (c.document && c.document.body && !Vo(b) && !b.google_reactive_ad_format && !b.google_ad_intent_query) {
            var e = parseInt(a.style.width, 10),
                f = $o(a, c);
            if (f > 0 && e > f) {
                var g = parseInt(a.style.height, 10);
                e = !!Gn[e + "x" + g];
                let h = f;
                if (e) {
                    let k = Hn(f, g);
                    if (k) h = k, b.google_ad_format = k + "x" + g + "_0ads_al";
                    else throw new W("No slot size for availableWidth=" + f);
                }
                b.google_ad_resize = !0;
                b.google_ad_width = h;
                e || (b.google_ad_format = null, b.google_override_format = !0);
                f = h;
                a.style.width = `${f}px`;
                Zo(b, 4)
            }
        }
        if (S(ni) ||
            U(c) < 488) {
            f = td(c) || c;
            g = a.offsetWidth || Zi(a, c, "width") || b.google_ad_width || 0;
            e = b.google_ad_client;
            if (d = en(f.location, "google_responsive_slot_preview") || Im(f, 1, d, e)) b: if (b.google_reactive_ad_format || b.google_ad_resize || Vo(b) || hn(a, b)) d = !1;
                else {
                    for (d = a; d; d = d.parentElement) {
                        f = Ud(d, c);
                        if (!f) {
                            b.gfwrnwer = 18;
                            d = !1;
                            break b
                        }
                        if (!Pa(["static", "relative"], f.position)) {
                            b.gfwrnwer = 17;
                            d = !1;
                            break b
                        }
                    }
                    if (!S(vi) && (d = T(qi), d = jn(c, a, g, d, b), d !== !0)) {
                        b.gfwrnwer = d;
                        d = !1;
                        break b
                    }
                    d = c === c.top ? !0 : !1
                }
            d ? (Zo(b, 1), d = !0) : d = !1
        } else d = !1;
        if (g = Vo(b)) Xo(g, a, b, c, d);
        else {
            if (hn(a, b)) {
                if (d = Ud(a, c)) a.style.width = d.width, a.style.height = d.height, gn(d, b);
                b.google_ad_width || (b.google_ad_width = a.offsetWidth);
                b.google_ad_height || (b.google_ad_height = a.offsetHeight);
                b.google_loader_features_used = 256;
                b.google_responsive_auto_format = dp(c, b)
            } else gn(a.style, b);
            c.location && c.location.hash === "#gfwmrp" || b.google_responsive_auto_format === 12 && b.google_full_width_responsive === "true" ? Xo(10, a, b, c, !1) : Math.random() < .01 && b.google_responsive_auto_format ===
                12 && (a = kn(a.offsetWidth || parseInt(a.style.width, 10) || b.google_ad_width, c, a, b), a !== !0 ? (b.efwr = !1, b.gfwrnwer = a) : b.efwr = !0)
        }
    };
    var fp = ["google_pause_ad_requests", "google_user_agent_client_hint"];

    function gp(a) {
        var b = a.jb,
            c = a.bb,
            d = a.nb,
            e = a.l,
            f = a.X,
            g = a.Xa;
        c.dataset.adsbygoogleStatus = "done";
        var h = d.google_reactive_ads_config;
        b !== 2 && ep(c, d, e, f);
        Yn(e, d);
        if (b !== 2 && hp(c, d, e)) ip(c, d, e, a.Ga);
        else if (S(Qi) || b === 2 || Ud(c, e) ? .display !== "none" || d.google_adtest === "on" || d.google_reactive_ad_format > 0 || d.google_reactive_ads_config)
            if (jp(d)) q.console && q.console.warn("Adsbygoogle tag with data-reactive-ad-format=" + String(d.google_reactive_ad_format) + " is deprecated. Check out page-level ads at https://www.google.com/adsense");
            else {
                if (b === 2) {
                    f = h.page_level_pubvars || {};
                    if (Z(O).page_contains_reactive_tag && !Z(O).allow_second_reactive_tag) {
                        if (f.pltais) {
                            Dm(!1);
                            return
                        }
                        throw new W("Only one 'enable_page_level_ads' allowed per page.");
                    }
                    Z(O).page_contains_reactive_tag = !0;
                    Dm(f.google_pgb_reactive === 7)
                }
                d.google_unique_id = ph(e);
                for (let k of fp) d[k] = d[k] || e[k];
                d.google_loader_used !== "sd" && (d.google_loader_used = "aa");
                d.google_reactive_tag_first = (Z(O).first_tag_on_page || 0) === 1;
                dk(164, () => {
                    var {
                        Fb: k,
                        Yb: p
                    } = Fn(e, d);
                    c.appendChild(p);
                    bo(d);
                    sb(d.google_reactive_sra_index) && d.google_ad_unit_key || (d.google_ad_unit_key = co(c, d), d.google_ad_dom_fingerprint = In(e, c), d.override_ady = eo(c), d.override_adx = fo(c));
                    var n = d.google_start_time ? ? sh,
                        m = (new Date).getTime();
                    d.google_async_iframe_id = k;
                    d.google_start_time = n;
                    d.google_bpp = m > n ? m - n : 1;
                    b !== 2 && (n = e.fqjyf || {}, e.fqjyf = n, n[k] = {
                        LmpfC: d,
                        klgrb: a.Ga
                    });
                    Zn(e, () => {
                        var l = p,
                            t = b === 1 ? {
                                OSwJs: 1,
                                QJRox: a.Ga,
                                mqAVR: {
                                    crjDQ: g,
                                    ...(a.gb ? {
                                        bPXfr: a.gb
                                    } : {})
                                }
                            } : {
                                OSwJs: 2,
                                mqAVR: {
                                    crjDQ: g
                                }
                            };
                        if (!l || !l.isConnected)
                            if (l = e.document.getElementById(String(d.google_async_iframe_id) +
                                    "_host"), l == null) throw Error("no_div");
                        (t = e.google_sa_impl({
                            pubWin: e,
                            vars: d,
                            innerInsElement: l,
                            KCuMo: t
                        })) && fk(911, t)
                    })
                })
            }
        else e.document.createComment && c.appendChild(e.document.createComment("No ad requested because of display:none on the adsbygoogle tag"))
    }

    function hp(a, b, c) {
        var d = Bm(c);
        !d ? .Va || b.google_adtest === "on" || w(a.className) && RegExp("(\\W|^)adsbygoogle-noablate(\\W|$)").test(a.className) ? d = !1 : d.Wa ? (a = aj(a, c), c = Xi(c).clientHeight, d = ((c === 0 ? null : a / c) || 0) >= d.Wa) : d = !0;
        return d
    }

    function ip(a, b, c, d) {
        a.className += " adsbygoogle-ablated-ad-slot";
        var e = c.fqjyf || {};
        c.fqjyf = e;
        var f = String(ma(a));
        e[f] = {
            LmpfC: b,
            klgrb: d
        };
        a.setAttribute("google_element_uid", f);
        Bm(c) ? .Vb === "slot" && (Xd(a.getAttribute("width")) !== null && a.setAttribute("width", "0"), Xd(a.getAttribute("height")) !== null && a.setAttribute("height", "0"), a.style.width = "0px", a.style.height = "0px")
    }

    function jp(a) {
        var b = a.google_pgb_reactive == null || a.google_pgb_reactive === 3;
        return (a.google_reactive_ad_format === 1 || a.google_reactive_ad_format === 8) && b
    };

    function kp(a, b, c, d, e) {
        if (!O.google_sa_queue) {
            O.google_sa_queue = [];
            var f = lp(H(b, 4), e, b);
            f ? (f = !1, b = mp(O, e), En(b.client, b.plah).then(g => {
                c.resolve(D(g, pj, 2) ? .u() || void 0);
                d.resolve(H(g, 1))
            }).catch(g => {
                var h = new Dg(2, lg(), void 0, void 0, void 0, void 0, ih);
                Rj(h, 1191, g);
                c.resolve(void 0);
                d.resolve(!0)
            })) : (c.resolve(Rm(b) ? .G() ? .u() || void 0), d.resolve(Rm(b) ? .A() ? ? !0));
            O.google_process_slots = ek(215, () => {
                np(O.google_sa_queue)
            });
            a = op(e, a, f);
            Sd(O.document, a)
        }
    }

    function np(a) {
        var b = a.shift();
        ub(b) && dk(216, b);
        a.length && q.setTimeout(ek(215, () => {
            np(a)
        }), 0)
    }

    function lp(a, b, c) {
        var d = O;
        if (a) {
            a = rh(b ? ? "");
            b = Rm(c) ? .g() ? .g() || "";
            let e = Rm(c) ? .j() || "";
            c = !(a && (b === a || e === a) && d.location.host && J(c, 17) === d.location.host)
        } else c = !1;
        return c
    }

    function op(a, b, c) {
        var d = O;
        b = c ? b.Rb : b.Sb;
        a = { ...(c ? mp(d, a) : {}),
            ...pn()
        };
        return Qd(b, new Map(Object.entries(a)))
    }

    function mp(a, b) {
        if (b) {
            a: {
                try {
                    for (; a;) {
                        if (a.location ? .hostname) {
                            var c = a.location.hostname;
                            break a
                        }
                        a = a.parent
                    }
                } catch (d) {}
                c = ""
            }
            return {
                client: rh(b),
                plah: c
            }
        }
        throw Error("PublisherCodeNotFoundForAma");
    };

    function pp(a, b, c) {
        return a ? .[c] ? ? b ? .attributes.getNamedItem(`data-${c.slice(7).replace(/_/g,"-")}`) ? .value
    }

    function qp(a, b) {
        return {
            kxiJd: {
                VbBrq: pp(a, b, "google_ad_public_floor"),
                hZGxt: pp(a, b, "google_ad_private_floor")
            },
            ZGVTR: pp(a, b, "google_pucrd"),
            zUuKK: pp(a, b, "google_cust_criteria")
        }
    };
    var rp = class extends L {
        g() {
            return J(this, 1)
        }
        j() {
            return K(this, 2)
        }
    };
    var sp = class extends L {
        getName() {
            return J(this, 1)
        }
    };
    var tp = class extends L {
        g() {
            return E(this, sp, 1, C())
        }
    };
    var up = class extends L {
        j() {
            return J(this, 1)
        }
        g() {
            return D(this, rp, 2)
        }
        H() {
            return H(this, 3)
        }
        N() {
            return H(this, 4)
        }
        O() {
            return D(this, wl, 5)
        }
        ea() {
            return D(this, xl, 6)
        }
        ga() {
            return D(this, tp, 7)
        }
        A() {
            return H(this, 8)
        }
        G() {
            return D(this, pj, 9)
        }
        fa() {
            return H(this, 10)
        }
    };
    var vp = class extends L {
        getId() {
            return I(this, 1)
        }
    };

    function wp(a) {
        return E(a, vp, 2, C())
    }
    var xp = class extends L {};
    var yp = class extends L {};
    var zp = class extends L {
        g() {
            return Vc(this, 2) ? ? wc
        }
        j() {
            return Vc(this, 4) ? ? wc
        }
        A() {
            return H(this, 3)
        }
    };
    var Ap = class extends L {};
    var Bp = class extends L {
        g() {
            return H(this, 1)
        }
        A() {
            return H(this, 2)
        }
        j() {
            return H(this, 3)
        }
    };

    function Rm(a) {
        return $c(a, up, 27, Cp)
    }
    var Dp = class extends L {
            g() {
                return D(this, Bp, 26)
            }
        },
        Cp = [27, 28];

    function Ep(a) {
        var b = Zj;
        try {
            if (!w(a)) throw Error(String(a));
            if (a.length > 0) return new Dp(JSON.parse(a))
        } catch (c) {
            b.K(838, c instanceof Error ? c : Error(String(c)))
        }
        return new Dp
    };

    function Fp(a) {
        if (a === a.top) return 0;
        for (let b = a; b && b !== b.top && sd(b); b = b.parent) {
            if (a.sf_) return 2;
            if (a.$sf) return 3;
            if (a.inGptIF) return 4;
            if (a.inDapIF) return 5
        }
        return 1
    };

    function Gp(a, b, c) {
        for (let f of b) a: {
            b = a;
            var d = f,
                e = c;
            for (let g = 0; g < b.g.length; g++) {
                if (b.g[g].element.contains(d)) {
                    b.g[g].labels.add(e);
                    break a
                }
                if (d.contains(b.g[g].element)) {
                    b.g[g].element = d;
                    b.g[g].labels.add(e);
                    break a
                }
            }
            b.g.push({
                element: d,
                labels: new Set([e])
            })
        }
    }
    class Hp {
        constructor() {
            this.g = []
        }
        getSlots() {
            return this.g
        }
    }

    function Ip(a) {
        var b = fl(a),
            c = new Hp;
        Gp(c, b.rb, 1);
        Gp(c, b.sb, 2);
        Gp(c, b.Bb, 3);
        Gp(c, b.Xb, 4);
        Gp(c, b.tb, 5);
        Gp(c, b.Mb, 6);
        return c.getSlots().map(d => {
            var e = new wf;
            var f = [...d.labels];
            e = Ic(e, 1, f, Rb);
            d = d.element.getBoundingClientRect();
            f = new vf;
            f = cd(f, 1, d.left + a.scrollX);
            f = cd(f, 2, d.top + a.scrollY);
            f = cd(f, 3, d.width);
            d = cd(f, 4, d.height);
            d = sc(d);
            e = F(e, 2, d);
            return sc(e)
        }).sort((d, e) => {
            d = D(d, vf, 2);
            d = I(d, 2);
            e = D(e, vf, 2);
            e = I(e, 2);
            return d - e
        })
    };

    function Jp(a) {
        return a.google_ad_client ? String(a.google_ad_client) : Z(a).head_tag_slot_vars ? .google_ad_client ? ? a.document.querySelector(".adsbygoogle[data-ad-client]") ? .getAttribute("data-ad-client") ? ? ""
    };

    function Bg(a, b, c = 0) {
        a.g.size > 0 || Kp(a);
        c = Math.min(Math.max(0, c), 9);
        var d = a.g.get(c);
        d ? d.push(b) : a.g.set(c, [b])
    }

    function Lp(a, b, c, d) {
        le(b, c, d);
        wk(a, () => me(b, c, d))
    }

    function Mp(a, b) {
        a.state !== 1 && (a.state = 1, a.g.size > 0 && Np(a, b))
    }

    function Kp(a) {
        a.l.document.visibilityState ? Lp(a, a.l.document, "visibilitychange", b => {
            a.l.document.visibilityState === "hidden" && Mp(a, b);
            a.l.document.visibilityState === "visible" && (a.state = 0)
        }) : "onpagehide" in a.l ? (Lp(a, a.l, "pagehide", b => {
            Mp(a, b)
        }), Lp(a, a.l, "pageshow", () => {
            a.state = 0
        })) : Lp(a, a.l, "beforeunload", b => {
            Mp(a, b)
        })
    }

    function Np(a, b) {
        for (let c = 9; c >= 0; c--) a.g.get(c) ? .forEach(d => {
            d(b)
        })
    }
    var Op = class extends vk {
        constructor(a) {
            super();
            this.l = a;
            this.state = 0;
            this.g = new Map
        }
    };
    async function Pp(a, b) {
        var c = 10;
        return c <= 0 ? Promise.reject(Error(`wfc bad input ${c} 200`)) : b() ? Promise.resolve() : new Promise((d, e) => {
            var f = a.setInterval(() => {
                --c ? b() && (a.clearInterval(f), d()) : (a.clearInterval(f), e(Error(`wfc timed out ${c}`)))
            }, 200)
        })
    };

    function Qp(a) {
        var b = a.state.pc;
        return b !== null && b !== 0 ? b : a.state.pc = ce(a.l)
    }

    function Rp(a) {
        var b = a.state.wpc;
        return b !== null && b !== "" ? b : a.state.wpc = Jp(a.l)
    }

    function Sp(a, b) {
        var c = new Pf;
        var d = Qp(a);
        c = ed(c, 1, d);
        d = Rp(a);
        c = hd(c, 2, d);
        c = ed(c, 3, a.state.sd);
        return ed(c, 7, Math.round(b || a.l.performance.now()))
    }
    async function Tp(a) {
        try {
            return await Pp(a.l, () => !(!Qp(a) || !Rp(a))), !0
        } catch (b) {
            return !1
        }
    }

    function Up(a, b) {
        if (a.i) {
            var c = a.u;
            b(c);
            a.state.psi = y(c)
        }
    }

    function Vp(a) {
        Bg(a.j, () => {
            var b = Sp(a);
            b = G(b, 12, Qf, a.B);
            a.i && !a.state.le.includes(3) && (a.state.le.push(3), wg(a.g, b))
        }, 9)
    }

    function Wp(a) {
        var b = new Mf;
        Bg(a.j, () => {
            F(b, 2, a.u);
            ed(b, 3, a.state.tar);
            var c = a.l;
            var d = new Af;
            var e = Ip(c);
            d = Tc(d, 1, e);
            e = ld(yf(xf(new zf, U(c)), Xi(c).clientHeight));
            d = F(d, 2, e);
            c = ld(yf(xf(new zf, Xi(c).scrollWidth), Xi(c).scrollHeight));
            c = F(d, 3, c);
            c = sc(c);
            F(b, 4, c);
            c = a.g;
            d = Sp(a);
            d = G(d, 8, Qf, b);
            wg(c, d)
        }, 9)
    }
    async function Xp(a) {
        var b = M(Yp);
        if (b.i && !b.state.le.includes(1)) {
            b.state.le.push(1);
            var c = b.l.performance.now();
            if (await Tp(b)) {
                var d = new If;
                a = Jc(d, 5, Ob(a), !1);
                d = yf(xf(new zf, Xi(b.l).scrollWidth), Xi(b.l).scrollHeight);
                a = F(a, 2, d);
                d = yf(xf(new zf, U(b.l)), Xi(b.l).clientHeight);
                a = F(a, 1, d);
                for (var e = d = b.l; d && d !== d.parent;) d = d.parent, sd(d) && (e = d);
                a = hd(a, 4, e.location.href);
                d = Fp(b.l);
                d !== 0 && (e = new Hf, d = id(e, 1, d), F(a, 3, d));
                d = b.g;
                c = Sp(b, c);
                c = G(c, 4, Qf, a);
                wg(d, c);
                Vp(b);
                Wp(b)
            }
        }
    }
    async function Zp(a, b, c) {
        if (a.i && c.length && !a.state.lgdp.includes(Number(b))) {
            a.state.lgdp.push(Number(b));
            var d = a.l.performance.now();
            if (await Tp(a)) {
                var e = a.g;
                a = Sp(a, d);
                d = new Gf;
                b = jd(d, 1, b);
                c = Ic(b, 2, c, Tb);
                c = G(a, 9, Qf, c);
                wg(e, c)
            }
        }
    }
    async function $p(a, b) {
        if (await Tp(a)) {
            var c = a.g;
            a = Sp(a);
            a = ed(a, 3, 1);
            b = G(a, 10, Qf, b);
            wg(c, b)
        }
    }
    async function aq(a, b) {
        if (await Tp(a)) {
            var c = a.g;
            a = Sp(a);
            a = ed(a, 3, 1);
            b = G(a, 18, Qf, b);
            wg(c, b)
        }
    }
    var Yp = class {
        constructor(a, b) {
            this.l = oh() || window;
            this.j = b ? ? new Op(this.l);
            this.g = a ? ? new Dg(2, lg(), 100, 100, !0, this.j, ih);
            this.state = pk(kk(), 33, () => {
                var c = T(oi);
                return {
                    sd: c,
                    ssp: c > 0 && Kd() < 1 / c,
                    pc: null,
                    wpc: null,
                    cu: null,
                    le: [],
                    lgdp: [],
                    psi: null,
                    tar: 0,
                    cc: null
                }
            })
        }
        get i() {
            return this.state.ssp
        }
        get u() {
            return dk(1178, () => md(Lf, jc(this.state.psi || []))) || new Lf
        }
        get B() {
            return dk(1227, () => md(Of, jc(this.state.cc || []))) || new Of
        }
    };

    function bq() {
        var a = window;
        return q.google_adtest === "on" || q.google_adbreak_test === "on" || a.location.host.endsWith("h5games.usercontent.goog") || a.location.host === "gamesnacks.com" ? a.document.querySelector('meta[name="h5-games-eids"]') ? .getAttribute("content") ? .split(",").map(b => Math.floor(Number(b))).filter(b => !isNaN(b) && b > 0) || [] : []
    };

    function cq(a, b) {
        return a instanceof HTMLScriptElement && b.test(a.src) ? 0 : 1
    }

    function dq(a) {
        var b = O.document;
        if (b.currentScript) return cq(b.currentScript, a);
        for (let c of b.scripts)
            if (cq(c, a) === 0) return 0;
        return 1
    };

    function eq(a, b) {
        var c = !!b.g() ? .g();
        return {
            [3]: {
                [55]: () => a === 0,
                [23]: d => Im(O, Number(d), b),
                [24]: d => Lm(Number(d), c),
                [61]: () => c,
                [63]: () => c || J(b, 8) === ".google.ch"
            },
            [4]: {},
            [5]: {
                [6]: () => J(b, 15)
            }
        }
    };

    function fq(a = q) {
        return a.ggeac || (a.ggeac = {})
    };

    function gq(a, b = document) {
        return !!b.featurePolicy ? .features().includes(a)
    }

    function hq(a, b = document) {
        return !!b.featurePolicy ? .allowedFeatures().includes(a)
    }

    function iq(a, b = navigator) {
        try {
            return !!b.protectedAudience ? .queryFeatureSupport ? .(a)
        } catch (c) {
            return !1
        }
    };

    function jq(a, b) {
        try {
            let d = a.split(".");
            a = q;
            let e = 0,
                f;
            for (; a != null && e < d.length; e++) f = a, a = a[d[e]], typeof a === "function" && (a = f[d[e]]());
            var c = a;
            if (typeof c === b) return c
        } catch {}
    }
    var kq = {
        [3]: {
            [8]: a => {
                try {
                    return ja(a) != null
                } catch {}
            },
            [9]: a => {
                try {
                    var b = ja(a)
                } catch {
                    return
                }
                if (a = typeof b === "function") b = b && b.toString && b.toString(), a = w(b) && b.indexOf("[native code]") != -1;
                return a
            },
            [10]: () => window === window.top,
            [6]: (a, b) => Pa(ih(b ? Number(b) : void 0), Number(a)),
            [27]: a => {
                a = jq(a, "boolean");
                return a !== void 0 ? a : void 0
            },
            [60]: a => {
                try {
                    return !!q.document.querySelector(a)
                } catch {}
            },
            [80]: a => {
                try {
                    return !!q.matchMedia(a).matches
                } catch {}
            },
            [69]: a => gq(a, q.document),
            [70]: a => hq(a, q.document),
            [79]: a => iq(a,
                q.navigator)
        },
        [4]: {
            [3]: () => Jd(),
            [6]: a => {
                a = jq(a, "number");
                return a !== void 0 ? a : void 0
            }
        },
        [5]: {
            [2]: () => window.location.href,
            [3]: () => {
                try {
                    return window.top.location.hash
                } catch {
                    return ""
                }
            },
            [4]: a => {
                a = jq(a, "string");
                return a !== void 0 ? a : void 0
            },
            [12]: a => {
                try {
                    let b = jq(a, "string");
                    if (b !== void 0) return atob(b)
                } catch (b) {}
            }
        }
    };

    function lq(a) {
        return mq({
            [0]: new Map,
            [1]: new Map,
            [2]: new Map
        }, a)
    }

    function mq(a, b) {
        var c = new Map;
        for (let [f, g] of a[1].entries()) {
            var d = f,
                e = g;
            let {
                ob: h,
                kb: k,
                lb: p
            } = e[e.length - 1];
            c.set(d, h + k * p)
        }
        for (let f of b)
            for (let g of E(f, xp, 2, C())) {
                if (wp(g).length === 0) continue;
                b = Vb(A(g, 8)) ? ? 0;
                !K(g, 4) || K(g, 13) || K(g, 14) || (b = c.get(K(g, 4)) ? ? 0, d = (Vb(A(g, 1)) ? ? 0) * wp(g).length, c.set(K(g, 4), b + d));
                d = [];
                for (e = 0; e < wp(g).length; e++) {
                    let h = {
                        ob: b,
                        kb: Vb(A(g, 1)) ? ? 0,
                        lb: wp(g).length,
                        Lb: e,
                        la: K(f, 1),
                        ua: g,
                        W: wp(g)[e]
                    };
                    d.push(h)
                }
                nq(a[2], K(g, 10), d) || nq(a[1], K(g, 4), d) || nq(a[0], wp(g)[0].getId(), d)
            }
        return a
    }

    function nq(a, b, c) {
        if (!b) return !1;
        a.has(b) || a.set(b, []);
        a.get(b).push(...c);
        return !0
    };

    function oq(a = Kd()) {
        return b => Oh(`${b} + ${a}`) % 1E3
    };
    const pq = [12, 13, 20];

    function qq(a, b) {
        var c = M(Jg).T,
            d = jf(D(b.ua, bf, 3), c);
        if (!d.success) return Hg(a.R, D(b.ua, bf, 3), b.la, b.W.getId(), d), !1;
        if (!d.value) return !1;
        c = jf(D(b.W, bf, 3), c);
        return c.success ? c.value ? !0 : !1 : (Hg(a.R, D(b.W, bf, 3), b.la, b.W.getId(), c), !1)
    }

    function rq(a, b, c) {
        a.g[c] || (a.g[c] = []);
        a = a.g[c];
        a.includes(b) || a.push(b)
    }

    function sq(a, b, c, d) {
        var e = [],
            f;
        if (f = b !== 9) a.u[b] ? f = !0 : (a.u[b] = !0, f = !1);
        if (f) return Fg(a.R, b, c, e, [], 4), e;
        f = pq.includes(b);
        var g = [],
            h = [];
        for (let m of [0, 1, 2])
            for (let [l, t] of a.pa[m].entries()) {
                var k = l,
                    p = t;
                let v = new Vf;
                var n = p.filter(z => z.la === b && a.i[z.W.getId()] && qq(a, z));
                if (n.length) {
                    for (let z of n) h.push(z.W);
                    continue
                }
                if (a.Ba) continue;
                m === 2 ? (n = d[1], kd(v, 2, Wf, k)) : n = d[0];
                k = n ? .(String(k)) ? ? (m === 2 && K(p[0].ua, 11) === 1 ? void 0 : d[0](String(k)));
                if (k !== void 0) {
                    for (let z of p) {
                        if (z.la !== b) continue;
                        p = k - z.ob;
                        n = z.kb;
                        let N = z.lb,
                            ya = z.Lb;
                        if (p < 0 || p >= n * N || p % N !== ya) continue;
                        if (!qq(a, z)) continue;
                        p = K(z.ua, 13);
                        p !== 0 && p !== void 0 && (n = a.j[String(p)], n !== void 0 && n !== z.W.getId() ? Gg(a.R, a.j[String(p)], z.W.getId(), p) : a.j[String(p)] = z.W.getId());
                        h.push(z.W)
                    }
                    Oc(v, Wf) !== 0 && (dd(v, 3, k), g.push(v))
                }
            }
        for (let m of h) d = m.getId(), e.push(d), rq(a, d, f ? 4 : c), Zg(E(m, mf, 2, C()), f ? ah() : [c], a.R, d);
        Fg(a.R, b, c, e, g, 1);
        return e
    }

    function tq(a, b) {
        b = b.map(c => new yp(c)).filter(c => !pq.includes(K(c, 1)));
        a.pa = mq(a.pa, b)
    }

    function uq(a, b) {
        P(1, c => {
            a.i[c] = !0
        }, b);
        P(2, (c, d, e) => sq(a, c, d, e), b);
        P(3, c => (a.g[c] || []).concat(a.g[4]), b);
        P(12, c => void tq(a, c), b);
        P(16, (c, d) => void rq(a, c, d), b)
    }
    var vq = class {
        constructor(a, b, c, {
            Ba: d = !1,
            Ic: e = []
        } = {}) {
            this.pa = a;
            this.R = c;
            this.u = {};
            this.Ba = d;
            this.g = {
                [b]: [],
                [4]: []
            };
            this.i = {};
            this.j = {};
            if (a = De()) {
                a = a.split(",") || [];
                for (let f of a)(a = Number(f)) && (this.i[a] = !0)
            }
            for (let f of e) this.i[f] = !0
        }
    };

    function wq(a, b) {
        a.g = ch(14, b, () => {})
    }
    class xq {
        constructor() {
            this.g = () => {}
        }
    }

    function yq(a) {
        M(xq).g(a)
    };

    function zq({
        Db: a,
        T: b,
        config: c,
        wb: d = fq(),
        xb: e = 0,
        R: f = new Ig(Ml(D(a, zp, 5) ? .g()) ? ? 0, Ml(D(a, zp, 5) ? .j()) ? ? 0, D(a, zp, 5) ? .A() ? ? !1),
        pa: g = lq(E(a, yp, 2, C(pb)))
    }) {
        d.hasOwnProperty("init-done") ? (ch(12, d, () => {})(E(a, yp, 2, C()).map(h => y(h))), ch(13, d, () => {})(E(a, mf, 1, C()).map(h => y(h)), e), b && ch(14, d, () => {})(b), Aq(e, d)) : (uq(new vq(g, e, f, c), d), dh(d), eh(d), fh(d), Aq(e, d), Zg(E(a, mf, 1, C(pb)), [e], f, void 0, !0), Kg = Kg || !(!c || !c.Ib), yq(kq), b && yq(b))
    }

    function Aq(a, b = fq()) {
        gh(M(hh), b, a);
        Bq(b, a);
        wq(M(xq), b);
        M(ae).A()
    }

    function Bq(a, b) {
        var c = M(ae);
        c.j = (d, e) => ch(5, a, () => !1)(d, e, b);
        c.B = (d, e) => ch(6, a, () => 0)(d, e, b);
        c.g = (d, e) => ch(7, a, () => "")(d, e, b);
        c.i = (d, e) => ch(8, a, () => [])(d, e, b);
        c.u = (d, e) => ch(17, a, () => [])(d, e, b);
        c.A = () => {
            ch(15, a, () => {})(b)
        }
    };

    function Cq(a, b) {
        b = {
            [0]: oq(ce(b).toString())
        };
        b = M(hh).j(a, b);
        a = Zp(M(Yp), a, b);
        lh.ta(1085, a)
    }

    function Dq(a, b, c) {
        var d = D(b, Ap, 12),
            e = H(b, 9);
        zq({
            Db: d,
            T: eq(c, b),
            config: {
                Ba: e && !!a.google_disable_experiments,
                Ib: e
            },
            wb: fq(a),
            xb: 1
        });
        if (c = J(b, 15)) c = Number(c), M(hh).i(c);
        for (let f of Cc(b, 19, Ub, C())) M(hh).g(f);
        Cq(12, a);
        Cq(10, a)
    };

    function Eq(a) {
        Zj.B(b => {
            b.shv = String(a);
            b.mjsv = lg();
            var c = ih(),
                d = bq();
            b.eid = c.concat(d).join(",")
        })
    };

    function Fq(a, b, c) {
        return {
            stavq: I(a, 1),
            jTCuI: J(a, 2),
            OmOVT: H(a, 20),
            xujKL: H(a, 9),
            AyxaY: I(a, 18) !== -1 ? I(a, 18) : void 0,
            SLqBY: J(a, 8) || void 0,
            xVQAt: J(a, 3),
            OSCLM: {
                UWEfJ: !!a.g() ? .g(),
                YguOd: !!a.g() ? .A(),
                SVQEK: !!a.g() ? .j()
            },
            jzoix: {
                PygXN: (Rm(a) ? .ga() ? .g() || []).map(d => ({
                    aJhyn: d.getName(),
                    ihulF: J(d, 2)
                }))
            },
            gjPrg: Rm(a) ? .j() ? ? void 0,
            zeuLy: Rm(a) ? .g() ? .g() ? ? void 0,
            ANqoe: J(a, 17) ? ? void 0,
            FJPve: !1,
            GLnKw: !1,
            tYcft: b.promise,
            EGzMj: c.promise,
            uNjDc: !!Rm(a) ? .fa()
        }
    };

    function Gq(a, b, c) {
        if (c === "sd") return 0;
        if (H(b, 22)) return 7;
        if (H(b, 16)) return 6;
        c = Rm(b) ? .g() ? .g();
        b = Rm(b) ? .g() ? .j() ? ? 0;
        a = c === a;
        switch (b) {
            case 1:
                return a ? 9 : 8;
            case 2:
                return a ? 11 : 10;
            case 3:
                return a ? 13 : 12
        }
        return 1
    };

    function Hq(a, b) {
        var c = new Iq;
        try {
            let f = a.createElement("link");
            if (f.relList ? .supports ? .("compression-dictionary") && Ha()) {
                var d = f;
                if (b instanceof Cd) d.href = Ed(b).toString(), d.rel = "compression-dictionary";
                else {
                    if (Hd.indexOf("compression-dictionary") === -1) throw Error('TrustedResourceUrl href attribute required with rel="compression-dictionary"');
                    var e = Fd.test(b) ? b : void 0;
                    e !== void 0 && (d.href = e, d.rel = "compression-dictionary")
                }
                a.head.appendChild(f)
            }
        } catch (f) {
            c.qa({
                methodName: 1296,
                ya: f
            })
        }
    }

    function Jq(a) {
        return Pd `https://googleads.g.doubleclick.net/pagead/managed/dict/${a}/adsbygoogle`
    };
    var Iq = class {
        constructor() {
            this.g = Zj
        }
        qa(a) {
            var b = a.ya;
            this.g.K(a.methodName ? ? 0, b instanceof Error ? b : Error(String(b)))
        }
    };

    function Kq(a, b, c) {
        le(a, "message", d => {
            try {
                var e = JSON.parse(d.data)
            } catch (f) {
                return
            }!e || e.googMsgType !== b || c(e, d)
        })
    };

    function Lq(a, b) {
        return b == null ? `&${a}=null` : `&${a}=${Math.floor(b)}`
    }

    function Mq(a, b) {
        return `&${a}=${b.toFixed(3)}`
    }

    function Nq() {
        var a = new Set,
            b = el();
        try {
            if (!b) return a;
            let c = b.pubads();
            for (let d of c.getSlots()) a.add(d.getSlotId().getDomId())
        } catch {}
        return a
    }

    function Oq(a) {
        a = a.id;
        return a != null && (Nq().has(a) || a.startsWith("google_ads_iframe_") || a.startsWith("aswift"))
    }

    function Pq(a, b, c) {
        if (!a.sources) return !1;
        switch (Qq(a)) {
            case 2:
                let d = Rq(a);
                if (d) return c.some(f => Sq(d, f));
                break;
            case 1:
                let e = Tq(a);
                if (e) return b.some(f => Sq(e, f))
        }
        return !1
    }

    function Qq(a) {
        if (!a.sources) return 0;
        a = a.sources.filter(b => b.previousRect && b.currentRect);
        if (a.length >= 1) {
            a = a[0];
            if (a.previousRect.top < a.currentRect.top) return 2;
            if (a.previousRect.top > a.currentRect.top) return 1
        }
        return 0
    }

    function Tq(a) {
        return Uq(a, b => b.currentRect)
    }

    function Rq(a) {
        return Uq(a, b => b.previousRect)
    }

    function Uq(a, b) {
        return a.sources.reduce((c, d) => {
            d = b(d);
            return c ? d && d.width * d.height !== 0 ? d.top < c.top ? d : c : c : d
        }, null)
    }

    function Sq(a, b) {
        var c = Math.min(a.right, b.right) - Math.max(a.left, b.left);
        a = Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top);
        return c <= 0 || a <= 0 ? !1 : c * a * 100 / ((b.right - b.left) * (b.bottom - b.top)) >= 50
    }

    function Vq() {
        var a = Array.from(document.getElementsByTagName("iframe")).filter(Oq),
            b = [...Nq()].map(c => document.getElementById(c)).filter(c => c !== null);
        Wq = window.scrollX;
        Xq = window.scrollY;
        return Yq = [...a, ...b].map(c => c.getBoundingClientRect())
    }

    function Zq() {
        var a = new $q;
        if (S(Pi)) {
            var b = window;
            if (!b.google_plmetrics && window.PerformanceObserver) {
                b.google_plmetrics = !0;
                b = ["layout-shift", "largest-contentful-paint", "first-input", "longtask", "event"];
                for (let c of b) b = {
                    type: c,
                    buffered: !0
                }, c === "event" && (b.durationThreshold = 40), ar(a).observe(b);
                br(a)
            }
        }
    }

    function cr(a, b) {
        var c = Wq !== window.scrollX || Xq !== window.scrollY ? [] : Yq,
            d = Vq();
        for (let e of b.getEntries()) switch (b = e.entryType, b) {
            case "layout-shift":
                dr(a, e, c, d);
                break;
            case "largest-contentful-paint":
                b = e;
                a.Na = Math.floor(b.renderTime || b.loadTime);
                a.Ma = b.size;
                break;
            case "first-input":
                b = e;
                a.Ja = Number((b.processingStart - b.startTime).toFixed(3));
                a.Ka = !0;
                a.g.some(f => f.entries.some(g => e.duration === g.duration && e.startTime === g.startTime)) || er(a, e);
                break;
            case "longtask":
                b = Math.max(0, e.duration - 50);
                a.A += b;
                a.N =
                    Math.max(a.N, b);
                a.ga += 1;
                break;
            case "event":
                er(a, e);
                break;
            default:
                Hb(b, void 0)
        }
    }

    function ar(a) {
        a.R || (a.R = new PerformanceObserver(Fj(640, b => {
            cr(a, b)
        })));
        return a.R
    }

    function br(a) {
        var b = Fj(641, () => {
                var d = document;
                (d.prerendering ? 3 : {
                    visible: 1,
                    hidden: 2,
                    prerender: 3,
                    preview: 4,
                    unloaded: 5,
                    "": 0
                }[d.visibilityState || d.webkitVisibilityState || d.mozVisibilityState || ""] ? ? 0) === 2 && fr(a)
            }),
            c = Fj(641, () => void fr(a));
        document.addEventListener("visibilitychange", b);
        document.addEventListener("pagehide", c);
        a.Ia = () => {
            document.removeEventListener("visibilitychange", b);
            document.removeEventListener("pagehide", c);
            ar(a).disconnect()
        }
    }

    function fr(a) {
        if (!a.Qa) {
            a.Qa = !0;
            ar(a).takeRecords();
            var b = "https://pagead2.googlesyndication.com/pagead/gen_204?id=plmetrics";
            window.LayoutShift && (b += Mq("cls", a.G), b += Mq("mls", a.O), b += Lq("nls", a.fa), window.LayoutShiftAttribution && (b += Mq("cas", a.B), b += Lq("nas", a.Pa), b += Mq("was", a.Ua)), b += Mq("wls", a.va), b += Mq("tls", a.Ta));
            window.LargestContentfulPaint && (b += Lq("lcp", a.Na), b += Lq("lcps", a.Ma));
            window.PerformanceEventTiming && a.Ka && (b += Lq("fid", a.Ja));
            window.PerformanceLongTaskTiming && (b += Lq("cbt", a.A),
                b += Lq("mbt", a.N), b += Lq("nlt", a.ga));
            let d = 0;
            for (var c of document.getElementsByTagName("iframe")) Oq(c) && d++;
            b += Lq("nif", d);
            b += Lq("ifi", qh(window));
            c = ih();
            b += `&eid=${encodeURIComponent(c.join())}`;
            b += `&top=${q===q.top?1:0}`;
            b += a.Sa ? `&qqid=${encodeURIComponent(a.Sa)}` : Lq("pvsid", ce(q));
            window.googletag && (b += "&gpt=1");
            c = Math.min(a.g.length - 1, Math.floor((a.R ? a.La : performance.interactionCount || 0) / 50));
            c >= 0 && (c = a.g[c].latency, c >= 0 && (b += Lq("inp", c)));
            window.fetch(b, {
                keepalive: !0,
                credentials: "include",
                redirect: "follow",
                method: "get",
                mode: "no-cors"
            });
            a.Ia()
        }
    }

    function dr(a, b, c, d) {
        if (!b.hadRecentInput) {
            a.G += Number(b.value);
            Number(b.value) > a.O && (a.O = Number(b.value));
            a.fa += 1;
            if (c = Pq(b, c, d)) a.B += b.value, a.Pa++;
            if (b.startTime - a.Oa > 5E3 || b.startTime - a.Ra > 1E3) a.Oa = b.startTime, a.i = 0, a.j = 0;
            a.Ra = b.startTime;
            a.i += b.value;
            c && (a.j += b.value);
            a.i > a.va && (a.va = a.i, a.Ua = a.j, a.Ta = b.startTime + b.duration)
        }
    }

    function er(a, b) {
        gr(a, b);
        var c = a.g[a.g.length - 1],
            d = a.H[b.interactionId];
        if (d || a.g.length < 10 || b.duration > c.latency) d ? (d.entries.push(b), d.latency = Math.max(d.latency, b.duration)) : (b = {
            id: b.interactionId,
            latency: b.duration,
            entries: [b]
        }, a.H[b.id] = b, a.g.push(b)), a.g.sort((e, f) => f.latency - e.latency), a.g.splice(10).forEach(e => {
            delete a.H[e.id]
        })
    }

    function gr(a, b) {
        b.interactionId && (a.ea = Math.min(a.ea, b.interactionId), a.u = Math.max(a.u, b.interactionId), a.La = a.u ? (a.u - a.ea) / 7 + 1 : 0)
    }
    var $q = class {
            constructor() {
                this.j = this.i = this.fa = this.O = this.G = 0;
                this.Ra = this.Oa = Number.NEGATIVE_INFINITY;
                this.g = [];
                this.H = {};
                this.La = 0;
                this.ea = Infinity;
                this.Ja = this.Ma = this.Na = this.Pa = this.Ua = this.B = this.Ta = this.va = this.u = 0;
                this.Ka = !1;
                this.ga = this.N = this.A = 0;
                this.R = null;
                this.Qa = !1;
                this.Ia = () => {};
                var a = document.querySelector("[data-google-query-id]");
                this.Sa = a ? a.getAttribute("data-google-query-id") : null
            }
        },
        Wq, Xq, Yq = [];
    let hr = null;
    const ir = [],
        jr = new Map;
    let kr = -1;

    function lr(a) {
        return fj.test(a.className) && a.dataset.adsbygoogleStatus !== "done"
    }

    function mr(a) {
        var b = document.getElementsByTagName("INS");
        for (let d = 0, e = b[d]; d < b.length; e = b[++d]) {
            var c = e;
            if (lr(c) && c.dataset.adsbygoogleStatus !== "reserved" && (!a || e.id === a)) return e
        }
        return null
    }

    function nr(a, b, c, d, e) {
        if (a && "shift" in a) {
            Up(M(Yp), g => {
                var h = Kf(g);
                Yc(h, 2) || (g = Kf(g), fd(g, 2))
            });
            for (var f = 20; a.length > 0 && f > 0;) {
                try {
                    or(a.shift(), b, c, d, e)
                } catch (g) {
                    setTimeout(() => {
                        throw g;
                    })
                }--f
            }
        }
    }

    function pr() {
        var a = Td("INS");
        a.className = "adsbygoogle";
        a.className += " adsbygoogle-noablate";
        Zd(a);
        a.dataset.adHi = "true";
        return a
    }

    function qr(a, b) {
        var c = {},
            d = Qm(a.google_ad_client, b);
        rd(Wi, (h, k) => {
            a.enable_page_level_ads === !1 ? c[k] = !1 : a.hasOwnProperty(k) ? c[k] = a[k] : d.includes(h) && (c[k] = !1)
        });
        la(a.enable_page_level_ads) && (c.page_level_pubvars = a.enable_page_level_ads);
        var e = pr();
        oe.body.appendChild(e);
        var f = {
            google_reactive_ads_config: c,
            google_ad_client: a.google_ad_client
        };
        f.google_pause_ad_requests = !!Z(O).pause_ad_requests;
        var g = Gq(rr(a), b, f.google_loader_used);
        gp({
            jb: 2,
            bb: e,
            nb: f,
            l: window,
            X: b,
            Xa: g
        });
        Up(M(Yp), h => {
            var k = Kf(h);
            Yc(k,
                6) || (h = Kf(h), fd(h, 6))
        })
    }

    function sr(a, b) {
        vn(q).wasPlaTagProcessed = !0;
        var c = () => {
                qr(a, b)
            },
            d = q.document;
        if (d.body || d.readyState === "complete" || d.readyState === "interactive") qr(a, b);
        else {
            let e = wd(ek(191, c));
            le(d, "DOMContentLoaded", e);
            q.MutationObserver != null && (new q.MutationObserver((f, g) => {
                d.body && (e(), g.disconnect())
            })).observe(d, {
                childList: !0,
                subtree: !0
            })
        }
    }

    function or(a, b, c, d, e) {
        var f = {};
        dk(165, () => {
            tr(a, f, b, c, d, e)
        }, g => {
            g.client = g.client || f.google_ad_client || a.google_ad_client;
            g.slotname = g.slotname || f.google_ad_slot;
            g.tag_origin = g.tag_origin || f.google_tag_origin
        })
    }

    function ur(a) {
        delete a.google_checked_head;
        rd(a, (b, c) => {
            ej[c] || (delete a[c], q.console.warn(`AdSense head tag doesn't support ${c.replace("google","data").replace(/_/g,"-")} attribute.`))
        })
    }

    function vr(a, b) {
        var c = wr();
        if (c) {
            var d = {};
            bp(c, d);
            ur(d);
            d.google_ad_intent_query && (d.google_responsive_auto_format = cp(d), d.google_reactive_ad_format = 42);
            c = Z(window);
            let f = {};
            for (var e in d) f[e] = d[e];
            c.head_tag_slot_vars = f;
            e = {
                google_ad_client: d.google_ad_client,
                enable_page_level_ads: d
            };
            if (d.google_ad_intent_query || d.google_ad_intents_format) e.enable_ad_intent_display_ads = !0;
            d.google_overlays === "bottom" && (e.overlays = {
                bottom: !0
            });
            d.google_overlays === "collapsed-bottom" && (e.overlays = {
                bottom: !0,
                ["collapsed-bottom"]: !0
            });
            delete d.google_overlays;
            O.adsbygoogle || (O.adsbygoogle = []);
            c = O.adsbygoogle;
            c.loaded ? c.push(e) : c.splice && c.splice(0, 0, e);
            xr(d, b, a)
        }
    }

    function wr() {
        var a = O;
        if (a = a.document.querySelector('script[src*="/pagead/js/adsbygoogle.js?client="]:not([data-checked-head])') || a.document.querySelector('script[src*="/pagead/js/adsbygoogle_direct.js?client="]:not([data-checked-head])') || a.document.querySelector('script[src*="/pagead/js/adsbygoogle.js"][data-ad-client]:not([data-checked-head])') || a.document.querySelector('script[src*="/pagead/js/adsbygoogle_direct.js"][data-ad-client]:not([data-checked-head])'))
            if (a.setAttribute("data-checked-head", "true"),
                Z(window).head_tag_slot_vars) yr(a);
            else return Up(M(Yp), b => {
                b = Kf(b);
                Jc(b, 7, Ob(!0), !1)
            }), a
    }

    function xr(a, b, c) {
        b = Rm(b) ? .N();
        a.google_adbreak_test || b ? zr(a, c) : Kq(window, "sc-cnf", () => {
            zr(a, c)
        })
    }

    function yr(a) {
        var b = Z(window).head_tag_slot_vars,
            c = a.getAttribute("src") || "";
        if ((a = We(c, "client") || a.getAttribute("data-ad-client") || "") && a !== b.google_ad_client) throw new W(`Warning: Do not add multiple property codes with AdSense tag to avoid seeing unexpected behavior. These codes were found on the page ${a}, ${String(b.google_ad_client)}`);
    }

    function Ar(a) {
        if (typeof a === "object" && a != null) {
            if (w(a.type)) return 2;
            if (w(a.sound) || w(a.preloadAdBreaks) || typeof a.h5AdsConfig === "object") return 3
        }
        return 0
    }

    function tr(a, b, c, d, e, f) {
        if (a == null) throw new W("push() called with no parameters.");
        var g = M(Yp);
        Up(g, k => {
            var p = Kf(k);
            Yc(p, 3) || (k = Kf(k), fd(k, 3))
        });
        var h = Ar(a);
        if (h !== 0)
            if (d = Em(), d.first_slotcar_request_processing_time || (d.first_slotcar_request_processing_time = Date.now(), d.adsbygoogle_execution_start_time = sh), hr == null) Br(a), ir.push(a);
            else if (h === 3) {
            let k = hr;
            dk(787, () => {
                k.handleAdConfig(a)
            })
        } else fk(730, hr.handleAdBreak(a));
        else {
            sh = (new Date).getTime();
            kp(c, d, e, f, rr(a));
            Cr();
            a: {
                if (!a.enable_ad_intent_display_ads &&
                    a.enable_page_level_ads != void 0) {
                    if (w(a.google_ad_client)) {
                        h = !0;
                        break a
                    }
                    throw new W("'google_ad_client' is missing from the tag config.");
                }
                h = !1
            }
            if (h) Up(g, k => {
                var p = Kf(k);
                Yc(p, 4) || (k = Kf(k), fd(k, 4))
            }), Dr(a, d);
            else if ((h = a.params) && rd(h, (k, p) => {
                    b[p] = k
                }), b.google_ad_output === "js") console.warn("Ads with google_ad_output='js' have been deprecated and no longer work. Contact your AdSense account manager or switch to standard AdSense ads.");
            else {
                h = Gq(rr(a), d, b.google_loader_used);
                c = Er(b, a);
                bp(c, b);
                e = Z(q).head_tag_slot_vars || {};
                rd(e, (k, p) => {
                    b.hasOwnProperty(p) || (b[p] = k)
                });
                if (c.hasAttribute("data-require-head") && !Z(q).head_tag_slot_vars) throw new W("AdSense head tag is missing. AdSense body tags don't work without the head tag. You can copy the head tag from your account on https://adsense.com.");
                if (!b.google_ad_client) throw new W("Ad client is missing from the slot.");
                if (e = (Z(O).first_tag_on_page || 0) === 0 && yn(b)) Up(g, k => {
                    var p = Kf(k);
                    Yc(p, 5) || (k = Kf(k), fd(k, 5))
                }), Fr(e);
                (Z(O).first_tag_on_page || 0) === 0 && (Z(O).first_tag_on_page =
                    2);
                b.google_pause_ad_requests = !!Z(O).pause_ad_requests;
                g = a.ofxVI;
                gp({
                    jb: 1,
                    bb: c,
                    nb: b,
                    l: window,
                    X: d,
                    Ga: g ? .recYb ? .klgrb ? ? qp(a.params, c),
                    ...(g ? .bPXfr ? {
                        gb: g.bPXfr
                    } : {}),
                    Xa: h
                })
            }
        }
    }

    function rr(a) {
        return a.google_ad_client ? a.google_ad_client : (a = a.params) && a.google_ad_client ? a.google_ad_client : Jp(O)
    }

    function Cr() {
        if (S(Ai)) {
            let a = Bm(O);
            a && a.Va || Cm(O)
        }
    }

    function Fr(a) {
        ne(() => {
            vn(q).wasPlaTagProcessed || q.adsbygoogle && q.adsbygoogle.push(a)
        })
    }

    function Dr(a, b) {
        (Z(O).first_tag_on_page || 0) === 0 && (Z(O).first_tag_on_page = 1);
        if (a.tag_partner) {
            var c = a.tag_partner;
            let d = Z(q);
            d.tag_partners = d.tag_partners || [];
            d.tag_partners.push(c)
        }
        zn(a, b);
        sr(a, b)
    }

    function Er(a, b) {
        if (a.google_ad_format === "rewarded") {
            if (a.google_ad_slot == null) throw new W("Rewarded format does not have valid ad slot");
            if (a.google_ad_loaded_callback == null) throw new W("Rewarded format does not have ad loaded callback");
            a.google_reactive_ad_format = 11;
            a.google_wrap_fullscreen_ad = !0;
            a.google_video_play_muted = !1;
            a.google_acr = a.google_ad_loaded_callback;
            delete a.google_ad_loaded_callback;
            delete a.google_ad_format
        }
        var c = !!a.google_wrap_fullscreen_ad;
        if (c) b = pr(), b.dataset.adsbygoogleStatus =
            "reserved", oe.documentElement.appendChild(b);
        else if (b = b.element) {
            if (!lr(b) && (b.id ? b = mr(b.id) : b = null, !b)) throw new W("'element' has already been filled.");
            if (!("innerHTML" in b)) throw new W("'element' is not a good DOM element.");
        } else if (b = mr(), !b) throw new W("All 'ins' elements in the DOM with class=adsbygoogle already have ads in them.");
        if (c) {
            c = O;
            try {
                let e = (c || window).document,
                    f = e.compatMode == "CSS1Compat" ? e.documentElement : e.body;
                var d = (new fe(f.clientWidth, f.clientHeight)).round()
            } catch (e) {
                d =
                    new fe(-12245933, -12245933)
            }
            a.google_ad_height = d.height;
            a.google_ad_width = d.width;
            a.fsapi = !0
        }
        return b
    }

    function Gr(a) {
        kk().S[nk(26)] = !!Number(a)
    }

    function Hr(a) {
        Number(a) ? Z(O).pause_ad_requests = !0 : (Z(O).pause_ad_requests = !1, a = () => {
            if (!Z(O).pause_ad_requests) {
                var b = {};
                let c;
                typeof window.CustomEvent === "function" ? c = new CustomEvent("adsbygoogle-pub-unpause-ad-requests-event", b) : (c = document.createEvent("CustomEvent"), c.initCustomEvent("adsbygoogle-pub-unpause-ad-requests-event", !!b.bubbles, !!b.cancelable, b.detail));
                O.dispatchEvent(c)
            }
        }, q.setTimeout(a, 0), q.setTimeout(a, 1E3))
    }

    function Ir(a, b = !1) {
        var c = a.revenueMicros,
            d = a.revenueCurrency;
        if (w(d) && sb(c)) {
            a = M(Yp);
            var e = new Nf;
            e = gd(e, 1, "CPM");
            e = gd(e, 2, "PRECISE");
            d = gd(e, 3, d);
            c = zc(d, 4, c == null ? c : Wb(c));
            b = zc(c, 5, Ob(b));
            aq(a, sc(b))
        }
    }

    function Jr(a) {
        ub(a) && Kq(window, "aevi", b => {
            try {
                let c = b.revenueMicros,
                    d = b.revenueCurrency;
                sb(c) && w(d) && (Ir(b), a({
                    valueMicros: Math.floor(c / 1E3),
                    currencyCode: d
                }))
            } catch {
                console.log("onPaidEvent function call failed. Please follow the documentation: https://services.google.com/fh/files/helpcenter/adsense_ilar_implementation_guide.pdf")
            }
        })
    }

    function Kr(a) {
        ub(a) && window.setTimeout(a, 0)
    }

    function Lr(a) {
        var b = Math.floor(a / 1E3);
        a = a % 1E3 * 1E6;
        var c = new Bf;
        b = ed(c, 1, b);
        return dd(b, 2, a)
    }

    function zr(a, b) {
        var c = { ...pn()
        };
        b = tn(Qd(b.Ub, new Map(Object.entries(c)))).then(d => {
            hr == null && (d.init(a), hr = d, Mr(d))
        });
        fk(723, b);
        b.finally(() => {
            ir.length = 0;
            var d = Date.now(),
                e = d - sh;
            var f = new Cf;
            e = Lr(e);
            f = F(f, 1, e);
            kr >= 0 && (d = Lr(d - kr), F(f, 2, d));
            d = M(Yp);
            e = Df(23);
            f = G(e, 14, Ff, f);
            $p(d, f)
        })
    }

    function Mr(a) {
        for (let [c, d] of jr) {
            var b = c;
            let e = d;
            e !== -1 && (q.clearTimeout(e), jr.delete(b))
        }
        for (b = 0; b < ir.length; b++) {
            if (jr.has(b)) continue;
            let c = ir[b],
                d = Ar(c);
            dk(723, () => {
                d === 3 ? a.handleAdConfig(c) : d === 2 && fk(730, a.handleAdBreakBeforeReady(c))
            })
        }
    }

    function Br(a) {
        var b = ir.length;
        if (Ar(a) === 2 && a.type === "preroll" && a.adBreakDone != null) {
            var c = a.adBreakDone;
            kr === -1 && (kr = Date.now());
            var d = q.setTimeout(() => {
                try {
                    c({
                        breakType: "preroll",
                        breakName: a.name,
                        breakFormat: "preroll",
                        breakStatus: "timeout"
                    }), jr.set(b, -1), $p(M(Yp), Df(22))
                } catch (e) {
                    console.error("[Ad Placement API] adBreakDone callback threw an error:", e instanceof Error ? e : Error(String(e)))
                }
            }, T(Ri) * 1E3);
            jr.set(b, d)
        }
    };
    (function(a, b, c, d = () => {}) {
        Zj.N(ik);
        dk(166, () => {
            var e = window;
            if (!e.BGtEY) {
                e.BGtEY = !0;
                var f = new Dg(2, a, void 0, void 0, void 0, void 0, ih);
                try {
                    $a(l => {
                        Rj(f, 1191, l)
                    })
                } catch (l) {}
                var g = Ep(b);
                Eq(J(g, 2));
                d();
                ue(16, [1, y(g)]);
                var h = oh(nh(O)) || O,
                    k = c(a, g),
                    p = O.document.currentScript === null ? 1 : dq(k.Wb);
                Dq(h, g, p);
                S(Oi) && J(g, 29) && Hq(h.document, Jq(J(g, 29)));
                Up(M(Yp), l => {
                    var t = I(l, 1) + 1;
                    dd(l, 1, t);
                    O.top === O && (t = I(l, 2) + 1, dd(l, 2, t));
                    t = Kf(l);
                    Yc(t, 1) || (l = Kf(l), fd(l, 1))
                });
                fk(1086, Xp(p === 0));
                if (!Ga() || va(Ja(), 11) >= 0) {
                    bk(S(Si));
                    ao();
                    lm(Pc(g, Bp, 26));
                    try {
                        Zq()
                    } catch {}
                    $n();
                    vr(k, g);
                    h = e.adsbygoogle;
                    if (!h || !h.loaded) {
                        var n = new qn,
                            m = new qn;
                        p = {
                            push: l => {
                                or(l, k, g, n, m)
                            },
                            loaded: !0,
                            pageState: Fq(g, n, m)
                        };
                        try {
                            Object.defineProperty(p, "requestNonPersonalizedAds", {
                                set: Gr
                            }), Object.defineProperty(p, "pauseAdRequests", {
                                set: Hr
                            }), Object.defineProperty(p, "onload", {
                                set: Kr
                            }), Object.defineProperty(p, "onPaidEvent", {
                                set: Jr
                            })
                        } catch {}
                        if (S(Ci)) {
                            let l = Jp(O);
                            M(ae).i(Di.g, Di.defaultValue).includes(l) && Kq(O, "aevi", t => {
                                Ir(t, !0)
                            })
                        }
                        if (h)
                            for (let l of ["requestNonPersonalizedAds",
                                    "pauseAdRequests", "onPaidEvent"
                                ]) h[l] !== void 0 && (p[l] = h[l]);
                        nr(h, k, g, n, m);
                        e.adsbygoogle = p;
                        h && (p.onload = h.onload)
                    }
                }
            }
        })
    })(lg(), typeof sttc === "undefined" ? void 0 : sttc, function(a, b) {
        b = I(b, 1) > 2012 ? `_fy${I(b,1)}` : "";
        Pd `data:text/javascript,//show_ads_impl_preview.js`;
        return {
            Ub: Pd `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/slotcar_library${b}.js`,
            Sb: Pd `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/show_ads_impl${b}.js`,
            Rb: Pd `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/show_ads_impl_with_ama${b}.js`,
            Wb: /^(?:https?:)?\/\/(?:pagead2\.googlesyndication\.com|securepubads\.g\.doubleclick\.net)\/pagead\/(?:js\/)?(?:show_ads|adsbygoogle(_direct)?)\.js(?:[?#].*)?$/
        }
    });
}).call(this, "[2021,\"r20260512\",\"r20190131\",null,null,null,null,\".google.co.in\",null,null,null,[[[698926295,null,null,[1]],[null,619278254,null,[null,10]],[null,45696523,null,[]],[906386022,null,null,[1]],[45693370,null,null,null,[[[6,null,null,3,null,2],[1]]]],[682658313,null,null,[1]],[null,1130,null,[null,100]],[null,1340,null,[null,0.2]],[null,1338,null,[null,0.3]],[null,1339,null,[null,0.3]],[null,1032,null,[null,200],[[[12,null,null,null,4,null,\"Android\",[\"navigator.userAgent\"]],[null,500]]]],[null,728201648,null,[null,100]],[null,1224,null,[null,0.01]],[null,1346,null,[null,6]],[null,1347,null,[null,3]],[1342,null,null,[1]],[null,846334470,null,[null,1000]],[1393,null,null,[1]],[null,1394,null,[null,120]],[null,1396,null,[null,1000]],[null,1395,null,[null,500]],[null,1263,null,[null,-1]],[null,1323,null,[null,-1]],[null,1265,null,[null,-1]],[null,1264,null,[null,-1]],[1267,null,null,[1]],[null,66,null,[null,-1]],[null,65,null,[null,-1]],[1241,null,null,[1]],[1300,null,null,[1]],[null,null,null,[null,null,null,[\"en\",\"de\",\"fr\",\"es\",\"ja\"]],null,1273],[null,null,null,[null,null,null,[\"44786015\",\"44786016\"]],null,1261],[812820063,null,null,[1]],[752401956,null,null,[1]],[null,770241922,null,[null,1000]],[789511913,null,null,[1]],[null,812862057,null,[null,1000]],[828567904,null,null,[1]],[null,null,null,[null,null,null,[\"ca-pub-7178919035426667\",\"ca-pub-6430486603399192\",\"ca-pub-6217516951440692\",\"ca-pub-3269777183832488\",\"ca-pub-4286071012672876\",\"ca-pub-6893876361346206\",\"ca-pub-6865079278713445\",\"ca-pub-6062692039613877\",\"ca-pub-8700401253704627\",\"ca-pub-7409460644561046\",\"ca-pub-1807333429605702\",\"ca-pub-4414232724432396\",\"ca-pub-8878716159434368\",\"ca-pub-1725310704471587\",\"ca-pub-7286478979881995\",\"ca-pub-5420212072167331\",\"ca-pub-3001544606526418\",\"ca-pub-7647808421428026\",\"ca-pub-6109939056400055\",\"ca-pub-6907038225839490\",\"ca-pub-6462695325264077\",\"ca-pub-9260533539525355\",\"ca-pub-9284205722386242\",\"ca-pub-0636857377230346\",\"ca-pub-9067164180551135\",\"ca-pub-9649286969563355\",\"ca-pub-6150993149788596\",\"ca-pub-0085763304086106\"]],null,45736067],[622128248,null,null,[]],[882071067,null,null,[1]],[882516810,null,null,[1]],[882001608,null,null,[1]],[842638817,null,null,[1]],[882071066,null,null,[1]],[884402455,null,null,[1]],[882516809,null,null,[1]],[882001607,null,null,[1]],[829415421,null,null,[1]],[767123927,null,null,[1]],[null,null,45718425,[null,null,\"max(100px, calc(\\u003cDH\\u003e - 356px))\"]],[null,null,45718424,[null,null,\"max(100px, calc(\\u003cDH\\u003e - 320px))\"]],[null,null,780033902,[null,null,\"calc(\\u003cDH\\u003e - 30px)\"]],[null,null,716722045,[null,null,\"calc(\\u003cDH\\u003e - 30px)\"]],[null,799568408,null,[null,10]],[null,null,null,[null,null,null,[\"\",\"ar\",\"bn\",\"en\",\"es\",\"fr\",\"hi\",\"id\",\"ja\",\"ko\",\"mr\",\"pt\",\"ru\",\"sr\",\"te\",\"th\",\"tr\",\"uk\",\"vi\",\"zh\"]],null,712458671],[null,855152761,null,[null,0.6]],[null,null,null,[],null,null,null,683929765],[null,null,872996096,[null,null,\"calc(\\u003cSW\\u003e \/ 1.2)\"]],[null,868282444,null,[null,1200]],[null,null,834418652,[null,null,\"calc(max(\\u003cDH\\u003e - 150px, 50px))\"]],[null,null,874614210,[]],[null,null,834418651,[null,null,\"calc(max(\\u003cDH\\u003e - 150px, 50px))\"]],[886669062,null,null,[1]],[839747468,null,null,[1]],[869697744,null,null,[1]],[899601681,null,null,[1]],[null,775999093,null,[null,1]],[824550200,null,null,[1]],[null,9604,null,[]],[null,717888910,null,[]],[null,9601,null,[null,0.0001]],[null,618163195,null,[null,8000]],[null,624950166,null,[null,3000]],[null,623405755,null,[null,300]],[null,508040914,null,[null,622]],[null,547455356,null,[null,49]],[null,9605,null,[]],[null,717888911,null,[]],[null,9606,null,[]],[null,717888912,null,[]],[null,9603,null,[null,4]],[null,650548030,null,[null,3]],[null,650548032,null,[null,300]],[null,650548031,null,[null,1]],[null,469675170,null,[null,68040]],[null,836239785,null,[null,0.6]],[45775975,null,null,[1]],[838458490,null,null,[1]],[458320011,null,null,[]],[null,458320009,null,[null,0.4]],[675298507,null,null,[]],[711741274,null,null,[]],[785440426,null,null,[1]],[776685355,null,null,[]],[570863962,null,null,[]],[null,null,570879859,[null,null,\"control_1\\\\.\\\\d\"]],[null,570863961,null,[null,50]],[570879858,null,null,[1]],[null,null,754933823,[null,null,\"1-0-45\"]],[null,1085,null,[null,5]],[null,63,null,[null,30]],[null,1080,null,[null,5]],[null,10019,null,[null,5]],[null,1027,null,[null,10]],[null,57,null,[null,120]],[null,1079,null,[null,5]],[null,1050,null,[null,30]],[715572365,null,null,[1]],[715572366,null,null,[1]],[562874197,null,null,[1]],[null,732217386,null,[null,10000]],[null,794150639,null,[null,5000]],[null,732217387,null,[null,500]],[null,811376351,null,[null,0.5]],[null,733329086,null,[null,30000]],[null,629808663,null,[null,100]],[null,736623795,null,[null,250]],[null,745376892,null,[null,1]],[null,745376893,null,[null,2]],[null,550718588,null,[null,250]],[886091922,null,null,[1]],[897236184,null,null,[1]],[null,624290870,null,[null,50]],[null,815871887,null,[null,0.8]],[506738118,null,null,[1]],[null,null,null,[null,null,null,[\"AlK2UR5SkAlj8jjdEc9p3F3xuFYlF6LYjAML3EOqw1g26eCwWPjdmecULvBH5MVPoqKYrOfPhYVL71xAXI1IBQoAAAB8eyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3NTgwNjcxOTksImlzU3ViZG9tYWluIjp0cnVlfQ==\",\"Amm8\/NmvvQfhwCib6I7ZsmUxiSCfOxWxHayJwyU1r3gRIItzr7bNQid6O8ZYaE1GSQTa69WwhPC9flq\/oYkRBwsAAACCeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3NTgwNjcxOTksImlzU3ViZG9tYWluIjp0cnVlfQ==\",\"A9nrunKdU5m96PSN1XsSGr3qOP0lvPFUB2AiAylCDlN5DTl17uDFkpQuHj1AFtgWLxpLaiBZuhrtb2WOu7ofHwEAAACKeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiQUlQcm9tcHRBUElNdWx0aW1vZGFsSW5wdXQiLCJleHBpcnkiOjE3NzQzMTA0MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9\",\"A93bovR+QVXNx2\/38qDbmeYYf1wdte9EO37K9eMq3r+541qo0byhYU899BhPB7Cv9QqD7wIbR1B6OAc9kEfYCA4AAACQeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiQUlQcm9tcHRBUElNdWx0aW1vZGFsSW5wdXQiLCJleHBpcnkiOjE3NzQzMTA0MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9\",\"A1S5fojrAunSDrFbD8OfGmFHdRFZymSM\/1ss3G+NEttCLfHkXvlcF6LGLH8Mo5PakLO1sCASXU1\/gQf6XGuTBgwAAACQeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXRhZ3NlcnZpY2VzLmNvbTo0NDMiLCJmZWF0dXJlIjoiQUlQcm9tcHRBUElNdWx0aW1vZGFsSW5wdXQiLCJleHBpcnkiOjE3NzQzMTA0MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9\"]],null,1934],[485990406,null,null,[1]]],[[12,[[10,[[31061690],[31061691,[[83,null,null,[1]],[84,null,null,[1]]]]],null,61],[40,[[95340252],[95340253,[[662101537,null,null,[1]]]]],[4,null,9,null,null,null,null,[\"LayoutShift\"]],71,null,null,null,800,null,null,null,null,null,5],[40,[[95340254],[95340255,[[662101539,null,null,[1]]]]],[4,null,9,null,null,null,null,[\"LayoutShift\"]],71,null,null,null,800,null,null,null,null,null,5],[1000,[[95387091,null,[6,null,null,6,null,3,null,[\"WH.bucket\"]]]],[12,null,null,null,4,null,\"www\\\\.wikihow\\\\.com\",[\"location.href\"]],165,null,null,null,null,null,null,null,null,37],[1000,[[95387092,null,[6,null,null,6,null,13,null,[\"WH.bucket\"]]]],[12,null,null,null,4,null,\"www\\\\.wikihow\\\\.com\",[\"location.href\"]],165,null,null,null,null,null,null,null,null,37]]],[13,[[500,[[31061692],[31061693,[[77,null,null,[1]],[78,null,null,[1]],[80,null,null,[1]],[76,null,null,[1]]]]],[4,null,6,null,null,null,null,[\"31061691\",\"4\"]]]]],[10,[[10,[[31084127],[31084128]]],[1000,[[31098562,[[null,null,14,[null,null,\"31098562\"]]],[6,null,null,null,6,null,\"31098562\"]]],[4,null,55],63,null,null,null,null,null,null,null,null,2],[1000,[[31098563,[[null,null,14,[null,null,\"31098563\"]]],[6,null,null,null,6,null,\"31098563\"]]],[4,null,55],63,null,null,null,null,null,null,null,null,2],[1000,[[31098592,[[null,null,14,[null,null,\"31098592\"]]],[6,null,null,null,6,null,\"31098592\"]]],[4,null,55],63,null,null,null,null,null,null,null,null,2],[1000,[[31098593,[[null,null,14,[null,null,\"31098593\"]]],[6,null,null,null,6,null,\"31098593\"]]],[4,null,55],63,null,null,null,null,null,null,null,null,2],[1000,[[31098610,[[null,null,14,[null,null,\"31098610\"]]],[6,null,null,null,6,null,\"31098610\"]]],[4,null,55],63,null,null,null,null,null,null,null,null,2],[1000,[[31098611,[[null,null,14,[null,null,\"31098611\"]]],[6,null,null,null,6,null,\"31098611\"]]],[4,null,55],63,null,null,null,null,null,null,null,null,2],[1,[[42531513],[42531514,[[316,null,null,[1]]]]]],[1,[[42531644],[42531645,[[368,null,null,[1]]]],[42531646,[[369,null,null,[1]],[368,null,null,[1]]]]]],[1,[[42532242],[42532243,[[1256,null,null,[1]],[290,null,null,[1]]]]]],[50,[[42532523],[42532524,[[1300,null,null,[]]]]]],[null,[[42532525],[42532526]]],[100,[[42533293],[42533294,[[1383,null,null,[1]],[null,54,null,[null,100]],[null,66,null,[null,10]],[null,65,null,[null,1000]]]]],null,145],[1,[[44801778],[44801779,[[506914611,null,null,[1]]]]],[4,null,55],143],[1,[[95345037],[95345038,[[1377,null,null,[1]]]]],[4,null,55]],[1,[[95379869],[95379870,[[1399,null,null,[1]],[null,1400,null,[null,100]]]],[95379871,[[1399,null,null,[1]],[null,1400,null,[null,300]]]],[95379872,[[1399,null,null,[1]],[null,1400,null,[null,500]]]],[95379873,[[1399,null,null,[1]],[null,1400,null,[null,1000]]]],[95379874,[[1399,null,null,[1]],[null,1400,null,[null,2000]]]]],null,158],[null,[[95379875],[95379876],[95379877],[95379878],[95379879],[95379880]],null,158],[10,[[95386335],[95386336],[95386337,[[1397,null,null,[1]]]]],null,160],[50,[[95386338,[[1397,null,null,[1]]]],[95386362]],null,160],[null,[[95386813],[95386814]],[4,null,55]],[1,[[95388156],[95388157,[[1393,null,null,[]],[null,1394,null,[]],[null,1396,null,[]],[null,1395,null,[]]]]]],[null,[[95388158],[95388159]]],[1,[[95389912],[95389913],[95389914]],[4,null,55],161],[424,[[95389919],[95389920,[[566279275,null,null,[1]],[622128248,null,null,[1]],[566279276,null,null,[1]]]]],[2,[[4,null,55],[12,null,null,null,2,null,\"gegen-hartz\\\\.de\/|maimai\\\\.pro\/|pixelpulsegame\\\\.com\/\"]]],143],[50,[[95390277],[95390278,[[566279275,null,null,[1]],[622128248,null,null,[1]],[566279276,null,null,[1]],[767123927,null,null,[]]]]],[4,null,55],143],[1,[[95390662],[95390663],[95390664]],[4,null,55],161],[397,[[95390680],[95390681]],[4,null,55],161],[100,[[95390787],[95390788,[[null,835164910,null,[null,4000]],[null,822918959,null,[null,1]]]]],[4,null,55]]]],[17,[[10,[[31084487],[31084488]],null,null,null,null,32,null,null,142,1],[10,[[31089209],[31089210]],null,null,null,null,39,null,null,189,1],[50,[[95373848],[95373849]],null,null,null,null,47,40,null,189,1],[10,[[95375758],[95375759]],null,null,null,null,48,140,null,189,1],[10,[[95379673],[95379674]],null,null,null,null,50,160,null,189,1],[null,[[95389578],[95389579,[[45712481,null,null,[1]]]],[95389580,[[null,619278254,null,[null,-1]]]]],[4,null,55],null,null,null,null,null,null,214,1]]],[11,[[50,[[95386193],[95386194],[95386195]],[4,null,8,null,null,null,null,[\"scheduler\"]],147,null,null,null,null,null,null,null,null,null,9]]]],null,null,[null,1000,1,1000]],null,null,\"31098563\",1,\"mycsg.in\",196962105,null,null,null,null,null,null,null,[0,0,0],[\"ca-pub-7309667479757182\",null,null,null,[[[[null,0,null,null,null,null,\"DIV.csg-r-login-actions\"],2,[\"10px\",\"10px\",1],[2],null,null,null,1],[[null,0,null,null,null,null,\"BODY\\u003eDIV.row.justify-content-center.fixed\"],4,[\"10px\",\"8px\",1],[2],null,null,null,1],[[null,0,null,null,null,null,\"DIV.card-deck\"],4,[\"10px\",\"10px\",1],[2],null,null,null,1]]],[null,[[null,null,null,null,null,null,[0,2]]]]],null,\"m202605140101\"]");