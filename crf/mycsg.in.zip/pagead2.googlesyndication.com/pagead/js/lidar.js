(function(window, document) {
    var n, aa = typeof Object.create == "function" ? Object.create : function(a) {
            function b() {}
            b.prototype = a;
            return new b
        },
        ba = typeof Object.defineProperties == "function" ? Object.defineProperty : function(a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a
        };

    function ca(a) {
        a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
        for (var b = 0; b < a.length; ++b) {
            var c = a[b];
            if (c && c.Math == Math) return c
        }
        throw Error("Cannot find global object");
    }
    var ea = ca(this),
        fa = "Int8 Uint8 Uint8Clamped Int16 Uint16 Int32 Uint32 Float32 Float64".split(" ");
    ea.BigInt64Array && (fa.push("BigInt64"), fa.push("BigUint64"));

    function ha(a, b) {
        if (b)
            for (var c = 0; c < fa.length; c++) ia(fa[c] + "Array.prototype." + a, b)
    }

    function p(a, b) {
        b && ia(a, b)
    }

    function ia(a, b) {
        var c = ea;
        a = a.split(".");
        for (var d = 0; d < a.length - 1; d++) {
            var e = a[d];
            if (!(e in c)) return;
            c = c[e]
        }
        a = a[a.length - 1];
        d = c[a];
        b = b(d);
        b != d && b != null && ba(c, a, {
            configurable: !0,
            writable: !0,
            value: b
        })
    }
    var ja;
    if (typeof Object.setPrototypeOf == "function") ja = Object.setPrototypeOf;
    else {
        var ka;
        a: {
            var la = {
                    a: !0
                },
                ma = {};
            try {
                ma.__proto__ = la;
                ka = ma.a;
                break a
            } catch (a) {}
            ka = !1
        }
        ja = ka ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    var na = ja;

    function x(a, b) {
        a.prototype = aa(b.prototype);
        a.prototype.constructor = a;
        if (na) na(a, b);
        else
            for (var c in b)
                if (c != "prototype")
                    if (Object.defineProperties) {
                        var d = Object.getOwnPropertyDescriptor(b, c);
                        d && Object.defineProperty(a, c, d)
                    } else a[c] = b[c];
        a.Og = b.prototype
    }

    function oa(a) {
        var b = 0;
        return function() {
            return b < a.length ? {
                done: !1,
                value: a[b++]
            } : {
                done: !0
            }
        }
    }

    function y(a) {
        var b = typeof Symbol != "undefined" && Symbol.iterator && a[Symbol.iterator];
        if (b) return b.call(a);
        if (typeof a.length == "number") return {
            next: oa(a)
        };
        throw Error(String(a) + " is not an iterable or ArrayLike");
    }

    function A(a) {
        if (!(a instanceof Array)) {
            a = y(a);
            for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
            a = c
        }
        return a
    }

    function pa(a) {
        return qa(a, a)
    }

    function qa(a, b) {
        a.raw = b;
        Object.freeze && (Object.freeze(a), Object.freeze(b));
        return a
    }

    function ra(a, b) {
        return Object.prototype.hasOwnProperty.call(a, b)
    }
    var sa = typeof Object.assign == "function" ? Object.assign : function(a, b) {
        if (a == null) throw new TypeError("No nullish arg");
        a = Object(a);
        for (var c = 1; c < arguments.length; c++) {
            var d = arguments[c];
            if (d)
                for (var e in d) ra(d, e) && (a[e] = d[e])
        }
        return a
    };
    p("Object.assign", function(a) {
        return a || sa
    });

    function ta(a) {
        if (!(a instanceof Object)) throw new TypeError("Iterator result " + a + " is not an object");
    }

    function B() {
        this.R = !1;
        this.u = null;
        this.l = void 0;
        this.i = 1;
        this.o = this.A = 0;
        this.ra = this.m = null
    }

    function ua(a) {
        if (a.R) throw new TypeError("Generator is already running");
        a.R = !0
    }
    B.prototype.ba = function(a) {
        this.l = a
    };

    function va(a, b) {
        a.m = {
            Oe: b,
            Ye: !0
        };
        a.i = a.A || a.o
    }
    B.prototype.getNextAddressJsc = function() {
        return this.i
    };
    B.prototype.getYieldResultJsc = function() {
        return this.l
    };
    B.prototype.return = function(a) {
        this.m = {
            return: a
        };
        this.i = this.o
    };
    B.prototype["return"] = B.prototype.return;
    B.prototype.Ga = function(a) {
        this.m = {
            ea: a
        };
        this.i = this.o
    };
    B.prototype.jumpThroughFinallyBlocks = B.prototype.Ga;
    B.prototype.g = function(a, b) {
        this.i = b;
        return {
            value: a
        }
    };
    B.prototype.yield = B.prototype.g;
    B.prototype.Ha = function(a, b) {
        a = y(a);
        var c = a.next();
        ta(c);
        if (c.done) this.l = c.value, this.i = b;
        else return this.u = a, this.g(c.value, b)
    };
    B.prototype.yieldAll = B.prototype.Ha;
    B.prototype.ea = function(a) {
        this.i = a
    };
    B.prototype.jumpTo = B.prototype.ea;
    B.prototype.H = function() {
        this.i = 0
    };
    B.prototype.jumpToEnd = B.prototype.H;
    B.prototype.M = function(a, b) {
        this.A = a;
        b != void 0 && (this.o = b)
    };
    B.prototype.setCatchFinallyBlocks = B.prototype.M;
    B.prototype.ta = function(a) {
        this.A = 0;
        this.o = a || 0
    };
    B.prototype.setFinallyBlock = B.prototype.ta;
    B.prototype.V = function(a, b) {
        this.i = a;
        this.A = b || 0
    };
    B.prototype.leaveTryBlock = B.prototype.V;
    B.prototype.D = function(a) {
        this.A = a || 0;
        a = this.m.Oe;
        this.m = null;
        return a
    };
    B.prototype.enterCatchBlock = B.prototype.D;
    B.prototype.Y = function(a, b, c) {
        c ? this.ra[c] = this.m : this.ra = [this.m];
        this.A = a || 0;
        this.o = b || 0
    };
    B.prototype.enterFinallyBlock = B.prototype.Y;
    B.prototype.Z = function(a, b) {
        b = this.ra.splice(b || 0)[0];
        (b = this.m = this.m || b) ? b.Ye ? this.i = this.A || this.o : b.ea != void 0 && this.o < b.ea ? (this.i = b.ea, this.m = null) : this.i = this.o: this.i = a
    };
    B.prototype.leaveFinallyBlock = B.prototype.Z;
    B.prototype.forIn = function(a) {
        return new wa(a)
    };
    B.prototype.forIn = B.prototype.forIn;

    function wa(a) {
        this.l = a;
        this.g = [];
        for (var b in a) this.g.push(b);
        this.g.reverse()
    }
    wa.prototype.i = function() {
        for (; this.g.length > 0;) {
            var a = this.g.pop();
            if (a in this.l) return a
        }
        return null
    };
    wa.prototype.getNext = wa.prototype.i;

    function xa(a) {
        this.g = new B;
        this.i = a
    }

    function ya(a, b) {
        ua(a.g);
        var c = a.g.u;
        if (c) return za(a, "return" in c ? c["return"] : function(d) {
            return {
                value: d,
                done: !0
            }
        }, b, a.g.return);
        a.g.return(b);
        return Aa(a)
    }

    function za(a, b, c, d) {
        try {
            var e = b.call(a.g.u, c);
            ta(e);
            if (!e.done) return a.g.R = !1, e;
            var f = e.value
        } catch (g) {
            return a.g.u = null, va(a.g, g), Aa(a)
        }
        a.g.u = null;
        d.call(a.g, f);
        return Aa(a)
    }

    function Aa(a) {
        for (; a.g.i;) try {
            var b = a.i(a.g);
            if (b) return a.g.R = !1, {
                value: b.value,
                done: !1
            }
        } catch (c) {
            a.g.l = void 0, va(a.g, c)
        }
        a.g.R = !1;
        if (a.g.m) {
            b = a.g.m;
            a.g.m = null;
            if (b.Ye) throw b.Oe;
            return {
                value: b.return,
                done: !0
            }
        }
        return {
            value: void 0,
            done: !0
        }
    }

    function Ba(a) {
        this.next = function(b) {
            ua(a.g);
            a.g.u ? b = za(a, a.g.u.next, b, a.g.ba) : (a.g.ba(b), b = Aa(a));
            return b
        };
        this.throw = function(b) {
            ua(a.g);
            a.g.u ? b = za(a, a.g.u["throw"], b, a.g.ba) : (va(a.g, b), b = Aa(a));
            return b
        };
        this.return = function(b) {
            return ya(a, b)
        };
        this[Symbol.iterator] = function() {
            return this
        }
    }

    function Ca(a) {
        function b(d) {
            return a.next(d)
        }

        function c(d) {
            return a.throw(d)
        }
        return new Promise(function(d, e) {
            function f(g) {
                g.done ? d(g.value) : Promise.resolve(g.value).then(b, c).then(f, e)
            }
            f(a.next())
        })
    }

    function Da(a) {
        return Ca(new Ba(new xa(a)))
    }
    p("Symbol", function(a) {
        function b(f) {
            if (this instanceof b) throw new TypeError("Symbol is not a constructor");
            return new c(d + (f || "") + "_" + e++, f)
        }

        function c(f, g) {
            this.g = f;
            ba(this, "description", {
                configurable: !0,
                writable: !0,
                value: g
            })
        }
        if (a) return a;
        c.prototype.toString = function() {
            return this.g
        };
        var d = "jscomp_symbol_" + (Math.random() * 1E9 >>> 0) + "_",
            e = 0;
        return b
    });
    p("Symbol.iterator", function(a) {
        if (a) return a;
        a = Symbol("Symbol.iterator");
        ba(Array.prototype, a, {
            configurable: !0,
            writable: !0,
            value: function() {
                return Ea(oa(this))
            }
        });
        return a
    });
    p("Symbol.asyncIterator", function(a) {
        return a ? a : Symbol("Symbol.asyncIterator")
    });

    function Ea(a) {
        a = {
            next: a
        };
        a[Symbol.iterator] = function() {
            return this
        };
        return a
    }

    function Fa(a) {
        this[Symbol.asyncIterator] = function() {
            return this
        };
        this[Symbol.iterator] = function() {
            return a
        };
        this.next = function(b) {
            return Promise.resolve(a.next(b))
        };
        this["throw"] = function(b) {
            return new Promise(function(c, d) {
                var e = a["throw"];
                e !== void 0 ? c(e.call(a, b)) : (c = a["return"], c !== void 0 && c.call(a), d(new TypeError("no `throw` method")))
            })
        };
        a["return"] !== void 0 && (this["return"] = function(b) {
            return Promise.resolve(a["return"](b))
        })
    }

    function D() {
        for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
        return b
    }
    p("globalThis", function(a) {
        return a || ea
    });
    p("Reflect.setPrototypeOf", function(a) {
        return a ? a : na ? function(b, c) {
            try {
                return na(b, c), !0
            } catch (d) {
                return !1
            }
        } : null
    });
    p("Promise", function(a) {
        function b(g) {
            this.i = 0;
            this.l = void 0;
            this.g = [];
            this.A = !1;
            var h = this.m();
            try {
                g(h.resolve, h.reject)
            } catch (k) {
                h.reject(k)
            }
        }

        function c() {
            this.g = null
        }

        function d(g) {
            return g instanceof b ? g : new b(function(h) {
                h(g)
            })
        }
        if (a) return a;
        c.prototype.i = function(g) {
            if (this.g == null) {
                this.g = [];
                var h = this;
                this.l(function() {
                    h.o()
                })
            }
            this.g.push(g)
        };
        var e = ea.setTimeout;
        c.prototype.l = function(g) {
            e(g, 0)
        };
        c.prototype.o = function() {
            for (; this.g && this.g.length;) {
                var g = this.g;
                this.g = [];
                for (var h = 0; h < g.length; ++h) {
                    var k = g[h];
                    g[h] = null;
                    try {
                        k()
                    } catch (l) {
                        this.m(l)
                    }
                }
            }
            this.g = null
        };
        c.prototype.m = function(g) {
            this.l(function() {
                throw g;
            })
        };
        b.prototype.m = function() {
            function g(l) {
                return function(m) {
                    k || (k = !0, l.call(h, m))
                }
            }
            var h = this,
                k = !1;
            return {
                resolve: g(this.V),
                reject: g(this.o)
            }
        };
        b.prototype.V = function(g) {
            if (g === this) this.o(new TypeError("A Promise cannot resolve to itself"));
            else if (g instanceof b) this.Z(g);
            else {
                a: switch (typeof g) {
                    case "object":
                        var h = g != null;
                        break a;
                    case "function":
                        h = !0;
                        break a;
                    default:
                        h = !1
                }
                h ? this.R(g) : this.u(g)
            }
        };
        b.prototype.R = function(g) {
            var h = void 0;
            try {
                h = g.then
            } catch (k) {
                this.o(k);
                return
            }
            typeof h == "function" ? this.ba(h, g) : this.u(g)
        };
        b.prototype.o = function(g) {
            this.D(2, g)
        };
        b.prototype.u = function(g) {
            this.D(1, g)
        };
        b.prototype.D = function(g, h) {
            if (this.i != 0) throw Error("Cannot settle(" + g + ", " + h + "): Promise already settled in state" + this.i);
            this.i = g;
            this.l = h;
            this.i === 2 && this.Y();
            this.H()
        };
        b.prototype.Y = function() {
            var g = this;
            e(function() {
                if (g.M()) {
                    var h = ea.console;
                    typeof h !== "undefined" && h.error(g.l)
                }
            }, 1)
        };
        b.prototype.M = function() {
            if (this.A) return !1;
            var g = ea.CustomEvent,
                h = ea.Event,
                k = ea.dispatchEvent;
            if (typeof k === "undefined") return !0;
            typeof g === "function" ? g = new g("unhandledrejection", {
                cancelable: !0
            }) : typeof h === "function" ? g = new h("unhandledrejection", {
                cancelable: !0
            }) : (g = ea.document.createEvent("CustomEvent"), g.initCustomEvent("unhandledrejection", !1, !0, g));
            g.promise = this;
            g.reason = this.l;
            return k(g)
        };
        b.prototype.H = function() {
            if (this.g != null) {
                for (var g = 0; g < this.g.length; ++g) f.i(this.g[g]);
                this.g = null
            }
        };
        var f = new c;
        b.prototype.Z = function(g) {
            var h = this.m();
            g.Rc(h.resolve, h.reject)
        };
        b.prototype.ba = function(g, h) {
            var k = this.m();
            try {
                g.call(h, k.resolve, k.reject)
            } catch (l) {
                k.reject(l)
            }
        };
        b.prototype.then = function(g, h) {
            function k(t, r) {
                return typeof t == "function" ? function(w) {
                    try {
                        l(t(w))
                    } catch (u) {
                        m(u)
                    }
                } : r
            }
            var l, m, q = new b(function(t, r) {
                l = t;
                m = r
            });
            this.Rc(k(g, l), k(h, m));
            return q
        };
        b.prototype.catch = function(g) {
            return this.then(void 0, g)
        };
        b.prototype.Rc = function(g, h) {
            function k() {
                switch (l.i) {
                    case 1:
                        g(l.l);
                        break;
                    case 2:
                        h(l.l);
                        break;
                    default:
                        throw Error("Unexpected state: " + l.i);
                }
            }
            var l = this;
            this.g == null ? f.i(k) : this.g.push(k);
            this.A = !0
        };
        b.resolve = d;
        b.reject = function(g) {
            return new b(function(h, k) {
                k(g)
            })
        };
        b.race = function(g) {
            return new b(function(h, k) {
                for (var l = y(g), m = l.next(); !m.done; m = l.next()) d(m.value).Rc(h, k)
            })
        };
        b.all = function(g) {
            var h = y(g),
                k = h.next();
            return k.done ? d([]) : new b(function(l, m) {
                function q(w) {
                    return function(u) {
                        t[w] = u;
                        r--;
                        r == 0 && l(t)
                    }
                }
                var t = [],
                    r = 0;
                do t.push(void 0), r++, d(k.value).Rc(q(t.length - 1), m), k = h.next(); while (!k.done)
            })
        };
        return b
    });
    p("Object.setPrototypeOf", function(a) {
        return a || na
    });
    p("Symbol.dispose", function(a) {
        return a ? a : Symbol("Symbol.dispose")
    });
    p("WeakMap", function(a) {
        function b(k) {
            this.g = (h += Math.random() + 1).toString();
            if (k) {
                k = y(k);
                for (var l; !(l = k.next()).done;) l = l.value, this.set(l[0], l[1])
            }
        }

        function c() {}

        function d(k) {
            var l = typeof k;
            return l === "object" && k !== null || l === "function"
        }

        function e(k) {
            if (!ra(k, g)) {
                var l = new c;
                ba(k, g, {
                    value: l
                })
            }
        }

        function f(k) {
            var l = Object[k];
            l && (Object[k] = function(m) {
                if (m instanceof c) return m;
                Object.isExtensible(m) && e(m);
                return l(m)
            })
        }
        if (function() {
                if (!a || !Object.seal) return !1;
                try {
                    var k = Object.seal({}),
                        l = Object.seal({}),
                        m = new a([
                            [k, 2],
                            [l, 3]
                        ]);
                    if (m.get(k) != 2 || m.get(l) != 3) return !1;
                    m.delete(k);
                    m.set(l, 4);
                    return !m.has(k) && m.get(l) == 4
                } catch (q) {
                    return !1
                }
            }()) return a;
        var g = "$jscomp_hidden_" + Math.random();
        f("freeze");
        f("preventExtensions");
        f("seal");
        var h = 0;
        b.prototype.set = function(k, l) {
            if (!d(k)) throw Error("Invalid WeakMap key");
            e(k);
            if (!ra(k, g)) throw Error("WeakMap key fail: " + k);
            k[g][this.g] = l;
            return this
        };
        b.prototype.get = function(k) {
            return d(k) && ra(k, g) ? k[g][this.g] : void 0
        };
        b.prototype.has = function(k) {
            return d(k) && ra(k, g) && ra(k[g], this.g)
        };
        b.prototype.delete = function(k) {
            return d(k) && ra(k, g) && ra(k[g], this.g) ? delete k[g][this.g] : !1
        };
        return b
    });
    p("Map", function(a) {
        function b() {
            var h = {};
            return h.Ra = h.next = h.head = h
        }

        function c(h, k) {
            var l = h[1];
            return Ea(function() {
                if (l) {
                    for (; l.head != h[1];) l = l.Ra;
                    for (; l.next != l.head;) return l = l.next, {
                        done: !1,
                        value: k(l)
                    };
                    l = null
                }
                return {
                    done: !0,
                    value: void 0
                }
            })
        }

        function d(h, k) {
            var l = k && typeof k;
            l == "object" || l == "function" ? f.has(k) ? l = f.get(k) : (l = "" + ++g, f.set(k, l)) : l = "p_" + k;
            var m = h[0][l];
            if (m && ra(h[0], l))
                for (h = 0; h < m.length; h++) {
                    var q = m[h];
                    if (k !== k && q.key !== q.key || k === q.key) return {
                        id: l,
                        list: m,
                        index: h,
                        entry: q
                    }
                }
            return {
                id: l,
                list: m,
                index: -1,
                entry: void 0
            }
        }

        function e(h) {
            this[0] = {};
            this[1] = b();
            this.size = 0;
            if (h) {
                h = y(h);
                for (var k; !(k = h.next()).done;) k = k.value, this.set(k[0], k[1])
            }
        }
        if (function() {
                if (!a || typeof a != "function" || !a.prototype.entries || typeof Object.seal != "function") return !1;
                try {
                    var h = Object.seal({
                            x: 4
                        }),
                        k = new a(y([
                            [h, "s"]
                        ]));
                    if (k.get(h) != "s" || k.size != 1 || k.get({
                            x: 4
                        }) || k.set({
                            x: 4
                        }, "t") != k || k.size != 2) return !1;
                    var l = k.entries(),
                        m = l.next();
                    if (m.done || m.value[0] != h || m.value[1] != "s") return !1;
                    m = l.next();
                    return m.done || m.value[0].x != 4 || m.value[1] != "t" || !l.next().done ? !1 : !0
                } catch (q) {
                    return !1
                }
            }()) return a;
        var f = new WeakMap;
        e.prototype.set = function(h, k) {
            h = h === 0 ? 0 : h;
            var l = d(this, h);
            l.list || (l.list = this[0][l.id] = []);
            l.entry ? l.entry.value = k : (l.entry = {
                next: this[1],
                Ra: this[1].Ra,
                head: this[1],
                key: h,
                value: k
            }, l.list.push(l.entry), this[1].Ra.next = l.entry, this[1].Ra = l.entry, this.size++);
            return this
        };
        e.prototype.delete = function(h) {
            h = d(this, h);
            return h.entry && h.list ? (h.list.splice(h.index, 1), h.list.length || delete this[0][h.id], h.entry.Ra.next = h.entry.next, h.entry.next.Ra = h.entry.Ra, h.entry.head = null, this.size--, !0) : !1
        };
        e.prototype.clear = function() {
            this[0] = {};
            this[1] = this[1].Ra = b();
            this.size = 0
        };
        e.prototype.has = function(h) {
            return !!d(this, h).entry
        };
        e.prototype.get = function(h) {
            return (h = d(this, h).entry) && h.value
        };
        e.prototype.entries = function() {
            return c(this, function(h) {
                return [h.key, h.value]
            })
        };
        e.prototype.keys = function() {
            return c(this, function(h) {
                return h.key
            })
        };
        e.prototype.values = function() {
            return c(this, function(h) {
                return h.value
            })
        };
        e.prototype.forEach = function(h, k) {
            for (var l = this.entries(), m; !(m = l.next()).done;) m = m.value, h.call(k, m[1], m[0], this)
        };
        e.prototype[Symbol.iterator] = e.prototype.entries;
        var g = 0;
        return e
    });
    p("Set", function(a) {
        function b(c) {
            this.g = new Map;
            if (c) {
                c = y(c);
                for (var d; !(d = c.next()).done;) this.add(d.value)
            }
            this.size = this.g.size
        }
        if (function() {
                if (!a || typeof a != "function" || !a.prototype.entries || typeof Object.seal != "function") return !1;
                try {
                    var c = Object.seal({
                            x: 4
                        }),
                        d = new a(y([c]));
                    if (!d.has(c) || d.size != 1 || d.add(c) != d || d.size != 1 || d.add({
                            x: 4
                        }) != d || d.size != 2) return !1;
                    var e = d.entries(),
                        f = e.next();
                    if (f.done || f.value[0] != c || f.value[1] != c) return !1;
                    f = e.next();
                    return f.done || f.value[0] == c || f.value[0].x != 4 || f.value[1] != f.value[0] ? !1 : e.next().done
                } catch (g) {
                    return !1
                }
            }()) return a;
        b.prototype.add = function(c) {
            c = c === 0 ? 0 : c;
            this.g.set(c, c);
            this.size = this.g.size;
            return this
        };
        b.prototype.delete = function(c) {
            c = this.g.delete(c);
            this.size = this.g.size;
            return c
        };
        b.prototype.clear = function() {
            this.g.clear();
            this.size = 0
        };
        b.prototype.has = function(c) {
            return this.g.has(c)
        };
        b.prototype.entries = function() {
            return this.g.entries()
        };
        b.prototype.values = function() {
            return this.g.values()
        };
        b.prototype.keys = b.prototype.values;
        b.prototype[Symbol.iterator] = b.prototype.values;
        b.prototype.forEach = function(c, d) {
            var e = this;
            this.g.forEach(function(f) {
                return c.call(d, f, f, e)
            })
        };
        return b
    });

    function Ga(a, b, c) {
        if (a == null) throw new TypeError("The 'this' value for String.prototype." + c + " must not be null or undefined");
        if (b instanceof RegExp) throw new TypeError("First argument to String.prototype." + c + " must not be a regular expression");
        return a + ""
    }
    p("Array.prototype.find", function(a) {
        return a ? a : function(b, c) {
            a: {
                var d = this;d instanceof String && (d = String(d));
                for (var e = d.length, f = 0; f < e; f++) {
                    var g = d[f];
                    if (b.call(c, g, f, d)) {
                        b = g;
                        break a
                    }
                }
                b = void 0
            }
            return b
        }
    });

    function Ha(a, b) {
        a instanceof String && (a += "");
        var c = 0,
            d = !1,
            e = {
                next: function() {
                    if (!d && c < a.length) {
                        var f = c++;
                        return {
                            value: b(f, a[f]),
                            done: !1
                        }
                    }
                    d = !0;
                    return {
                        done: !0,
                        value: void 0
                    }
                }
            };
        e[Symbol.iterator] = function() {
            return e
        };
        return e
    }
    p("Array.prototype.entries", function(a) {
        return a ? a : function() {
            return Ha(this, function(b, c) {
                return [b, c]
            })
        }
    });
    p("Array.prototype.keys", function(a) {
        return a ? a : function() {
            return Ha(this, function(b) {
                return b
            })
        }
    });
    p("String.prototype.startsWith", function(a) {
        return a ? a : function(b, c) {
            var d = Ga(this, b, "startsWith"),
                e = d.length,
                f = b.length;
            c = Math.max(0, Math.min(c | 0, d.length));
            for (var g = 0; g < f && c < e;)
                if (d[c++] != b[g++]) return !1;
            return g >= f
        }
    });
    p("Number.isFinite", function(a) {
        return a ? a : function(b) {
            return typeof b !== "number" ? !1 : !isNaN(b) && b !== Infinity && b !== -Infinity
        }
    });
    p("String.prototype.repeat", function(a) {
        return a ? a : function(b) {
            var c = Ga(this, null, "repeat");
            if (b < 0 || b > 1342177279) throw new RangeError("Invalid count value");
            b |= 0;
            for (var d = ""; b;)
                if (b & 1 && (d += c), b >>>= 1) c += c;
            return d
        }
    });
    p("Object.entries", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) ra(b, d) && c.push([d, b[d]]);
            return c
        }
    });
    p("Array.from", function(a) {
        return a ? a : function(b, c, d) {
            c = c != null ? c : function(h) {
                return h
            };
            var e = [],
                f = typeof Symbol != "undefined" && Symbol.iterator && b[Symbol.iterator];
            if (typeof f == "function") {
                b = f.call(b);
                for (var g = 0; !(f = b.next()).done;) e.push(c.call(d, f.value, g++))
            } else
                for (f = b.length, g = 0; g < f; g++) e.push(c.call(d, b[g], g));
            return e
        }
    });
    p("Number.MAX_SAFE_INTEGER", function() {
        return 9007199254740991
    });
    p("Number.MIN_SAFE_INTEGER", function() {
        return -9007199254740991
    });
    p("Number.isInteger", function(a) {
        return a ? a : function(b) {
            return Number.isFinite(b) ? b === Math.floor(b) : !1
        }
    });
    p("Number.isSafeInteger", function(a) {
        return a ? a : function(b) {
            return Number.isInteger(b) && Math.abs(b) <= Number.MAX_SAFE_INTEGER
        }
    });
    p("Object.is", function(a) {
        return a ? a : function(b, c) {
            return b === c ? b !== 0 || 1 / b === 1 / c : b !== b && c !== c
        }
    });
    p("Array.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            var d = this;
            d instanceof String && (d = String(d));
            var e = d.length;
            c = c || 0;
            for (c < 0 && (c = Math.max(c + e, 0)); c < e; c++) {
                var f = d[c];
                if (f === b || Object.is(f, b)) return !0
            }
            return !1
        }
    });
    p("String.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            return Ga(this, b, "includes").indexOf(b, c || 0) !== -1
        }
    });
    p("Object.values", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) ra(b, d) && c.push(b[d]);
            return c
        }
    });
    p("Math.trunc", function(a) {
        return a ? a : function(b) {
            b = Number(b);
            if (isNaN(b) || b === Infinity || b === -Infinity || b === 0) return b;
            var c = Math.floor(Math.abs(b));
            return b < 0 ? -c : c
        }
    });
    p("Number.isNaN", function(a) {
        return a ? a : function(b) {
            return typeof b === "number" && isNaN(b)
        }
    });
    p("Array.prototype.values", function(a) {
        return a ? a : function() {
            return Ha(this, function(b, c) {
                return c
            })
        }
    });
    p("String.prototype.padStart", function(a) {
        return a ? a : function(b, c) {
            var d = Ga(this, null, "padStart");
            b -= d.length;
            c = c !== void 0 ? String(c) : " ";
            return (b > 0 && c ? c.repeat(Math.ceil(b / c.length)).substring(0, b) : "") + d
        }
    });
    p("Array.prototype.fill", function(a) {
        return a ? a : function(b, c, d) {
            var e = this.length || 0;
            c < 0 && (c = Math.max(0, e + c));
            if (d == null || d > e) d = e;
            d = Number(d);
            d < 0 && (d = Math.max(0, e + d));
            for (c = Number(c || 0); c < d; c++) this[c] = b;
            return this
        }
    });
    ha("fill", function(a) {
        return a ? a : Array.prototype.fill
    });
    p("Array.prototype.flat", function(a) {
        return a ? a : function(b) {
            b = b === void 0 ? 1 : b;
            var c = [];
            Array.prototype.forEach.call(this, function(d) {
                Array.isArray(d) && b > 0 ? (d = Array.prototype.flat.call(d, b - 1), c.push.apply(c, d)) : c.push(d)
            });
            return c
        }
    });
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    var Ia = this || self;

    function Ja(a, b) {
        a: {
            var c = ["CLOSURE_FLAGS"];
            for (var d = Ia, e = 0; e < c.length; e++)
                if (d = d[c[e]], d == null) {
                    c = null;
                    break a
                }
            c = d
        }
        a = c && c[a];
        return a != null ? a : b
    }

    function Ka(a) {
        var b = typeof a;
        return b != "object" ? b : a ? Array.isArray(a) ? "array" : b : "null"
    }

    function Ma(a) {
        var b = Ka(a);
        return b == "array" || b == "object" && typeof a.length == "number"
    }

    function Na(a) {
        var b = typeof a;
        return b == "object" && a != null || b == "function"
    }

    function Oa(a) {
        return a
    }

    function Pa(a, b) {
        function c() {}
        c.prototype = b.prototype;
        a.Og = b.prototype;
        a.prototype = new c;
        a.prototype.constructor = a;
        a.Bh = function(d, e, f) {
            for (var g = Array(arguments.length - 2), h = 2; h < arguments.length; h++) g[h - 2] = arguments[h];
            return b.prototype[e].apply(d, g)
        }
    };
    var Qa;

    function Ra(a, b) {
        if (typeof a === "string") return typeof b !== "string" || b.length != 1 ? -1 : a.indexOf(b, 0);
        for (var c = 0; c < a.length; c++)
            if (c in a && a[c] === b) return c;
        return -1
    }

    function Sa(a, b) {
        for (var c = a.length, d = typeof a === "string" ? a.split("") : a, e = 0; e < c; e++) e in d && b.call(void 0, d[e], e, a)
    }

    function Ua(a, b) {
        for (var c = a.length, d = [], e = 0, f = typeof a === "string" ? a.split("") : a, g = 0; g < c; g++)
            if (g in f) {
                var h = f[g];
                b.call(void 0, h, g, a) && (d[e++] = h)
            }
        return d
    }

    function Va(a, b, c) {
        for (var d = a.length, e = Array(d), f = typeof a === "string" ? a.split("") : a, g = 0; g < d; g++) g in f && (e[g] = b.call(c, f[g], g, a));
        return e
    }

    function Wa(a, b) {
        var c = "";
        Sa(a, function(d, e) {
            c = b.call(void 0, c, d, e, a)
        });
        return c
    }

    function Xa(a, b) {
        for (var c = a.length, d = typeof a === "string" ? a.split("") : a, e = 0; e < c; e++)
            if (e in d && b.call(void 0, d[e], e, a)) return !0;
        return !1
    }

    function Ya(a) {
        for (var b = ["x", "y", "width", "height"], c = b.length, d = typeof b === "string" ? b.split("") : b, e = 0; e < c; e++)
            if (e in d && !a.call(void 0, d[e], e, b)) return !1;
        return !0
    }

    function Za(a, b) {
        a: {
            for (var c = a.length, d = typeof a === "string" ? a.split("") : a, e = 0; e < c; e++)
                if (e in d && b.call(void 0, d[e], e, a)) {
                    b = e;
                    break a
                }
            b = -1
        }
        return b < 0 ? null : typeof a === "string" ? a.charAt(b) : a[b]
    }

    function bb(a, b) {
        b = Ra(a, b);
        b >= 0 && Array.prototype.splice.call(a, b, 1)
    }

    function cb(a) {
        return Array.prototype.concat.apply([], arguments)
    }

    function db(a) {
        var b = a.length;
        if (b > 0) {
            for (var c = Array(b), d = 0; d < b; d++) c[d] = a[d];
            return c
        }
        return []
    }

    function eb(a, b, c) {
        return arguments.length <= 2 ? Array.prototype.slice.call(a, b) : Array.prototype.slice.call(a, b, c)
    }

    function fb(a, b) {
        a.sort(b || gb)
    }

    function hb(a, b, c) {
        if (!Ma(a) || !Ma(b) || a.length != b.length) return !1;
        var d = a.length;
        c = c || ib;
        for (var e = 0; e < d; e++)
            if (!c(a[e], b[e])) return !1;
        return !0
    }

    function gb(a, b) {
        return a > b ? 1 : a < b ? -1 : 0
    }

    function ib(a, b) {
        return a === b
    }

    function kb(a) {
        for (var b = [], c = 0; c < arguments.length; c++) {
            var d = arguments[c];
            if (Array.isArray(d))
                for (var e = 0; e < d.length; e += 8192) {
                    var f = eb(d, e, e + 8192);
                    f = kb.apply(null, f);
                    for (var g = 0; g < f.length; g++) b.push(f[g])
                } else b.push(d)
        }
        return b
    }

    function lb(a, b, c) {
        return cb.apply([], Va(a, b, c))
    };
    var mb = {
            NONE: 0,
            kh: 1
        },
        nb = {
            fh: 0,
            sh: 1,
            rh: 2,
            th: 3
        },
        ob = {
            dh: "a",
            ih: "d",
            wh: "v"
        };

    function pb() {
        this.aa = 0;
        this.i = !1;
        this.g = -1;
        this.ja = !1;
        this.l = 0
    }
    pb.prototype.isVisible = function() {
        return this.ja ? this.aa >= .3 : this.aa >= .5
    };
    var qb = {
            eh: 0,
            mh: 1
        },
        rb = {
            668123728: 0,
            668123729: 1
        },
        sb = {
            44731964: 0,
            44731965: 1
        },
        tb = {
            NONE: 0,
            oh: 1,
            nh: 2
        },
        ub = {
            480596784: 0,
            480596785: 1,
            21063355: 2
        };

    function vb(a, b, c) {
        for (var d in a) b.call(c, a[d], d, a)
    }

    function wb(a, b) {
        var c = {},
            d;
        for (d in a) b.call(void 0, a[d], d, a) && (c[d] = a[d]);
        return c
    }

    function xb(a) {
        var b = yb,
            c;
        for (c in b)
            if (!a.call(void 0, b[c], c, b)) return !1;
        return !0
    }

    function zb(a) {
        var b = [],
            c = 0,
            d;
        for (d in a) b[c++] = a[d];
        return b
    }

    function Ab(a) {
        var b = {},
            c;
        for (c in a) b[c] = a[c];
        return b
    }
    var Bb = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");

    function Cb(a, b) {
        for (var c, d, e = 1; e < arguments.length; e++) {
            d = arguments[e];
            for (c in d) a[c] = d[c];
            for (var f = 0; f < Bb.length; f++) c = Bb[f], Object.prototype.hasOwnProperty.call(d, c) && (a[c] = d[c])
        }
    };

    function Db() {
        this.g = null;
        this.m = !1;
        this.i = null
    }

    function Eb(a) {
        a.m = !0;
        return a
    }

    function Fb(a, b) {
        a.i && Sa(b, function(c) {
            c = a.i[c];
            c !== void 0 && a.l(c)
        })
    }

    function Gb(a) {
        Db.call(this);
        this.o = a
    }
    x(Gb, Db);
    Gb.prototype.l = function(a) {
        var b;
        if (!(b = this.g !== null)) {
            a: {
                b = this.o;
                for (c in b)
                    if (b[c] == a) {
                        var c = !0;
                        break a
                    }
                c = !1
            }
            b = !c
        }
        b || (this.g = a)
    };

    function Hb() {
        Db.call(this)
    }
    x(Hb, Db);
    Hb.prototype.l = function(a) {
        this.g === null && typeof a === "number" && (this.g = a)
    };

    function Ib() {
        this.g = {};
        this.l = !0;
        this.i = {}
    }
    Ib.prototype.reset = function() {
        this.g = {};
        this.l = !0;
        this.i = {}
    };

    function Kb(a, b, c) {
        a.g[b] || (a.g[b] = new Gb(c));
        return a.g[b]
    }

    function Lb(a, b) {
        (a = a.g.od) && a.l(b)
    }

    function Mb(a, b) {
        var c = a.i;
        if (c !== null && b in c) return a.i[b];
        if (a = a.g[b]) return a.g
    }

    function Nb(a) {
        var b = {},
            c = wb(a.g, function(d) {
                return d.m
            });
        vb(c, function(d, e) {
            d = a.i[e] !== void 0 ? String(a.i[e]) : d.m && d.g !== null ? String(d.g) : "";
            d.length > 0 && (b[e] = d)
        }, a);
        return b
    }

    function Ob(a, b) {
        if (!a.l) return b;
        b = b.split("&");
        for (var c = b.length - 1; c >= 0; c--) {
            var d = b[c].split("="),
                e = decodeURIComponent(d[0]);
            d.length > 1 ? (d = decodeURIComponent(d[1]), d = /^[0-9]+$/g.exec(d) ? parseInt(d, 10) : d) : d = 1;
            (e = a.g[e]) && e.l(d)
        }
        return b.join("&")
    }

    function Pb(a, b) {
        a.l && Sa(zb(a.g), function(c) {
            return Fb(c, b)
        })
    }

    function Qb(a, b) {
        a.l && b && typeof b === "string" && (b = b.match(/[&;?]eid=([^&;]+)/)) && b.length === 2 && (b = decodeURIComponent(b[1]).split(","), b = Va(b, function(c) {
            return Number(c)
        }), Pb(a, b))
    };

    function Rb(a) {
        Kb(a, "od", mb);
        Eb(Kb(a, "opac", qb));
        Eb(Kb(a, "sbeos", qb));
        Eb(Kb(a, "prf", qb));
        Eb(Kb(a, "mwt", qb));
        Kb(a, "iogeo", qb)
    };
    var Sb = document,
        G = window;
    var Tb = Ja(610401301, !1),
        Ub = Ja(748402147, !0);

    function Vb(a, b) {
        return a.toLowerCase().indexOf(b.toLowerCase()) != -1
    };

    function Wb() {
        var a = Ia.navigator;
        return a && (a = a.userAgent) ? a : ""
    }
    var Xb, Yb = Ia.navigator;
    Xb = Yb ? Yb.userAgentData || null : null;

    function Zb(a) {
        if (!Tb || !Xb) return !1;
        for (var b = 0; b < Xb.brands.length; b++) {
            var c = Xb.brands[b].brand;
            if (c && c.indexOf(a) != -1) return !0
        }
        return !1
    }

    function H(a) {
        return Wb().indexOf(a) != -1
    };

    function $b() {
        return Tb ? !!Xb && Xb.brands.length > 0 : !1
    }

    function ac() {
        return $b() ? !1 : H("Opera")
    }

    function bc() {
        return H("Firefox") || H("FxiOS")
    }

    function cc() {
        return H("Safari") && !(dc() || ($b() ? 0 : H("Coast")) || ac() || ($b() ? 0 : H("Edge")) || ($b() ? Zb("Microsoft Edge") : H("Edg/")) || ($b() ? Zb("Opera") : H("OPR")) || bc() || H("Silk") || H("Android"))
    }

    function dc() {
        return $b() ? Zb("Chromium") : (H("Chrome") || H("CriOS")) && !($b() ? 0 : H("Edge")) || H("Silk")
    }

    function ec() {
        return H("Android") && !(dc() || bc() || ac() || H("Silk"))
    };
    /* 
     
     Copyright Google LLC 
     SPDX-License-Identifier: Apache-2.0 
    */
    var fc = globalThis.trustedTypes,
        hc;

    function ic() {
        var a = null;
        if (!fc) return a;
        try {
            var b = function(c) {
                return c
            };
            a = fc.createPolicy("goog#html", {
                createHTML: b,
                createScript: b,
                createScriptURL: b
            })
        } catch (c) {}
        return a
    };

    function jc(a) {
        this.g = a
    }
    jc.prototype.toString = function() {
        return this.g + ""
    };

    function kc(a) {
        var b;
        hc === void 0 && (hc = ic());
        a = (b = hc) ? b.createScriptURL(a) : a;
        return new jc(a)
    };
    var lc = pa([""]),
        mc = qa(["\x00"], ["\\0"]),
        nc = qa(["\n"], ["\\n"]),
        oc = qa(["\x00"], ["\\u0000"]);

    function pc(a) {
        return a.toString().indexOf("`") === -1
    }
    pc(function(a) {
        return a(lc)
    }) || pc(function(a) {
        return a(mc)
    }) || pc(function(a) {
        return a(nc)
    }) || pc(function(a) {
        return a(oc)
    });

    function qc(a, b) {
        a.__closure__error__context__984382 || (a.__closure__error__context__984382 = {});
        a.__closure__error__context__984382.severity = b
    };

    function rc() {
        return "opacity".replace(/\-([a-z])/g, function(a, b) {
            return b.toUpperCase()
        })
    }

    function sc(a) {
        return String(a).replace(/([A-Z])/g, "-$1").toLowerCase()
    }

    function tc(a) {
        return a.replace(RegExp("(^|[\\s]+)([a-z])", "g"), function(b, c, d) {
            return c + d.toUpperCase()
        })
    };

    function uc() {
        return Tb ? !!Xb && !!Xb.platform : !1
    }

    function vc() {
        return H("iPhone") && !H("iPod") && !H("iPad")
    }

    function wc() {
        vc() || H("iPad") || H("iPod")
    };

    function xc(a) {
        xc[" "](a);
        return a
    }
    xc[" "] = function() {};

    function yc(a, b) {
        try {
            return xc(a[b]), !0
        } catch (c) {}
        return !1
    };
    ac();
    var zc = $b() ? !1 : H("Trident") || H("MSIE");
    H("Edge");
    var Ac = H("Gecko") && !(Vb(Wb(), "WebKit") && !H("Edge")) && !(H("Trident") || H("MSIE")) && !H("Edge"),
        Bc = Vb(Wb(), "WebKit") && !H("Edge"),
        Cc = Bc && H("Mobile");
    uc() || H("Macintosh");
    uc() || H("Windows");
    (uc() ? Xb.platform === "Linux" : H("Linux")) || uc() || H("CrOS");
    uc() || H("Android");
    vc();
    H("iPad");
    H("iPod");
    wc();
    Vb(Wb(), "KaiOS");
    bc();
    vc() || H("iPod");
    H("iPad");
    ec();
    dc();
    cc() && wc();
    var Dc = !zc && !cc();

    function Ec(a, b) {
        if (/-[a-z]/.test(b)) return null;
        if (Dc && a.dataset) {
            if (ec() && !(b in a.dataset)) return null;
            a = a.dataset[b];
            return a === void 0 ? null : a
        }
        return a.getAttribute("data-" + sc(b))
    }

    function Fc(a, b) {
        return /-[a-z]/.test(b) ? !1 : Dc && a.dataset ? b in a.dataset : a.hasAttribute ? a.hasAttribute("data-" + sc(b)) : !!a.getAttribute("data-" + sc(b))
    };

    function Gc(a, b) {
        this.x = a !== void 0 ? a : 0;
        this.y = b !== void 0 ? b : 0
    }
    n = Gc.prototype;
    n.clone = function() {
        return new Gc(this.x, this.y)
    };
    n.equals = function(a) {
        return a instanceof Gc && (this == a ? !0 : this && a ? this.x == a.x && this.y == a.y : !1)
    };
    n.ceil = function() {
        this.x = Math.ceil(this.x);
        this.y = Math.ceil(this.y);
        return this
    };
    n.floor = function() {
        this.x = Math.floor(this.x);
        this.y = Math.floor(this.y);
        return this
    };
    n.round = function() {
        this.x = Math.round(this.x);
        this.y = Math.round(this.y);
        return this
    };

    function Hc(a, b) {
        this.width = a;
        this.height = b
    }
    n = Hc.prototype;
    n.clone = function() {
        return new Hc(this.width, this.height)
    };
    n.aspectRatio = function() {
        return this.width / this.height
    };
    n.isEmpty = function() {
        return !(this.width * this.height)
    };
    n.ceil = function() {
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    n.floor = function() {
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    n.round = function() {
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    "ARTICLE SECTION NAV ASIDE H1 H2 H3 H4 H5 H6 HEADER FOOTER ADDRESS P HR PRE BLOCKQUOTE OL UL LH LI DL DT DD FIGURE FIGCAPTION MAIN DIV EM STRONG SMALL S CITE Q DFN ABBR RUBY RB RT RTC RP DATA TIME CODE VAR SAMP KBD SUB SUP I B U MARK BDI BDO SPAN BR WBR NOBR INS DEL PICTURE PARAM TRACK MAP TABLE CAPTION COLGROUP COL TBODY THEAD TFOOT TR TD TH SELECT DATALIST OPTGROUP OPTION OUTPUT PROGRESS METER FIELDSET LEGEND DETAILS SUMMARY MENU DIALOG SLOT CANVAS FONT CENTER ACRONYM BASEFONT BIG DIR HGROUP STRIKE TT".split(" ").concat(["BUTTON", "INPUT"]);

    function Ic(a) {
        var b = D.apply(1, arguments);
        if (b.length === 0) return kc(a[0]);
        for (var c = a[0], d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return kc(c)
    };

    function Jc(a) {
        return a ? new Kc(Lc(a)) : Qa || (Qa = new Kc)
    }

    function Mc(a) {
        var b = a.scrollingElement ? a.scrollingElement : Bc || a.compatMode != "CSS1Compat" ? a.body || a.documentElement : a.documentElement;
        a = a.defaultView;
        return new Gc((a == null ? void 0 : a.pageXOffset) || b.scrollLeft, (a == null ? void 0 : a.pageYOffset) || b.scrollTop)
    }

    function Nc(a, b, c) {
        function d(h) {
            h && b.appendChild(typeof h === "string" ? a.createTextNode(h) : h)
        }
        for (var e = 1; e < c.length; e++) {
            var f = c[e];
            if (!Ma(f) || Na(f) && f.nodeType > 0) d(f);
            else {
                a: {
                    if (f && typeof f.length == "number") {
                        if (Na(f)) {
                            var g = typeof f.item == "function" || typeof f.item == "string";
                            break a
                        }
                        if (typeof f === "function") {
                            g = typeof f.item == "function";
                            break a
                        }
                    }
                    g = !1
                }
                Sa(g ? db(f) : f, d)
            }
        }
    }

    function Lc(a) {
        return a.nodeType == 9 ? a : a.ownerDocument || a.document
    }

    function Oc(a, b) {
        a && (a = a.parentNode);
        for (var c = 0; a;) {
            if (b(a)) return a;
            a = a.parentNode;
            c++
        }
        return null
    }

    function Kc(a) {
        this.g = a || Ia.document || document
    }
    n = Kc.prototype;
    n.getElementsByTagName = function(a, b) {
        return (b || this.g).getElementsByTagName(String(a))
    };
    n.appendChild = function(a, b) {
        a.appendChild(b)
    };
    n.append = function(a, b) {
        Nc(Lc(a), a, arguments)
    };
    n.canHaveChildren = function(a) {
        if (a.nodeType != 1) return !1;
        switch (a.tagName) {
            case "APPLET":
            case "AREA":
            case "BASE":
            case "BR":
            case "COL":
            case "COMMAND":
            case "EMBED":
            case "FRAME":
            case "HR":
            case "IMG":
            case "INPUT":
            case "IFRAME":
            case "ISINDEX":
            case "KEYGEN":
            case "LINK":
            case "NOFRAMES":
            case "NOSCRIPT":
            case "META":
            case "OBJECT":
            case "PARAM":
            case "SCRIPT":
            case "SOURCE":
            case "STYLE":
            case "TRACK":
            case "WBR":
                return !1
        }
        return !0
    };
    n.isElement = function(a) {
        return Na(a) && a.nodeType == 1
    };
    n.contains = function(a, b) {
        if (!a || !b) return !1;
        if (a.contains && b.nodeType == 1) return a == b || a.contains(b);
        if (typeof a.compareDocumentPosition != "undefined") return a == b || !!(a.compareDocumentPosition(b) & 16);
        for (; b && a != b;) b = b.parentNode;
        return b == a
    };

    function Pc() {
        this.g = this.U = null;
        this.i = "no"
    }

    function Qc(a) {
        if (!a) return !1;
        try {
            var b = a.getBoundingClientRect();
            return b && b.height >= 30 && b.width >= 30
        } catch (c) {
            return !1
        }
    }

    function Rc(a) {
        return Ua(a, function(b) {
            return Qc(b)
        })
    }

    function Sc(a, b) {
        b = b === void 0 ? !0 : b;
        return Ua(a, function(c) {
            return c.nodeName != "SCRIPT" && (!b || c.nodeName != "FONT")
        })
    }

    function Tc(a, b) {
        b = b === void 0 ? !0 : b;
        if (!a) return null;
        if (!a.children) return a;
        for (var c = Sc(db(a.children), b); c.length;) {
            var d = Rc(c);
            if (d.length == 1) return d[0];
            if (d.length > 1) break;
            c = lb(c, function(e) {
                return e.children ? Sc(db(e.children)) : []
            }, b)
        }
        return a
    }

    function Yc() {
        var a = G.document.body;
        return kb(Va(["GoogleActiveViewInnerContainer"], function(b) {
            return db((a || document).querySelectorAll("." + b))
        }))
    };

    function Zc() {}
    Zc.prototype.now = function() {
        return 0
    };
    Zc.prototype.i = function() {
        return 0
    };
    Zc.prototype.l = function() {
        return 0
    };
    Zc.prototype.g = function() {
        return 0
    };

    function $c() {
        if (!ad()) throw Error();
    }
    x($c, Zc);

    function ad() {
        return !(!G || !G.performance)
    }
    $c.prototype.now = function() {
        return ad() && G.performance.now ? G.performance.now() : Zc.prototype.now.call(this)
    };
    $c.prototype.i = function() {
        return ad() && G.performance.memory ? G.performance.memory.totalJSHeapSize || 0 : Zc.prototype.i.call(this)
    };
    $c.prototype.l = function() {
        return ad() && G.performance.memory ? G.performance.memory.usedJSHeapSize || 0 : Zc.prototype.l.call(this)
    };
    $c.prototype.g = function() {
        return ad() && G.performance.memory ? G.performance.memory.jsHeapSizeLimit || 0 : Zc.prototype.g.call(this)
    };

    function bd(a) {
        a.Dh = !0;
        return a
    };
    var cd = bd(function(a) {
            return typeof a === "number"
        }),
        dd = bd(function(a) {
            return typeof a === "string"
        }),
        ed = bd(function(a) {
            return typeof a === "boolean"
        });

    function fd() {}

    function gd(a) {
        var b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    };

    function I(a, b, c, d) {
        this.top = a;
        this.i = b;
        this.g = c;
        this.left = d
    }
    n = I.prototype;
    n.bb = function() {
        return this.i - this.left
    };
    n.Za = function() {
        return this.g - this.top
    };
    n.clone = function() {
        return new I(this.top, this.i, this.g, this.left)
    };
    n.contains = function(a) {
        return this && a ? a instanceof I ? a.left >= this.left && a.i <= this.i && a.top >= this.top && a.g <= this.g : a.x >= this.left && a.x <= this.i && a.y >= this.top && a.y <= this.g : !1
    };

    function hd(a, b) {
        return a == b ? !0 : a && b ? a.top == b.top && a.i == b.i && a.g == b.g && a.left == b.left : !1
    }
    n.ceil = function() {
        this.top = Math.ceil(this.top);
        this.i = Math.ceil(this.i);
        this.g = Math.ceil(this.g);
        this.left = Math.ceil(this.left);
        return this
    };
    n.floor = function() {
        this.top = Math.floor(this.top);
        this.i = Math.floor(this.i);
        this.g = Math.floor(this.g);
        this.left = Math.floor(this.left);
        return this
    };
    n.round = function() {
        this.top = Math.round(this.top);
        this.i = Math.round(this.i);
        this.g = Math.round(this.g);
        this.left = Math.round(this.left);
        return this
    };

    function id(a, b, c) {
        b instanceof Gc ? (a.left += b.x, a.i += b.x, a.top += b.y, a.g += b.y) : (a.left += b, a.i += b, typeof c === "number" && (a.top += c, a.g += c));
        return a
    };
    var jd = {};

    function kd(a) {
        try {
            return a.getBoundingClientRect()
        } catch (b) {
            return {
                left: 0,
                top: 0,
                right: 0,
                bottom: 0
            }
        }
    }

    function ld(a, b) {
        var c = new Gc(0, 0);
        var d = (d = Lc(a)) ? d.defaultView : window;
        if (!yc(d, "parent")) return c;
        do {
            if (d == b) {
                var e = Lc(a);
                var f = new Gc(0, 0);
                if (a != (e ? Lc(e) : document).documentElement) {
                    var g = kd(a);
                    e = Jc(e);
                    e = Mc(e.g);
                    f.x = g.left + e.x;
                    f.y = g.top + e.y
                }
            } else f = kd(a), f = new Gc(f.left, f.top);
            c.x += f.x;
            c.y += f.y
        } while (d && d != b && d != d.parent && (a = d.frameElement) && (d = d.parent));
        return c
    };
    var md = gd(function() {
        var a = !1;
        try {
            var b = Object.defineProperty({}, "passive", {
                get: function() {
                    a = !0
                }
            });
            Ia.addEventListener("test", null, b)
        } catch (c) {}
        return a
    });

    function nd(a) {
        return a ? a.passive && md() ? a : a.capture || !1 : !1
    }

    function od(a, b, c, d) {
        return typeof a.addEventListener === "function" ? (a.addEventListener(b, c, nd(d)), !0) : !1
    }

    function pd(a, b, c) {
        typeof a.removeEventListener === "function" && a.removeEventListener(b, c, nd())
    };

    function qd(a) {
        if (a.prerendering) return 3;
        var b;
        return (b = {
            visible: 1,
            hidden: 2,
            prerender: 3,
            preview: 4,
            unloaded: 5,
            "": 0
        }[a.visibilityState || a.webkitVisibilityState || a.mozVisibilityState || ""]) != null ? b : 0
    }

    function rd(a) {
        var b;
        a.visibilityState ? b = "visibilitychange" : a.mozVisibilityState ? b = "mozvisibilitychange" : a.webkitVisibilityState && (b = "webkitvisibilitychange");
        return b
    };

    function sd() {}
    sd.prototype.isVisible = function() {
        return qd(Sb) === 1
    };
    sd.prototype.g = function() {
        return qd(Sb) === 0
    };
    sd.prototype.m = function(a) {
        var b = rd(Sb);
        return b ? od(Sb, b, a, {
            capture: !1
        }) : !1
    };
    sd.prototype.o = function(a) {
        var b = rd(Sb);
        b && pd(Sb, b, a)
    };

    function td(a) {
        try {
            return !!a && a.location.href != null && yc(a, "foo")
        } catch (b) {
            return !1
        }
    }

    function ud(a) {
        for (var b = a; a && a !== a.parent;) a = a.parent, td(a) && (b = a);
        return b
    };

    function vd() {
        return Tb && Xb ? Xb.mobile : !wd() && (H("iPod") || H("iPhone") || H("Android") || H("IEMobile"))
    }

    function wd() {
        return Tb && Xb ? !Xb.mobile && (H("iPad") || H("Android") || H("Silk")) : H("iPad") || H("Android") && !H("Mobile") || H("Silk")
    };
    var xd = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)");

    function yd() {
        var a = Ia,
            b = [],
            c = null;
        do {
            var d = a;
            if (td(d)) {
                var e = d.location.href;
                c = d.document && d.document.referrer || null
            } else e = c, c = null;
            b.push(new zd(e || ""));
            try {
                a = d.parent
            } catch (f) {
                a = null
            }
        } while (a && d !== a);
        d = 0;
        for (a = b.length - 1; d <= a; ++d) b[d].depth = a - d;
        d = Ia;
        if (d.location && d.location.ancestorOrigins && d.location.ancestorOrigins.length === b.length - 1)
            for (a = 1; a < b.length; ++a) e = b[a], e.url || (e.url = d.location.ancestorOrigins[a - 1] || "", e.g = !0);
        return b
    }

    function Ad(a, b) {
        this.g = a;
        this.i = b
    }

    function zd(a, b) {
        this.url = a;
        this.g = !!b;
        this.depth = null
    };

    function Bd(a, b) {
        if (a)
            for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    };

    function Cd() {
        this.l = "&";
        this.i = {};
        this.m = 0;
        this.g = []
    }

    function Dd(a, b) {
        var c = {};
        c[a] = b;
        return [c]
    }

    function Ed(a, b, c, d, e) {
        var f = [];
        Bd(a, function(g, h) {
            (g = Fd(g, b, c, d, e)) && f.push(h + "=" + g)
        });
        return f.join(b)
    }

    function Fd(a, b, c, d, e) {
        if (a == null) return "";
        b = b || "&";
        c = c || ",$";
        dd(c) && (c = c.split(""));
        if (a instanceof Array) {
            if (d || (d = 0), d < c.length) {
                for (var f = [], g = 0; g < a.length; g++) f.push(Fd(a[g], b, c, d + 1, e));
                return f.join(c[d])
            }
        } else if (typeof a === "object") return e || (e = 0), e < 2 ? encodeURIComponent(Ed(a, b, c, d, e + 1)) : "...";
        return encodeURIComponent(String(a))
    }

    function Gd(a, b, c) {
        b = b + "//pagead2.googlesyndication.com" + c;
        var d = Hd(a) - c.length;
        if (d < 0) return "";
        a.g.sort(function(m, q) {
            return m - q
        });
        c = null;
        for (var e = "", f = 0; f < a.g.length; f++)
            for (var g = a.g[f], h = a.i[g], k = 0; k < h.length; k++) {
                if (!d) {
                    c = c == null ? g : c;
                    break
                }
                var l = Ed(h[k], a.l, ",$");
                if (l) {
                    l = e + l;
                    if (d >= l.length) {
                        d -= l.length;
                        b += l;
                        e = a.l;
                        break
                    }
                    c = c == null ? g : c
                }
            }
        a = "";
        c != null && (a = e + "trn=" + c);
        return b + a
    }

    function Hd(a) {
        var b = 1,
            c;
        for (c in a.i) c.length > b && (b = c.length);
        return 3997 - b - a.l.length - 1
    };

    function Id(a, b) {
        b = b === void 0 ? document : b;
        return b.createElement(String(a).toLowerCase())
    };

    function Jd(a, b, c, d, e) {
        e = e === void 0 ? !1 : e;
        a.google_image_requests || (a.google_image_requests = []);
        var f = Id("IMG", a.document);
        if (d) {
            var g = function() {
                d && bb(a.google_image_requests, f);
                pd(f, "load", g);
                pd(f, "error", g)
            };
            od(f, "load", g);
            od(f, "error", g)
        }
        c && (f.referrerPolicy = "no-referrer");
        e && (f.attributionSrc = "");
        f.src = b;
        a.google_image_requests.push(f)
    }

    function Kd(a) {
        var b = b === void 0 ? !1 : b;
        var c = c === void 0 ? !1 : c;
        if (Ld()) Jd(window, a, !0, b, c);
        else {
            var d = Ia.document;
            if (d.body) {
                var e = d.getElementById("goog-srcless-iframe");
                e || (e = Id("IFRAME"), e.style.display = "none", e.id = "goog-srcless-iframe", d.body.appendChild(e));
                d = e
            } else d = null;
            d && d.contentWindow && Jd(d.contentWindow, a, !0, b, c)
        }
    }
    var Ld = gd(function() {
        return "referrerPolicy" in Id("IMG")
    });

    function Md(a) {
        var b = "Ab";
        if (a.Ab && a.hasOwnProperty(b)) return a.Ab;
        b = new a;
        return a.Ab = b
    };

    function Pd() {
        this.g = new sd;
        this.i = ad() ? new $c : new Zc
    }
    Pd.prototype.setInterval = function(a, b) {
        return G.setInterval(a, b)
    };
    Pd.prototype.clearInterval = function(a) {
        G.clearInterval(a)
    };
    Pd.prototype.setTimeout = function(a, b) {
        return G.setTimeout(a, b)
    };
    Pd.prototype.clearTimeout = function(a) {
        G.clearTimeout(a)
    };

    function Qd(a) {
        Rd();
        Jd(G, a, !1, !1, !1)
    };

    function Sd() {}

    function Rd() {
        var a = Md(Sd);
        if (!a.g) {
            if (!G) throw Error("Context has not been set and window is undefined.");
            a.g = Md(Pd)
        }
        return a.g
    };

    function Td() {
        throw Error("Invalid UTF8");
    }

    function Ud(a, b) {
        b = String.fromCharCode.apply(null, b);
        return a == null ? b : a + b
    }
    var Vd = void 0,
        Wd, Xd = typeof TextDecoder !== "undefined",
        Yd, Zd = typeof String.prototype.isWellFormed === "function",
        $d = typeof TextEncoder !== "undefined";

    function ae(a) {
        Ia.setTimeout(function() {
            throw a;
        }, 0)
    };
    var be = {},
        ce = null,
        de = Ac || Bc || typeof Ia.btoa == "function";

    function ee(a) {
        var b;
        b === void 0 && (b = 0);
        fe();
        b = be[b];
        for (var c = Array(Math.floor(a.length / 3)), d = b[64] || "", e = 0, f = 0; e < a.length - 2; e += 3) {
            var g = a[e],
                h = a[e + 1],
                k = a[e + 2],
                l = b[g >> 2];
            g = b[(g & 3) << 4 | h >> 4];
            h = b[(h & 15) << 2 | k >> 6];
            k = b[k & 63];
            c[f++] = l + g + h + k
        }
        l = 0;
        k = d;
        switch (a.length - e) {
            case 2:
                l = a[e + 1], k = b[(l & 15) << 2] || d;
            case 1:
                a = a[e], c[f] = b[a >> 2] + b[(a & 3) << 4 | l >> 4] + k + d
        }
        return c.join("")
    }

    function ge(a) {
        var b = a.length,
            c = b * 3 / 4;
        c % 3 ? c = Math.floor(c) : "=.".indexOf(a[b - 1]) != -1 && (c = "=.".indexOf(a[b - 2]) != -1 ? c - 2 : c - 1);
        var d = new Uint8Array(c),
            e = 0;
        he(a, function(f) {
            d[e++] = f
        });
        return e !== c ? d.subarray(0, e) : d
    }

    function he(a, b) {
        function c(k) {
            for (; d < a.length;) {
                var l = a.charAt(d++),
                    m = ce[l];
                if (m != null) return m;
                if (!/^[\s\xa0]*$/.test(l)) throw Error("Unknown base64 encoding at char: " + l);
            }
            return k
        }
        fe();
        for (var d = 0;;) {
            var e = c(-1),
                f = c(0),
                g = c(64),
                h = c(64);
            if (h === 64 && e === -1) break;
            b(e << 2 | f >> 4);
            g != 64 && (b(f << 4 & 240 | g >> 2), h != 64 && b(g << 6 & 192 | h))
        }
    }

    function fe() {
        if (!ce) {
            ce = {};
            for (var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), b = ["+/=", "+/", "-_=", "-_.", "-_"], c = 0; c < 5; c++) {
                var d = a.concat(b[c].split(""));
                be[c] = d;
                for (var e = 0; e < d.length; e++) {
                    var f = d[e];
                    ce[f] === void 0 && (ce[f] = e)
                }
            }
        }
    };
    var ie = typeof Uint8Array !== "undefined",
        je = !zc && typeof btoa === "function",
        ke = /[-_.]/g,
        le = {
            "-": "+",
            _: "/",
            ".": "="
        };

    function me(a) {
        return le[a] || ""
    }

    function ne(a) {
        if (!je) return ge(a);
        a = ke.test(a) ? a.replace(ke, me) : a;
        a = atob(a);
        for (var b = new Uint8Array(a.length), c = 0; c < a.length; c++) b[c] = a.charCodeAt(c);
        return b
    }
    var oe = {};

    function pe(a, b) {
        qe(b);
        this.g = a;
        if (a != null && a.length === 0) throw Error("ByteString should be constructed with non-empty values");
    }
    pe.prototype.isEmpty = function() {
        return this.g == null
    };

    function re(a) {
        qe(oe);
        var b = a.g;
        b == null || ie && b != null && b instanceof Uint8Array || (typeof b === "string" ? b = ne(b) : (Ka(b), b = null));
        return b == null ? b : a.g = b
    }
    var se;

    function qe(a) {
        if (a !== oe) throw Error("illegal external caller");
    };
    var te = void 0;

    function ue(a) {
        a = Error(a);
        qc(a, "warning");
        return a
    }

    function ve(a, b) {
        if (a != null) {
            var c;
            var d = (c = te) != null ? c : te = {};
            c = d[a] || 0;
            c >= b || (d[a] = c + 1, a = Error(), qc(a, "incident"), ae(a))
        }
    };

    function we() {
        return typeof BigInt === "function"
    };
    var xe = typeof Symbol === "function" && typeof Symbol() === "symbol";

    function ye(a, b, c) {
        return typeof Symbol === "function" && typeof Symbol() === "symbol" ? (c === void 0 ? 0 : c) && Symbol.for && a ? Symbol.for(a) : a != null ? Symbol(a) : Symbol() : b
    }
    var ze = ye("jas", void 0, !0),
        Ae = ye(void 0, "0di"),
        Be = ye(void 0, Symbol()),
        Ce = ye(void 0, "0ubs"),
        De = ye(void 0, "0ubsb"),
        Ee = ye(void 0, "0actk"),
        Fe = ye("m_m", "Fh", !0);
    var Ge = {
            jg: {
                value: 0,
                configurable: !0,
                writable: !0,
                enumerable: !1
            }
        },
        He = Object.defineProperties,
        K = xe ? ze : "jg",
        Ie, Je = [];
    Ke(Je, 7);
    Ie = Object.freeze(Je);

    function Le(a, b) {
        xe || K in a || He(a, Ge);
        a[K] |= b
    }

    function Ke(a, b) {
        xe || K in a || He(a, Ge);
        a[K] = b
    };
    var Me = {};

    function Ne(a, b) {
        return b === void 0 ? a.i !== Oe && !!(2 & (a.F[K] | 0)) : !!(2 & b) && a.i !== Oe
    }
    var Oe = {},
        Pe = Object.freeze({});

    function Qe(a, b, c) {
        var d = b & 128 ? 0 : -1,
            e = a.length,
            f;
        if (f = !!e) f = a[e - 1], f = f != null && typeof f === "object" && f.constructor === Object;
        var g = e + (f ? -1 : 0);
        for (b = b & 128 ? 1 : 0; b < g; b++) c(b - d, a[b]);
        if (f) {
            a = a[e - 1];
            for (var h in a) Object.prototype.hasOwnProperty.call(a, h) && !isNaN(h) && c(+h, a[h])
        }
    }
    var Re = {};
    var Se = typeof Ia.BigInt === "function" && typeof Ia.BigInt(0) === "bigint";

    function Te(a) {
        var b = a;
        if (dd(b)) {
            if (!/^\s*(?:-?[1-9]\d*|0)?\s*$/.test(b)) throw Error(String(b));
        } else if (cd(b) && !Number.isSafeInteger(b)) throw Error(String(b));
        return Se ? BigInt(a) : a = ed(a) ? a ? "1" : "0" : dd(a) ? a.trim() || "0" : String(a)
    }
    var af = bd(function(a) {
            return Se ? a >= Ue && a <= Ve : a[0] === "-" ? We(a, Xe) : We(a, $e)
        }),
        Xe = Number.MIN_SAFE_INTEGER.toString(),
        Ue = Se ? BigInt(Number.MIN_SAFE_INTEGER) : void 0,
        $e = Number.MAX_SAFE_INTEGER.toString(),
        Ve = Se ? BigInt(Number.MAX_SAFE_INTEGER) : void 0;

    function We(a, b) {
        if (a.length > b.length) return !1;
        if (a.length < b.length || a === b) return !0;
        for (var c = 0; c < a.length; c++) {
            var d = a[c],
                e = b[c];
            if (d > e) return !1;
            if (d < e) return !0
        }
    };
    var bf = typeof Uint8Array.prototype.slice === "function",
        cf = 0,
        df = 0,
        ef;

    function ff(a) {
        var b = a >>> 0;
        cf = b;
        df = (a - b) / 4294967296 >>> 0
    }

    function gf(a) {
        if (a < 0) {
            ff(-a);
            var b = y(hf(cf, df));
            a = b.next().value;
            b = b.next().value;
            cf = a >>> 0;
            df = b >>> 0
        } else ff(a)
    }

    function jf(a, b) {
        var c = b * 4294967296 + (a >>> 0);
        return Number.isSafeInteger(c) ? c : kf(a, b)
    }

    function lf(a, b) {
        return Te(we() ? BigInt.asUintN(64, (BigInt(b >>> 0) << BigInt(32)) + BigInt(a >>> 0)) : kf(a, b))
    }

    function mf(a, b) {
        return we() ? Te(BigInt.asIntN(64, (BigInt.asUintN(32, BigInt(b)) << BigInt(32)) + BigInt.asUintN(32, BigInt(a)))) : Te(nf(a, b))
    }

    function kf(a, b) {
        b >>>= 0;
        a >>>= 0;
        if (b <= 2097151) var c = "" + (4294967296 * b + a);
        else we() ? c = "" + (BigInt(b) << BigInt(32) | BigInt(a)) : (c = (a >>> 24 | b << 8) & 16777215, b = b >> 16 & 65535, a = (a & 16777215) + c * 6777216 + b * 6710656, c += b * 8147497, b *= 2, a >= 1E7 && (c += a / 1E7 >>> 0, a %= 1E7), c >= 1E7 && (b += c / 1E7 >>> 0, c %= 1E7), c = b + of (c) + of (a));
        return c
    }

    function of (a) {
        a = String(a);
        return "0000000".slice(a.length) + a
    }

    function nf(a, b) {
        b & 2147483648 ? we() ? a = "" + (BigInt(b | 0) << BigInt(32) | BigInt(a >>> 0)) : (b = y(hf(a, b)), a = b.next().value, b = b.next().value, a = "-" + kf(a, b)) : a = kf(a, b);
        return a
    }

    function pf(a) {
        if (a.length < 16) gf(Number(a));
        else if (we()) a = BigInt(a), cf = Number(a & BigInt(4294967295)) >>> 0, df = Number(a >> BigInt(32) & BigInt(4294967295));
        else {
            var b = +(a[0] === "-");
            df = cf = 0;
            for (var c = a.length, d = b, e = (c - b) % 6 + b; e <= c; d = e, e += 6) d = Number(a.slice(d, e)), df *= 1E6, cf = cf * 1E6 + d, cf >= 4294967296 && (df += Math.trunc(cf / 4294967296), df >>>= 0, cf >>>= 0);
            b && (b = y(hf(cf, df)), a = b.next().value, b = b.next().value, cf = a, df = b)
        }
    }

    function hf(a, b) {
        b = ~b;
        a ? a = ~a + 1 : b += 1;
        return [a, b]
    };

    function qf(a) {
        return Array.prototype.slice.call(a)
    };
    var rf = typeof BigInt === "function" ? BigInt.asIntN : void 0,
        sf = typeof BigInt === "function" ? BigInt.asUintN : void 0,
        tf = Number.isSafeInteger,
        uf = Number.isFinite,
        vf = Math.trunc;

    function wf(a) {
        if (a == null || typeof a === "number") return a;
        if (a === "NaN" || a === "Infinity" || a === "-Infinity") return Number(a)
    }

    function xf(a) {
        if (a == null || typeof a === "boolean") return a;
        if (typeof a === "number") return !!a
    }
    var yf = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;

    function zf(a) {
        switch (typeof a) {
            case "bigint":
                return !0;
            case "number":
                return uf(a);
            case "string":
                return yf.test(a);
            default:
                return !1
        }
    }

    function Af(a) {
        if (!uf(a)) throw ue("enum");
        return a | 0
    }

    function Bf(a) {
        return a == null ? a : uf(a) ? a | 0 : void 0
    }

    function Cf(a) {
        if (a != null) {
            if (typeof a !== "number") throw ue("int32");
            if (!uf(a)) throw ue("int32");
            a |= 0
        }
        return a
    }

    function Df(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return uf(a) ? a | 0 : void 0
    }

    function Ef(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return uf(a) ? a >>> 0 : void 0
    }

    function Ff(a) {
        var b = void 0;
        b != null || (b = 1024);
        if (!zf(a)) throw ue("int64");
        var c = typeof a;
        switch (b) {
            case 512:
                switch (c) {
                    case "string":
                        return Gf(a);
                    case "bigint":
                        return String(rf(64, a));
                    default:
                        return Hf(a)
                }
            case 1024:
                switch (c) {
                    case "string":
                        return b = vf(Number(a)), tf(b) ? a = Te(b) : (b = a.indexOf("."), b !== -1 && (a = a.substring(0, b)), a = we() ? Te(rf(64, BigInt(a))) : Te(If(a))), a;
                    case "bigint":
                        return Te(rf(64, a));
                    default:
                        return tf(a) ? Te(Jf(a)) : Te(Hf(a))
                }
            case 0:
                switch (c) {
                    case "string":
                        return Gf(a);
                    case "bigint":
                        return Te(rf(64, a));
                    default:
                        return Jf(a)
                }
            default:
                throw Error("Unknown format requested type for int64");
        }
    }

    function If(a) {
        var b = a.length;
        if (a[0] === "-" ? b < 20 || b === 20 && a <= "-9223372036854775808" : b < 19 || b === 19 && a <= "9223372036854775807") return a;
        pf(a);
        return nf(cf, df)
    }

    function Jf(a) {
        a = vf(a);
        if (!tf(a)) {
            gf(a);
            var b = cf,
                c = df;
            if (a = c & 2147483648) b = ~b + 1 >>> 0, c = ~c >>> 0, b == 0 && (c = c + 1 >>> 0);
            b = jf(b, c);
            a = typeof b === "number" ? a ? -b : b : a ? "-" + b : b
        }
        return a
    }

    function Hf(a) {
        a = vf(a);
        tf(a) ? a = String(a) : (gf(a), a = nf(cf, df));
        return a
    }

    function Gf(a) {
        var b = vf(Number(a));
        if (tf(b)) return String(b);
        b = a.indexOf(".");
        b !== -1 && (a = a.substring(0, b));
        return If(a)
    }

    function Kf(a) {
        if (a == null) return a;
        var b = typeof a;
        if (b === "bigint") return String(rf(64, a));
        if (zf(a)) {
            if (b === "string") return Gf(a);
            if (b === "number") return Jf(a)
        }
    }

    function Lf(a) {
        if (a == null) return a;
        var b = typeof a;
        if (b === "bigint") return String(sf(64, a));
        if (zf(a)) {
            if (b === "string") return b = vf(Number(a)), tf(b) && b >= 0 ? a = String(b) : (b = a.indexOf("."), b !== -1 && (a = a.substring(0, b)), a[0] === "-" ? b = !1 : (b = a.length, b = b < 20 ? !0 : b === 20 && a <= "18446744073709551615"), b || (pf(a), a = kf(cf, df))), a;
            if (b === "number") return a = vf(a), a >= 0 && tf(a) || (gf(a), a = jf(cf, df)), a
        }
    }

    function Mf(a) {
        return a == null || typeof a === "string" ? a : void 0
    }

    function Nf(a, b, c) {
        if (a != null && a[Fe] === Me) return a;
        if (Array.isArray(a)) {
            var d = a[K] | 0;
            c = d | c & 32 | c & 2;
            c !== d && Ke(a, c);
            return new b(a)
        }
    };

    function Of(a) {
        return a
    };

    function Pf(a) {
        var b = Oa(Be);
        return b ? a[b] : void 0
    }

    function Qf() {}

    function Rf(a, b) {
        for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && !isNaN(c) && b(a, +c, a[c])
    }

    function Sf(a) {
        var b = new Qf;
        Rf(a, function(c, d, e) {
            b[d] = qf(e)
        });
        b.g = a.g;
        return b
    }

    function Tf(a, b) {
        b < 100 || ve(Ce, 1)
    };

    function Uf(a, b, c, d) {
        var e = d !== void 0;
        d = !!d;
        var f = Oa(Be),
            g;
        !e && xe && f && (g = a[f]) && Rf(g, Tf);
        f = [];
        var h = a.length;
        g = 4294967295;
        var k = !1,
            l = !!(b & 64),
            m = l ? b & 128 ? 0 : -1 : void 0;
        if (!(b & 1)) {
            var q = h && a[h - 1];
            q != null && typeof q === "object" && q.constructor === Object ? (h--, g = h) : q = void 0;
            if (l && !(b & 128) && !e) {
                k = !0;
                var t;
                g = ((t = Vf) != null ? t : Of)(g - m, m, a, q, void 0) + m
            }
        }
        b = void 0;
        for (t = 0; t < h; t++) {
            var r = a[t];
            if (r != null && (r = c(r, d)) != null)
                if (l && t >= g) {
                    var w = t - m,
                        u = void 0;
                    ((u = b) != null ? u : b = {})[w] = r
                } else f[t] = r
        }
        if (q)
            for (var v in q) Object.prototype.hasOwnProperty.call(q, v) && (h = q[v], h != null && (h = c(h, d)) != null && (t = +v, r = void 0, l && !Number.isNaN(t) && (r = t + m) < g ? f[r] = h : (t = void 0, ((t = b) != null ? t : b = {})[v] = h)));
        b && (k ? f.push(b) : f[g] = b);
        e && Oa(Be) && (a = Pf(a)) && a instanceof Qf && (f[Be] = Sf(a));
        return f
    }

    function Wf(a) {
        switch (typeof a) {
            case "number":
                return Number.isFinite(a) ? a : "" + a;
            case "bigint":
                return af(a) ? Number(a) : "" + a;
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (Array.isArray(a)) {
                    var b = a[K] | 0;
                    return a.length === 0 && b & 1 ? void 0 : Uf(a, b, Wf)
                }
                if (a != null && a[Fe] === Me) return Xf(a);
                if (a instanceof pe) {
                    b = a.g;
                    if (b == null) a = "";
                    else if (typeof b === "string") a = b;
                    else {
                        if (je) {
                            for (var c = "", d = 0, e = b.length - 10240; d < e;) c += String.fromCharCode.apply(null, b.subarray(d, d += 10240));
                            c += String.fromCharCode.apply(null, d ? b.subarray(d) : b);
                            b = btoa(c)
                        } else b = ee(b);
                        a = a.g = b
                    }
                    return a
                }
                return
        }
        return a
    }
    var Vf;

    function Xf(a) {
        a = a.F;
        return Uf(a, a[K] | 0, Wf)
    };
    var Yf, Zf;

    function $f(a) {
        switch (typeof a) {
            case "boolean":
                return Yf || (Yf = [0, void 0, !0]);
            case "number":
                return a > 0 ? void 0 : a === 0 ? Zf || (Zf = [0, void 0]) : [-a, void 0];
            case "string":
                return [0, a];
            case "object":
                return a
        }
    }

    function ag(a, b) {
        return bg(a, b[0], b[1])
    }

    function bg(a, b, c, d) {
        d = d === void 0 ? 0 : d;
        if (a == null) {
            var e = 32;
            c ? (a = [c], e |= 128) : a = [];
            b && (e = e & -16760833 | (b & 1023) << 14)
        } else {
            if (!Array.isArray(a)) throw Error("narr");
            e = a[K] | 0;
            if (Ub && 1 & e) throw Error("rfarr");
            2048 & e && !(2 & e) && cg();
            if (e & 256) throw Error("farr");
            if (e & 64) return (e | d) !== e && Ke(a, e | d), a;
            if (c && (e |= 128, c !== a[0])) throw Error("mid");
            a: {
                c = a;e |= 64;
                var f = c.length;
                if (f) {
                    var g = f - 1,
                        h = c[g];
                    if (h != null && typeof h === "object" && h.constructor === Object) {
                        b = e & 128 ? 0 : -1;
                        g -= b;
                        if (g >= 1024) throw Error("pvtlmt");
                        for (var k in h) Object.prototype.hasOwnProperty.call(h, k) && (f = +k, f < g && (c[f + b] = h[k], delete h[k]));
                        e = e & -16760833 | (g & 1023) << 14;
                        break a
                    }
                }
                if (b) {
                    k = Math.max(b, f - (e & 128 ? 0 : -1));
                    if (k > 1024) throw Error("spvt");
                    e = e & -16760833 | (k & 1023) << 14
                }
            }
        }
        Ke(a, e | 64 | d);
        return a
    }

    function cg() {
        if (Ub) throw Error("carr");
        ve(Ee, 5)
    };

    function dg(a, b) {
        if (typeof a !== "object") return a;
        if (Array.isArray(a)) {
            var c = a[K] | 0;
            a.length === 0 && c & 1 ? a = void 0 : c & 2 || (!b || 4096 & c || 16 & c ? a = eg(a, c, !1, b && !(c & 16)) : (Le(a, 34), c & 4 && Object.freeze(a)));
            return a
        }
        if (a != null && a[Fe] === Me) return b = a.F, c = b[K] | 0, Ne(a, c) ? a : fg(a, b, c) ? gg(a, b) : eg(b, c);
        if (a instanceof pe) return a
    }

    function gg(a, b, c) {
        a = new a.constructor(b);
        c && (a.i = Oe);
        a.l = Oe;
        return a
    }

    function eg(a, b, c, d) {
        d != null || (d = !!(34 & b));
        a = Uf(a, b, dg, d);
        d = 32;
        c && (d |= 2);
        b = b & 16769217 | d;
        Ke(a, b);
        return a
    }

    function hg(a) {
        if (a.i !== Oe) return !1;
        var b = a.F;
        b = eg(b, b[K] | 0);
        Le(b, 2048);
        a.F = b;
        a.i = void 0;
        a.l = void 0;
        return !0
    }

    function ig(a) {
        if (!hg(a) && Ne(a, a.F[K] | 0)) throw Error();
    }

    function jg(a, b) {
        b === void 0 && (b = a[K] | 0);
        b & 32 && !(b & 4096) && Ke(a, b | 4096)
    }

    function fg(a, b, c) {
        return c & 2 ? !0 : c & 32 && !(c & 4096) ? (Ke(b, c | 2), a.i = Oe, !0) : !1
    };

    function kg(a, b) {
        a = lg(a.F, b);
        if (a !== null) return a
    }

    function lg(a, b, c, d) {
        if (b === -1) return null;
        var e = b + (c ? 0 : -1),
            f = a.length - 1;
        if (!(f < 1 + (c ? 0 : -1))) {
            if (e >= f) {
                var g = a[f];
                if (g != null && typeof g === "object" && g.constructor === Object) {
                    c = g[b];
                    var h = !0
                } else if (e === f) c = g;
                else return
            } else c = a[e];
            if (d && c != null) {
                d = d(c);
                if (d == null) return d;
                if (!Object.is(d, c)) return h ? g[b] = d : a[e] = d, d
            }
            return c
        }
    }

    function mg(a, b, c) {
        ig(a);
        var d = a.F;
        ng(d, d[K] | 0, b, c);
        return a
    }

    function ng(a, b, c, d, e) {
        var f = c + (e ? 0 : -1),
            g = a.length - 1;
        if (g >= 1 + (e ? 0 : -1) && f >= g) {
            var h = a[g];
            if (h != null && typeof h === "object" && h.constructor === Object) return h[c] = d, b
        }
        if (f <= g) return a[f] = d, b;
        if (d !== void 0) {
            var k;
            g = ((k = b) != null ? k : b = a[K] | 0) >> 14 & 1023 || 536870912;
            c >= g ? d != null && (f = {}, a[g + (e ? 0 : -1)] = (f[c] = d, f)) : a[f] = d
        }
        return b
    }

    function og(a, b, c) {
        a = a.F;
        return pg(a, a[K] | 0, b, c) !== void 0
    }

    function qg(a, b, c, d, e) {
        var f = a.F,
            g = f[K] | 0;
        d = Ne(a, g) ? 1 : d;
        e = !!e || d === 3;
        d === 2 && hg(a) && (f = a.F, g = f[K] | 0);
        a = rg(f, b);
        var h = a === Ie ? 7 : a[K] | 0,
            k = sg(h, g);
        var l = 4 & k ? !1 : !0;
        if (l) {
            4 & k && (a = qf(a), h = 0, k = tg(k, g), g = ng(f, g, b, a));
            for (var m = 0, q = 0; m < a.length; m++) {
                var t = c(a[m]);
                t != null && (a[q++] = t)
            }
            q < m && (a.length = q);
            c = (k | 4) & -513;
            k = c &= -1025;
            k &= -4097
        }
        k !== h && (Ke(a, k), 2 & k && Object.freeze(a));
        return a = ug(a, k, f, g, b, d, l, e)
    }

    function ug(a, b, c, d, e, f, g, h) {
        var k = b;
        f === 1 || (f !== 4 ? 0 : 2 & b || !(16 & b) && 32 & d) ? vg(b) || (b |= !a.length || g && !(4096 & b) || 32 & d && !(4096 & b || 16 & b) ? 2 : 256, b !== k && Ke(a, b), Object.freeze(a)) : (f === 2 && vg(b) && (a = qf(a), k = 0, b = tg(b, d), d = ng(c, d, e, a)), vg(b) || (h || (b |= 16), b !== k && Ke(a, b)));
        2 & b || !(4096 & b || 16 & b) || jg(c, d);
        return a
    }

    function rg(a, b, c) {
        a = lg(a, b, c);
        return Array.isArray(a) ? a : Ie
    }

    function sg(a, b) {
        2 & b && (a |= 2);
        return a | 1
    }

    function vg(a) {
        return !!(2 & a) && !!(4 & a) || !!(256 & a)
    }

    function wg(a, b, c, d) {
        ig(a);
        var e = a.F;
        ng(e, e[K] | 0, b, (d === "0" ? Number(c) === 0 : c === d) ? void 0 : c);
        return a
    }

    function xg(a, b, c) {
        if (b & 2) throw Error();
        var d = b & 128 ? Re : void 0,
            e = rg(a, c, d),
            f = e === Ie ? 7 : e[K] | 0,
            g = sg(f, b);
        if (2 & g || vg(g) || 16 & g) g === f || vg(g) || Ke(e, g), e = qf(e), f = 0, g = tg(g, b), ng(a, b, c, e, d);
        g &= -13;
        g !== f && Ke(e, g);
        return e
    }

    function yg(a, b, c) {
        var d = a[K] | 0,
            e = d & 128 ? Re : void 0,
            f = lg(a, c, e);
        if (f != null && f[Fe] === Me) {
            if (!Ne(f)) return hg(f), f.F;
            var g = f.F
        } else Array.isArray(f) && (g = f);
        if (g) {
            var h = g[K] | 0;
            h & 2 && (g = eg(g, h))
        }
        g = ag(g, b);
        g !== f && ng(a, d, c, g, e);
        return g
    }

    function pg(a, b, c, d) {
        var e = !1;
        d = lg(a, d, void 0, function(f) {
            var g = Nf(f, c, b);
            e = g !== f && g != null;
            return g
        });
        if (d != null) return e && !Ne(d) && jg(a, b), d
    }

    function zg(a) {
        var b = Ag;
        a = a.F;
        (a = pg(a, a[K] | 0, b, 2)) || (a = b[Ae]) || (a = new b, Le(a.F, 34), a = b[Ae] = a);
        return a
    }

    function Bg(a, b, c) {
        var d = a.F,
            e = d[K] | 0;
        b = pg(d, e, b, c);
        if (b == null) return b;
        e = d[K] | 0;
        if (!Ne(a, e)) {
            var f = b;
            var g = f.F,
                h = g[K] | 0;
            f = Ne(f, h) ? fg(f, g, h) ? gg(f, g, !0) : new f.constructor(eg(g, h, !1)) : f;
            f !== b && (hg(a) && (d = a.F, e = d[K] | 0), b = f, e = ng(d, e, c, b), jg(d, e))
        }
        return b
    }

    function Cg(a) {
        a = a.F;
        var b = a[K] | 0,
            c = Dg;
        var d = !!d || !1;
        var e = rg(a, 10),
            f = e === Ie ? 7 : e[K] | 0,
            g = sg(f, b),
            h = !(4 & g);
        if (h) {
            var k = e,
                l = b,
                m;
            (m = !!(2 & g)) && (l |= 2);
            for (var q = !m, t = !0, r = 0, w = 0; r < k.length; r++) {
                var u = Nf(k[r], c, l);
                if (u instanceof c) {
                    if (!m) {
                        var v = Ne(u);
                        q && (q = !v);
                        t && (t = v)
                    }
                    k[w++] = u
                }
            }
            w < r && (k.length = w);
            g |= 4;
            g = t ? g & -4097 : g | 4096;
            g = q ? g | 8 : g & -9
        }
        g !== f && (Ke(e, g), 2 & g && Object.freeze(e));
        return e = ug(e, g, a, b, 10, 1, h, d)
    }

    function Eg(a, b, c) {
        c == null && (c = void 0);
        mg(a, b, c);
        c && !Ne(c) && jg(a.F);
        return a
    }

    function tg(a, b) {
        return a = (2 & b ? a | 2 : a & -3) & -273
    }

    function Fg(a, b, c) {
        ig(a);
        b = qg(a, b, Bf, 2, !0);
        if (Array.isArray(c))
            for (var d = c.length, e = 0; e < d; e++) b.push(Af(c[e]));
        else
            for (c = y(c), d = c.next(); !d.done; d = c.next()) b.push(Af(d.value));
        return a
    }

    function Gg(a, b, c) {
        c = c === void 0 ? !1 : c;
        var d;
        return (d = xf(kg(a, b))) != null ? d : c
    }

    function Hg(a, b) {
        var c = c === void 0 ? 0 : c;
        var d;
        return (d = Df(kg(a, b))) != null ? d : c
    }

    function Ig(a) {
        var b = b === void 0 ? "" : b;
        a = Mf(kg(a, 2));
        return a != null ? a : b
    }

    function Jg(a, b, c) {
        if (c != null && typeof c !== "boolean") throw Error("Expected boolean but got " + Ka(c) + ": " + c);
        return mg(a, b, c)
    }

    function Kg(a, b, c) {
        if (c != null) {
            if (typeof c !== "number") throw ue("uint32");
            if (!uf(c)) throw ue("uint32");
            c >>>= 0
        }
        return mg(a, b, c)
    }

    function Lg(a, b, c) {
        return wg(a, b, c == null ? c : Ff(c), "0")
    }

    function Mg(a, b, c) {
        if (c != null && typeof c !== "string") throw Error();
        return mg(a, b, c)
    }

    function Ng(a, b, c) {
        return mg(a, b, c == null ? c : Af(c))
    };

    function Og(a, b, c) {
        this.buffer = a;
        if (c && !b) throw Error();
        this.g = b
    }

    function Pg(a, b) {
        if (typeof a === "string") return new Og(ne(a), b);
        if (Array.isArray(a)) return new Og(new Uint8Array(a), b);
        if (a.constructor === Uint8Array) return new Og(a, !1);
        if (a.constructor === ArrayBuffer) return a = new Uint8Array(a), new Og(a, !1);
        if (a.constructor === pe) return b = re(a) || new Uint8Array(0), new Og(b, !0, a);
        if (a instanceof Uint8Array) return a = a.constructor === Uint8Array ? a : new Uint8Array(a.buffer, a.byteOffset, a.byteLength), new Og(a, !1);
        throw Error();
    };

    function Qg(a, b, c, d) {
        this.i = null;
        this.o = !1;
        this.g = this.l = this.m = 0;
        this.init(a, b, c, d)
    }
    Qg.prototype.init = function(a, b, c, d) {
        var e = d === void 0 ? {} : d;
        d = e.Qc === void 0 ? !1 : e.Qc;
        e = e.kd === void 0 ? !1 : e.kd;
        this.Qc = d;
        this.kd = e;
        a && (a = Pg(a, this.kd), this.i = a.buffer, this.o = a.g, this.m = b || 0, this.l = c !== void 0 ? this.m + c : this.i.length, this.g = this.m)
    };
    Qg.prototype.clear = function() {
        this.i = null;
        this.o = !1;
        this.g = this.l = this.m = 0;
        this.Qc = !1
    };
    Qg.prototype.reset = function() {
        this.g = this.m
    };

    function Rg(a, b) {
        var c = 0,
            d = 0,
            e = 0,
            f = a.i,
            g = a.g;
        do {
            var h = f[g++];
            c |= (h & 127) << e;
            e += 7
        } while (e < 32 && h & 128);
        if (e > 32)
            for (d |= (h & 127) >> 4, e = 3; e < 32 && h & 128; e += 7) h = f[g++], d |= (h & 127) << e;
        Sg(a, g);
        if (!(h & 128)) return b(c >>> 0, d >>> 0);
        throw Error();
    }

    function Sg(a, b) {
        a.g = b;
        if (b > a.l) throw Error();
    }

    function Tg(a) {
        var b = a.i,
            c = a.g,
            d = b[c++],
            e = d & 127;
        if (d & 128 && (d = b[c++], e |= (d & 127) << 7, d & 128 && (d = b[c++], e |= (d & 127) << 14, d & 128 && (d = b[c++], e |= (d & 127) << 21, d & 128 && (d = b[c++], e |= d << 28, d & 128 && b[c++] & 128 && b[c++] & 128 && b[c++] & 128 && b[c++] & 128 && b[c++] & 128))))) throw Error();
        Sg(a, c);
        return e
    }

    function Ug(a) {
        return Tg(a) >>> 0
    }

    function Vg(a) {
        return Rg(a, lf)
    }

    function Wg(a) {
        var b = a.i,
            c = a.g,
            d = b[c],
            e = b[c + 1],
            f = b[c + 2];
        b = b[c + 3];
        Sg(a, a.g + 4);
        return (d << 0 | e << 8 | f << 16 | b << 24) >>> 0
    }

    function Xg(a) {
        var b = Wg(a),
            c = Wg(a);
        a = (c >> 31) * 2 + 1;
        var d = c >>> 20 & 2047;
        b = 4294967296 * (c & 1048575) + b;
        return d == 2047 ? b ? NaN : a * Infinity : d == 0 ? a * 4.9E-324 * b : a * Math.pow(2, d - 1075) * (b + 4503599627370496)
    }

    function Yg(a) {
        for (var b = 0, c = a.g, d = c + 10, e = a.i; c < d;) {
            var f = e[c++];
            b |= f;
            if ((f & 128) === 0) return Sg(a, c), !!(b & 127)
        }
        throw Error();
    }

    function Zg(a) {
        return Tg(a)
    }

    function $g(a, b) {
        if (b < 0) throw Error();
        var c = a.g;
        b = c + b;
        if (b > a.l) throw Error();
        a.g = b;
        return c
    }
    var ah = [];

    function bh(a, b, c, d) {
        if (ah.length) {
            var e = ah.pop();
            e.init(a, b, c, d);
            a = e
        } else a = new Qg(a, b, c, d);
        this.g = a;
        this.m = this.g.g;
        this.i = this.l = -1;
        eh(this, d)
    }

    function eh(a, b) {
        b = b === void 0 ? {} : b;
        a.Gd = b.Gd === void 0 ? !1 : b.Gd
    }

    function fh(a, b, c, d) {
        if (gh.length) {
            var e = gh.pop();
            eh(e, d);
            e.g.init(a, b, c, d);
            return e
        }
        return new bh(a, b, c, d)
    }

    function hh(a) {
        a.g.clear();
        a.l = -1;
        a.i = -1;
        gh.length < 100 && gh.push(a)
    }
    bh.prototype.reset = function() {
        this.g.reset();
        this.m = this.g.g;
        this.i = this.l = -1
    };

    function ih(a) {
        var b = a.g;
        if (b.g == b.l) return !1;
        a.m = a.g.g;
        var c = Ug(a.g);
        b = c >>> 3;
        c &= 7;
        if (!(c >= 0 && c <= 5)) throw Error();
        if (b < 1) throw Error();
        a.l = b;
        a.i = c;
        return !0
    }

    function jh(a) {
        switch (a.i) {
            case 0:
                a.i != 0 ? jh(a) : Yg(a.g);
                break;
            case 1:
                a = a.g;
                Sg(a, a.g + 8);
                break;
            case 2:
                if (a.i != 2) jh(a);
                else {
                    var b = Ug(a.g);
                    a = a.g;
                    Sg(a, a.g + b)
                }
                break;
            case 5:
                a = a.g;
                Sg(a, a.g + 4);
                break;
            case 3:
                b = a.l;
                do {
                    if (!ih(a)) throw Error();
                    if (a.i == 4) {
                        if (a.l != b) throw Error();
                        break
                    }
                    jh(a)
                } while (1);
                break;
            default:
                throw Error();
        }
    }

    function kh(a, b, c) {
        var d = a.g.l,
            e = Ug(a.g);
        e = a.g.g + e;
        var f = e - d;
        f <= 0 && (a.g.l = e, c(b, a, void 0, void 0, void 0), f = e - a.g.g);
        if (f) throw Error();
        a.g.g = e;
        a.g.l = d
    }

    function lh(a, b, c) {
        var d = Ug(a.g);
        for (d = a.g.g + d; a.g.g < d;) c.push(b(a.g))
    }
    var gh = [];

    function mh(a, b) {
        this.i = a >>> 0;
        this.g = b >>> 0
    }

    function nh(a) {
        if (!a) return oh || (oh = new mh(0, 0));
        if (!/^\d+$/.test(a)) return null;
        pf(a);
        return new mh(cf, df)
    }
    var oh;

    function ph(a, b) {
        this.i = a >>> 0;
        this.g = b >>> 0
    }

    function qh(a) {
        if (!a) return rh || (rh = new ph(0, 0));
        if (!/^-?\d+$/.test(a)) return null;
        pf(a);
        return new ph(cf, df)
    }
    var rh;

    function sh() {
        this.g = []
    }
    sh.prototype.length = function() {
        return this.g.length
    };
    sh.prototype.end = function() {
        var a = this.g;
        this.g = [];
        return a
    };

    function th(a, b, c) {
        for (; c > 0 || b > 127;) a.g.push(b & 127 | 128), b = (b >>> 7 | c << 25) >>> 0, c >>>= 7;
        a.g.push(b)
    }

    function uh(a, b) {
        for (; b > 127;) a.g.push(b & 127 | 128), b >>>= 7;
        a.g.push(b)
    }

    function vh(a, b) {
        if (b >= 0) uh(a, b);
        else {
            for (var c = 0; c < 9; c++) a.g.push(b & 127 | 128), b >>= 7;
            a.g.push(1)
        }
    }

    function wh(a, b) {
        a.g.push(b >>> 0 & 255);
        a.g.push(b >>> 8 & 255);
        a.g.push(b >>> 16 & 255);
        a.g.push(b >>> 24 & 255)
    };

    function xh() {
        this.l = [];
        this.i = 0;
        this.g = new sh
    }

    function yh(a, b) {
        b.length !== 0 && (a.l.push(b), a.i += b.length)
    }

    function zh(a, b) {
        Ah(a, b, 2);
        b = a.g.end();
        yh(a, b);
        b.push(a.i);
        return b
    }

    function Bh(a, b) {
        var c = b.pop();
        for (c = a.i + a.g.length() - c; c > 127;) b.push(c & 127 | 128), c >>>= 7, a.i++;
        b.push(c);
        a.i++
    }

    function Ah(a, b, c) {
        uh(a.g, b * 8 + c)
    }

    function Ch(a, b, c) {
        if (c != null) switch (Ah(a, b, 0), typeof c) {
            case "number":
                a = a.g;
                gf(c);
                th(a, cf, df);
                break;
            case "bigint":
                c = BigInt.asUintN(64, c);
                c = new mh(Number(c & BigInt(4294967295)), Number(c >> BigInt(32)));
                th(a.g, c.i, c.g);
                break;
            default:
                c = nh(c), th(a.g, c.i, c.g)
        }
    }

    function Dh(a, b, c) {
        c != null && (c = parseInt(c, 10), Ah(a, b, 0), vh(a.g, c))
    };

    function Eh() {
        function a() {
            throw Error();
        }
        Object.setPrototypeOf(a, a.prototype);
        return a
    }
    var Fh = Eh(),
        Gh = Eh(),
        Hh = Eh(),
        Ih = Eh(),
        Jh = Eh(),
        Kh = Eh(),
        Lh = Eh(),
        Mh = Eh(),
        Nh = Eh(),
        Oh = Eh(),
        Ph = Eh();

    function Qh(a, b, c) {
        this.F = bg(a, b, c, 2048)
    }
    Qh.prototype.toJSON = function() {
        return Xf(this)
    };

    function Rh(a) {
        return JSON.stringify(Xf(a))
    }
    Qh.prototype.clone = function() {
        var a = this.F,
            b = a[K] | 0;
        return fg(this, a, b) ? gg(this, a, !0) : new this.constructor(eg(a, b, !1))
    };
    Qh.prototype[Fe] = Me;
    Qh.prototype.toString = function() {
        return this.F.toString()
    };

    function Sh(a, b, c) {
        this.g = a;
        this.i = b;
        a = Oa(Fh);
        this.l = !!a && c === a || !1
    }

    function Th(a) {
        var b = Uh;
        var c = c === void 0 ? Fh : c;
        return new Sh(a, b, c)
    }

    function Uh(a, b, c, d, e) {
        b = b instanceof Qh ? b.F : Array.isArray(b) ? ag(b, d) : void 0;
        b != null && (c = zh(a, c), e(b, a), Bh(a, c))
    }
    var Vh = Th(function(a, b, c, d, e) {
            if (a.i !== 2) return !1;
            kh(a, yg(b, d, c), e);
            return !0
        }),
        Wh = Th(function(a, b, c, d, e) {
            if (a.i !== 2) return !1;
            kh(a, yg(b, d, c), e);
            return !0
        }),
        Xh = Symbol(),
        Yh = Symbol(),
        Zh = Symbol(),
        $h = Symbol(),
        ai = Symbol(),
        bi, ci;

    function di(a, b, c, d) {
        var e = d[a];
        if (e) return e;
        e = {};
        e.Gf = d;
        e.Cc = $f(d[0]);
        var f = d[1],
            g = 1;
        f && f.constructor === Object && (e.Jd = f, f = d[++g], typeof f === "function" && (e.Ze = !0, bi != null || (bi = f), ci != null || (ci = d[g + 1]), f = d[g += 2]));
        for (var h = {}; f && ei(f);) {
            for (var k = 0; k < f.length; k++) h[f[k]] = f;
            f = d[++g]
        }
        for (k = 1; f !== void 0;) {
            typeof f === "number" && (k += f, f = d[++g]);
            var l = void 0;
            if (f instanceof Sh) var m = f;
            else m = Vh, g--;
            f = void 0;
            if ((f = m) == null ? 0 : f.l) {
                f = d[++g];
                l = d;
                var q = g;
                typeof f === "function" && (f = f(), l[q] = f);
                l = f
            }
            f = d[++g];
            q = k + 1;
            typeof f === "number" && f < 0 && (q -= f, f = d[++g]);
            for (; k < q; k++) {
                var t = h[k];
                l ? c(e, k, m, l, t) : b(e, k, m, t)
            }
        }
        return d[a] = e
    }

    function ei(a) {
        return Array.isArray(a) && !!a.length && typeof a[0] === "number" && a[0] > 0
    }

    function fi(a) {
        return Array.isArray(a) ? a[0] instanceof Sh ? a : [Wh, a] : [a, void 0]
    };

    function gi(a, b, c, d) {
        var e = c.g;
        a[b] = d ? function(f, g, h) {
            return e(f, g, h, d)
        } : e
    }

    function hi(a, b, c, d, e) {
        var f = c.g,
            g, h;
        a[b] = function(k, l, m) {
            return f(k, l, m, h || (h = di(Yh, gi, hi, d).Cc), g || (g = ii(d)), e)
        }
    }

    function ii(a) {
        var b = a[Zh];
        if (b != null) return b;
        var c = di(Yh, gi, hi, a);
        b = c.Ze ? function(d, e) {
            return bi(d, e, c)
        } : function(d, e) {
            for (; ih(e) && e.i != 4;) {
                var f = e.l,
                    g = c[f];
                if (g == null) {
                    var h = c.Jd;
                    h && (h = h[f]) && (h = ji(h), h != null && (g = c[f] = h))
                }
                if (g == null || !g(e, d, f)) {
                    g = e;
                    h = g.m;
                    jh(g);
                    var k = g;
                    if (k.Gd) var l = void 0;
                    else g = k.g.g - h, k.g.g = h, k = k.g, g == 0 ? g = se || (se = new pe(null, oe)) : (h = $g(k, g), k.Qc && k.o ? g = k.i.subarray(h, h + g) : (k = k.i, g = h + g, g = h === g ? new Uint8Array(0) : bf ? k.slice(h, g) : new Uint8Array(k.subarray(h, g))), g = g.length == 0 ? se || (se = new pe(null, oe)) : new pe(g, oe)), l = g;
                    k = h = g = void 0;
                    var m = d;
                    l && ((g = (h = (k = m[Be]) != null ? k : m[Be] = new Qf)[f]) != null ? g : h[f] = []).push(l)
                }
            }
            if (d = Pf(d)) d.g = c.Gf[ai];
            return !0
        };
        a[Zh] = b;
        a[ai] = ki.bind(a);
        return b
    }

    function ki(a, b, c, d) {
        var e = this[Yh],
            f = this[Zh],
            g = ag(void 0, e.Cc),
            h = Pf(a);
        if (h) {
            var k = !1,
                l = e.Jd;
            if (l) {
                e = function(w, u, v) {
                    if (v.length !== 0)
                        if (l[u])
                            for (w = y(v), u = w.next(); !u.done; u = w.next()) {
                                u = fh(u.value);
                                try {
                                    k = !0, f(g, u)
                                } finally {
                                    hh(u)
                                }
                            } else d == null || d(a, u, v)
                };
                if (b == null) Rf(h, e);
                else if (h != null) {
                    var m = h[b];
                    m && e(h, b, m)
                }
                if (k) {
                    var q = a[K] | 0;
                    if (q & 2 && q & 2048 && (c == null || !c.Zh)) throw Error();
                    var t = q & 128 ? Re : void 0,
                        r = function(w, u) {
                            if (lg(a, w, t) != null) switch (c == null ? void 0 : c.Yh) {
                                case 1:
                                    return;
                                default:
                                    throw Error();
                            }
                            u != null && (q = ng(a, q, w, u, t));
                            delete h[w]
                        };
                    b == null ? Qe(g, g[K] | 0, function(w, u) {
                        r(w, u)
                    }) : r(b, lg(g, b, t))
                }
            }
        }
    }

    function ji(a) {
        a = fi(a);
        var b = a[0].g;
        if (a = a[1]) {
            var c = ii(a),
                d = di(Yh, gi, hi, a).Cc;
            return function(e, f, g) {
                return b(e, f, g, d, c)
            }
        }
        return b
    };

    function li(a, b, c) {
        a[b] = c.i
    }

    function mi(a, b, c, d) {
        var e, f, g = c.i;
        a[b] = function(h, k, l) {
            return g(h, k, l, f || (f = di(Xh, li, mi, d).Cc), e || (e = ni(d)))
        }
    }

    function ni(a) {
        var b = a[$h];
        if (!b) {
            var c = di(Xh, li, mi, a);
            b = function(d, e) {
                return oi(d, e, c)
            };
            a[$h] = b
        }
        return b
    }

    function oi(a, b, c) {
        Qe(a, a[K] | 0, function(d, e) {
            if (e != null) {
                var f = pi(c, d);
                f ? f(b, e, d) : d < 500 || ve(De, 3)
            }
        });
        (a = Pf(a)) && Rf(a, function(d, e, f) {
            yh(b, b.g.end());
            for (d = 0; d < f.length; d++) yh(b, re(f[d]) || new Uint8Array(0))
        })
    }

    function pi(a, b) {
        var c = a[b];
        if (c) return c;
        if (c = a.Jd)
            if (c = c[b]) {
                c = fi(c);
                var d = c[0].i;
                if (c = c[1]) {
                    var e = ni(c),
                        f = di(Xh, li, mi, c).Cc;
                    c = a.Ze ? ci(f, e) : function(g, h, k) {
                        return d(g, h, k, f, e)
                    }
                } else c = d;
                return a[b] = c
            }
    };
    var qi = Te(0);

    function ri(a, b, c) {
        if (Array.isArray(b)) {
            var d = b[K] | 0;
            if (d & 4) return b;
            for (var e = 0, f = 0; e < b.length; e++) {
                var g = a(b[e]);
                g != null && (b[f++] = g)
            }
            f < e && (b.length = f);
            a = d | 1;
            c && (a = (a | 4) & -1537);
            a !== d && Ke(b, a);
            c && a & 2 && Object.freeze(b);
            return b
        }
    }

    function si(a, b) {
        var c = new xh;
        oi(a.F, c, di(Xh, li, mi, b));
        yh(c, c.g.end());
        a = new Uint8Array(c.i);
        b = c.l;
        for (var d = b.length, e = 0, f = 0; f < d; f++) {
            var g = b[f];
            a.set(g, e);
            e += g.length
        }
        c.l = [a];
        return a
    }

    function ti(a, b, c) {
        return new Sh(a, b, c)
    }

    function ui(a, b, c) {
        return new Sh(a, b, c)
    }

    function vi(a, b, c) {
        ng(a, a[K] | 0, b, c, (a[K] | 0) & 128 ? Re : void 0)
    }

    function wi(a, b, c) {
        b = wf(b);
        b != null && (Ah(a, c, 1), a = a.g, c = ef || (ef = new DataView(new ArrayBuffer(8))), c.setFloat64(0, +b, !0), cf = c.getUint32(0, !0), df = c.getUint32(4, !0), wh(a, cf), wh(a, df))
    }

    function xi(a, b, c) {
        b = Kf(b);
        if (b != null) {
            switch (typeof b) {
                case "string":
                    qh(b)
            }
            if (b != null) switch (Ah(a, c, 0), typeof b) {
                case "number":
                    a = a.g;
                    gf(b);
                    th(a, cf, df);
                    break;
                case "bigint":
                    c = BigInt.asUintN(64, b);
                    c = new ph(Number(c & BigInt(4294967295)), Number(c >> BigInt(32)));
                    th(a.g, c.i, c.g);
                    break;
                default:
                    c = qh(b), th(a.g, c.i, c.g)
            }
        }
    }

    function yi(a, b, c) {
        b = Df(b);
        b != null && b != null && (Ah(a, c, 0), vh(a.g, b))
    }

    function zi(a, b, c) {
        if (a.i !== 0 && a.i !== 2) return !1;
        b = xg(b, b[K] | 0, c);
        a.i == 2 ? lh(a, Zg, b) : b.push(Tg(a.g));
        return !0
    }
    var Ai = ti(function(a, b, c) {
            if (a.i !== 1) return !1;
            vi(b, c, Xg(a.g));
            return !0
        }, wi, Oh),
        Bi = ti(function(a, b, c) {
            if (a.i !== 1) return !1;
            a = Xg(a.g);
            vi(b, c, a === 0 ? void 0 : a);
            return !0
        }, wi, Oh),
        Ci = ti(function(a, b, c) {
            if (a.i !== 5) return !1;
            var d = Wg(a.g);
            a = (d >> 31) * 2 + 1;
            var e = d >>> 23 & 255;
            d &= 8388607;
            vi(b, c, e == 255 ? d ? NaN : a * Infinity : e == 0 ? a * 1.401298464324817E-45 * d : a * Math.pow(2, e - 150) * (d + 8388608));
            return !0
        }, function(a, b, c) {
            b = wf(b);
            b != null && (Ah(a, c, 5), a = a.g, c = ef || (ef = new DataView(new ArrayBuffer(8))), c.setFloat32(0, +b, !0), df = 0, cf = c.getUint32(0, !0), wh(a, cf))
        }, Nh),
        Di = ti(function(a, b, c) {
            a.i !== 0 ? a = !1 : (vi(b, c, Rg(a.g, mf)), a = !0);
            return a
        }, xi, Lh),
        Ei = ti(function(a, b, c) {
            a.i !== 0 ? b = !1 : (a = Rg(a.g, mf), vi(b, c, a === qi ? void 0 : a), b = !0);
            return b
        }, xi, Lh),
        Fi = ti(function(a, b, c) {
            a.i !== 0 ? a = !1 : (vi(b, c, Vg(a.g)), a = !0);
            return a
        }, function(a, b, c) {
            b = Lf(b);
            if (b != null) {
                switch (typeof b) {
                    case "string":
                        nh(b)
                }
                Ch(a, c, b)
            }
        }, Mh),
        Gi = ui(function(a, b, c) {
            a.i !== 0 && a.i !== 2 ? a = !1 : (b = xg(b, b[K] | 0, c), a.i == 2 ? lh(a, Vg, b) : b.push(Vg(a.g)), a = !0);
            return a
        }, function(a, b, c) {
            b = ri(Lf, b, !1);
            if (b != null)
                for (var d = 0; d < b.length; d++) Ch(a, c, b[d])
        }, Mh),
        Hi = ti(function(a, b, c) {
            if (a.i !== 0) return !1;
            vi(b, c, Tg(a.g));
            return !0
        }, yi, Ih),
        Ii = ui(function(a, b, c) {
            if (a.i !== 0 && a.i !== 2) return !1;
            b = xg(b, b[K] | 0, c);
            a.i == 2 ? lh(a, Tg, b) : b.push(Tg(a.g));
            return !0
        }, function(a, b, c) {
            b = ri(Df, b, !0);
            if (b != null)
                for (var d = 0; d < b.length; d++) {
                    var e = a,
                        f = c,
                        g = b[d];
                    g != null && (Ah(e, f, 0), vh(e.g, g))
                }
        }, Ih),
        Ji = ti(function(a, b, c) {
            if (a.i !== 0) return !1;
            a = Tg(a.g);
            vi(b, c, a === 0 ? void 0 : a);
            return !0
        }, yi, Ih),
        Ki = ti(function(a, b, c) {
            if (a.i !== 5) return !1;
            vi(b, c, Wg(a.g));
            return !0
        }, function(a, b, c) {
            b = Ef(b);
            b != null && (Ah(a, c, 5), wh(a.g, b))
        }, Kh),
        Li = ti(function(a, b, c) {
            if (a.i !== 0) return !1;
            vi(b, c, Yg(a.g));
            return !0
        }, function(a, b, c) {
            b = xf(b);
            b != null && (Ah(a, c, 0), a.g.g.push(b ? 1 : 0))
        }, Gh),
        Mi = ti(function(a, b, c) {
            if (a.i !== 2) return !1;
            var d = Ug(a.g);
            a = a.g;
            var e = $g(a, d);
            a = a.i;
            if (Xd) {
                var f = a,
                    g;
                (g = Wd) || (g = Wd = new TextDecoder("utf-8", {
                    fatal: !0
                }));
                d = e + d;
                f = e === 0 && d === f.length ? f : f.subarray(e, d);
                try {
                    var h = g.decode(f)
                } catch (q) {
                    if (Vd === void 0) {
                        try {
                            g.decode(new Uint8Array([128]))
                        } catch (t) {}
                        try {
                            g.decode(new Uint8Array([97])), Vd = !0
                        } catch (t) {
                            Vd = !1
                        }
                    }!Vd && (Wd = void 0);
                    throw q;
                }
            } else {
                h = e;
                d = h + d;
                e = [];
                for (var k = null, l, m; h < d;) l = a[h++], l < 128 ? e.push(l) : l < 224 ? h >= d ? Td() : (m = a[h++], l < 194 || (m & 192) !== 128 ? (h--, Td()) : e.push((l & 31) << 6 | m & 63)) : l < 240 ? h >= d - 1 ? Td() : (m = a[h++], (m & 192) !== 128 || l === 224 && m < 160 || l === 237 && m >= 160 || ((g = a[h++]) & 192) !== 128 ? (h--, Td()) : e.push((l & 15) << 12 | (m & 63) << 6 | g & 63)) : l <= 244 ? h >= d - 2 ? Td() : (m = a[h++], (m & 192) !== 128 || (l << 28) + (m - 144) >> 30 !== 0 || ((g = a[h++]) & 192) !== 128 || ((f = a[h++]) & 192) !== 128 ? (h--, Td()) : (l = (l & 7) << 18 | (m & 63) << 12 | (g & 63) << 6 | f & 63, l -= 65536, e.push((l >> 10 & 1023) + 55296, (l & 1023) + 56320))) : Td(), e.length >= 8192 && (k = Ud(k, e), e.length = 0);
                h = Ud(k, e)
            }
            vi(b, c, h);
            return !0
        }, function(a, b, c) {
            b = Mf(b);
            if (b != null) {
                var d = !1;
                d = d === void 0 ? !1 : d;
                if ($d) {
                    if (d && (Zd ? !b.isWellFormed() : /(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])/.test(b))) throw Error("Found an unpaired surrogate");
                    b = (Yd || (Yd = new TextEncoder)).encode(b)
                } else {
                    for (var e = 0, f = new Uint8Array(3 * b.length), g = 0; g < b.length; g++) {
                        var h = b.charCodeAt(g);
                        if (h < 128) f[e++] = h;
                        else {
                            if (h < 2048) f[e++] = h >> 6 | 192;
                            else {
                                if (h >= 55296 && h <= 57343) {
                                    if (h <= 56319 && g < b.length) {
                                        var k = b.charCodeAt(++g);
                                        if (k >= 56320 && k <= 57343) {
                                            h = (h - 55296) * 1024 + k - 56320 + 65536;
                                            f[e++] = h >> 18 | 240;
                                            f[e++] = h >> 12 & 63 | 128;
                                            f[e++] = h >> 6 & 63 | 128;
                                            f[e++] = h & 63 | 128;
                                            continue
                                        } else g--
                                    }
                                    if (d) throw Error("Found an unpaired surrogate");
                                    h = 65533
                                }
                                f[e++] = h >> 12 | 224;
                                f[e++] = h >> 6 & 63 | 128
                            }
                            f[e++] = h & 63 | 128
                        }
                    }
                    b = e === f.length ? f : f.subarray(0, e)
                }
                Ah(a, c, 2);
                uh(a.g, b.length);
                yh(a, a.g.end());
                yh(a, b)
            }
        }, Hh),
        Ni = ti(function(a, b, c) {
            if (a.i !== 0) return !1;
            vi(b, c, Ug(a.g));
            return !0
        }, function(a, b, c) {
            b = Ef(b);
            b != null && b != null && (Ah(a, c, 0), uh(a.g, b))
        }, Jh),
        Oi = ui(function(a, b, c) {
            if (a.i !== 0 && a.i !== 2) return !1;
            b = xg(b, b[K] | 0, c);
            a.i == 2 ? lh(a, Ug, b) : b.push(Ug(a.g));
            return !0
        }, function(a, b, c) {
            b = ri(Ef, b, !0);
            if (b != null && b.length) {
                c = zh(a, c);
                for (var d = 0; d < b.length; d++) uh(a.g, b[d]);
                Bh(a, c)
            }
        }, Jh),
        Pi = ti(function(a, b, c) {
            if (a.i !== 0) return !1;
            vi(b, c, Tg(a.g));
            return !0
        }, function(a, b, c) {
            Dh(a, c, Df(b))
        }, Ph),
        Qi = ui(zi, function(a, b, c) {
            b = ri(Df, b, !0);
            if (b != null)
                for (var d = 0; d < b.length; d++) Dh(a, c, b[d])
        }, Ph),
        Ri = ui(zi, function(a, b, c) {
            b = ri(Df, b, !0);
            if (b != null && b.length) {
                c = zh(a, c);
                for (var d = 0; d < b.length; d++) vh(a.g, b[d]);
                Bh(a, c)
            }
        }, Ph);

    function Si(a, b) {
        return function(c, d) {
            var e = {
                kd: !0
            };
            d && Object.assign(e, d);
            c = fh(c, void 0, void 0, e);
            try {
                var f = new a,
                    g = f.F;
                ii(b)(g, c);
                var h = f
            } finally {
                hh(c)
            }
            return h
        }
    }

    function Ti(a) {
        return function() {
            return si(this, a)
        }
    }

    function Ui(a) {
        return function(b) {
            if (b == null || b == "") b = new a;
            else {
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error("dnarr");
                Le(b, 32);
                b = new a(b)
            }
            return b
        }
    };

    function Vi(a) {
        this.F = bg(a, void 0, void 0, 2048)
    }
    x(Vi, Qh);
    Vi.prototype.g = Ti([0, Bi, Ei, -2, Ji]);

    function Wi(a) {
        this.l = a;
        this.g = -1;
        this.i = this.m = 0
    }

    function Xi(a, b) {
        return function() {
            var c = D.apply(0, arguments);
            if (a.g > -1) return b.apply(null, A(c));
            try {
                return a.g = a.l.i.now(), b.apply(null, A(c))
            } finally {
                a.m += a.l.i.now() - a.g, a.g = -1, a.i += 1
            }
        }
    };

    function Yi(a, b) {
        this.i = a;
        this.l = b;
        this.g = new Wi(a)
    };

    function Zi() {
        this.g = {}
    }

    function $i(a, b) {
        a = a.g[b.key];
        if (b.valueType === "proto") {
            try {
                var c = JSON.parse(a);
                if (Array.isArray(c)) return c
            } catch (d) {}
            return b.defaultValue
        }
        return typeof a === typeof b.defaultValue ? a : b.defaultValue
    }

    function aj(a, b) {
        try {
            var c = JSON.parse(b)[0];
            b = "";
            for (var d = 0; d < c.length; d++) b += String.fromCharCode(c.charCodeAt(d) ^ "\u0003\u0007\u0003\u0007\b\u0004\u0004\u0006\u0005\u0003".charCodeAt(d % 10));
            a.g = JSON.parse(b)
        } catch (e) {}
    };
    var bj = {
        qh: 1,
        xh: 2,
        ph: 3,
        1: "POSITION",
        2: "VISIBILITY",
        3: "MONITOR_VISIBILITY"
    };

    function cj() {
        this.A = void 0;
        this.Ia = this.H = 0;
        this.D = -1;
        this.g = new Ib;
        Eb(Kb(this.g, "mv", tb)).i = ub === void 0 ? null : ub;
        Kb(this.g, "omid", qb);
        Eb(Kb(this.g, "epoh", qb));
        Eb(Kb(this.g, "epph", qb));
        Eb(Kb(this.g, "umt", qb)).i = rb === void 0 ? null : rb;
        Eb(Kb(this.g, "phel", qb));
        Eb(Kb(this.g, "phell", qb));
        Eb(Kb(this.g, "oseid", bj));
        var a = this.g;
        a.g.sloi || (a.g.sloi = new Hb);
        Eb(a.g.sloi);
        Kb(this.g, "mm", ob);
        Eb(Kb(this.g, "ovms", nb));
        Eb(Kb(this.g, "xdi", qb));
        Eb(Kb(this.g, "amp", qb));
        Eb(Kb(this.g, "prf", qb));
        Eb(Kb(this.g, "gtx", qb));
        Eb(Kb(this.g, "mvp_lv", qb));
        Eb(Kb(this.g, "ssmol", qb)).i = sb === void 0 ? null : sb;
        Eb(Kb(this.g, "fmd", qb));
        Kb(this.g, "gen204simple", qb);
        this.i = new Yi(Rd(), this.g);
        this.o = null;
        this.l = this.m = this.u = !1;
        this.flags = new Zi
    }

    function L() {
        return Md(cj)
    };

    function dj(a, b, c, d) {
        if (Math.random() < (d || a.g)) try {
            if (c instanceof Cd) var e = c;
            else e = new Cd, Bd(c, function(g, h) {
                var k = e,
                    l = k.m++;
                g = Dd(h, g);
                k.g.push(l);
                k.i[l] = g
            });
            var f = Gd(e, a.i, "/pagead/gen_204?id=" + b + "&");
            f && Qd(f)
        } catch (g) {}
    };

    function ej(a, b, c) {
        c = c === void 0 ? {} : c;
        this.error = a;
        this.meta = c;
        this.context = b.context;
        this.msg = b.message || "";
        this.id = b.id || "jserror"
    };
    var fj = null;

    function gj() {
        var a = a === void 0 ? Ia : a;
        return (a = a.performance) && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : Date.now()
    }

    function hj() {
        var a = a === void 0 ? Ia : a;
        return (a = a.performance) && a.now ? a.now() : null
    };

    function ij(a, b, c) {
        this.label = a;
        this.type = b;
        this.value = c;
        this.duration = 0;
        this.taskId = this.slotId = void 0;
        this.uniqueId = Math.random()
    };
    var jj = Ia.performance,
        kj = !!(jj && jj.mark && jj.measure && jj.clearMarks),
        lj = gd(function() {
            var a;
            if (a = kj) {
                var b = b === void 0 ? window : b;
                if (fj === null) {
                    fj = "";
                    try {
                        a = "";
                        try {
                            a = b.top.location.hash
                        } catch (d) {
                            a = b.location.hash
                        }
                        if (a) {
                            var c = a.match(/\bdeid=([\d,]+)/);
                            fj = c ? c[1] : ""
                        }
                    } catch (d) {}
                }
                b = fj;
                a = !!b.indexOf && b.indexOf("1337") >= 0
            }
            return a
        });

    function mj() {
        var a = window;
        this.events = [];
        this.i = a || Ia;
        var b = null;
        a && (a.google_js_reporting_queue = a.google_js_reporting_queue || [], this.events = a.google_js_reporting_queue, b = a.google_measure_js_timing);
        this.g = lj() || (b != null ? b : Math.random() < 1)
    }

    function nj(a) {
        a && jj && lj() && (jj.clearMarks("goog_" + a.label + "_" + a.uniqueId + "_start"), jj.clearMarks("goog_" + a.label + "_" + a.uniqueId + "_end"))
    }
    mj.prototype.start = function(a, b) {
        if (!this.g) return null;
        var c = hj() || gj();
        a = new ij(a, b, c);
        b = "goog_" + a.label + "_" + a.uniqueId + "_start";
        jj && lj() && jj.mark(b);
        return a
    };
    mj.prototype.end = function(a) {
        if (this.g && cd(a.value)) {
            var b = hj() || gj();
            a.duration = b - a.value;
            b = "goog_" + a.label + "_" + a.uniqueId + "_end";
            jj && lj() && jj.mark(b);
            !this.g || this.events.length > 2048 || this.events.push(a)
        }
    };
    var oj = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");

    function pj(a, b) {
        if (a) {
            a = a.split("&");
            for (var c = 0; c < a.length; c++) {
                var d = a[c].indexOf("="),
                    e = null;
                if (d >= 0) {
                    var f = a[c].substring(0, d);
                    e = a[c].substring(d + 1)
                } else f = a[c];
                b(f, e ? decodeURIComponent(e.replace(/\+/g, " ")) : "")
            }
        }
    };

    function qj() {
        var a = rj;
        this.i = sj;
        this.Me = "jserror";
        this.ie = !0;
        this.zd = null;
        this.l = this.Wd;
        this.g = a === void 0 ? null : a
    }

    function tj(a, b) {
        var c = uj;
        return Xi(L().i.g, function() {
            try {
                if (c.g && c.g.g) {
                    var d = c.g.start(a.toString(), 3);
                    var e = b();
                    c.g.end(d)
                } else e = b()
            } catch (g) {
                var f = c.ie;
                try {
                    nj(d), f = c.l(a, new vj(wj(g)), void 0, void 0)
                } catch (h) {
                    c.Wd(217, h)
                }
                if (!f) throw g;
            }
            return e
        })()
    }

    function xj(a, b) {
        return Xi(L().i.g, function() {
            var c = D.apply(0, arguments);
            return tj(a, function() {
                return b.apply(void 0, c)
            })
        })
    }
    qj.prototype.Wd = function(a, b, c, d, e) {
        e = e || this.Me;
        try {
            var f = new Cd;
            f.g.push(1);
            f.i[1] = Dd("context", a);
            b.error && b.meta && b.id || (b = new vj(wj(b)));
            if (b.msg) {
                var g = b.msg.substring(0, 512);
                f.g.push(2);
                f.i[2] = Dd("msg", g)
            }
            var h = b.meta || {};
            if (this.zd) try {
                this.zd(h)
            } catch (F) {}
            if (d) try {
                d(h)
            } catch (F) {}
            d = [h];
            f.g.push(3);
            f.i[3] = d;
            var k = k || yd();
            var l = new zd(Ia.location.href, !1);
            d = null;
            var m = k.length - 1;
            for (g = m; g >= 0; --g) {
                var q = k[g];
                !d && xd.test(q.url) && (d = q);
                if (q.url && !q.g) {
                    l = q;
                    break
                }
            }
            q = null;
            var t = k.length && k[m].url;
            l.depth !== 0 && t && (q = k[m]);
            var r = new Ad(l, q);
            if (r.i) {
                var w = r.i.url || "";
                f.g.push(4);
                f.i[4] = Dd("top", w)
            }
            var u = {
                url: r.g.url || ""
            };
            if (r.g.url) {
                var v = r.g.url.match(oj),
                    C = v[1],
                    P = v[3],
                    J = v[4];
                k = "";
                C && (k += C + ":");
                P && (k += "//", k += P, J && (k += ":" + J));
                var da = k
            } else da = "";
            u = [u, {
                url: da
            }];
            f.g.push(5);
            f.i[5] = u;
            dj(this.i, e, f, c)
        } catch (F) {
            try {
                dj(this.i, e, {
                    context: "ecmserr",
                    rctx: a,
                    msg: wj(F),
                    url: r && r.g.url
                }, c)
            } catch (z) {}
        }
        return this.ie
    };

    function wj(a) {
        var b = a.toString();
        a.name && b.indexOf(a.name) == -1 && (b += ": " + a.name);
        a.message && b.indexOf(a.message) == -1 && (b += ": " + a.message);
        if (a.stack) a: {
            a = a.stack;
            var c = b;
            try {
                a.indexOf(c) == -1 && (a = c + "\n" + a);
                for (var d; a != d;) d = a, a = a.replace(/((https?:\/..*\/)[^\/:]*:\d+(?:.|\n)*)\2/, "$1");
                b = a.replace(/\n */g, "\n");
                break a
            } catch (e) {
                b = c;
                break a
            }
            b = void 0
        }
        return b
    }

    function vj(a) {
        ej.call(this, Error(a), {
            message: a
        })
    }
    x(vj, ej);
    var sj, uj, rj = new mj;

    function yj() {
        if (G && typeof G.google_measure_js_timing != "undefined" && !G.google_measure_js_timing) {
            var a = rj;
            a.g = !1;
            a.events !== a.i.google_js_reporting_queue && (lj() && Sa(a.events, nj), a.events.length = 0)
        }
    }
    sj = new function() {
        var a = "https:";
        G && G.location && G.location.protocol === "http:" && (a = "http:");
        this.i = a;
        this.g = .01
    };
    uj = new qj;
    G && G.document && (G.document.readyState == "complete" ? yj() : rj.g && od(G, "load", function() {
        yj()
    }));

    function zj(a) {
        uj.zd = function(b) {
            Sa(a, function(c) {
                c(b)
            })
        }
    }

    function Aj(a, b) {
        return tj(a, b)
    }

    function Bj(a, b) {
        return xj(a, b)
    }

    function Cj(a, b, c, d) {
        uj.Wd(a, b, c, d)
    };
    var Dj = Date.now(),
        Ej = -1,
        Fj = -1,
        Gj = !1;

    function Hj() {
        return Date.now() - Dj
    }

    function Ij() {
        var a = L().A,
            b = Fj >= 0 ? Hj() - Fj : -1,
            c = Gj ? Hj() - Ej : -1;
        if (a == 947190542) return 100;
        if (a == 79463069) return 200;
        a = [2E3, 4E3];
        var d = [250, 500, 1E3];
        Cj(637, Error(), .001);
        var e = b;
        c != -1 && c < b && (e = c);
        for (b = 0; b < a.length; ++b)
            if (e < a[b]) {
                var f = d[b];
                break
            }
        f === void 0 && (f = d[a.length]);
        return f
    };

    function Jj(a, b, c) {
        var d = new I(0, 0, 0, 0);
        this.time = a;
        this.volume = null;
        this.l = b;
        this.g = d;
        this.i = null;
        this.m = c
    }
    Jj.prototype.equals = function(a, b) {
        return !!a && (!(b === void 0 ? 0 : b) || this.volume == a.volume) && this.l == a.l && hd(this.g, a.g) && this.i == a.i
    };

    function Kj(a, b, c, d, e, f, g, h) {
        this.m = a;
        this.D = b;
        this.l = c;
        this.u = d;
        this.i = e;
        this.o = f;
        this.g = g;
        this.A = h
    }
    Kj.prototype.equals = function(a, b) {
        return this.m.equals(a.m, b === void 0 ? !1 : b) && this.D == a.D && hd(this.l, a.l) && hd(this.u, a.u) && this.i == a.i && this.o == a.o && this.g == a.g && this.A == a.A
    };
    var Lj = ["GoogleActiveViewElement", "GoogleActiveViewClass", "DfaVisibilityIdentifier"];
    var yb = {
        sf: "addEventListener",
        tf: "getMaxSize",
        uf: "getScreenSize",
        vf: "getState",
        wf: "getVersion",
        yf: "removeEventListener",
        xf: "isViewable"
    };

    function Mj(a) {
        var b = a !== a.top,
            c = a.top === ud(a),
            d = -1,
            e = 0;
        if (b && c && a.top.mraid) {
            d = 3;
            var f = a.top.mraid
        } else d = (f = a.mraid) ? b ? c ? 2 : 1 : 0 : -1;
        f && (f.IS_GMA_SDK || (e = 2), xb(function(g) {
            return typeof f[g] === "function"
        }) || (e = 1));
        return {
            Ea: f,
            Na: e,
            Sa: d
        }
    };

    function Nj() {
        var a = window.document;
        return a && typeof a.elementFromPoint === "function"
    };

    function Oj(a, b, c) {
        try {
            if (a) {
                if (!b.top) return new I(-12245933, -12245933, -12245933, -12245933);
                b = b.top
            }
            a: {
                var d = b;
                if (a && d !== null && d != d.top) {
                    if (!d.top) {
                        var e = new Hc(-12245933, -12245933);
                        break a
                    }
                    d = d.top
                }
                try {
                    if (c === void 0 ? 0 : c) var f = (new Hc(d.innerWidth, d.innerHeight)).round();
                    else {
                        var g = (d || window).document,
                            h = g.compatMode == "CSS1Compat" ? g.documentElement : g.body;
                        f = (new Hc(h.clientWidth, h.clientHeight)).round()
                    }
                    e = f
                } catch (w) {
                    e = new Hc(-12245933, -12245933)
                }
            }
            a = e;
            var k = a.height,
                l = a.width;
            if (l === -12245933) return new I(l, l, l, l);
            var m = Jc(b.document);
            var q = Mc(m.g);
            var t = q.x,
                r = q.y;
            return new I(r, t + l, r + k, t)
        } catch (w) {
            return new I(-12245933, -12245933, -12245933, -12245933)
        }
    };

    function Pj() {
        var a = Rd().g;
        return a.g() ? -1 : a.isVisible() ? 0 : 1
    };

    function Qj() {
        var a = Wb();
        return a ? Xa("AmazonWebAppPlatform;Android TV;Apple TV;AppleTV;BRAVIA;BeyondTV;Freebox;GoogleTV;HbbTV;LongTV;MiBOX;MiTV;NetCast.TV;Netcast;Opera TV;PANASONIC;POV_TV;SMART-TV;SMART_TV;SWTV;Smart TV;SmartTV;TV Store;UnionTV;Version/8.0 Safari/601.1 WPE;WebOS".split(";"), function(b) {
            return Vb(a, b)
        }) || Vb(a, "OMI/") && !Vb(a, "XiaoMi/") ? !0 : Vb(a, "Presto") && Vb(a, "Linux") && !Vb(a, "X11") && !Vb(a, "Android") && !Vb(a, "Mobi") : !1
    }

    function Rj() {
        var a;
        (a = Vb(Wb(), "CrKey") && !(Vb(Wb(), "CrKey") && Vb(Wb(), "SmartSpeaker")) || Vb(Wb(), "PlayStation") || Vb(Wb(), "Roku") || Qj() || Vb(Wb(), "Xbox")) || (a = Wb(), a = Vb(a, "AppleTV") || Vb(a, "Apple TV") || Vb(a, "CFNetwork") || Vb(a, "tvOS"));
        a || (a = Wb(), a = Vb(a, "sdk_google_atv_x86") || Vb(a, "Android TV"));
        return a
    };

    function Sj() {
        this.A = !td(G.top);
        this.o = wd() || vd();
        var a = yd();
        a = a.length > 0 && a[a.length - 1] != null && a[a.length - 1].url != null ? ((a = a[a.length - 1].url.match(oj)[3] || null) ? decodeURI(a) : a) || "" : "";
        this.domain = a;
        this.g = new I(0, 0, 0, 0);
        this.l = new Hc(0, 0);
        this.u = new Hc(0, 0);
        this.i = new I(0, 0, 0, 0);
        this.frameOffset = new Gc(0, 0);
        this.D = !1;
        this.m = !(!G || !Mj(G).Ea);
        this.update(G)
    }

    function Tj(a, b) {
        b && b.screen && (a.l = new Hc(b.screen.width, b.screen.height))
    }

    function Uj(a, b) {
        a: {
            var c = a.g ? new Hc(a.g.bb(), a.g.Za()) : new Hc(0, 0);b = b === void 0 ? G : b;b !== null && b != b.top && (b = b.top);
            var d = 0,
                e = 0;
            try {
                var f = b.document,
                    g = f.body,
                    h = f.documentElement;
                if (f.compatMode == "CSS1Compat" && h.scrollHeight) d = h.scrollHeight != c.height ? h.scrollHeight : h.offsetHeight, e = h.scrollWidth != c.width ? h.scrollWidth : h.offsetWidth;
                else {
                    var k = h.scrollHeight,
                        l = h.scrollWidth,
                        m = h.offsetHeight,
                        q = h.offsetWidth;
                    h.clientHeight != m && (k = g.scrollHeight, l = g.scrollWidth, m = g.offsetHeight, q = g.offsetWidth);
                    k > c.height ? k > m ? (d = k, e = l) : (d = m, e = q) : k < m ? (d = k, e = l) : (d = m, e = q)
                }
                var t = new Hc(e, d);
                break a
            } catch (r) {
                t = new Hc(-12245933, -12245933);
                break a
            }
            t = void 0
        }
        a.u = t
    }
    Sj.prototype.update = function(a) {
        a && a.document && (this.i = Oj(!1, a, this.o), this.g = Oj(!0, a, this.o), Uj(this, a), Tj(this, a))
    };

    function Vj() {
        if (Wj().D) return !0;
        var a = Rd().g,
            b = a.isVisible();
        a = a.g();
        return b || a
    }

    function Wj() {
        return Md(Sj)
    };

    function Xj(a) {
        this.l = a;
        this.i = 0;
        this.g = null
    }
    Xj.prototype.cancel = function() {
        Rd().clearTimeout(this.g);
        this.g = null
    };
    Xj.prototype.K = function() {
        var a = this,
            b = Rd(),
            c = L().i.g;
        this.g = b.setTimeout(Xi(c, Bj(143, function() {
            a.i++;
            a.l.sample()
        })), Ij())
    };

    function Yj(a, b, c) {
        this.m = a;
        this.Kc = c === void 0 ? "na" : c;
        this.u = [];
        this.Y = !1;
        this.i = new Jj(-1, !0, this);
        this.g = this;
        this.Ha = b;
        this.Wa = this.Z = !1;
        this.Kb = "uk";
        this.mb = !1;
        this.o = !0
    }
    n = Yj.prototype;
    n.Jc = function() {
        return this.Ta()
    };
    n.Ta = function() {
        return !1
    };
    n.dc = function() {
        return this.Y = !0
    };
    n.Ob = function() {
        return this.g.Kb
    };
    n.Qb = function() {
        return this.g.Wa
    };
    n.fail = function(a, b) {
        if (!this.Wa || (b === void 0 ? 0 : b)) this.Wa = !0, this.Kb = a, this.Ha = 0, this.g != this || Zj(this)
    };
    n.sa = function() {
        return this.g.Kc
    };
    n.tb = function() {
        return this.g.Kd()
    };
    n.Kd = function() {
        return {}
    };
    n.ab = function() {
        return this.g.Ha
    };

    function ak(a, b) {
        Ra(a.u, b) >= 0 || (a.u.push(b), b.ad(a.g), b.Qa(a.i), b.fc() && (a.Z = !0))
    }
    n.qd = function() {
        var a = Wj();
        a.g = Oj(!0, this.m, a.o)
    };
    n.rd = function() {
        Tj(Wj(), this.m)
    };
    n.se = function() {
        Uj(Wj(), this.m)
    };
    n.te = function() {
        var a = Wj();
        a.i = Oj(!1, this.m, a.o)
    };

    function bk(a) {
        a = a.g;
        a.rd();
        a.qd();
        a.te();
        a.se();
        a.i.g = a.i.g
    }

    function ck(a) {
        var b = Hj(),
            c = Vj();
        return new Jj(b, c, a)
    }
    n.sample = function() {};
    n.isActive = function() {
        return this.g.o
    };

    function dk(a) {
        a.Z = a.u.length ? Xa(a.u, function(b) {
            return b.fc()
        }) : !1
    }

    function ek(a) {
        var b = db(a.u);
        Sa(b, function(c) {
            c.Qa(a.i)
        })
    }

    function Zj(a) {
        var b = db(a.u);
        Sa(b, function(c) {
            c.ad(a.g)
        });
        a.g != a || ek(a)
    }
    n.ad = function(a) {
        var b = this.g;
        this.g = a.ab() >= this.Ha ? a : this;
        b !== this.g ? (this.o = this.g.o, Zj(this)) : this.o !== this.g.o && (this.o = this.g.o, Zj(this))
    };
    n.Qa = function(a) {
        if (a.m === this.g) {
            var b = !this.i.equals(a, this.Z);
            this.i = a;
            b && ek(this)
        }
    };
    n.fc = function() {
        return this.Z
    };
    n.dispose = function() {
        this.mb = !0
    };
    n.Ub = function() {
        return this.mb
    };

    function fk(a, b, c, d) {
        this.element = a;
        this.G = new I(0, 0, 0, 0);
        this.containerGeometry = null;
        this.u = new I(0, 0, 0, 0);
        this.g = b;
        this.D = c;
        this.H = d;
        this.A = !1;
        this.timestamp = -1;
        this.o = new Kj(b.i, this.element, this.G, new I(0, 0, 0, 0), 0, 0, Hj(), 0);
        this.i = void 0
    }
    n = fk.prototype;
    n.observe = function() {
        return !0
    };
    n.unobserve = function() {};
    n.dispose = function() {
        if (!this.Ub()) {
            var a = this.g;
            bb(a.u, this);
            a.Z && this.fc() && dk(a);
            this.unobserve();
            this.A = !0
        }
    };
    n.Ub = function() {
        return this.A
    };
    n.tb = function() {
        return this.g.tb()
    };
    n.ab = function() {
        return this.g.ab()
    };
    n.Ob = function() {
        return this.g.Ob()
    };
    n.Qb = function() {
        return this.g.Qb()
    };
    n.ad = function() {};
    n.Qa = function() {
        gk(this)
    };
    n.fc = function() {
        return this.H
    };

    function hk(a) {
        this.o = !1;
        this.g = a;
        this.m = function() {}
    }
    n = hk.prototype;
    n.ab = function() {
        return this.g.ab()
    };
    n.Ob = function() {
        return this.g.Ob()
    };
    n.Qb = function() {
        return this.g.Qb()
    };
    n.create = function(a, b, c) {
        var d = null;
        this.g && (d = this.Ee(a, b, c), ak(this.g, d));
        return d
    };
    n.td = function() {
        return this.sd()
    };
    n.sd = function() {
        return !1
    };
    n.init = function(a) {
        return this.g.dc() ? (ak(this.g, this), this.m = a, !0) : !1
    };
    n.ad = function(a) {
        a.ab() == 0 && this.m(a.Ob(), this)
    };
    n.Qa = function() {};
    n.fc = function() {
        return !1
    };
    n.dispose = function() {
        this.o = !0
    };
    n.Ub = function() {
        return this.o
    };
    n.tb = function() {
        return {}
    };

    function ik(a, b, c) {
        this.l = c === void 0 ? 0 : c;
        this.i = a;
        this.g = b == null ? "" : b
    }

    function jk(a) {
        switch (Math.trunc(a.l)) {
            case -16:
                return -16;
            case -8:
                return -8;
            case 0:
                return 0;
            case 8:
                return 8;
            case 16:
                return 16;
            default:
                return 16
        }
    }

    function kk(a, b) {
        return a.l < b.l ? !0 : a.l > b.l ? !1 : a.i < b.i ? !0 : a.i > b.i ? !1 : typeof a.g < typeof b.g ? !0 : typeof a.g > typeof b.g ? !1 : a.g < b.g
    };

    function lk() {
        this.l = 0;
        this.g = [];
        this.i = !1
    }
    lk.prototype.add = function(a, b, c) {
        ++this.l;
        a = new ik(a, b, c);
        this.g.push(new ik(a.i, a.g, a.l + this.l / 4096));
        this.i = !0;
        return this
    };

    function mk(a, b) {
        Sa(b.g, function(c) {
            a.add(c.i, c.g, jk(c))
        })
    }

    function nk(a, b) {
        var c = c === void 0 ? 0 : c;
        var d = d === void 0 ? !0 : d;
        Bd(b, function(e, f) {
            d && e === void 0 || a.add(f, e, c)
        });
        return a
    }

    function ok(a) {
        var b = pk;
        a.i && (fb(a.g, function(c, d) {
            return kk(d, c) ? 1 : kk(c, d) ? -1 : 0
        }), a.i = !1);
        return Wa(a.g, function(c, d) {
            d = b(d);
            return "" + c + (c != "" && d != "" ? "&" : "") + d
        })
    };

    function pk(a) {
        var b = a.i;
        a = a.g;
        if (a !== "")
            if (typeof a === "boolean") b = a ? b : "";
            else if (Array.isArray(a)) b = a.length === 0 ? b : b + "=" + a.join();
        else {
            var c = Ra(["mtos", "tos", "p"], b) >= 0;
            b = b + "=" + (c ? a : encodeURIComponent(a))
        }
        return b
    };

    function qk(a) {
        var b = b === void 0 ? !0 : b;
        this.g = new lk;
        a !== void 0 && mk(this.g, a);
        b && this.g.add("v", "unreleased", -16)
    }
    qk.prototype.toString = function() {
        var a = "//pagead2.googlesyndication.com//pagead/gen_204",
            b = ok(this.g);
        b.length > 0 && (a += "?" + b);
        return a
    };

    function rk(a, b, c, d, e) {
        var f = [];
        if (b.length) return f = Va(b, function(g) {
            return g + "&id=" + a
        });
        b = "//" + (e || "pagead2.googlesyndication.com") + "/activeview";
        e = [];
        c && e.push("avi=" + c);
        d && e.push("cid=" + d);
        e.push("id=" + a);
        f.push(b + "?" + e.join("&"));
        return f
    }

    function sk(a) {
        if (!G.navigator || !G.navigator.sendBeacon) return !1;
        a = a.toString().split("?");
        return G.navigator.sendBeacon(a[0], a[1])
    };

    function tk() {
        this.g = 0
    };

    function uk() {
        this.M = this.M;
        this.Xa = this.Xa
    }
    uk.prototype.M = !1;
    uk.prototype.Ub = function() {
        return this.M
    };
    uk.prototype.dispose = function() {
        this.M || (this.M = !0, this.vc())
    };
    uk.prototype[Symbol.dispose] = function() {
        this.dispose()
    };
    uk.prototype.vc = function() {
        if (this.Xa)
            for (; this.Xa.length;) this.Xa.shift()()
    };

    function vk(a, b, c) {
        Sa(a.l, function(d) {
            var e = a.g;
            if (!d.g && (d.l(b, c), d.m())) {
                d.g = !0;
                var f = d.i(),
                    g = new lk;
                g.add("id", "av-js");
                g.add("type", "verif");
                g.add("vtype", d.o);
                d = Md(tk);
                g.add("i", d.g++);
                g.add("adk", e);
                nk(g, f);
                e = new qk(g);
                Qd(e.toString())
            }
        })
    };

    function wk(a) {
        this.F = bg(a, void 0, void 0, 2048)
    }
    x(wk, Qh);
    var xk = [0, Di, Ki, -1];

    function yk() {
        this.g = this.i = this.l = 0
    }
    yk.prototype.update = function(a, b, c) {
        a && (this.l += b, this.i += b, this.g = Math.max(this.g, this.i));
        if (c === void 0 ? !a : c) this.i = 0
    };
    var zk = [1, .75, .5, .3, 0];

    function Bk(a) {
        this.g = a = a === void 0 ? zk : a;
        this.i = Va(this.g, function() {
            return new yk
        })
    }

    function Ck(a) {
        return Dk(a, function(b) {
            return b.l
        }, !1)
    }

    function Ek(a) {
        return Dk(a, function(b) {
            return b.g
        }, !0)
    }
    Bk.prototype.update = function(a, b, c, d, e, f) {
        f = f === void 0 ? !0 : f;
        b = e ? Math.min(a, b) : b;
        for (e = 0; e < this.g.length; e++) {
            var g = this.g[e],
                h = b > 0 && b >= g;
            g = !(a > 0 && a >= g) || c;
            this.i[e].update(f && h, d, !f || g)
        }
    };

    function Dk(a, b, c) {
        a = Va(a.i, function(d) {
            return b(d)
        });
        return c ? a : Fk(a)
    }

    function Fk(a) {
        return Va(a, function(b, c, d) {
            return c > 0 ? d[c] - d[c - 1] : d[c]
        })
    };

    function Gk() {
        this.pa = new Bk;
        this.kb = this.jb = 0;
        this.g = new yk;
        this.i = -1;
        this.l = new Bk([1, .9, .8, .7, .6, .5, .4, .3, .2, .1, 0])
    }
    Gk.prototype.update = function(a, b, c, d) {
        this.i = Math.max(this.i, b.aa);
        this.l.update(b.l, c.l, b.i, a, d);
        this.jb += a;
        b.aa === 0 && (this.kb += a);
        this.pa.update(b.aa, c.aa, b.i, a, d);
        c = d || c.ja != b.ja ? c.isVisible() && b.isVisible() : c.isVisible();
        b = !b.isVisible() || b.i;
        this.g.update(c, a, b)
    };

    function Hk(a) {
        return a.g.g >= 1E3
    };
    if (Sb && Sb.URL) {
        var Ik = Sb.URL,
            Jk;
        a: {
            if (Ik) {
                var Kk = RegExp(".*[&#?]google_debug(=[^&]*)?(&.*)?$");
                try {
                    var Lk = Kk.exec(decodeURIComponent(Ik));
                    if (Lk) {
                        Jk = Lk[1] && Lk[1].length > 1 ? Lk[1].substring(1) : "true";
                        break a
                    }
                } catch (a) {}
            }
            Jk = ""
        }
        uj.ie = !(Jk.length > 0)
    }

    function Mk(a, b, c, d) {
        var e = e === void 0 ? !1 : e;
        c = xj(d, c);
        od(a, b, c, {
            capture: e
        })
    };
    var Nk = new I(0, 0, 0, 0);

    function Ok(a, b) {
        b = Pk(b);
        return b === 0 ? 0 : Pk(a) / b
    }

    function Pk(a) {
        return Math.max(a.g - a.top, 0) * Math.max(a.i - a.left, 0)
    }

    function Qk(a, b) {
        if (!a || !b) return !1;
        for (var c = 0; a !== null && c++ < 100;) {
            if (a === b) return !0;
            try {
                if (a = a.parentElement || a) {
                    var d = Lc(a),
                        e = d && (d ? d.defaultView : window),
                        f = e && e.frameElement;
                    f && (a = f)
                }
            } catch (g) {
                break
            }
        }
        return !1
    }

    function Rk(a, b, c) {
        if (!a || !b) return !1;
        b = id(a.clone(), -b.left, -b.top);
        a = (b.left + b.i) / 2;
        b = (b.top + b.g) / 2;
        td(window.top) && window.top && window.top.document && (window = window.top);
        if (!Nj()) return !1;
        a = window.document.elementFromPoint(a, b);
        if (!a) return !1;
        b = (b = (b = Lc(c)) && b.defaultView && b.defaultView.frameElement) && Qk(b, a);
        var d = a === c;
        a = !d && a && Oc(a, function(e) {
            return e === c
        });
        return !(b || d || a)
    }

    function Sk(a, b, c, d) {
        return Wj().A ? !1 : a.bb() <= 0 || a.Za() <= 0 ? !0 : c && d ? Aj(208, function() {
            return Rk(a, b, c)
        }) : !1
    };
    var Tk = new I(0, 0, 0, 0);

    function Uk(a, b, c) {
        uk.call(this);
        this.position = Tk.clone();
        this.g = new Gk;
        this.Vb = -2;
        Date.now();
        this.Pe = -1;
        this.De = b;
        this.Ua = null;
        this.R = !1;
        this.ed = null;
        this.hc = -1;
        this.X = c;
        this.Kb = function() {};
        this.Qe = function() {};
        this.J = new Pc;
        this.J.U = a;
        this.J.g = a;
        this.o = !1;
        this.A = {
            Yd: null,
            Xd: null
        };
        this.Zb = !0;
        this.V = null;
        L().H++;
        this.i = new pb;
        this.Ie = this.mb = -1;
        this.fg = 0;
        this.S = null;
        this.lc = this.Ae = !1;
        this.l = new Ib;
        Rb(this.l);
        Vk(this);
        this.X == 1 ? Lb(this.l, 1) : Lb(this.l, 0)
    }
    x(Uk, uk);
    n = Uk.prototype;
    n.vc = function() {
        Wk(this);
        this.V && this.V.dispose();
        this.S && this.S.dispose();
        delete this.g;
        delete this.Kb;
        delete this.Qe;
        delete this.J.U;
        delete this.J.g;
        delete this.A;
        delete this.V;
        delete this.S;
        delete this.l;
        uk.prototype.vc.call(this)
    };

    function Xk(a) {
        return a.S ? a.S.G : a.position
    }
    n.ud = function(a) {
        var b = L();
        typeof a === "string" && a.length != 0 && Ob(b.g, a)
    };

    function Vk(a) {
        (a = a.J.U) && a.getAttribute && Fc(a, "googleAvInapp") && (Wj().m = !0)
    }
    n.fe = function() {
        this.R = !0
    };
    n.yc = function() {
        return this.R
    };
    n.de = function() {
        this.i.aa = 0
    };

    function Yk(a, b) {
        if (a.S) {
            if (b.sa() === a.S.sa()) return;
            a.S.dispose();
            a.S = null
        }
        b = b.create(a.J.g, a.l, !1);
        if (b = b != null && b.observe() ? b : null) a.S = b
    }

    function Zk(a, b, c) {
        if (a.S) {
            gk(a.S);
            var d = a.S.o,
                e = d.m,
                f = e.g;
            if (d.u != null) {
                var g = d.l;
                a.ed = new Gc(g.left - f.left, g.top - f.top)
            }
            f = a.hd() ? Math.max(d.i, d.o) : d.i;
            g = {};
            e.volume !== null && (g.volume = e.volume);
            a.Ua && a.De != -1 && d.g !== -1 && a.Ua.g !== -1 ? (e = d.g - a.Ua.g, e = e > 1E4 ? 0 : e) : e = 0;
            a.Ua = d;
            a.pe(f, b, c, !1, g, e, d.A)
        }
    }

    function $k(a) {
        if (a.yc() && a.V) {
            var b = Mb(a.l, "od") == 1,
                c = Wj().g,
                d = a.V,
                e = a.S ? a.S.sa() : "ns",
                f = a.ed,
                g = new Hc(c.bb(), c.Za());
            c = a.hd();
            a = {
                Ng: e,
                ed: f,
                Wg: g,
                hd: c,
                aa: a.i.aa,
                Sg: b
            };
            if (b = d.i) {
                gk(b);
                e = b.o;
                f = e.m.g;
                var h = g = null;
                e.u != null && f && (g = e.l, g = new Gc(g.left - f.left, g.top - f.top), h = new Hc(f.i - f.left, f.g - f.top));
                c = {
                    Ng: b.sa(),
                    ed: g,
                    Wg: h,
                    hd: c,
                    Sg: !1,
                    aa: c ? Math.max(e.i, e.o) : e.i
                }
            } else c = null;
            c && vk(d, a, c)
        }
    }
    n.pe = function(a, b, c, d, e, f, g) {
        this.o || (this.yc() && (e = new pb, e.i = c, e.g = Pj(), e.aa = this.hc === 0 && Mb(this.l, "opac") === 1 ? 0 : a, e.ja = this.ja(), e.l = g, a = d && this.i.aa >= (this.ja() ? .3 : .5), this.g.update(f, e, this.i, a), this.De = b, e.aa > 0 && (-1 === this.mb && (this.mb = b), this.Ie = b), this.Pe == -1 && Hk(this.g) && (this.Pe = b), this.Vb == -2 && (this.Vb = Pk(Xk(this)) ? e.aa : -1), this.i = e), this.Kb(this))
    };
    n.ja = function() {
        return !1
    };
    n.hd = function() {
        return this.Ae || !1
    };

    function al(a) {
        var b = a.R;
        b = (a.lc || a.Ub()) && !b;
        var c = L().Ia !== 2 || !1;
        return a.o || c && b ? 2 : Hk(a.g) ? 4 : 3
    }

    function Wk(a) {
        a.J.g && (a.A.Yd && (pd(a.J.g, "mouseover", a.A.Yd), a.A.Yd = null), a.A.Xd && (pd(a.J.g, "mouseout", a.A.Xd), a.A.Xd = null))
    }

    function bl(a, b, c) {
        b && (a.Kb = b);
        c && (a.Qe = c)
    };

    function cl() {
        this.l = !0;
        this.i = []
    }
    cl.prototype.isVisible = function() {
        return this.l
    };
    cl.prototype.g = function() {
        return !1
    };
    cl.prototype.m = function(a) {
        this.i.push(a);
        return !0
    };
    cl.prototype.o = function(a) {
        this.i = Ua(this.i, function(b) {
            return a !== b
        })
    };

    function dl(a) {
        return cc() ? (a = (a = Lc(a)) && (a ? a.defaultView : window), !!(a && a.location && a.location.ancestorOrigins && a.location.ancestorOrigins.length > 0 && a.location.origin == a.location.ancestorOrigins[0])) : !0
    };

    function el() {}
    el.prototype.next = function() {
        return fl
    };
    var fl = {
        done: !0,
        value: void 0
    };
    el.prototype.ue = function() {
        return this
    };

    function gl(a) {
        if (a instanceof el) return a;
        if (typeof a.ue == "function") return a.ue(!1);
        if (Ma(a)) {
            var b = 0,
                c = new el;
            c.next = function() {
                for (;;) {
                    if (b >= a.length) return fl;
                    if (b in a) return {
                        value: a[b++],
                        done: !1
                    };
                    b++
                }
            };
            return c
        }
        throw Error("Not implemented");
    }

    function hl(a, b) {
        if (Ma(a)) Sa(a, b);
        else
            for (a = gl(a);;) {
                var c = a.next();
                if (c.done) break;
                b.call(void 0, c.value, void 0, a)
            }
    }

    function il(a, b) {
        var c = 1;
        hl(a, function(d) {
            c = b.call(void 0, c, d)
        });
        return c
    }

    function jl(a, b) {
        var c = gl(a);
        a = new el;
        a.next = function() {
            var d = c.next(),
                e = d.value;
            return d.done ? fl : b.call(void 0, e, void 0, c) ? {
                value: e,
                done: !1
            } : fl
        };
        return a
    }

    function kl(a) {
        var b = gl(a);
        a = new el;
        var c = 100;
        a.next = function() {
            return c-- > 0 ? b.next() : fl
        };
        return a
    };

    function ll(a, b) {
        this.l = b;
        this.i = a == null;
        this.g = a
    }
    x(ll, el);
    ll.prototype.next = function() {
        if (this.i) return fl;
        var a = this.g || null;
        this.i = a == null;
        var b;
        if (b = a) {
            b = this.l;
            if (yc(a, "parentElement") && a.parentElement != null && a != a.parentElement) var c = a.parentElement;
            else if (b) {
                var d = d === void 0 ? dl : d;
                if (d(a)) try {
                    var e = Lc(a),
                        f = e && (e ? e.defaultView : window),
                        g = f && f.frameElement;
                    c = g == null ? null : g
                } catch (h) {
                    c = null
                } else c = null
            } else c = null;
            b = c
        }
        this.g = b;
        return {
            value: a,
            done: !1
        }
    };

    function ml(a) {
        var b = 1;
        a = kl(new ll(a, !0));
        a = jl(a, function() {
            return b > 0
        });
        return il(a, function(c, d) {
            var e = 1;
            if (yc(d, "style") && d.style) {
                var f = parseFloat;
                a: {
                    var g = Lc(d);
                    if (g.defaultView && g.defaultView.getComputedStyle && (g = g.defaultView.getComputedStyle(d, null))) {
                        g = g.opacity || g.getPropertyValue("opacity") || "";
                        break a
                    }
                    g = ""
                }
                if (!g) {
                    g = d.style[rc()];
                    if (typeof g !== "undefined") d = g;
                    else {
                        g = d.style;
                        var h = jd.opacity;
                        if (!h) {
                            var k = rc();
                            h = k;
                            d.style[k] === void 0 && (k = (Bc ? "Webkit" : Ac ? "Moz" : null) + tc(k), d.style[k] !== void 0 && (h = k));
                            jd.opacity = h
                        }
                        d = g[h] || ""
                    }
                    g = d
                }
                f = f(g);
                typeof f !== "number" || isNaN(f) || (e = f)
            }
            return b = c * e
        })
    };

    function nl() {
        this.i = !1
    }
    nl.prototype.g = function(a, b) {
        b = b === void 0 ? {} : b;
        this.i || (this.i = this.l(a, b))
    };
    nl.prototype.l = function() {
        return !1
    };

    function ol(a, b, c, d, e, f, g, h, k) {
        h = h === void 0 ? [] : h;
        k = k === void 0 ? "" : k;
        Uk.call(this, c, d, e);
        this.Jb = b;
        this.Mb = 0;
        this.Ff = null;
        this.ta = this.ba = "";
        this.D = [];
        this.ra = [];
        this.Z = this.jc = "";
        this.Nc = !1;
        this.qg = [];
        this.H = this.u = "";
        this.Ga = !1;
        this.lb = [];
        this.m = this.Ue = !1;
        this.Ha = 0;
        this.Y = this.kc = Pj();
        this.Va = 0;
        this.Wa = f;
        this.Kc = this.Ge = !1;
        this.ug = k;
        this.rg = h;
        if (a = this.J.U) this.Mb == 0 ? this.J.U ? (b = this.J.U._adk_, b || (b = (b = Ec(this.J.U, "googleAvAdk")) && !/[^0-9]/.test(b) ? parseInt(b, 10) : 0)) : b = 0 : b = this.Mb, this.Mb = b, this.ba == "" && (this.ba = String(a._avi_ || "")), this.ta == "" && (this.ta = a._avihost_ ? String(a._avihost_) : "pagead2.googlesyndication.com"), this.D.length || (this.D = pl(a, "_avicxn_", "googleAvCxn")), this.ra.length || (this.ra = pl(a, "_avieoscxn_", "googleEOSAvCxn")), this.jc == "" && (this.jc = String(a._aviextcxn_ || Ec(a, "googleAvExtCxn") || "")), this.Z == "" && (this.Z = String(a._cid_ || "")), this.Nc || (this.Nc = !!a._imm_ || Fc(a, "googleAvImmediate")), this.H == "" && (this.H = String(a._cvu_ || Ec(a, "googleAvCpmav") || "")), this.u == "" && (this.u = String(Ec(a, "googleAvBtr") || "")), this.lb.length || (this.lb = pl(a, "", "googleAvVrus")), this.ud(String(a._avm_ || Ec(a, "googleAvMetadata") || "")), a = String(Ec(a, "googleAvFlags") || ""), b = L(), typeof a === "string" && a.length != 0 && aj(b.flags, a);
        Qb(L().g, this.Jb)
    }
    x(ol, Uk);

    function pl(a, b, c) {
        return (a = String(a[b] || Ec(a, c) || "")) ? a.split("|") : []
    }
    n = ol.prototype;
    n.vc = function() {
        delete this.qg;
        Uk.prototype.vc.call(this)
    };

    function ql(a) {
        var b = {},
            c = L();
        (Mb(c.g, "omid") !== 1 || c.l) && Sa(a.rg, function(d) {
            return d.g(a, b)
        })
    }
    n.yc = function() {
        return this.R && !(this.Va == 1 || this.Va == 3)
    };
    n.de = function() {
        Uk.prototype.de.call(this)
    };
    n.fe = function() {
        this.R || (gj(), this.Wa !== void 0 && this.Wa(!1, this.Vb), this.u != null && this.u != "" && (Kd(this.u), this.u = ""));
        Uk.prototype.fe.call(this)
    };
    n.ud = function(a) {
        if (typeof a === "string" && a.length != 0) {
            var b = new Ib,
                c = L();
            Kb(b, "omid", qb);
            Ob(b, a);
            b = Mb(b, "omid");
            b !== null && (c.g.i.omid = b);
            a = Ob(this.l, a);
            c = a.split("&");
            for (b = 0; b < c.length; b++) {
                var d = c[b];
                d == "ts=0" ? this.Zb = !1 : d.lastIndexOf("la=", 0) == 0 ? (d = d.split("=")[1], d == "0" ? this.Ha = 2 : d == "1" && (this.Ha = 1)) : d.lastIndexOf("cr=", 0) == 0 && d.split("=")[1] == "1" && (this.Ae = !0)
            }
            this.i.ja = this.ja();
            Uk.prototype.ud.call(this, a)
        }
    };
    n.pe = function(a, b, c, d, e, f, g) {
        var h = Hk(this.g),
            k = Math.floor(this.i.aa * 100);
        this.Ha = Pk(Xk(this)) >= 242500 ? 1 : 2;
        Uk.prototype.pe.call(this, a, b, c, d, e, f, g);
        this.Y == -1 && this.i.g != -1 ? this.Y = this.i.g : this.Y == 0 && this.i.g == 1 && (this.Y = 1);
        a = Hk(this.g);
        b = Math.floor(this.i.aa * 100);
        Mb(L().g, "gen204simple") && !a && !this.Kc && k >= 50 && b < 50 && (Qd("https://pagead2.googlesyndication.com/pagead/gen_204?id=av-yt&bin=simple&type=nonVisible&mcvt=" + (this.g.g.g + "&uuid=" + this.ug)), this.Kc = !0);
        (!h && a || b != k) && this.Wa !== void 0 && this.Wa(a, b);
        try {
            this.hc = ml(this.J.g)
        } catch (l) {}
    };
    n.ja = function() {
        return Cc ? !1 : this.Ha == 1
    };

    function rl(a, b) {
        switch (b) {
            case 1:
                if (a.D.length) return a.D;
                break;
            case 2:
                if (a.ra.length) return a.ra;
                if (a.D.length) return a.D
        }
        return []
    }

    function sl(a) {
        var b = Wj(),
            c = Nb(a.l),
            d = b.frameOffset,
            e = Xk(a);
        c.p = [e.top + d.y, e.left + d.x, e.g + d.y, e.i + d.x];
        d = a.g;
        c.tos = Ck(d.pa);
        e = Ek(d.pa);
        c.mtos = e;
        c.mcvt = d.g.g;
        c.rs = a.X;
        (e = a.X == 5) || (c.ht = a.fg);
        a.mb >= 0 && (c.tfs = a.mb, c.tls = a.Ie);
        c.mc = Math.floor(d.i * 100) / 100;
        c.lte = Math.floor(a.Vb * 100) / 100;
        c.bas = a.kc;
        c.bac = a.Y;
        b.A && (c["if"] = a.o ? 0 : 1);
        c.met = a.J.i;
        e && a.Jb && (c.req = encodeURIComponent(a.Jb).substring(0, 100));
        a.ja() && (c.la = "1");
        c.avms = a.S ? a.S.sa() : "ns";
        a.S && Cb(c, a.S.tb());
        a.Ge && (c.radf = "1");
        a.Va != 0 && (c.md = a.Va);
        c.btr = a.u != null && a.u != "" ? 1 : 0;
        c.cpmav = tl(a) ? 1 : 0;
        Rd().g.isVisible() || (c.pv = 0);
        c.abdbg = [a.o ? 0 : 1, a.yc() ? 1 : 0].join(";");
        c.tm = a.g.jb;
        c.tu = a.g.kb;
        return c
    }

    function tl(a) {
        return a.H != null && a.H.match(/\/pagead\/adview\?.*ai=.*&vt=\d+/i) != null
    };

    function ul(a) {
        var b = [0, 2, 4],
            c = !1,
            d = vl;
        c = c === void 0 ? !0 : c;
        d = d === void 0 ? function() {
            return !0
        } : d;
        return function(e) {
            var f = e[a];
            if (Array.isArray(f) && d(e)) return wl(f, b, c)
        }
    }

    function xl(a, b) {
        return function(c) {
            return b(c) ? c[a] : void 0
        }
    }

    function yl(a) {
        return function(b) {
            for (var c = 0; c < a.length; c++)
                if (a[c] === b.e || a[c] === void 0 && !b.hasOwnProperty("e")) return !0;
            return !1
        }
    }

    function wl(a, b, c) {
        return c === void 0 || c ? Ua(a, function(d, e) {
            return Ra(b, e) >= 0
        }) : Va(b, function(d, e, f) {
            return a.slice(e > 0 ? f[e - 1] + 1 : 0, d + 1).reduce(function(g, h) {
                return g + h
            }, 0)
        })
    };
    var zl = yl([void 0, 1, 2, 3, 4, 8, 16]),
        vl = yl([void 0, 4, 8, 16]);
    Object.assign({}, {
        sv: "sv",
        v: "v",
        cb: "cb",
        e: "e",
        nas: "nas",
        msg: "msg",
        "if": "if",
        sdk: "sdk",
        p: "p",
        p0: xl("p0", vl),
        p1: xl("p1", vl),
        p2: xl("p2", vl),
        p3: xl("p3", vl),
        cp: "cp",
        tos: "tos",
        mtos: "mtos",
        amtos: "amtos",
        mtos1: ul("mtos1"),
        mtos2: ul("mtos2"),
        mtos3: ul("mtos3"),
        mcvt: "mcvt",
        ps: "ps",
        scs: "scs",
        bs: "bs",
        vht: "vht",
        mut: "mut",
        a: "a",
        a0: xl("a0", vl),
        a1: xl("a1", vl),
        a2: xl("a2", vl),
        a3: xl("a3", vl),
        ft: "ft",
        dft: "dft",
        at: "at",
        dat: "dat",
        as: "as",
        vpt: "vpt",
        gmm: "gmm",
        std: "std",
        efpf: "efpf",
        swf: "swf",
        nio: "nio",
        px: "px",
        nnut: "nnut",
        vmer: "vmer",
        vmmk: "vmmk",
        vmiec: "vmiec",
        nmt: "nmt",
        tcm: "tcm",
        bt: "bt",
        pst: "pst",
        vpaid: "vpaid",
        dur: "dur",
        vmtime: "vmtime",
        dtos: "dtos",
        dtoss: "dtoss",
        dvs: "dvs",
        dfvs: "dfvs",
        dvpt: "dvpt",
        fmf: "fmf",
        vds: "vds",
        is: "is",
        i0: "i0",
        i1: "i1",
        i2: "i2",
        i3: "i3",
        ic: "ic",
        cs: "cs",
        c: "c",
        c0: xl("c0", vl),
        c1: xl("c1", vl),
        c2: xl("c2", vl),
        c3: xl("c3", vl),
        mc: "mc",
        nc: "nc",
        mv: "mv",
        nv: "nv",
        qmt: xl("qmtos", zl),
        qnc: xl("qnc", zl),
        qmv: xl("qmv", zl),
        qnv: xl("qnv", zl),
        raf: "raf",
        rafc: "rafc",
        lte: "lte",
        ces: "ces",
        tth: "tth",
        femt: "femt",
        femvt: "femvt",
        emc: "emc",
        emuc: "emuc",
        emb: "emb",
        avms: "avms",
        nvat: "nvat",
        qi: "qi",
        psm: "psm",
        psv: "psv",
        psfv: "psfv",
        psa: "psa",
        pnk: "pnk",
        pnc: "pnc",
        pnmm: "pnmm",
        pns: "pns",
        ptlt: "ptlt",
        pngs: "pings",
        veid: "veid",
        ssb: "ssb",
        ss0: xl("ss0", vl),
        ss1: xl("ss1", vl),
        ss2: xl("ss2", vl),
        ss3: xl("ss3", vl),
        dc_rfl: "urlsigs",
        obd: "obd",
        omidp: "omidp",
        omidr: "omidr",
        omidv: "omidv",
        omida: "omida",
        omids: "omids",
        omidpv: "omidpv",
        omidam: "omidam",
        omidct: "omidct",
        omidia: "omidia",
        omiddc: "omiddc",
        omidlat: "omidlat",
        omiddit: "omiddit",
        nopd: "nopd",
        co: "co",
        tm: "tm",
        tu: "tu"
    }, {
        avid: function(a) {
            return function() {
                return a
            }
        }("audio"),
        avas: "avas",
        vs: "vs"
    });

    function Al(a, b, c, d) {
        fk.call(this, a, b, c, d)
    }
    x(Al, fk);
    Al.prototype.Cd = function(a) {
        var b;
        return Ok(a, (b = this.i) != null ? b : this.G)
    };
    Al.prototype.Bd = function(a) {
        return Ok(a, Wj().g)
    };
    Al.prototype.Ad = function(a, b) {
        return Ok(a, b)
    };

    function gk(a) {
        a.timestamp = Hj();
        if (a.element) {
            var b = a.element,
                c = a.g.g.m;
            try {
                try {
                    var d = b.getBoundingClientRect();
                    var e = new I(d.top, d.right, d.bottom, d.left)
                } catch (q) {
                    e = new I(0, 0, 0, 0)
                }
                var f = e.i - e.left,
                    g = e.g - e.top,
                    h = ld(b, c),
                    k = h.x,
                    l = h.y;
                var m = new I(Math.round(l), Math.round(k + f), Math.round(l + g), Math.round(k))
            } catch (q) {
                m = Nk.clone()
            }
            a.containerGeometry = m;
            m = a.containerGeometry;
            m = a.i ? new I(Math.max(m.top + a.i.top, m.top), Math.min(m.left + a.i.i, m.i), Math.min(m.top + a.i.g, m.g), Math.max(m.left + a.i.left, m.left)) : m.clone();
            a.G = m
        }
        a.element && typeof a.element.videoWidth === "number" && typeof a.element.videoHeight === "number" && (m = a.element, g = new Hc(m.videoWidth, m.videoHeight), m = a.G, b = m.bb(), c = m.Za(), f = g.width, g = g.height, f <= 0 || g <= 0 || b <= 0 || c <= 0 || (f /= g, g = b / c, m = m.clone(), f > g ? (b /= f, c = (c - b) / 2, c > 0 && (c = m.top + c, m.top = Math.round(c), m.g = Math.round(c + b))) : (c *= f, b = Math.round((b - c) / 2), b > 0 && (b = m.left + b, m.left = Math.round(b), m.i = Math.round(b + c)))), a.G = m);
        a.u = a.g.i.g;
        m = a.G;
        b = a.u;
        m = m.left <= b.i && b.left <= m.i && m.top <= b.g && b.top <= m.g ? new I(Math.max(m.top, b.top), Math.min(m.i, b.i), Math.min(m.g, b.g), Math.max(m.left, b.left)) : new I(0, 0, 0, 0);
        b = m.top >= m.g || m.left >= m.i ? new I(0, 0, 0, 0) : m;
        m = a.g.i;
        g = f = c = 0;
        (a.G.g - a.G.top) * (a.G.i - a.G.left) > 0 && (Sk(b, a.u, a.element, Mb(a.D, "od") == 1) ? b = new I(0, 0, 0, 0) : (c = Wj().l, g = new I(0, c.height, c.width, 0), c = a.Cd(b), f = a.Bd(b), g = a.Ad(b, g)));
        b = b.top >= b.g || b.left >= b.i ? new I(0, 0, 0, 0) : id(b, -a.G.left, -a.G.top);
        Vj() || (f = c = 0);
        a.o = new Kj(m, a.element, a.G, b, c, f, a.timestamp, g)
    }
    Al.prototype.sa = function() {
        return this.g.sa()
    };

    function Bl() {
        this.i = [];
        this.g = []
    }

    function Cl(a) {
        var b = Dl;
        return a ? Za(b.g, function(c) {
            return c.J.U == a
        }) : null
    }

    function El() {
        var a = Dl;
        return a.i.length == 0 ? a.g : a.g.length == 0 ? a.i : cb(a.g, a.i)
    }
    Bl.prototype.reset = function() {
        this.i = [];
        this.g = []
    };

    function Fl(a) {
        var b = [];
        Sa(a, function(c) {
            c.J.U && Cl(c.J.U) == null && (Dl.g.push(c), b.push(c))
        })
    }
    var Dl = Md(Bl);

    function Gl() {
        this.g = this.i = null
    }

    function Hl(a, b) {
        function c(d, e) {
            b(d, e)
        }
        if (a.i == null) return !1;
        a.g = Za(a.i, function(d) {
            return d != null && d.td()
        });
        a.g && (a.g.init(c) ? bk(a.g.g) : b(a.g.g.Ob(), a.g));
        return a.g != null
    };

    function Il(a) {
        a = Jl(a);
        hk.call(this, a.length ? a[a.length - 1] : new Yj(G, 0));
        this.l = a;
        this.i = null
    }
    x(Il, hk);
    n = Il.prototype;
    n.sa = function() {
        return (this.i ? this.i : this.g).sa()
    };
    n.tb = function() {
        return (this.i ? this.i : this.g).tb()
    };
    n.ab = function() {
        return (this.i ? this.i : this.g).ab()
    };
    n.init = function(a) {
        var b = !1;
        Sa(this.l, function(c) {
            c.dc() && (b = !0)
        });
        b && (this.m = a, ak(this.g, this));
        return b
    };
    n.dispose = function() {
        Sa(this.l, function(a) {
            a.dispose()
        });
        hk.prototype.dispose.call(this)
    };
    n.td = function() {
        return Xa(this.l, function(a) {
            return a.Jc()
        })
    };
    n.sd = function() {
        return Xa(this.l, function(a) {
            return a.Ta()
        })
    };
    n.Ee = function(a, b, c) {
        return new Al(a, this.g, b, c)
    };
    n.Qa = function(a) {
        this.i = a.m
    };

    function Jl(a) {
        if (!a.length) return [];
        a = Ua(a, function(c) {
            return c != null && c.Jc()
        });
        for (var b = 1; b < a.length; b++) ak(a[b - 1], a[b]);
        return a
    };

    function Kl() {};

    function Ll() {
        this.done = !1;
        this.g = {
            yd: 0,
            xd: 0,
            bi: 0,
            He: 0,
            Pd: -1,
            Of: 0,
            Nf: 0,
            Pf: 0,
            gf: 0
        };
        this.i = null;
        this.u = !1;
        this.m = null;
        this.D = 0;
        this.l = new Xj(this);
        this.o = null
    }

    function Ml() {
        var a = Nl;
        a.u || (a.u = !0, Ol(a, function() {
            return a.A.apply(a, A(D.apply(0, arguments)))
        }), a.A())
    }
    Ll.prototype.sample = function() {
        Pl(this, El(), !1)
    };

    function Ql() {
        Md(Kl);
        var a = Md(Gl);
        a.g != null && a.g.g ? bk(a.g.g) : Wj().update(G)
    }

    function Pl(a, b, c) {
        if (!a.done && (a.l.cancel(), b.length != 0)) {
            a.m = null;
            try {
                Ql();
                var d = Hj();
                L().D = d;
                if (Md(Gl).g != null)
                    for (var e = 0; e < b.length; e++) Zk(b[e], d, c);
                for (d = 0; d < b.length; d++) $k(b[d]);
                ++a.g.He
            } finally {
                c ? Sa(b, function(f) {
                    return f.de()
                }) : a.l.K()
            }
        }
    }

    function Ol(a, b) {
        a.i || (b = xj(142, b), Rd().g.m(b) && (a.i = b))
    }
    Ll.prototype.A = function() {
        var a = Vj(),
            b = Hj();
        a ? (Gj || (Ej = b, Sa(Dl.i, function(c) {
            return c.g.o(b, !c.m())
        })), Gj = !0) : (this.D = Rl(this, b), Gj = !1, Sa(Dl.i, function(c) {
            c.yc() && c.g.m(b)
        }));
        Pl(this, El(), !a)
    };

    function Sl(a) {
        var b = Nl;
        if (!b.m || a) {
            var c = G.document,
                d = Fj >= 0 ? Hj() - Fj : -1;
            a = Hj();
            b.g.Pd == -1 && (d = a);
            var e = Wj(),
                f = L(),
                g = Nb(f.g),
                h = El();
            try {
                if (h.length > 0) {
                    var k = e.g;
                    k && (g.bs = [k.bb(), k.Za()]);
                    var l = e.u;
                    l && (g.ps = [l.width, l.height]);
                    G.screen && (g.scs = [G.screen.width, G.screen.height])
                } else g.url = encodeURIComponent(G.location.href.substring(0, 512)), c.referrer && (g.referrer = encodeURIComponent(c.referrer.substring(0, 512)));
                g.tt = d;
                g.pt = Fj;
                g.bin = f.Ia;
                G.google_osd_load_pub_page_exp !== void 0 && (g.olpp = G.google_osd_load_pub_page_exp);
                k = -1;
                b.o !== null && (k = b.o() ? 1 : 0);
                var m = [1, b.g.yd, b.g.xd, b.g.He, b.g.Pd, 0, b.l.i, b.g.Of, b.g.Nf, b.g.Pf, b.g.gf, k].join(";");
                g.deb = m;
                g.tvt = Rl(b, a);
                e.m && (g.inapp = 1);
                if (G !== null && G != G.top) {
                    h.length > 0 && (g.iframe_loc = encodeURIComponent(G.location.href.substring(0, 512)));
                    var q = e.i;
                    g.is = [q.bb(), q.Za()]
                }
            } catch (t) {
                g.error = 1
            }
            b.m = g
        }
        b = Ab(b.m);
        m = L().i;
        if (Mb(m.l, "prf") == 1) {
            q = new Vi;
            a = m.g;
            e = 0;
            a.g > -1 && (e = a.l.i.now() - a.g);
            a = a.m + e;
            if (a != null && typeof a !== "number") throw Error("Value of float/double field must be a number, found " + typeof a + ": " + a);
            q = wg(q, 1, a, 0);
            a = m.g;
            q = wg(q, 5, Cf(a.g > -1 ? a.i + 1 : a.i), 0);
            q = Lg(q, 2, m.i.i.l());
            q = Lg(q, 3, m.i.i.i());
            m = Lg(q, 4, m.i.i.g());
            q = {};
            m = (q.pf = ee(m.g()), q)
        } else m = {};
        Cb(b, m);
        return b
    }

    function Tl() {
        Sa(El(), function(a) {
            a.J.U && Md(Kl)
        })
    }

    function Ul() {
        var a = Md(Gl);
        if (a.g != null) {
            var b = El(),
                c = a.g;
            Sa(b, function(d) {
                return Yk(d, c)
            })
        }
    }

    function Rl(a, b) {
        a = a.D;
        Gj && (a += b - Ej);
        return a
    }

    function Vl() {
        var a = a === void 0 ? function() {
            return {}
        } : a;
        uj.Me = "av-js";
        sj.g = .01;
        zj([function(b) {
            var c = L(),
                d = {};
            Cb(b, (d.bin = c.Ia, d.type = "error", d), Nb(c.g), Sl(), a())
        }])
    }
    var Nl = Md(Ll);
    var Wl = null;

    function Xl(a) {
        var b = Wl || G;
        if (!b) return "";
        var c = [];
        if (a === void 0 || !a) {
            if (!b.location || !b.location.href) return "";
            c.push("url=" + encodeURIComponent(b.location.href.substring(0, 512)))
        }
        b.document && b.document.referrer && c.push("referrer=" + encodeURIComponent(b.document.referrer.substring(0, 512)));
        return c.join("&")
    };

    function Yl(a) {
        var b = {};
        b.adk = a.Mb || 1;
        Cb(b, sl(a));
        Nl.g.yd = G.__google_lidar_;
        var c = Sl();
        Cb(b, c);
        c = Xl(c.url !== void 0);
        pj(c, function(d, e) {
            return b[d] = e
        });
        b.itpl = Number(Ec(a.J.U, "googleAvItpl")) || 0;
        return b
    };
    var Zl = /(?:\[|%5B)([a-zA-Z0-9_]+)(?:\]|%5D)/g;

    function $l(a, b) {
        return a.replace(Zl, function(c, d) {
            try {
                var e = b !== null && d in b ? b[d] : void 0;
                if (e == null || e.toString() == null) return c;
                e = e.toString();
                if (e == "" || !/^[\s\xa0]*$/.test(e == null ? "" : String(e))) return encodeURIComponent(e).replace(/%2C/g, ",")
            } catch (f) {}
            return c
        })
    };

    function am(a) {
        this.i = a
    }

    function bm(a, b, c) {
        return c.X === 14 || c.X === 16 || c.X === 17 ? (c = {}, c.VIEWABILITY = b, $l(a, c)) : a + "&" + b
    }
    am.prototype.g = function(a, b, c) {
        var d = this.i(a);
        Cb(d, wb(c, function(e, f) {
            return f != "id"
        }));
        d = d !== void 0 ? ok(nk(new lk, d)) : "";
        b = rk(c.id, rl(a, b), a.ba, a.Z, a.ta);
        b = y(b);
        for (c = b.next(); !c.done; c = b.next())
            if (c = c.value) c = bm(c, d, a), Mb(a.l, "sbeos") == 1 ? sk(c) || Qd((c.toString() + "&sberr=1").toString()) : Qd(c.toString());
        return !0
    };

    function cm() {}

    function dm(a, b, c) {
        return c.X === 14 || c.X === 16 || c.X === 17 ? (c = {}, c.VIEWABILITY = b, $l(a, c)) : a + "&" + b
    }
    cm.prototype.g = function(a, b, c) {
        var d = Yl(a);
        Cb(d, wb(c, function(e, f) {
            return f != "id"
        }));
        d = d !== void 0 ? ok(nk(new lk, d)) : "";
        b = rk(c.id, rl(a, b), a.ba, a.Z, a.ta);
        b = y(b);
        for (c = b.next(); !c.done; c = b.next())
            if (c = c.value) c = dm(c, d, a), Qd(c.toString());
        return !0
    };

    function em(a, b) {
        this.i = !1;
        this.u = a;
        this.o = b
    }
    x(em, nl);
    em.prototype.l = function(a, b) {
        b.id = this.o;
        b.vs = al(a);
        var c = this.o === "lidar2" ? 1 : 2;
        return this.m(a) ? this.u.g(a, c, b) : !1
    };
    em.prototype.m = function() {
        return !0
    };

    function fm(a) {
        em.call(this, a, "lidartos")
    }
    x(fm, em);
    fm.prototype.l = function(a, b) {
        var c = "";
        a.m && (c += "a");
        a.Ga && (c += "c");
        b.sent = c;
        return em.prototype.l.call(this, a, b)
    };
    fm.prototype.m = function(a) {
        return a.Zb && !a.o && Hk(a.g)
    };

    function gm(a) {
        em.call(this, a, "lidar2")
    }
    x(gm, em);
    gm.prototype.m = function(a) {
        return a.o
    };

    function hm(a, b, c) {
        var d = Xl(b.url !== void 0);
        pj(d, function(e, f) {
            return b[e] = f
        });
        Sa(a, function(e, f) {
            var g = al(e);
            if (g != 3 || e.X != 5) b.adk = e.Mb || f + 1, Cb(b, sl(e)), c && (b.avms = c.sa()), b.vs = g, b.itpl = Number(Ec(e.J.U, "googleAvItpl")) || 0, f = new am(function() {
                return Ab(b)
            }), e.Zb && !e.o && Hk(e.g) ? (g = {}, f.g(e, 2, (g.id = "lidar2", g.tsf = 1, g)), e.Zb = !1) : (g = {}, f.g(e, 1, (g.id = "lidar2", g)), e.m = !0)
        })
    }

    function im(a, b) {
        Sa(a, function(c, d) {
            (new fm(new am(function() {
                b.adk = c.Mb || d + 1;
                Cb(b, sl(c));
                b.vs = al(c);
                b.itpl = Number(Ec(c.J.U, "googleAvItpl")) || 0;
                return b
            }))).g(c);
            c.Zb = !1
        })
    };

    function jm(a) {
        em.call(this, a, "lidar2")
    }
    x(jm, em);
    jm.prototype.g = function(a, b) {
        b = b === void 0 ? {} : b;
        b.r = "v";
        em.prototype.g.call(this, a, b);
        a.m = a.m || this.i
    };
    jm.prototype.m = function(a) {
        return Hk(a.g) && !a.m
    };
    var km = ["FRAME", "IMG", "IFRAME"],
        lm = /^[01](px)?$/;

    function mm() {
        this.i = this.g = !1
    }

    function nm() {
        var a = new mm;
        a.g = !0;
        return a
    }

    function om() {
        var a = nm();
        a.i = !0;
        return a
    }

    function pm(a) {
        return dd(a) ? document.getElementById(a) : a
    }

    function qm(a) {
        var b = !1;
        b = b === void 0 ? !1 : b;
        if (a.tagName === "IMG") {
            if (a.complete && (!a.naturalWidth || !a.naturalHeight)) return !0;
            var c;
            if (b && ((c = a.style) == null ? void 0 : c.display) === "none") return !0
        }
        var d, e;
        return lm.test((d = a.getAttribute("width")) != null ? d : "") && lm.test((e = a.getAttribute("height")) != null ? e : "")
    }

    function rm(a, b) {
        if (a.tagName === "IMG") return a.naturalWidth && a.naturalHeight ? !0 : !1;
        try {
            if (a.readyState) var c = a.readyState;
            else {
                var d, e;
                c = (d = a.contentWindow) == null ? void 0 : (e = d.document) == null ? void 0 : e.readyState
            }
            return c === "complete"
        } catch (f) {
            return b === void 0 ? !1 : b
        }
    }

    function sm(a) {
        a || (a = function(b, c, d) {
            b.addEventListener(c, d)
        });
        return a
    }

    function tm(a, b, c, d) {
        c = c === void 0 ? new mm : c;
        if (a = pm(a)) {
            d = sm(d);
            for (var e = !1, f = function(v) {
                    e || (e = !0, b(v))
                }, g, h = 2, k = 0; k < km.length; ++k)
                if (km[k] === a.tagName) {
                    h = 3;
                    g = [a];
                    break
                }
            g || (g = a.querySelectorAll(km.join(",")));
            var l = 0,
                m = 0,
                q = !0,
                t = a = !1;
            k = {};
            for (var r = 0; r < g.length; k = {
                    cd: void 0
                }, r++) {
                var w = g[r];
                if (!qm(w))
                    if (k.cd = w.tagName === "IMG", rm(w, c.g)) a = !0, k.cd && (q = !0);
                    else {
                        l++;
                        var u = function(v) {
                            return function(C) {
                                l--;
                                !l && q && f(h);
                                v.cd && (C = C && C.type === "error", m--, C || (q = !0), !m && t && q && f(h))
                            }
                        }(k);
                        d(w, "load", u);
                        k.cd && (m++, d(w, "error", u))
                    }
            }
            m === 0 && (q = !0);
            g = null;
            g = Ia.document.readyState === "complete";
            if (l === 0 && !a && g) h = 5;
            else if (l || !a) {
                d(Ia, "load", function() {
                    !c.i || !m && q ? f(4) : t = !0
                });
                return
            }
            f(h)
        }
    };

    function um() {
        var a = this;
        this.g = this.l = !1;
        Vl();
        Nl.o = function() {
            return vm(a)
        }
    }

    function wm(a) {
        a.l || (a.l = !0, Mk(G, "unload", function() {
            xm("u")
        }, 171), Mb(L().g, "phell") == 1 && Mk(G, "pagehide", function() {
            xm("ph")
        }, 498))
    }

    function ym() {
        return Xa(Dl.g, function(a) {
            return !a.m || a.Zb || (Pk(Xk(a)) <= 0 ? !1 : tl(a) && !a.Ga)
        })
    }

    function zm() {
        if (!ym()) {
            Nl.done = !0;
            Dl.reset();
            var a = Nl;
            a.u = !1;
            a.g.gf++;
            a.i && (Rd().g.o(a.i), a.i = null);
            a = El();
            for (var b, c = 0; c < a.length; ++c) b = a[c], b.J.g && Wk(b);
            a = Md(Gl);
            a.g != null && (a.g.dispose(), a.g = null)
        }
    }

    function Am(a, b) {
        if (L().o) {
            var c = L().o;
            a.i(b, c)
        } else b.fe()
    }

    function Bm(a) {
        var b = b === void 0 ? !0 : b;
        try {
            if (vm(a)) {
                a.g = !0;
                var c = Wj(),
                    d = Hj();
                Fj = d;
                var e = L();
                e.A = 947190542;
                Wl = ud(G);
                var f = Nl.g;
                f.Pd = Hj() - d;
                f.xd = 0;
                b && Cm(a, d, a.Zc());
                var g = Dl.g;
                f.xd = g.length;
                G.__google_lidar_adblocks_count_ = g.length;
                if (g.length < 1) xm("n");
                else {
                    Tl();
                    var h = Md(Gl);
                    if (h.i == null) {
                        var k = Dm(e.g);
                        h.i = k
                    }
                    Hl(h, function(l, m) {
                        Em(l);
                        xm(l, m)
                    }) ? Nl.done || (Fm(), Ul(), Ml()) : c.m ? (Em("w"), xm("w")) : (Em("i"), xm("i"))
                }
            }
        } catch (l) {
            throw Dl.reset(), xm("x"), l;
        }
    }

    function Em(a) {
        var b = Dl.g;
        L().o = a;
        Sa(b, function(c) {
            return c.o = !0
        })
    }

    function Fm() {
        Rd().setTimeout(Bj(176, function() {
            return xm("t")
        }), 36E5)
    }

    function vm(a) {
        if (a.g || Nl.done) return !1;
        Rd();
        a = G.document;
        return a && a.body && a.body.getBoundingClientRect && typeof G.setInterval === "function" && typeof G.clearInterval === "function" && typeof G.setTimeout === "function" && typeof G.clearTimeout === "function" ? !0 : (xm("c"), !1)
    }

    function xm(a, b) {
        var c = Dl.g;
        Sa(c, function(f) {
            f.lc = !0
        });
        var d = L();
        if (Mb(d.g, "omid") === 1) {
            if (a !== "w" && a !== "i" && !d.l) return
        } else if (d.u && !d.m) return;
        Nl.l.cancel();
        if (!Nl.done && (Pl(Nl, c, !0), !Nl.done)) {
            d = Ua(c, function(f) {
                return !f.m
            });
            var e = {};
            a = (e.r = a, e);
            b && Cb(a, b.tb());
            Nl.g.yd = G.__google_lidar_;
            e = Sl(!1);
            Cb(a, e);
            d.length == 0 || hm(d, a, b);
            im(c, a);
            Nl.done = !0
        }
    }

    function Gm(a, b, c, d, e) {
        var f = L(),
            g = new ol(G, "", b, d, c, fd, [], [new jm(new cm)], e);
        d = f.i.g;
        bl(g, Xi(d, function() {
            return a.m.apply(a, A(D.apply(0, arguments)))
        }), Xi(d, function() {
            return a.i.apply(a, A(D.apply(0, arguments)))
        }));
        Fl([g]);
        tm(b, Xi(d, function() {
            if (g && !g.Ub()) {
                Am(a, g);
                if (g.J.U) {
                    var h = g.J,
                        k = !0,
                        l = !0;
                    k = k === void 0 ? !1 : k;
                    l = l === void 0 ? !1 : l;
                    h.g = h.U;
                    h.i = "mue";
                    if (!Qc(h.U)) {
                        var m = Tc(h.U),
                            q = Tc(h.U, !1);
                        Qc(q);
                        Qc(m) ? (h.g = m, h.i = "ie") : k && (l || G !== G.top) && (k = Yc(), k.length == 1 && (h.g = k[0], h.i = "ce"))
                    }
                }
                Wj().m || Rj() || !Rd().g.g() || c == 17 ? a.g ? (h = Md(Gl), h.g != null && Yk(g, h.g), g.J.U && Md(Kl), Pl(Nl, El(), !1)) : Bm(a) : (Em("pv"), xm("pv"))
            }
        }), nm(), function(h, k, l) {
            Mk(h, k, l, 177)
        });
        return g
    }
    um.prototype.Zc = function() {
        return []
    };

    function Cm(a, b, c) {
        var d = [];
        Sa(c, function(e) {
            var f = b,
                g = "";
            g = g === void 0 ? "" : g;
            f = f === void 0 ? Hj() : f;
            wm(a);
            var h = Hm(e);
            h == 0 || Cl(e) != null ? e = null : (Mb(L().g, "gen204simple") && Qd("https://pagead2.googlesyndication.com/pagead/gen_204?id=av-yt&bin=simple&type=registerAd&uuid=" + g), e = Gm(a, e, h, f, g));
            e && d.push(e)
        });
        return d
    }

    function Hm(a) {
        if (!a) return 0;
        var b = Ec(a, "googleAvRs");
        if (b != null) switch (Number(b)) {
            case 6:
                return 5;
            case 9:
                return L().u = !0, 8;
            case 15:
                return 14;
            case 16:
                return 15;
            case 17:
                return 16;
            case 18:
                return 17;
            default:
                return 0
        }
        if (!a.id) return 0;
        a = a.id;
        return a.lastIndexOf("DfaVisibilityIdentifier", 0) == 0 ? 5 : a.lastIndexOf("YtKevlarVisibilityIdentifier", 0) == 0 ? 14 : a.lastIndexOf("YtSparklesVisibilityIdentifier", 0) == 0 ? 16 : a.lastIndexOf("YtKabukiVisibilityIdentifier", 0) == 0 ? 17 : 0
    }
    um.prototype.i = function(a, b) {
        if (a && !Nl.done && (a.o = !0, !a.m)) {
            var c = new gm(new cm),
                d = al(a),
                e = {};
            c.g(a, (e.vs = d, e.r = b, e));
            a.m = c.i
        }
        zm()
    };
    um.prototype.m = function(a) {
        if (a) {
            if (!Nl.done && a instanceof ol && (ql(a), !Nl.done && Hk(a.g) && (Pk(Xk(a)) <= 0 ? 0 : tl(a) && !a.Ga) && a.H && (Kd(a.H), a.Ga = !0), !Nl.done && Hk(a.g) && a.lb.length && !a.Ue)) {
                for (var b = y(a.lb), c = b.next(); !c.done; c = b.next())(c = c.value) && Kd(c);
                a.Ue = !0
            }
            zm()
        }
    };

    function Im(a, b) {
        this.key = a;
        this.defaultValue = b === void 0 ? !1 : b;
        this.valueType = "boolean"
    }

    function Jm(a, b) {
        this.key = a;
        this.defaultValue = b === void 0 ? 0 : b;
        this.valueType = "number"
    };
    var Km = new Im("45653435"),
        Lm = new Im("100006"),
        Mm = new Jm("45362137"),
        Nm = new Im("45377435"),
        Om = new Im("45618478"),
        Pm = new Jm("45738539", 2),
        Qm = new Im("45661569"),
        Rm = new Im("45642405"),
        Sm = new Im("45372163"),
        Tm = new Im("45407241"),
        Um = new Im("45722991", !0),
        Vm = new Im("45382077"),
        Wm = new Im("45658589"),
        Xm = new Jm("45706257", 36E5),
        Ym = new Im("45407239"),
        Zm = new Im("45407240", !0),
        $m = new Im("45430682");

    function an(a, b, c) {
        fk.call(this, null, a, b, c);
        this.l = this.m = null
    }
    x(an, Al);
    n = an.prototype;
    n.sa = function() {
        return "omid"
    };
    n.Qa = function(a) {
        this.G = Wj().i || new I(0, 0, 0, 0);
        $i(L().flags, Lm) && (this.m = a.i, this.m !== null && (this.l = this.m * Pk(this.G)));
        Al.prototype.Qa.call(this, a)
    };
    n.Cd = function(a) {
        return this.m !== null ? this.m : Al.prototype.Cd.call(this, a)
    };
    n.Bd = function(a) {
        return this.l !== null ? (a = Pk(Wj().g), a === 0 ? 0 : this.l / a) : Al.prototype.Bd.call(this, a)
    };
    n.Ad = function(a, b) {
        return this.l !== null ? (a = Pk(b), a === 0 ? 0 : this.l / a) : Al.prototype.Ad.call(this, a, b)
    };

    function bn(a, b) {
        if (!b) throw Error("Value for " + a + " is undefined, null or blank.");
        if (typeof b !== "string" && !(b instanceof String)) throw Error("Value for " + a + " is not a string.");
        if (b.trim() === "") throw Error("Value for " + a + " is empty string.");
    }

    function cn(a) {
        if (!a) throw Error("functionToExecute must not be truthy.");
    }

    function dn(a, b) {
        if (b == null) throw Error(a + " must not be null or undefined.");
        if (typeof b !== "number" || isNaN(b)) throw Error("Value for " + a + " is not a number");
        if (b < 0) throw Error(a + " must be a positive number.");
    };

    function en() {
        return /\d+\.\d+\.\d+(-.*)?/.test("1.6.5-google_20260406")
    }

    function fn() {
        for (var a = ["1", "6", "5"], b = ["1", "0", "3"], c = 0; c < 3; c++) {
            var d = parseInt(a[c], 10),
                e = parseInt(b[c], 10);
            if (d > e) break;
            else if (d < e) return !1
        }
        return !0
    };
    var gn = {
        bh: "app",
        yh: "web"
    };

    function hn(a, b, c, d) {
        this.g = a;
        this.method = b;
        this.version = c;
        this.args = d
    }

    function jn(a) {
        return !!a && a.omid_message_guid !== void 0 && a.omid_message_method !== void 0 && a.omid_message_version !== void 0 && typeof a.omid_message_guid === "string" && typeof a.omid_message_method === "string" && typeof a.omid_message_version === "string" && (a.omid_message_args === void 0 || a.omid_message_args !== void 0)
    }

    function kn(a) {
        return new hn(a.omid_message_guid, a.omid_message_method, a.omid_message_version, a.omid_message_args)
    }

    function ln(a) {
        var b = {};
        b = (b.omid_message_guid = a.g, b.omid_message_method = a.method, b.omid_message_version = a.version, b);
        a.args !== void 0 && (b.omid_message_args = a.args);
        return b
    };

    function mn(a) {
        this.g = a
    };

    function nn(a, b) {
        try {
            return a.frames && !!a.frames[b]
        } catch (c) {
            return !1
        }
    }

    function on(a) {
        return ["omid_v1_present", "omid_v1_present_web", "omid_v1_present_app"].some(function(b) {
            return nn(a, b)
        })
    }

    function pn(a) {
        for (var b = y(Object.values(gn)), c = b.next(); !c.done; c = b.next()) {
            c = c.value;
            var d = {};
            d = (d.app = "omid_v1_present_app", d.web = "omid_v1_present_web", d)[c];
            if (nn(a, d)) return c
        }
        return null
    };

    function qn(a, b) {
        return a && (a[b] || (a[b] = {}))
    };

    function rn() {
        return typeof crypto !== "undefined" && typeof crypto.getRandomValues === "function"
    }

    function sn() {
        var a = new Uint8Array(16);
        crypto.getRandomValues(a);
        a[6] = a[6] & 15 | 64;
        a[8] = a[8] & 63 | 128;
        for (var b = [], c = 0; c < 16; c++) b.push(a[c].toString(16).padStart(2, "0"));
        return b[0] + b[1] + b[2] + b[3] + "-" + b[4] + b[5] + "-" + b[6] + b[7] + "-" + b[8] + b[9] + "-" + b[10] + b[11] + b[12] + b[13] + b[14] + b[15]
    }

    function tn() {
        return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(a) {
            var b = Math.random() * 16 | 0;
            return a === "y" ? (b & 3 | 8).toString(16) : b.toString(16)
        })
    };

    function un() {
        var a = D.apply(0, arguments);
        vn(function() {
            throw new(Function.prototype.bind.apply(Error, [null, "Could not complete the test successfully - "].concat(A(a))));
        }, function() {
            return console.error.apply(console, A(a))
        })
    }

    function vn(a, b) {
        typeof jasmine !== "undefined" && jasmine ? a() : typeof console !== "undefined" && console && console.error && b()
    };
    var wn = function() {
        if (typeof omidGlobal !== "undefined" && omidGlobal) return omidGlobal;
        if (typeof global !== "undefined" && global) return global;
        if (typeof window !== "undefined" && window) return window;
        if (typeof globalThis !== "undefined" && globalThis) return globalThis;
        var a = Function("return this")();
        if (a) return a;
        throw Error("Could not determine global object context.");
    }();

    function xn(a) {
        this.g = a;
        this.handleExportedMessage = xn.prototype.i.bind(this)
    }
    x(xn, mn);
    xn.prototype.sendMessage = function(a, b) {
        b = b === void 0 ? this.g : b;
        if (!b) throw Error("Message destination must be defined at construction time or when sending the message.");
        b.handleExportedMessage(ln(a), this)
    };
    xn.prototype.i = function(a, b) {
        if (jn(a) && this.onMessage) this.onMessage(kn(a), b)
    };

    function yn(a) {
        return a != null && typeof a.top !== "undefined" && a.top != null
    }

    function zn(a) {
        if (a === wn) return !1;
        try {
            if (typeof a.location.hostname === "undefined") return !0
        } catch (b) {
            return !0
        }
        return !1
    }

    function An() {
        var a;
        typeof a === "undefined" && typeof window !== "undefined" && window && (a = window);
        return yn(a) ? a : wn
    };

    function Bn(a, b) {
        this.g = b = b === void 0 ? wn : b;
        var c = this;
        a.addEventListener("message", function(d) {
            if (typeof d.data === "object") {
                var e = d.data;
                if (jn(e) && d.source && c.onMessage) c.onMessage(kn(e), d.source)
            }
        })
    }
    x(Bn, mn);
    Bn.prototype.sendMessage = function(a, b) {
        b = b === void 0 ? this.g : b;
        if (!b) throw Error("Message destination must be defined at construction time or when sending the message.");
        b.postMessage(ln(a), "*")
    };
    var Cn = ["omid", "v1_VerificationServiceCommunication"],
        Dn = ["omidVerificationProperties", "serviceWindow"];

    function En(a, b) {
        return b.reduce(function(c, d) {
            return c && c[d]
        }, a)
    };

    function Fn(a) {
        if (!a) {
            a = An();
            var b = b === void 0 ? on : b;
            var c = [],
                d = En(a, Dn);
            d && c.push(d);
            c.push(yn(a) ? a.top : wn);
            a: {
                c = y(c);
                for (var e = c.next(); !e.done; e = c.next()) {
                    b: {
                        d = a;e = e.value;
                        var f = b;
                        if (!zn(e)) try {
                            var g = En(e, Cn);
                            if (g) {
                                var h = new xn(g);
                                break b
                            }
                        } catch (k) {}
                        h = f(e) ? new Bn(d, e) : null
                    }
                    if (d = h) {
                        a = d;
                        break a
                    }
                }
                a = null
            }
        }
        if (this.i = a) this.i.onMessage = this.bg.bind(this);
        else if (b = (b = wn.omid3p) && typeof b.registerSessionObserver === "function" && typeof b.addEventListener === "function" ? b : null) this.l = b;
        this.u = this.A = 0;
        this.m = {};
        this.o = [];
        (this.g = (b = wn.omidVerificationProperties) ? b.injectionId : void 0) || (rn() ? sn() : tn())
    }
    n = Fn.prototype;
    n.T = function() {
        var a = An();
        var b = (b = wn.omidVerificationProperties) && b.injectionSource ? b.injectionSource : void 0;
        return (b || pn(a) || pn(yn(a) ? a.top : wn)) !== "web" || this.g ? !(!this.i && !this.l) : !1
    };

    function Gn(a, b, c) {
        cn(b);
        a.l ? a.l.registerSessionObserver(b, c, a.g) : a.Yb("addSessionListener", b, c, a.g)
    }
    n.addEventListener = function(a, b) {
        bn("eventType", a);
        cn(b);
        this.l ? this.l.addEventListener(a, b, this.g) : this.Yb("addEventListener", b, a, this.g)
    };

    function Hn(a, b, c, d) {
        bn("url", b);
        wn.document && wn.document.createElement ? In(a, b, c, d) : a.Yb("sendUrl", function(e) {
            e && c ? c() : !e && d && d()
        }, b)
    }

    function In(a, b, c, d) {
        function e(g) {
            var h = a.o.indexOf(f);
            h >= 0 && a.o.splice(h, 1);
            g && g()
        }
        var f = wn.document.createElement("img");
        a.o.push(f);
        f.addEventListener("load", e.bind(a, c));
        f.addEventListener("error", e.bind(a, d));
        f.src = b
    }
    n.setTimeout = function(a, b) {
        cn(a);
        dn("timeInMillis", b);
        if (Jn()) return wn.setTimeout(a, b);
        var c = this.A++;
        this.Yb("setTimeout", a, c, b);
        return c
    };
    n.clearTimeout = function(a) {
        dn("timeoutId", a);
        Jn() ? wn.clearTimeout(a) : this.ff("clearTimeout", a)
    };
    n.setInterval = function(a, b) {
        cn(a);
        dn("timeInMillis", b);
        if (Kn()) return wn.setInterval(a, b);
        var c = this.u++;
        this.Yb("setInterval", a, c, b);
        return c
    };
    n.clearInterval = function(a) {
        dn("intervalId", a);
        Kn() ? wn.clearInterval(a) : this.ff("clearInterval", a)
    };

    function Jn() {
        return typeof wn.setTimeout === "function" && typeof wn.clearTimeout === "function"
    }

    function Kn() {
        return typeof wn.setInterval === "function" && typeof wn.clearInterval === "function"
    }
    n.bg = function(a) {
        var b = a.method,
            c = a.g;
        a = a.args;
        if (b === "response" && this.m[c]) {
            var d = en() && fn() ? a ? a : [] : a && typeof a === "string" ? JSON.parse(a) : [];
            this.m[c].apply(this, d)
        }
        b === "error" && window.console && un(a)
    };
    n.ff = function(a) {
        this.Yb.apply(this, [a, null].concat(A(D.apply(1, arguments))))
    };
    n.Yb = function(a, b) {
        var c = D.apply(2, arguments);
        if (this.i) {
            var d = rn() ? sn() : tn();
            b && (this.m[d] = b);
            var e = "VerificationService." + a;
            c = en() && fn() ? c : JSON.stringify(c);
            this.i.sendMessage(new hn(d, e, "1.6.5-google_20260406", c))
        }
    };
    var Ln = void 0;
    if (Ln = Ln === void 0 ? typeof omidExports === "undefined" ? null : omidExports : Ln) {
        var Mn = ["OmidVerificationClient"];
        Mn.slice(0, Mn.length - 1).reduce(qn, Ln)[Mn[Mn.length - 1]] = Fn
    };
    Fn.Ab = void 0;
    Fn.g = function() {
        return Fn.Ab ? Fn.Ab : Fn.Ab = new Fn
    };
    var Nn = {},
        On = (Nn.notFound = !0, Nn.hidden = !0, Nn.backgrounded = !0, Nn.noOutputDevice = !0, Nn);

    function Pn() {
        Yj.call(this, G, 2, "omid");
        this.Xa = Fn.g();
        this.jc = Fn.g().T();
        this.D = [];
        this.H = this.ba = this.V = this.A = this.R = this.M = this.ra = this.l = this.Nc = this.Ga = void 0;
        this.kc = "normal";
        this.lc = this.hc = !1;
        this.ta = void 0;
        this.Va = !1;
        this.Jb = this.Ua = void 0
    }
    x(Pn, Yj);

    function Qn(a) {
        a.Xa.addEventListener("geometryChange", function(b) {
            Rn(397, function() {
                return Sn(a, b)
            })
        })
    }

    function Tn(a) {
        function b(c) {
            Rn(399, function() {
                return Un(a, c)
            })
        }
        Sa("loaded start firstQuartile midpoint thirdQuartile complete pause resume bufferStart bufferFinish skipped volumeChange playerStateChange adUserInteraction impression".split(" "), function(c) {
            a.Xa.addEventListener(c, b)
        })
    }

    function Vn(a) {
        Gn(a.Xa, function(b) {
            Rn(398, function() {
                return Wn(a, b)
            })
        }, "doubleclickbygoogle.com")
    }

    function Sn(a, b) {
        Xn(b, function(c, d, e, f) {
            a.H !== c && (c = Error("Received geometry event from a different session. Expected session id: " + (a.H + ", Received session id: ") + (c + ". Creative type: ") + (a.M + ", Omid partner: ") + (a.A + ", App info: ") + JSON.stringify(a.l)), Cj(1071, c));
            e = f.viewport;
            c = Wj().l;
            d = Wj().g;
            e != null && e.width != null && e.height != null && (c = (new Hc(e.width, e.height)).floor(), d = (new I(0, e.width, e.height, 0)).floor());
            var g = f.adView,
                h = g.geometry,
                k = g.onScreenGeometry;
            f = new I(0, 0, 0, 0);
            e = new I(0, 0, 0, 0);
            var l = null;
            Yn(k) && Yn(h) && (f = (new I(k.y, k.x + k.width, k.y + k.height, k.x)).floor(), e = (new I(h.y, h.x + h.width, h.y + h.height, h.x)).floor(), $i(L().flags, Lm) ? l = g.percentageInView / 100 : h.width > 0 && h.height > 0 && (l = k.width * k.height / (h.width * h.height)));
            a.D = g.reasons || [];
            (g = !Xa(a.D, function(m) {
                return On[m]
            })) && l !== null && l > 0 && (a.lc = !0, a.hc && (L().l = !0));
            h = a.D.includes("noOutputDevice");
            a.Va = a.Va || h;
            Zn(a, c, d, e, f, l, g, a.i.volume, h)
        })
    }

    function Un(a, b) {
        Xn(b, function(c, d, e, f) {
            if (e === "impression") a.hc = !0, a.lc && (L().l = !0);
            else {
                d = a.i.volume;
                c = !1;
                if (Ra(["start", "volumeChange"], e) >= 0) {
                    d = typeof(f == null ? void 0 : f.deviceVolume) === "number" ? f == null ? void 0 : f.deviceVolume : a.R && a.R == "web" ? 1 : null;
                    var g = typeof(f == null ? void 0 : f.mediaPlayerVolume) === "number" ? f == null ? void 0 : f.mediaPlayerVolume : typeof f.videoPlayerVolume === "number" ? f == null ? void 0 : f.videoPlayerVolume : null;
                    d = typeof d === "number" && typeof g === "number" ? d * g : null;
                    d != null && (a.i.volume = d, c = !0)
                }
                e == "playerStateChange" && f.state != null && (a.kc = f.state, c = !0);
                g = Wj();
                c && Zn(a, g.l, g.g, g.i, a.i.g, a.i.i, a.i.l, d, null)
            }
            if (e == "impression" || e == "loaded") f.creativeType ? a.M = f.creativeType : f.mediaType && (a.M = f.mediaType == "video" ? "video" : a.ba == "native" ? "nativeDisplay" : "htmlDisplay")
        })
    }

    function Wn(a, b) {
        Xn(b, function(c, d, e, f) {
            e == "sessionStart" && f.context && (a.Nc = f.verificationParameters, a.l = f.context.app, a.ba = f.context.adSessionType, a.ra = f.context.accessMode, a.R = f.context.environment, a.ta = f.context.deviceCategory, f.context.omidNativeInfo && f.context.omidNativeInfo.partnerName ? a.A = f.context.omidNativeInfo.partnerName : f.context.omidJsInfo && f.context.omidJsInfo.partnerName && (a.A = f.context.omidJsInfo.partnerName), f.context.omidNativeInfo && f.context.omidNativeInfo.partnerVersion ? a.V = f.context.omidNativeInfo.partnerVersion : f.context.omidJsInfo && f.context.omidJsInfo.partnerVersion && (a.V = f.context.omidJsInfo.partnerVersion));
            ["sessionStart", "sessionError"].includes(e);
            e == "sessionFinish" && typeof a.Ga === "function" && a.Ga();
            a.H === void 0 ? a.H = c : a.H !== c && Cj(1072, Error("Received session event from a different session. Expected session id: " + (a.H + ", Received session id: ") + (c + ".  partner: ") + a.A + (" partner version: " + a.V)));
            e == "sessionStart" && f.lastActivity && f.lastActivity.timestamp && typeof f.lastActivity.timestamp === "number" && (a.Ua = f.lastActivity.timestamp, a.Jb = Math.round((d - a.Ua) / 1E3))
        })
    }

    function Yn(a) {
        return a != null && Ya(function(b) {
            return a.hasOwnProperty(b)
        })
    }

    function Xn(a, b) {
        a != null && a.adSessionId != null && a.timestamp != null && a.type != null ? b(a.adSessionId, a.timestamp, a.type, a.data || {}) : (a = Error("OMSDK event missing some data: " + JSON.stringify(a)), Cj(543, a))
    }

    function Rn(a, b) {
        try {
            b.apply()
        } catch (c) {
            Cj(a, c)
        }
    }

    function Zn(a, b, c, d, e, f, g, h, k) {
        var l = Md(cl);
        if (l.l !== g) {
            l.l = g;
            l = y(l.i);
            for (var m = l.next(); !m.done; m = l.next()) m = m.value, m(null)
        }
        k !== null && Md(cl);
        a.kc != "minimized" && g || (e = new I(0, 0, 0, 0));
        k = Wj();
        e = e || new I(0, 0, 0, 0);
        l = ck(a);
        k.l = b;
        k.g = c;
        k.i = d;
        l.g = e;
        l.i = f;
        l.l = g;
        l.volume = h;
        a.Qa(l)
    }
    n = Pn.prototype;
    n.qd = function() {};
    n.rd = function() {};
    n.se = function() {};
    n.te = function() {};
    n.Jc = function() {
        var a = L();
        return a.Ia === 6 || a.Ia === 5 ? this.Ta() : Mb(a.g, "omid") == 1 && this.Ta()
    };
    n.Ta = function() {
        return this.jc
    };
    n.Kd = function() {
        var a = {},
            b = L();
        this.Ta() && Mb(b.g, "sloi") && (Ma(this.D) && this.D.length > 0 && (a.omidr = Va(eb(this.D, 0, 5), function(c) {
            return String(c).slice(0, 2)
        }).join(",")), this.l && (this.l.libraryVersion && (a.omidv = this.l.libraryVersion), this.l.appId && (a.omida = this.l.appId)), this.A && (a.omidp = this.A), this.ba && (a.omids = this.ba.charAt(0)), this.V && (a.omidpv = this.V.substring(0, 30)), this.ra && (a.omidam = this.ra.charAt(0)), this.M && (a.omidct = this.M.charAt(0)), this.R && (a.omidia = this.R == "app" ? 1 : 0), this.ta && (a.omiddc = this.ta), this.Va && (a.nopd = 1), this.Ua && (a.omiddit = this.Jb));
        return a
    };
    n.dc = function() {
        var a = this;
        if (this.Y || !this.jc) return !this.Qb();
        this.Y = !0;
        Rn(391, function() {
            return Vn(a)
        });
        Rn(390, function() {
            return Qn(a)
        });
        Rn(392, function() {
            return Tn(a)
        });
        return !0
    };

    function $n(a) {
        hk.call(this, Md(Pn));
        Md(Pn).Ga = a
    }
    x($n, hk);
    n = $n.prototype;
    n.sa = function() {
        return "omid"
    };
    n.Ee = function(a, b, c) {
        return new an(this.g, b, c)
    };
    n.sd = function() {
        return this.g.Ta()
    };
    n.td = function() {
        return this.g.Jc()
    };
    n.init = function() {
        this.g.dc();
        return !0
    };
    n.dispose = function() {
        this.g.dispose();
        hk.prototype.dispose.call(this)
    };

    function ao() {
        Yj.call(this, G, 2, "mraid");
        this.M = 0;
        this.D = this.H = !1;
        this.A = null;
        this.l = Mj(this.m);
        this.i.g = new I(0, 0, 0, 0);
        this.R = !1
    }
    x(ao, Yj);
    n = ao.prototype;
    n.Ta = function() {
        return this.l.Ea != null
    };
    n.Kd = function() {
        var a = {};
        this.M && (a.mraid = this.M);
        this.H && (a.mlc = 1);
        a.mtop = this.l.Sa;
        this.A && (a.mse = this.A);
        this.R && (a.msc = 1);
        a.mcp = this.l.Na;
        return a
    };
    n.hb = function(a) {
        var b = D.apply(1, arguments);
        try {
            return this.l.Ea[a].apply(this.l.Ea, b)
        } catch (c) {
            Cj(538, c, .01, function(d) {
                d.method = a
            })
        }
    };

    function bo(a, b, c) {
        a.hb("addEventListener", b, c)
    }
    n.dc = function() {
        var a = this;
        if (this.Y) return !this.Qb();
        this.Y = !0;
        if (this.l.Na === 2) return this.A = "ng", this.fail("w"), !1;
        if (this.l.Na === 1) return this.A = "mm", this.fail("w"), !1;
        Wj().D = !0;
        this.m.document.readyState && this.m.document.readyState == "complete" ? co(this) : Mk(this.m, "load", function() {
            Rd().setTimeout(Bj(292, function() {
                return co(a)
            }), 100)
        }, 292);
        return !0
    };

    function co(a) {
        L().m = !!a.hb("isViewable");
        bo(a, "viewableChange", eo);
        a.hb("getState") === "loading" ? bo(a, "ready", fo) : go(a)
    }

    function go(a) {
        typeof a.l.Ea.AFMA_LIDAR === "string" ? (a.H = !0, ho(a)) : (a.l.Na = 3, a.A = "nc", a.fail("w"))
    }

    function ho(a) {
        a.D = !1;
        var b = Mb(L().g, "rmmt") == 1,
            c = !!a.hb("isViewable");
        (b ? !c : 1) && Rd().setTimeout(Bj(524, function() {
            a.D || (io(a), Cj(540, Error()), a.A = "mt", a.fail("w"))
        }), 500);
        jo(a);
        bo(a, a.l.Ea.AFMA_LIDAR, ko)
    }

    function jo(a) {
        var b = Mb(L().g, "sneio") == 1,
            c = a.l.Ea.AFMA_LIDAR_EXP_1 !== void 0,
            d = a.l.Ea.AFMA_LIDAR_EXP_2 !== void 0;
        (b = b && d) && (a.l.Ea.AFMA_LIDAR_EXP_2 = !0);
        c && (a.l.Ea.AFMA_LIDAR_EXP_1 = !b)
    }

    function io(a) {
        a.hb("removeEventListener", a.l.Ea.AFMA_LIDAR, ko);
        a.H = !1
    }
    n.qd = function() {
        var a = Wj(),
            b = lo(this, "getMaxSize");
        a.g = new I(0, b.width, b.height, 0)
    };
    n.rd = function() {
        Wj().l = lo(this, "getScreenSize")
    };

    function lo(a, b) {
        if (a.hb("getState") === "loading") return new Hc(-1, -1);
        b = a.hb(b);
        if (!b) return new Hc(-1, -1);
        a = parseInt(b.width, 10);
        b = parseInt(b.height, 10);
        return isNaN(a) || isNaN(b) ? new Hc(-1, -1) : new Hc(a, b)
    }
    n.dispose = function() {
        io(this);
        Yj.prototype.dispose.call(this)
    };

    function fo() {
        try {
            var a = Md(ao);
            a.hb("removeEventListener", "ready", fo);
            go(a)
        } catch (b) {
            Cj(541, b)
        }
    }

    function ko(a, b) {
        try {
            var c = Md(ao);
            c.D = !0;
            var d = a ? new I(a.y, a.x + a.width, a.y + a.height, a.x) : new I(0, 0, 0, 0);
            var e = ck(c);
            e.g = d;
            e.volume = b;
            c.Qa(e)
        } catch (f) {
            Cj(542, f)
        }
    }

    function eo(a) {
        var b = L(),
            c = Md(ao);
        a && !b.m && (b.m = !0, c.R = !0, c.A && c.fail("w", !0))
    };

    function mo() {
        um.call(this)
    }
    x(mo, um);
    n = mo.prototype;
    n.sg = function() {
        var a = this;
        if (G.__google_lidar_) {
            if (G.__google_lidar_ += 1, G.__google_lidar_adblocks_count_) {
                var b = G.__google_lidar_radf_;
                b && typeof b === "function" && b()
            }
        } else {
            G.__google_lidar_ = 1;
            wm(this);
            b = L();
            b.Ia = 2;
            b = b.i.g;
            G.__google_lidar_radf_ = Xi(b, function() {
                return a.Fg.apply(a, A(D.apply(0, arguments)))
            });
            var c = G.document.readyState;
            c && c === "complete" ? this.Vd() : (od(G, "load", Xi(b, function() {
                Rd().setTimeout(Bj(172, function() {
                    return a.cg.apply(a, A(D.apply(0, arguments)))
                }), 100)
            })), Mk(G, "DOMContentLoaded", function() {
                return a.Vd.apply(a, A(D.apply(0, arguments)))
            }, 173))
        }
    };
    n.cg = function() {
        var a = this;
        Sa(Dl.g, function(b) {
            return Am(a, b)
        });
        this.Vd()
    };
    n.Vd = function() {
        var a = Hj(),
            b = this.Zc();
        if (b.length)
            if (this.g) try {
                Cm(this, a, b)
            } catch (c) {} else Bm(this)
    };

    function Dm(a) {
        return Mb(a, "omid") == 1 ? [new $n(function() {
            return xm("u")
        })] : [new Il([Md(ao)])]
    }
    n.Fg = function() {
        var a = this.Zc();
        if (a.length) try {
            var b = Hj(),
                c = Cm(this, b, a);
            Sa(c, function(d) {
                d.Ge = !0
            })
        } catch (d) {}
    };
    n.Zc = function() {
        return kb(Va(Lj, function(a) {
            a = document.querySelectorAll("." + a);
            return db(a)
        }))
    };

    function no() {
        this.le = 0
    }
    no.prototype.bc = function(a, b) {
        var c = this;
        return function() {
            var d = D.apply(0, arguments);
            c.le = a;
            return b.apply(null, A(d))
        }
    };

    function oo() {
        var a = {};
        this.La = (a[3] = [], a[2] = [], a[1] = [], a);
        this.Sd = !1
    }

    function po(a, b, c) {
        var d = qo(a, c);
        a.La[c].push(b);
        d && a.La[c].length === 1 && a.flush()
    }

    function qo(a, b) {
        return Object.keys(a.La).map(function(c) {
            return Number(c)
        }).filter(function(c) {
            return !isNaN(c) && c > b
        }).every(function(c) {
            return a.La[c].length === 0
        })
    }
    oo.prototype.flush = function() {
        if (!this.Sd) {
            this.Sd = !0;
            try {
                for (; Object.values(this.La).some(function(a) {
                        return a.length > 0
                    });) ro(this, 3), ro(this, 2), ro(this, 1)
            } catch (a) {
                throw Object.values(this.La).forEach(function(b) {
                    return void b.splice(0, b.length)
                }), a;
            } finally {
                this.Sd = !1
            }
        }
    };

    function ro(a, b) {
        for (; qo(a, b) && a.La[b].length > 0;) a.La[b][0](), a.La[b].shift()
    }
    ea.Object.defineProperties(oo.prototype, {
        Kg: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return Object.values(this.La).some(function(a) {
                    return a.length > 0
                })
            }
        }
    });

    function so() {
        this.g = new Map
    }

    function to(a, b) {
        var c = a.g.get(b);
        if (c) return c;
        var d;
        c = (d = b.description) != null ? d : Math.floor(Math.random() * 2147483648).toString(36) + Math.abs(Math.floor(Math.random() * 2147483648) ^ Date.now()).toString(36);
        a.g.set(b, c);
        return c
    };
    /* 
     
     
     Copyright (c) 2015-2018 Google, Inc., Netflix, Inc., Microsoft Corp. and contributors 
     Licensed under the Apache License, Version 2.0 (the "License"); 
     you may not use this file except in compliance with the License. 
     You may obtain a copy of the License at 
         http://www.apache.org/licenses/LICENSE-2.0 
     Unless required by applicable law or agreed to in writing, software 
     distributed under the License is distributed on an "AS IS" BASIS, 
     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
     See the License for the specific language governing permissions and 
     limitations under the License. 
    */
    function uo(a) {
        var b = Error.call(this, a ? a.length + " errors occurred during unsubscription:\n" + a.map(function(c, d) {
            return d + 1 + ") " + c.toString()
        }).join("\n  ") : "");
        this.message = b.message;
        "stack" in b && (this.stack = b.stack);
        this.errors = a;
        Object.setPrototypeOf(this, this.constructor.prototype);
        this.name = "UnsubscriptionError"
    }
    x(uo, Error);

    function vo(a, b) {
        a && (b = a.indexOf(b), 0 <= b && a.splice(b, 1))
    };

    function M(a) {
        return typeof a === "function"
    };

    function wo(a) {
        this.o = a;
        this.closed = !1;
        this.l = this.i = null
    }
    n = wo.prototype;
    n.unsubscribe = function() {
        if (!this.closed) {
            this.closed = !0;
            var a = this.i;
            if (Array.isArray(a))
                for (var b = y(a), c = b.next(); !c.done; c = b.next()) c.value.remove(this);
            else a == null || a.remove(this);
            b = this.o;
            if (M(b)) try {
                b()
            } catch (f) {
                var d = f instanceof uo ? f.errors : [f]
            }
            var e = this.l;
            if (e)
                for (this.l = null, b = y(e), c = b.next(); !c.done; c = b.next()) {
                    c = c.value;
                    try {
                        M(c) ? c() : c.unsubscribe()
                    } catch (f) {
                        c = void 0, d = (c = d) != null ? c : [], f instanceof uo ? d = [].concat(A(d), A(f.errors)) : d.push(f)
                    }
                }
            if (d) throw new uo(d);
        }
    };
    n.add = function(a) {
        if (a && a !== this)
            if (this.closed) M(a) ? a() : a.unsubscribe();
            else {
                if (a instanceof wo) {
                    if (a.closed || a.Af(this)) return;
                    a.zf(this)
                }
                var b;
                (this.l = (b = this.l) != null ? b : []).push(a)
            }
    };
    n.Af = function(a) {
        var b = this.i;
        return b === a || Array.isArray(b) && b.includes(a)
    };
    n.zf = function(a) {
        var b = this.i;
        this.i = Array.isArray(b) ? (b.push(a), b) : b ? [b, a] : a
    };
    n.Bf = function(a) {
        var b = this.i;
        b === a ? this.i = null : Array.isArray(b) && vo(b, a)
    };
    n.remove = function(a) {
        var b = this.l;
        b && vo(b, a);
        a instanceof wo && a.Bf(this)
    };
    var xo = new wo;
    xo.closed = !0;
    wo.g = xo;

    function yo(a) {
        return a instanceof wo || a && "closed" in a && M(a.remove) && M(a.add) && M(a.unsubscribe)
    };

    function zo() {
        setTimeout.apply(null, A(D.apply(0, arguments)))
    };

    function Ao() {};

    function Bo(a) {
        zo(function() {
            throw a;
        })
    };

    function Co(a) {
        wo.call(this);
        this.g = !1;
        this.destination = a instanceof Co ? a : new Do(!a || M(a) ? {
            next: a != null ? a : void 0
        } : a);
        yo(a) && a.add(this)
    }
    x(Co, wo);
    Co.g = wo.g;
    Co.create = function(a, b, c) {
        return new Eo(a, b, c)
    };
    n = Co.prototype;
    n.next = function(a) {
        this.g || this.vd(a)
    };
    n.error = function(a) {
        this.g || (this.g = !0, this.we(a))
    };
    n.complete = function() {
        this.g || (this.g = !0, this.Lc())
    };
    n.unsubscribe = function() {
        this.closed || (this.g = !0, wo.prototype.unsubscribe.call(this))
    };
    n.vd = function(a) {
        this.destination.next(a)
    };
    n.we = function(a) {
        this.destination.error(a);
        this.unsubscribe()
    };
    n.Lc = function() {
        this.destination.complete();
        this.unsubscribe()
    };

    function Do(a) {
        this.g = a
    }
    Do.prototype.next = function(a) {
        var b = this.g;
        if (b.next) try {
            b.next(a)
        } catch (c) {
            Bo(c)
        }
    };
    Do.prototype.error = function(a) {
        var b = this.g;
        if (b.error) try {
            b.error(a)
        } catch (c) {
            Bo(c)
        } else Bo(a)
    };
    Do.prototype.complete = function() {
        var a = this.g;
        if (a.complete) try {
            a.complete()
        } catch (b) {
            Bo(b)
        }
    };

    function Eo(a, b, c) {
        Co.call(this);
        var d;
        M(a) || !a ? d = {
            next: a != null ? a : void 0,
            error: b != null ? b : void 0,
            complete: c != null ? c : void 0
        } : d = a;
        this.destination = new Do(d)
    }
    x(Eo, Co);
    Eo.g = Co.g;
    Eo.create = Co.create;
    var Fo = typeof Symbol === "function" && Symbol.observable || "@@observable";

    function Go(a) {
        return a
    };

    function N() {
        return Ho(D.apply(0, arguments))
    }

    function Ho(a) {
        return a.length === 0 ? Go : a.length === 1 ? a[0] : function(b) {
            return a.reduce(function(c, d) {
                return d(c)
            }, b)
        }
    };

    function O(a) {
        a && (this.Ma = a)
    }
    n = O.prototype;
    n.Db = function(a) {
        var b = new O;
        b.source = this;
        b.u = a;
        return b
    };
    n.subscribe = function(a, b, c) {
        a = a && a instanceof Co || a && M(a.next) && M(a.error) && M(a.complete) && yo(a) ? a : new Eo(a, b, c);
        b = this.u;
        c = this.source;
        a.add(b ? b.call(a, c) : c ? this.Ma(a) : this.wd(a));
        return a
    };
    n.wd = function(a) {
        try {
            return this.Ma(a)
        } catch (b) {
            a.error(b)
        }
    };
    n.forEach = function(a, b) {
        var c = this;
        b = Io(b);
        return new b(function(d, e) {
            var f = c.subscribe(function(g) {
                try {
                    a(g)
                } catch (h) {
                    e(h), f == null || f.unsubscribe()
                }
            }, e, d)
        })
    };
    n.Ma = function(a) {
        var b;
        return (b = this.source) == null ? void 0 : b.subscribe(a)
    };
    O.prototype[Fo] = function() {
        return this
    };
    O.prototype.j = function() {
        var a = D.apply(0, arguments);
        return a.length ? Ho(a)(this) : this
    };
    O.create = function(a) {
        return new O(a)
    };

    function Io(a) {
        var b;
        return (b = a != null ? a : void 0) != null ? b : Promise
    };

    function Jo() {
        var a = Error.call(this, "object unsubscribed");
        this.message = a.message;
        "stack" in a && (this.stack = a.stack);
        Object.setPrototypeOf(this, this.constructor.prototype);
        this.name = "ObjectUnsubscribedError"
    }
    x(Jo, Error);

    function Q() {
        this.i = [];
        this.l = this.g = this.closed = !1;
        this.o = null
    }
    x(Q, O);
    n = Q.prototype;
    n.Db = function(a) {
        var b = new Ko(this, this);
        b.u = a;
        return b
    };
    n.nb = function() {
        if (this.closed) throw new Jo;
    };
    n.next = function(a) {
        this.nb();
        if (!this.g) {
            var b = this.i.slice();
            b = y(b);
            for (var c = b.next(); !c.done; c = b.next()) c.value.next(a)
        }
    };
    n.error = function(a) {
        this.nb();
        if (!this.g) {
            this.l = this.g = !0;
            this.o = a;
            for (var b = this.i; b.length;) b.shift().error(a)
        }
    };
    n.complete = function() {
        this.nb();
        if (!this.g) {
            this.g = !0;
            for (var a = this.i; a.length;) a.shift().complete()
        }
    };
    n.unsubscribe = function() {
        this.g = this.closed = !0;
        this.i = null
    };
    n.wd = function(a) {
        this.nb();
        return O.prototype.wd.call(this, a)
    };
    n.Ma = function(a) {
        this.nb();
        this.ve(a);
        return this.ye(a)
    };
    n.ye = function(a) {
        var b = this,
            c = this.g,
            d = this.i;
        return this.l || c ? wo.g : (d.push(a), new wo(function() {
            return vo(b.i, a)
        }))
    };
    n.ve = function(a) {
        var b = this.o,
            c = this.g;
        this.l ? a.error(b) : c && a.complete()
    };
    Q.create = function(a, b) {
        return new Ko(a, b)
    };

    function Ko(a, b) {
        Q.call(this);
        this.destination = a;
        this.source = b
    }
    x(Ko, Q);
    Ko.create = Q.create;
    Ko.prototype.next = function(a) {
        var b, c;
        (b = this.destination) == null || (c = b.next) == null || c.call(b, a)
    };
    Ko.prototype.error = function(a) {
        var b, c;
        (b = this.destination) == null || (c = b.error) == null || c.call(b, a)
    };
    Ko.prototype.complete = function() {
        var a, b;
        (a = this.destination) == null || (b = a.complete) == null || b.call(a)
    };
    Ko.prototype.Ma = function(a) {
        var b, c;
        return (c = (b = this.source) == null ? void 0 : b.subscribe(a)) != null ? c : wo.g
    };

    function Lo(a) {
        Q.call(this);
        this.m = a
    }
    x(Lo, Q);
    Lo.create = Q.create;
    Lo.prototype.Ma = function(a) {
        var b = Q.prototype.Ma.call(this, a);
        !b.closed && a.next(this.m);
        return b
    };
    Lo.prototype.next = function(a) {
        Q.prototype.next.call(this, this.m = a)
    };
    ea.Object.defineProperties(Lo.prototype, {
        value: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                var a = this.o,
                    b = this.m;
                if (this.l) throw a;
                this.nb();
                return b
            }
        }
    });
    var Mo = new O(function(a) {
        return a.complete()
    });

    function No(a, b) {
        return new O(function(c) {
            var d = 0;
            return b.K(function() {
                d === a.length ? c.complete() : (c.next(a[d++]), c.closed || this.K())
            })
        })
    };

    function Oo(a, b) {
        if (!a) throw Error("Iterable cannot be null");
        return new O(function(c) {
            var d = new wo;
            d.add(b.K(function() {
                var e = a[Symbol.asyncIterator]();
                d.add(b.K(function() {
                    var f = this;
                    e.next().then(function(g) {
                        g.done ? c.complete() : (c.next(g.value), f.K())
                    })
                }))
            }));
            return d
        })
    };
    var Po = typeof Symbol === "function" && Symbol.iterator ? Symbol.iterator : "@@iterator";

    function Qo(a, b, c) {
        b = b.K(function() {
            try {
                c.call(this)
            } catch (d) {
                a.error(d)
            }
        }, 0);
        a.add(b)
    };

    function Ro(a, b) {
        return new O(function(c) {
            var d;
            c.add(b.K(function() {
                d = a[Po]();
                Qo(c, b, function() {
                    var e = d.next(),
                        f = e.value;
                    e.done ? c.complete() : (c.next(f), this.K())
                })
            }));
            return function() {
                var e;
                return M((e = d) == null ? void 0 : e.return) && d.return()
            }
        })
    };

    function So(a, b) {
        return new O(function(c) {
            var d = new wo;
            d.add(b.K(function() {
                var e = a[Fo]();
                d.add(e.subscribe({
                    next: function(f) {
                        d.add(b.K(function() {
                            return c.next(f)
                        }))
                    },
                    error: function(f) {
                        d.add(b.K(function() {
                            return c.error(f)
                        }))
                    },
                    complete: function() {
                        d.add(b.K(function() {
                            return c.complete()
                        }))
                    }
                }))
            }));
            return d
        })
    };

    function To(a, b) {
        return new O(function(c) {
            return b.K(function() {
                return a.then(function(d) {
                    c.add(b.K(function() {
                        c.next(d);
                        c.add(b.K(function() {
                            return c.complete()
                        }))
                    }))
                }, function(d) {
                    c.add(b.K(function() {
                        return c.error(d)
                    }))
                })
            })
        })
    };

    function Uo(a) {
        return a && typeof a.length === "number" && typeof a !== "function"
    };

    function Vo(a) {
        return new TypeError("You provided " + (a !== null && typeof a === "object" ? "an invalid object" : "'" + a + "'") + " where a stream was expected. You can provide an Observable, Promise, Array, AsyncIterable, or Iterable.")
    };

    function Wo(a, b) {
        if (a != null) {
            if (M(a[Fo])) return So(a, b);
            if (Uo(a)) return No(a, b);
            if (M(a == null ? void 0 : a.then)) return To(a, b);
            if (Symbol.asyncIterator && M(a == null ? void 0 : a[Symbol.asyncIterator])) return Oo(a, b);
            if (M(a == null ? void 0 : a[Po])) return Ro(a, b)
        }
        throw Vo(a);
    };

    function Xo(a, b) {
        return b ? Wo(a, b) : Yo(a)
    }

    function Yo(a) {
        if (a instanceof O) return a;
        if (a != null) {
            if (M(a[Fo])) return Zo(a);
            if (Uo(a)) return $o(a);
            if (M(a == null ? void 0 : a.then)) return ap(a);
            if (Symbol.asyncIterator && M(a == null ? void 0 : a[Symbol.asyncIterator])) return bp(a);
            if (M(a == null ? void 0 : a[Po])) return cp(a)
        }
        throw Vo(a);
    }

    function Zo(a) {
        return new O(function(b) {
            var c = a[Fo]();
            if (M(c.subscribe)) return c.subscribe(b);
            throw new TypeError("Provided object does not correctly implement Symbol.observable");
        })
    }

    function $o(a) {
        return new O(function(b) {
            for (var c = 0; c < a.length && !b.closed; c++) b.next(a[c]);
            b.complete()
        })
    }

    function ap(a) {
        return new O(function(b) {
            a.then(function(c) {
                b.closed || (b.next(c), b.complete())
            }, function(c) {
                return b.error(c)
            }).then(null, Bo)
        })
    }

    function cp(a) {
        return new O(function(b) {
            for (var c = a[Po](); !b.closed;) {
                var d = c.next(),
                    e = d.value;
                d.done ? b.complete() : b.next(e)
            }
            return function() {
                return M(c == null ? void 0 : c.return) && c.return()
            }
        })
    }

    function bp(a) {
        return new O(function(b) {
            dp(a, b).catch(function(c) {
                return b.error(c)
            })
        })
    }

    function dp(a, b) {
        var c, d, e, f, g, h;
        return Da(function(k) {
            switch (k.i) {
                case 1:
                    k.M(2, 3);
                    var l = a[Symbol.asyncIterator];
                    f = l !== void 0 ? l.call(a) : new Fa(y(a));
                case 5:
                    return k.g(f.next(), 8);
                case 8:
                    d = k.l;
                    if (d.done) {
                        k.ea(3);
                        break
                    }
                    g = d.value;
                    b.next(g);
                    k.ea(5);
                    break;
                case 3:
                    k.Y();
                    k.ta(9);
                    if (!d || d.done || !(e = f.return)) {
                        k.ea(9);
                        break
                    }
                    return k.g(e.call(f), 9);
                case 9:
                    k.Y(0, 0, 1);
                    if (c) throw c.error;
                    k.Z(10, 1);
                    break;
                case 10:
                    k.Z(4);
                    break;
                case 2:
                    h = k.D();
                    c = {
                        error: h
                    };
                    k.ea(3);
                    break;
                case 4:
                    b.complete(), k.H()
            }
        })
    };

    function ep(a, b) {
        return b ? No(a, b) : $o(a)
    };

    function fp(a) {
        return M(a[a.length - 1]) ? a.pop() : void 0
    }

    function gp(a) {
        var b = a[a.length - 1];
        return b && M(b.K) ? a.pop() : void 0
    };

    function hp() {
        var a = D.apply(0, arguments),
            b = gp(a);
        return b ? No(a, b) : ep(a)
    };

    function ip(a) {
        var b = M(a) ? a : function() {
            return a
        };
        return new O(function(c) {
            return c.error(b())
        })
    };
    var jp = {
        now: function() {
            return (jp.Tf || Date).now()
        },
        Tf: void 0
    };

    function kp(a, b, c) {
        a = a === void 0 ? Infinity : a;
        b = b === void 0 ? Infinity : b;
        c = c === void 0 ? jp : c;
        Q.call(this);
        this.A = a;
        this.H = b;
        this.D = c;
        this.buffer = [];
        this.m = b === Infinity;
        this.A = Math.max(1, a);
        this.H = Math.max(1, b)
    }
    x(kp, Q);
    kp.create = Q.create;
    kp.prototype.next = function(a) {
        var b = this.buffer,
            c = this.m,
            d = this.D,
            e = this.H;
        this.g || (b.push(a), !c && b.push(d.now() + e));
        lp(this);
        Q.prototype.next.call(this, a)
    };
    kp.prototype.Ma = function(a) {
        this.nb();
        lp(this);
        for (var b = this.ye(a), c = this.m, d = this.buffer.slice(), e = 0; e < d.length && !a.closed; e += c ? 1 : 2) a.next(d[e]);
        this.ve(a);
        return b
    };

    function lp(a) {
        var b = a.A,
            c = a.D,
            d = a.buffer;
        a = a.m;
        var e = (a ? 1 : 2) * b;
        b < Infinity && e < d.length && d.splice(0, d.length - e);
        if (!a) {
            b = c.now();
            c = 0;
            for (a = 1; a < d.length && d[a] <= b; a += 2) c = a;
            c && d.splice(0, c + 1)
        }
    };

    function mp(a, b) {
        b = b === void 0 ? np : b;
        this.g = a;
        this.now = b
    }
    mp.prototype.K = function(a, b, c) {
        b = b === void 0 ? 0 : b;
        return (new this.g(this, a)).K(c, b)
    };
    var np = jp.now;

    function op() {
        var a = Error.call(this, "no elements in sequence");
        this.message = a.message;
        "stack" in a && (this.stack = a.stack);
        Object.setPrototypeOf(this, this.constructor.prototype);
        this.name = "EmptyError"
    }
    x(op, Error);

    function pp(a) {
        return new Promise(function(b, c) {
            var d = new Eo({
                next: function(e) {
                    b(e);
                    d.unsubscribe()
                },
                error: c,
                complete: function() {
                    c(new op)
                }
            });
            a.subscribe(d)
        })
    };

    function R(a, b, c, d, e) {
        Co.call(this, a);
        this.m = e;
        b && (this.vd = function(f) {
            try {
                b(f)
            } catch (g) {
                this.destination.error(g)
            }
        });
        c && (this.we = function(f) {
            try {
                c(f)
            } catch (g) {
                this.destination.error(g)
            }
            this.unsubscribe()
        });
        d && (this.Lc = function() {
            try {
                d()
            } catch (f) {
                this.destination.error(f)
            }
            this.unsubscribe()
        })
    }
    x(R, Co);
    R.g = Co.g;
    R.create = Co.create;
    R.prototype.unsubscribe = function() {
        var a;
        this.closed || (a = this.m) != null && a.call(this);
        Co.prototype.unsubscribe.call(this)
    };

    function qp(a) {
        return function(b) {
            if (M(b == null ? void 0 : b.Db)) return b.Db(function(c) {
                try {
                    return a(c, this)
                } catch (d) {
                    this.error(d)
                }
            });
            throw new TypeError("Unable to lift unknown Observable type");
        }
    };

    function rp() {
        return qp(function(a, b) {
            var c = null;
            a.Mc++;
            var d = new R(b, void 0, void 0, void 0, function() {
                if (!a || a.Mc <= 0 || 0 < --a.Mc) c = null;
                else {
                    var e = a.Lb,
                        f = c;
                    c = null;
                    !e || f && e !== f || e.unsubscribe();
                    b.unsubscribe()
                }
            });
            a.subscribe(d);
            d.closed || (c = a.connect())
        })
    };

    function sp(a, b) {
        this.source = a;
        this.hf = b;
        this.g = null;
        this.Mc = 0;
        this.Lb = null
    }
    x(sp, O);
    sp.create = O.create;
    sp.prototype.Ma = function(a) {
        return tp(this).subscribe(a)
    };

    function tp(a) {
        var b = a.g;
        if (!b || b.g) a.g = a.hf();
        return a.g
    }
    sp.prototype.i = function() {
        this.Mc = 0;
        var a = this.Lb;
        this.g = this.Lb = null;
        a == null || a.unsubscribe()
    };
    sp.prototype.connect = function() {
        var a = this,
            b = this.Lb;
        if (!b) {
            b = this.Lb = new wo;
            var c = tp(this);
            b.add(this.source.subscribe(new R(c, void 0, function(d) {
                a.i();
                c.error(d)
            }, function() {
                a.i();
                c.complete()
            }, function() {
                return a.i()
            })));
            b.closed && (this.Lb = null, b = wo.g)
        }
        return b
    };

    function up() {
        var a = vp;
        var b = b === void 0 ? 0 : b;
        return qp(function(c, d) {
            d.add(a.K(function() {
                return c.subscribe(d)
            }, b))
        })
    };

    function S(a) {
        return qp(function(b, c) {
            var d = 0;
            b.subscribe(new R(c, function(e) {
                c.next(a.call(void 0, e, d++))
            }))
        })
    };
    var wp = Array.isArray;

    function xp(a) {
        return S(function(b) {
            return wp(b) ? a.apply(null, A(b)) : a(b)
        })
    };
    var yp = Array.isArray,
        zp = Object,
        Ap = zp.getPrototypeOf,
        Bp = zp.prototype,
        Cp = zp.keys;

    function Dp(a) {
        if (a.length === 1) {
            var b = a[0];
            if (yp(b)) return {
                args: b,
                keys: null
            };
            if (b && typeof b === "object" && Ap(b) === Bp) return a = Cp(b), {
                args: a.map(function(c) {
                    return b[c]
                }),
                keys: a
            }
        }
        return {
            args: a,
            keys: null
        }
    };

    function Ep() {
        var a = D.apply(0, arguments),
            b = gp(a),
            c = fp(a);
        a = Dp(a);
        var d = a.args,
            e = a.keys;
        if (d.length === 0) return Xo([], b);
        b = new O(Fp(d, b, e ? function(f) {
            for (var g = {}, h = 0; h < f.length; h++) g[e[h]] = f[h];
            return g
        } : Go));
        return c ? b.j(xp(c)) : b
    }

    function Gp(a, b, c) {
        Co.call(this, a);
        this.vd = b;
        this.m = c
    }
    x(Gp, Co);
    Gp.g = Co.g;
    Gp.create = Co.create;
    Gp.prototype.Lc = function() {
        this.m() ? Co.prototype.Lc.call(this) : this.unsubscribe()
    };

    function Fp(a, b, c) {
        c = c === void 0 ? Go : c;
        return function(d) {
            Hp(b, function() {
                for (var e = a.length, f = Array(e), g = e, h = a.map(function() {
                        return !1
                    }), k = !0, l = {
                        wb: 0
                    }; l.wb < e; l = {
                        wb: l.wb
                    }, l.wb++) Hp(b, function(m) {
                    return function() {
                        Xo(a[m.wb], b).subscribe(new Gp(d, function(q) {
                            f[m.wb] = q;
                            k && (h[m.wb] = !0, k = !h.every(Go));
                            k || d.next(c(f.slice()))
                        }, function() {
                            return --g === 0
                        }))
                    }
                }(l), d)
            }, d)
        }
    }

    function Hp(a, b, c) {
        a ? c.add(a.K(b)) : b()
    };

    function Ip(a, b, c, d) {
        function e(l) {
            g++;
            Yo(c(l, h++)).subscribe(new R(b, function(m) {
                b.next(m)
            }, void 0, function() {
                g--;
                for (var m = {}; f.length && g < d; m = {
                        Ce: void 0
                    }) m.Ce = f.shift(), e(m.Ce);
                !k || f.length || g || b.complete()
            }))
        }
        var f = [],
            g = 0,
            h = 0,
            k = !1;
        a.subscribe(new R(b, function(l) {
            return g < d ? e(l) : f.push(l)
        }, void 0, function() {
            k = !0;
            !k || f.length || g || b.complete()
        }));
        return function() {
            f = null
        }
    };

    function Jp(a, b) {
        var c = c === void 0 ? Infinity : c;
        if (M(b)) return Jp(function(d, e) {
            return S(function(f, g) {
                return b(d, f, e, g)
            })(Yo(a(d, e)))
        }, c);
        typeof b === "number" && (c = b);
        return qp(function(d, e) {
            return Ip(d, e, a, c)
        })
    };

    function Kp(a) {
        a = a === void 0 ? Infinity : a;
        return Jp(Go, a)
    };

    function Lp() {
        var a = D.apply(0, arguments);
        return Kp(1)(ep(a, gp(a)))
    };

    function Mp(a) {
        return new O(function(b) {
            Yo(a()).subscribe(b)
        })
    };
    var Np = ["addListener", "removeListener"],
        Op = ["addEventListener", "removeEventListener"],
        Pp = ["on", "off"];

    function Qp(a, b, c) {
        if (M(c)) {
            var d = c;
            c = void 0
        }
        if (d) return Qp(a, b, c).j(xp(d));
        d = y(M(a.addEventListener) && M(a.removeEventListener) ? Op.map(function(g) {
            return function(h) {
                return a[g](b, h, c)
            }
        }) : M(a.addListener) && M(a.removeListener) ? Np.map(Rp(a, b)) : M(a.Uh) && M(a.Hh) ? Pp.map(Rp(a, b)) : []);
        var e = d.next().value,
            f = d.next().value;
        return !e && Uo(a) ? Jp(function(g) {
            return Qp(g, b, c)
        })(ep(a)) : new O(function(g) {
            function h() {
                var k = D.apply(0, arguments);
                return g.next(1 < k.length ? k : k[0])
            }
            if (!e) throw new TypeError("Invalid event target");
            e(h);
            return function() {
                return f(h)
            }
        })
    }

    function Rp(a, b) {
        return function(c) {
            return function(d) {
                return a[c](b, d)
            }
        }
    };

    function Sp() {
        wo.call(this)
    }
    x(Sp, wo);
    Sp.g = wo.g;
    Sp.prototype.K = function() {
        return this
    };

    function Tp(a, b) {
        return setInterval.apply(null, [a, b].concat(A(D.apply(2, arguments))))
    };

    function Up(a, b) {
        wo.call(this);
        this.g = a;
        this.m = b;
        this.pending = !1
    }
    x(Up, Sp);
    Up.g = Sp.g;
    n = Up.prototype;
    n.K = function(a, b) {
        b = b === void 0 ? 0 : b;
        if (this.closed) return this;
        this.state = a;
        a = this.id;
        var c = this.g;
        a != null && (this.id = Vp(this, a, b));
        this.pending = !0;
        this.delay = b;
        this.id = this.id || this.be(c, this.id, b);
        return this
    };
    n.be = function(a, b, c) {
        c = c === void 0 ? 0 : c;
        return Tp(a.flush.bind(a, this), c)
    };

    function Vp(a, b, c) {
        c = c === void 0 ? 0 : c;
        if (c != null && a.delay === c && a.pending === !1) return b;
        clearInterval(b)
    }
    n.execute = function(a, b) {
        if (this.closed) return Error("executing a cancelled action");
        this.pending = !1;
        if (a = this.xe(a, b)) return a;
        this.pending === !1 && this.id != null && (this.id = Vp(this, this.id, null))
    };
    n.xe = function(a) {
        var b = !1;
        try {
            this.m(a)
        } catch (d) {
            b = !0;
            var c = !!d && d || Error(d)
        }
        if (b) return this.unsubscribe(), c
    };
    n.unsubscribe = function() {
        if (!this.closed) {
            var a = this.id,
                b = this.g.actions;
            this.m = this.state = this.g = null;
            this.pending = !1;
            vo(b, this);
            a != null && (this.id = Vp(this, a, null));
            this.delay = null;
            Sp.prototype.unsubscribe.call(this)
        }
    };

    function Wp(a, b) {
        b = b === void 0 ? np : b;
        mp.call(this, a, b);
        this.actions = [];
        this.active = !1
    }
    x(Wp, mp);
    Wp.prototype.flush = function(a) {
        var b = this.actions;
        if (this.active) b.push(a);
        else {
            var c;
            this.active = !0;
            do
                if (c = a.execute(a.state, a.delay)) break; while (a = b.shift());
            this.active = !1;
            if (c) {
                for (; a = b.shift();) a.unsubscribe();
                throw c;
            }
        }
    };

    function Xp() {
        var a = D.apply(0, arguments),
            b = gp(a);
        var c = typeof a[a.length - 1] === "number" ? a.pop() : Infinity;
        return a.length ? a.length === 1 ? Yo(a[0]) : Kp(c)(ep(a, b)) : Mo
    };
    var Yp = new O(Ao);
    var Zp = Array.isArray;

    function $p(a) {
        return a.length === 1 && Zp(a[0]) ? a[0] : a
    };

    function aq() {
        var a = $p(D.apply(0, arguments));
        return qp(function(b, c) {
            function d() {
                if (!c.closed)
                    if (e.length > 0) {
                        try {
                            var f = Yo(e.shift())
                        } catch (h) {
                            d();
                            return
                        }
                        var g = new R(c, void 0, Ao, Ao);
                        c.add(f.subscribe(g));
                        g.add(d)
                    } else c.complete()
            }
            var e = [b].concat(A(a));
            d()
        })
    };

    function T(a) {
        return qp(function(b, c) {
            var d = 0;
            b.subscribe(new R(c, function(e) {
                return a.call(void 0, e, d++) && c.next(e)
            }))
        })
    };

    function bq() {
        var a = D.apply(0, arguments);
        a = $p(a);
        return a.length === 1 ? Yo(a[0]) : new O(cq(a))
    }

    function cq(a) {
        return function(b) {
            for (var c = [], d = {
                    Rb: 0
                }; c && !b.closed && d.Rb < a.length; d = {
                    Rb: d.Rb
                }, d.Rb++) c.push(Yo(a[d.Rb]).subscribe(new R(b, function(e) {
                return function(f) {
                    if (c) {
                        for (var g = 0; g < c.length; g++) g !== e.Rb && c[g].unsubscribe();
                        c = null
                    }
                    b.next(f)
                }
            }(d))))
        }
    };

    function dq() {
        var a = D.apply(0, arguments),
            b = fp(a),
            c = $p(a);
        return c.length ? new O(function(d) {
            var e = c.map(function() {
                    return []
                }),
                f = c.map(function() {
                    return !1
                });
            d.add(function() {
                e = f = null
            });
            for (var g = {
                    ib: 0
                }; !d.closed && g.ib < c.length; g = {
                    ib: g.ib
                }, g.ib++) Yo(c[g.ib]).subscribe(new R(d, function(h) {
                return function(k) {
                    e[h.ib].push(k);
                    e.every(function(l) {
                        return l.length
                    }) && (k = e.map(function(l) {
                        return l.shift()
                    }), d.next(b ? b.apply(null, A(k)) : k), e.some(function(l, m) {
                        return !l.length && f[m]
                    }) && d.complete())
                }
            }(g), void 0, function(h) {
                return function() {
                    f[h.ib] = !0;
                    !e[h.ib].length && d.complete()
                }
            }(g)));
            return function() {
                e = f = null
            }
        }) : Mo
    };

    function eq(a, b) {
        Up.call(this, a, b);
        this.g = a;
        this.m = b
    }
    x(eq, Up);
    eq.g = Up.g;
    eq.prototype.K = function(a, b) {
        b = b === void 0 ? 0 : b;
        if (b > 0) return Up.prototype.K.call(this, a, b);
        this.delay = b;
        this.state = a;
        this.g.flush(this);
        return this
    };
    eq.prototype.execute = function(a, b) {
        return b > 0 || this.closed ? Up.prototype.execute.call(this, a, b) : this.xe(a, b)
    };
    eq.prototype.be = function(a, b, c) {
        c = c === void 0 ? 0 : c;
        return c != null && c > 0 || c == null && this.delay > 0 ? Up.prototype.be.call(this, a, b, c) : a.flush(this)
    };

    function fq() {
        Wp.apply(this, arguments)
    }
    x(fq, Wp);
    var vp = new fq(eq);

    function gq() {
        this.P = new no;
        this.B = new oo;
        this.g = Symbol();
        this.uc = new so
    }
    gq.prototype.Md = function() {
        return Yp
    };

    function hq(a, b) {
        a.Pa !== null && a.Pa.next(b)
    }

    function iq(a) {
        if ((typeof a === "bigint" || typeof a === "number" || typeof a === "string") && typeof BigInt === "function") return BigInt(a)
    }
    ea.Object.defineProperties(gq.prototype, {
        Hb: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.g
            }
        }
    });
    var jq = ["sessionStart", "sessionError", "sessionFinish"];

    function pq(a, b) {
        this.na = a;
        this.nd = b;
        this.ready = !1;
        this.g = [];
        this.o = function() {};
        this.u = function() {};
        this.l = function() {};
        this.m = function() {};
        this.i = function() {}
    }

    function qq(a, b) {
        a.o = b
    }

    function rq(a, b) {
        a.u = b
    }

    function sq(a, b) {
        a.l = b
    }

    function tq(a, b) {
        a.m = b
    }

    function uq(a, b) {
        a.i = b;
        a.i(a.g.length)
    }

    function vq(a) {
        for (var b = y("geometryChange impression loaded start firstQuartile midpoint thirdQuartile complete pause resume bufferStart bufferFinish skipped volumeChange playerStateChange adUserInteraction".split(" ")), c = b.next(); !c.done; c = b.next()) a.na.addEventListener(c.value, function(d) {
            wq(a, d)
        });
        Gn(a.na, function(d) {
            d.type !== "sessionStart" && wq(a, d)
        }, a.nd);
        Gn(a.na, function(d) {
            d.type === "sessionStart" && (wq(a, d), xq(a), yq(a))
        }, a.nd)
    }

    function wq(a, b) {
        a.g.push(b);
        a.i(a.g.length);
        yq(a)
    }

    function yq(a) {
        if (a.ready)
            for (; a.g.length > 0;) {
                var b = a.g.pop();
                b !== void 0 && (b.type === "geometryChange" ? a.l(b) : b.type === "impression" ? a.m(b) : jq.includes(b.type) ? a.o(b) : a.u(b));
                a.i(a.g.length)
            }
    }

    function xq(a) {
        a.ready || (a.ready = !0, a.g.sort(function(b, c) {
            return c.timestamp - b.timestamp
        }))
    };

    function zq(a) {
        return qp(function(b, c) {
            var d = null,
                e = !1,
                f;
            d = b.subscribe(new R(c, void 0, function(g) {
                f = Yo(a(g, zq(a)(b)));
                d ? (d.unsubscribe(), d = null, f.subscribe(c)) : e = !0
            }));
            e && (d.unsubscribe(), d = null, f.subscribe(c))
        })
    };

    function Aq(a, b, c) {
        return function(d, e) {
            var f = c,
                g = b,
                h = 0;
            d.subscribe(new R(e, function(k) {
                var l = h++;
                g = f ? a(g, k, l) : (f = !0, k);
                e.next(g)
            }, void 0, void 0))
        }
    };

    function Bq() {
        var a = D.apply(0, arguments),
            b = fp(a);
        return b ? N(Bq.apply(null, A(a)), xp(b)) : qp(function(c, d) {
            Fp([c].concat(A($p(a))))(d)
        })
    }

    function Cq() {
        return Bq.apply(null, A(D.apply(0, arguments)))
    };

    function Dq(a) {
        a = a === void 0 ? null : a;
        return qp(function(b, c) {
            var d = !1;
            b.subscribe(new R(c, function(e) {
                d = !0;
                c.next(e)
            }, void 0, function() {
                d || c.next(a);
                c.complete()
            }))
        })
    };

    function Eq() {
        return qp(function(a, b) {
            a.subscribe(new R(b, Ao))
        })
    };

    function Fq(a) {
        return qp(function(b, c) {
            b.subscribe(new R(c, function() {
                return c.next(a)
            }))
        })
    };

    function Gq(a) {
        return a <= 0 ? function() {
            return Mo
        } : qp(function(b, c) {
            var d = 0;
            b.subscribe(new R(c, function(e) {
                ++d <= a && (c.next(e), a <= d && c.complete())
            }))
        })
    };

    function Hq(a) {
        return Jp(function(b, c) {
            return a(b, c).j(Gq(1), Fq(b))
        })
    };

    function Iq(a) {
        return qp(function(b, c) {
            var d = new Set;
            b.subscribe(new R(c, function(e) {
                var f = a ? a(e) : e;
                d.has(f) || (d.add(f), c.next(e))
            }))
        })
    };

    function U(a) {
        var b = b === void 0 ? Go : b;
        var c;
        a = (c = a) != null ? c : Jq;
        return qp(function(d, e) {
            var f, g = !0;
            d.subscribe(new R(e, function(h) {
                var k = b(h);
                if (g || !a(f, k)) g = !1, f = k, e.next(h)
            }))
        })
    }

    function Jq(a, b) {
        return a === b
    };

    function Kq(a) {
        a = a === void 0 ? Lq : a;
        return qp(function(b, c) {
            var d = !1;
            b.subscribe(new R(c, function(e) {
                d = !0;
                c.next(e)
            }, void 0, function() {
                return d ? c.complete() : c.error(a())
            }))
        })
    }

    function Lq() {
        return new op
    };

    function Mq() {
        var a = D.apply(0, arguments);
        return function(b) {
            return Lp(b, hp.apply(null, A(a)))
        }
    };

    function Nq(a) {
        return qp(function(b, c) {
            var d = 0;
            b.subscribe(new R(c, function(e) {
                a.call(void 0, e, d++, b) || (c.next(!1), c.complete())
            }, void 0, function() {
                c.next(!0);
                c.complete()
            }))
        })
    };

    function Oq() {
        return qp(function(a, b) {
            var c = [];
            a.subscribe(new R(b, function(d) {
                c.push(d);
                1 < c.length && c.shift()
            }, void 0, function() {
                for (var d = y(c), e = d.next(); !e.done; e = d.next()) b.next(e.value);
                b.complete()
            }, function() {
                c = null
            }))
        })
    };

    function Pq(a, b) {
        var c = arguments.length >= 2;
        return function(d) {
            return d.j(a ? T(function(e, f) {
                return a(e, f, d)
            }) : Go, Oq(), c ? Dq(b) : Kq(function() {
                return new op
            }))
        }
    };

    function Qq(a) {
        var b = M(a) ? a : function() {
            return a
        };
        return M() ? qp(function(c, d) {
            var e = b();
            (void 0)(e).subscribe(d).add(c.subscribe(e))
        }) : function(c) {
            var d = new sp(c, b);
            M(c == null ? void 0 : c.Db) && (d.Db = c.Db);
            d.source = c;
            d.hf = b;
            return d
        }
    };

    function Rq() {
        return qp(function(a, b) {
            var c, d = !1;
            a.subscribe(new R(b, function(e) {
                var f = c;
                c = e;
                d && b.next([f, e]);
                d = !0
            }))
        })
    };

    function Sq(a) {
        var b = new kp(a, void 0, void 0);
        return function(c) {
            return Qq(function() {
                return b
            })(c)
        }
    };

    function Tq() {
        var a = a === void 0 ? Infinity : a;
        return a <= 0 ? function() {
            return Mo
        } : qp(function(b, c) {
            function d() {
                var g = !1;
                f = b.subscribe(new R(c, void 0, void 0, function() {
                    ++e < a ? f ? (f.unsubscribe(), f = null, d()) : g = !0 : c.complete()
                }));
                g && (f.unsubscribe(), f = null, d())
            }
            var e = 0,
                f;
            d()
        })
    };

    function Uq(a, b) {
        return qp(Aq(a, b, arguments.length >= 2))
    };

    function Vq() {
        var a = a || {};
        var b = a.Kf === void 0 ? function() {
                return new Q
            } : a.Kf,
            c = a.Hg === void 0 ? !0 : a.Hg,
            d = a.Ig === void 0 ? !0 : a.Ig,
            e = a.Jg === void 0 ? !0 : a.Jg;
        return function(f) {
            function g() {
                h = k = null;
                m = q = !1
            }
            var h = null,
                k = null,
                l = 0,
                m = !1,
                q = !1;
            return qp(function(t, r) {
                l++;
                var w;
                k = (w = k) != null ? w : b();
                r.add(function() {
                    l--;
                    if (e && !l && !q && !m) {
                        var u = h;
                        g();
                        u == null || u.unsubscribe()
                    }
                });
                k.subscribe(r);
                !h && l > 0 && (h = new Eo({
                    next: function(u) {
                        return k.next(u)
                    },
                    error: function(u) {
                        q = !0;
                        var v = k;
                        d && g();
                        v.error(u)
                    },
                    complete: function() {
                        m = !0;
                        var u = k;
                        c && g();
                        u.complete()
                    }
                }), Xo(t).subscribe(h))
            })(f)
        }
    };

    function Wq(a) {
        return qp(function(b, c) {
            var d = !1,
                e = 0;
            b.subscribe(new R(c, function(f) {
                return (d || (d = !a(f, e++))) && c.next(f)
            }))
        })
    };

    function V() {
        var a = D.apply(0, arguments),
            b = gp(a);
        return qp(function(c, d) {
            (b ? Lp(a, c, b) : Lp(a, c)).subscribe(d)
        })
    };

    function X(a) {
        return qp(function(b, c) {
            var d = null,
                e = 0,
                f = !1;
            b.subscribe(new R(c, function(g) {
                var h;
                (h = d) == null || h.unsubscribe();
                h = e++;
                Yo(a(g, h)).subscribe(d = new R(c, function(k) {
                    return c.next(k)
                }, void 0, function() {
                    d = null;
                    f && !d && c.complete()
                }))
            }, void 0, function() {
                (f = !0, !d) && c.complete()
            }))
        })
    };

    function Xq(a, b) {
        b = b === void 0 ? !1 : b;
        return qp(function(c, d) {
            var e = 0;
            c.subscribe(new R(d, function(f) {
                var g = a(f, e++);
                (g || b) && d.next(f);
                !g && d.complete()
            }))
        })
    };

    function Yq(a, b, c) {
        var d = M(a) || b || c ? {
            next: a,
            error: b,
            complete: c
        } : a;
        return d ? qp(function(e, f) {
            e.subscribe(new R(f, function(g) {
                var h;
                (h = d.next) == null || h.call(d, g);
                f.next(g)
            }, function(g) {
                var h;
                (h = d.error) == null || h.call(d, g);
                f.error(g)
            }, function() {
                var g;
                (g = d.complete) == null || g.call(d);
                f.complete()
            }))
        }) : Go
    };

    function Zq() {
        var a = D.apply(0, arguments),
            b = fp(a);
        return qp(function(c, d) {
            for (var e = a.length, f = Array(e), g = a.map(function() {
                    return !1
                }), h = !1, k = {
                    eb: 0
                }; k.eb < e; k = {
                    eb: k.eb
                }, k.eb++) Yo(a[k.eb]).subscribe(new R(d, function(l) {
                return function(m) {
                    f[l.eb] = m;
                    h || g[l.eb] || (g[l.eb] = !0, (h = g.every(Go)) && (g = null))
                }
            }(k), void 0, Ao));
            c.subscribe(new R(d, function(l) {
                h && (l = [l].concat(A(f)), d.next(b ? b.apply(null, A(l)) : l))
            }))
        })
    };

    function $q(a) {
        this.na = a
    }
    $q.prototype.T = function(a) {
        return (a == null ? 0 : a.oc) ? !0 : (a == null ? void 0 : a.ka) === "POST" || (a == null ? 0 : a.rb) || (a == null ? 0 : a.Uc) ? !1 : this.na.T()
    };
    $q.prototype.ping = function() {
        var a = this,
            b = hp.apply(null, A(D.apply(0, arguments))).j(Jp(function(c) {
                return ar(a, c)
            }), Nq(function(c) {
                return c
            }), Sq(1));
        b.connect();
        return b
    };

    function ar(a, b) {
        var c = new kp(1);
        Hn(a.na, b, function() {
            c.next(!0);
            c.complete()
        }, function() {
            c.next(!1);
            c.complete()
        });
        return c
    }
    $q.prototype.fd = function(a, b, c) {
        this.ping.apply(this, A(D.apply(3, arguments)))
    };

    function br(a, b) {
        var c = !1;
        return new O(function(d) {
            var e = a.setTimeout(function() {
                c = !0;
                d.next(!0);
                d.complete()
            }, b);
            return function() {
                c || a.clearTimeout(e)
            }
        })
    };

    function cr(a, b) {
        b = Error.call(this, b ? a + ": " + b : String(a));
        this.message = b.message;
        "stack" in b && (this.stack = b.stack);
        this.code = a;
        this.__proto__ = cr.prototype;
        this.name = String(a)
    }
    x(cr, Error);

    function dr(a) {
        cr.call(this, 1E3, 'sfr:"' + a + '"');
        this.g = a;
        this.__proto__ = dr.prototype
    }
    x(dr, cr);

    function er() {
        cr.call(this, 1003);
        this.__proto__ = er.prototype
    }
    x(er, cr);

    function fr() {
        cr.call(this, 1009);
        this.__proto__ = fr.prototype
    }
    x(fr, cr);

    function gr() {
        cr.call(this, 1011);
        this.__proto__ = gr.prototype
    }
    x(gr, cr);

    function hr() {
        cr.call(this, 1007);
        this.__proto__ = er.prototype
    }
    x(hr, cr);

    function ir() {
        cr.call(this, 1008);
        this.__proto__ = er.prototype
    }
    x(ir, cr);

    function jr() {
        cr.call(this, 1001);
        this.__proto__ = jr.prototype
    }
    x(jr, cr);

    function kr(a) {
        cr.call(this, 1004, String(a));
        this.g = a;
        this.__proto__ = kr.prototype
    }
    x(kr, cr);

    function lr(a) {
        cr.call(this, 1010, a);
        this.__proto__ = mr.prototype
    }
    x(lr, cr);

    function mr(a) {
        cr.call(this, 1005, a);
        this.__proto__ = mr.prototype
    }
    x(mr, cr);
    var nr = Symbol("time-origin"),
        or = Symbol("date");

    function pr(a, b) {
        this.value = a;
        this.timeline = b
    }

    function qr(a, b) {
        if (b.timeline !== a.timeline) throw new hr;
    }

    function rr(a, b) {
        qr(a, b);
        return a.value - b.value
    }
    n = pr.prototype;
    n.equals = function(a) {
        return rr(this, a) === 0
    };
    n.maximum = function(a) {
        qr(this, a);
        return this.value >= a.value ? this : a
    };
    n.round = function() {
        return new pr(Math.round(this.value), this.timeline)
    };
    n.add = function(a) {
        return new pr(this.value + a, this.timeline)
    };
    n.toString = function() {
        return String(this.value)
    };

    function sr(a) {
        this.na = a;
        this.timeline = or
    }
    n = sr.prototype;
    n.setTimeout = function(a, b) {
        return Number(this.na.setTimeout(function() {
            return a()
        }, b))
    };
    n.clearTimeout = function(a) {
        this.na.clearTimeout(a)
    };
    n.now = function() {
        return new pr(Date.now(), this.timeline)
    };
    n.interval = function(a, b) {
        var c = this.Ka(a).subscribe(b);
        return function() {
            return void c.unsubscribe()
        }
    };
    n.Ka = function(a) {
        return br(this, a).j(Tq(), Uq(function(b) {
            return b + 1
        }, -1))
    };
    n.ua = function() {
        return !0
    };

    function tr(a, b) {
        this.context = a;
        this.g = b
    }
    tr.prototype.T = function(a) {
        return this.g.T(a)
    };
    tr.prototype.O = function(a, b) {
        if (!this.T(b)) throw new fr;
        return new ur(this.context, this.g, b != null ? b : void 0, a)
    };

    function ur(a, b, c, d) {
        var e = this;
        this.i = b;
        this.properties = c;
        this.url = d;
        this.g = !0;
        this.rb = new Map;
        this.body = void 0;
        var f;
        this.method = (f = c == null ? void 0 : c.ka) != null ? f : "GET";
        this.l = a.Md().subscribe(function() {
            e.sendNow()
        })
    }
    ur.prototype.deactivate = function() {
        this.g = !1
    };
    ur.prototype.sendNow = function() {
        if (this.g)
            if (this.l.unsubscribe(), this.i.T(this.properties)) try {
                if (this.rb.size > 0 || this.body !== void 0) {
                    var a, b;
                    this.i.fd((a = this.properties) != null ? a : {}, this.rb, (b = this.body) != null ? b : "", this.url)
                } else this.i.ping(this.url);
                this.g = !1
            } catch (c) {} else this.g = !1
    };

    function vr(a, b, c, d, e, f) {
        this.mode = a;
        this.C = b;
        this.l = c;
        this.g = d;
        this.o = e;
        this.m = f;
        this.i = !1;
        this.id = this.mode === 0 ? wr(this) : 0
    }

    function wr(a) {
        return a.C.setTimeout(function() {
            xr(a)
        }, a.g)
    }

    function yr(a, b) {
        var c = rr(b, a.l);
        c >= a.g ? xr(a) : (a.l = b, a.g -= c)
    }

    function xr(a) {
        try {
            a.o(a.l.add(a.g))
        } finally {
            a.i = !0, a.m()
        }
    }
    vr.prototype.qe = function(a, b) {
        this.i || (this.mode === 1 && a === 1 ? yr(this, b) : this.mode === 1 && a === 0 ? (this.mode = a, yr(this, this.C.now()), this.i || (this.id = wr(this))) : this.mode === 0 && a === 1 && (this.mode = a, this.clear(), yr(this, b)))
    };
    vr.prototype.clear = function() {
        this.i || this.C.clearTimeout(this.id)
    };

    function zr(a) {
        this.Vc = a;
        this.kg = this.mode = 0;
        this.Tb = {};
        this.timeline = a.timeline;
        this.Cb = a.now()
    }
    n = zr.prototype;
    n.qe = function(a, b) {
        this.mode = a;
        qr(this.Cb, b);
        this.Cb = b;
        Object.values(this.Tb).forEach(function(c) {
            return void c.qe(a, b)
        })
    };
    n.now = function() {
        return this.mode === 1 ? this.Cb : this.Vc.now()
    };
    n.setTimeout = function(a, b) {
        var c = this,
            d = ++this.kg,
            e = this.mode === 1 ? this.Cb : this.Vc.now();
        this.Tb[d] = new vr(this.mode, this.Vc, e, b, function(f) {
            var g = c.Cb;
            c.mode === 1 && (c.Cb = f);
            a();
            c.Cb = g
        }, function() {
            delete c.Tb[d]
        });
        return d
    };
    n.clearTimeout = function(a) {
        this.Tb[a] && (this.Tb[a].clear(), delete this.Tb[a])
    };
    n.interval = function() {
        throw Error("'interval' is not supported for DualModeTimeProvider");
    };
    n.Ka = function() {
        throw Error("'intervalObservable' is not supported for DualModeTimeProvider");
    };
    n.ua = function() {
        return this.Vc.ua()
    };

    function Ar(a, b) {
        var c = new zr(a);
        a = b.subscribe(function(d) {
            c.qe(d.value ? 1 : 0, d.timestamp)
        });
        return {
            C: c,
            Gh: a
        }
    };

    function Br(a) {
        var b = Object.assign({}, a);
        delete b.timestamp;
        return {
            timestamp: new pr(a.timestamp, or),
            value: b
        }
    };

    function Cr(a) {
        return a !== void 0 && typeof a.x === "number" && typeof a.y === "number" && typeof a.width === "number" && typeof a.height === "number"
    };
    var Dr = pa(["https://www.googleadservices.com/pagead/managed/js/activeview/", "/reach_worklet.html"]),
        Er = pa(["./reach_worklet.js"]),
        Fr = pa(["./reach_worklet.js"]),
        Gr = pa(["./reach_worklet.html"]),
        Hr = pa(["./reach_worklet.js"]),
        Ir = pa(["./reach_worklet.js"]);

    function Jr() {
        var a = {};
        return a[0] = Ic(Dr, "current"), a[1] = Ic(Er), a[2] = Ic(Fr), a
    }
    Ic(Gr);
    Ic(Hr);
    Ic(Ir);

    function Kr(a, b, c, d) {
        c = c === void 0 ? null : c;
        d = d === void 0 ? Jr() : d;
        gq.call(this);
        this.na = a;
        this.nd = b;
        this.Pa = c;
        this.je = d;
        this.gb = null;
        this.ee = new kp(3);
        this.ee.j(T(function(e) {
            return e.value.type === "sessionStart"
        }));
        this.Lg = this.ee.j(T(function(e) {
            return e.value.type === "sessionFinish"
        }));
        this.Ve = new kp(1);
        this.Vg = new kp;
        this.Re = new kp(10);
        this.N = new tr(this, new $q(a));
        this.pg = this.na.T();
        this.C = Lr(this, new sr(this.na))
    }
    x(Kr, gq);

    function Mr(a) {
        a.gb !== null && vq(a.gb)
    }
    Kr.prototype.validate = function() {
        return this.pg
    };

    function Lr(a, b) {
        a.gb = new pq(a.na, a.nd);
        var c = new kp;
        qq(a.gb, function(f) {
            f = Br(f);
            c.next({
                timestamp: f.timestamp,
                value: !0
            });
            a.ee.next(f)
        });
        sq(a.gb, function(f) {
            if (f === void 0) var g = !1;
            else {
                g = f.data;
                var h;
                (h = g === void 0) || (h = g.viewport, h = h === void 0 || h !== void 0 && typeof h.width === "number" && typeof h.height === "number");
                h ? (g = g.adView, g = g !== void 0 && typeof g.percentageInView === "number" && (g.geometry === void 0 || Cr(g.geometry)) && (g.onScreenGeometry === void 0 || Cr(g.onScreenGeometry))) : g = !1
            }
            g ? (f = Br(f), c.next({
                timestamp: f.timestamp,
                value: !0
            }), a.Re.next(f)) : .01 >= Math.random() && (f = "https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=error&name=invalid_geo&context=1092&msg=" + JSON.stringify(f), a.N.O(f).sendNow())
        });
        rq(a.gb, function(f) {
            f = Br(f);
            c.next({
                timestamp: f.timestamp,
                value: !0
            });
            a.Vg.next(f)
        });
        tq(a.gb, function(f) {
            f = Br(f);
            c.next({
                timestamp: f.timestamp,
                value: !0
            });
            a.Ve.next(f)
        });
        var d = 0;
        uq(a.gb, function(f) {
            d += f;
            d > 0 && f === 0 && c.next({
                timestamp: a.C.now(),
                value: !1
            })
        });
        var e = c.j(Xq(function(f) {
            return f.value
        }, !0));
        return Ar(b, e).C
    }
    ea.Object.defineProperties(Kr.prototype, {
        global: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return Nr
            }
        }
    });
    var Nr = {};

    function Or(a) {
        try {
            var b = new Fn;
            return new Kr(b, "doubleclickbygoogle.com-omid", void 0, a)
        } catch (c) {}
    };

    function Pr(a, b) {
        return function(c) {
            return new O(function(d) {
                return c.subscribe(function(e) {
                    a.bc(b, function() {
                        d.next(e)
                    })()
                }, function(e) {
                    a.bc(b, function() {
                        d.error(e)
                    })()
                }, function() {
                    a.bc(b, function() {
                        d.complete()
                    })()
                })
            })
        }
    };

    function Qr() {
        for (var a = y(D.apply(0, arguments)), b = a.next(); !b.done; b = a.next())
            if (b = b.value, b.ua()) {
                this.C = b;
                return
            }
        this.C = new Rr
    }
    n = Qr.prototype;
    n.ua = function() {
        return this.C.ua()
    };
    n.now = function() {
        return this.C.now()
    };
    n.setTimeout = function(a, b) {
        return this.C.setTimeout(a, b)
    };
    n.clearTimeout = function(a) {
        this.C.clearTimeout(a)
    };
    n.interval = function(a, b) {
        var c = this.Ka(a).subscribe(b);
        return function() {
            return void c.unsubscribe()
        }
    };
    n.Ka = function(a) {
        return this.C.Ka(a)
    };
    ea.Object.defineProperties(Qr.prototype, {
        timeline: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.C.timeline
            }
        }
    });

    function Rr() {
        this.timeline = Symbol()
    }
    n = Rr.prototype;
    n.ua = function() {
        return !1
    };
    n.now = function() {
        return new pr(0, this.timeline)
    };
    n.setTimeout = function() {
        return 0
    };
    n.clearTimeout = function() {};
    n.interval = function() {
        return function() {}
    };
    n.Ka = function() {
        return Yp
    };

    function Sr(a, b) {
        this.W = a;
        this.P = b
    }
    n = Sr.prototype;
    n.setTimeout = function(a, b) {
        return this.W.setTimeout(this.P.bc(734, a), b)
    };
    n.clearTimeout = function(a) {
        this.W.clearTimeout(a)
    };
    n.interval = function(a, b) {
        var c = this.Ka(a).subscribe(b);
        return function() {
            return void c.unsubscribe()
        }
    };
    n.Ka = function(a) {
        var b = this;
        return new O(function(c) {
            var d = 0,
                e = b.W.setInterval(function() {
                    c.next(d++)
                }, a);
            return function() {
                b.W.clearInterval(e)
            }
        })
    };
    n.ua = function() {
        return !!this.W.clearTimeout && "setTimeout" in this.W && "setInterval" in this.W && !!this.W.clearInterval
    };

    function Tr(a, b) {
        Sr.call(this, a, b);
        this.timeline = or
    }
    x(Tr, Sr);
    Tr.prototype.now = function() {
        return new pr(this.W.Date.now(), this.timeline)
    };
    Tr.prototype.ua = function() {
        return !!this.W.Date && !!this.W.Date.now && Sr.prototype.ua.call(this)
    };

    function Ur(a, b) {
        Sr.call(this, a, b);
        this.timeline = nr
    }
    x(Ur, Sr);
    Ur.prototype.now = function() {
        return new pr(this.W.performance.now(), this.timeline)
    };
    Ur.prototype.ua = function() {
        return !!this.W.performance && !!this.W.performance.now && Sr.prototype.ua.call(this)
    };

    function Vr(a) {
        var b = D.apply(1, arguments),
            c = this;
        this.g = [];
        this.g.push(a);
        b.forEach(function(d) {
            c.g.push(d)
        })
    }
    Vr.prototype.T = function(a) {
        return this.g.some(function(b) {
            return b.T(a)
        })
    };
    Vr.prototype.O = function(a, b) {
        for (var c = 0; c < this.g.length; c++)
            if (this.g[c].T(b)) return this.g[c].O(a, b);
        throw new fr;
    };

    function Wr(a) {
        a = a.global;
        if (a.fetchLater) return a.fetchLater.bind(a)
    }

    function Xr(a) {
        this.context = a;
        if (Yr === void 0) a: {
            var b, c, d = (b = a.global) == null ? void 0 : (c = b.document) == null ? void 0 : c.createElement("meta");
            if (d) try {
                d.httpEquiv = "origin-trial";
                d.content = "AxjhRadLCARYRJawRjMjq4U8V8okQvSnrBIJWdMajuEkN3/DfVAcLcFhMVrUWnOXagwlI8dQD84FwJDGj9ohqAYAAABveyJvcmlnaW4iOiJodHRwczovL2dvb2dsZWFkc2VydmljZXMuY29tOjQ0MyIsImZlYXR1cmUiOiJGZXRjaExhdGVyQVBJIiwiZXhwaXJ5IjoxNzI1NDA3OTk5LCJpc1RoaXJkUGFydHkiOnRydWV9";
                a.global.document.head.append(d);
                Yr = d;
                break a
            } catch (e) {}
            Yr = void 0
        }
    }
    var Yr;
    Xr.prototype.T = function(a) {
        return Wr(this.context) !== void 0 && !(a == null || !a.Ke) && !Zr(this.context) && !(a == null ? 0 : a.oc) && !(a == null ? 0 : a.rb) && !(a == null ? 0 : a.Uc)
    };
    Xr.prototype.O = function(a, b) {
        if (!this.T(b)) throw new fr;
        return new $r(this.context, a, b)
    };

    function $r(a, b, c) {
        this.context = a;
        this.properties = c;
        this.l = b;
        var d;
        this.ka = (d = c == null ? void 0 : c.ka) != null ? d : "GET";
        a = Wr(this.context);
        if (a === void 0) throw Error();
        this.fetchLater = a;
        as(this, bs(this))
    }

    function as(a, b) {
        a.g && a.g.activated || (a.i = new AbortController, a.g = a.fetchLater(b, {
            method: a.ka,
            cache: "no-cache",
            mode: "no-cors",
            signal: a.i.signal,
            activateAfter: 96E4
        }))
    }

    function bs(a) {
        a = a.l;
        return (a.slice(-1)[0] === "&" ? a : a + "&") + "flapi=1"
    }
    $r.prototype.deactivate = function() {
        this.g && !this.g.activated && this.i && (this.i.abort(), this.g = void 0)
    };
    $r.prototype.sendNow = function() {};
    ea.Object.defineProperties($r.prototype, {
        url: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.l
            },
            set: function(a) {
                this.l = a;
                a = bs(this);
                this.g && this.g.activated || !this.i || (this.i.abort(), this.g = void 0);
                as(this, a)
            }
        },
        method: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.ka
            }
        }
    });

    function cs(a) {
        this.context = a
    }
    cs.prototype.T = function() {
        return !Zr(this.context) && !!this.context.global.fetch
    };
    cs.prototype.ping = function() {
        var a = this;
        return Xp.apply(null, A(D.apply(0, arguments).map(function(b) {
            return Xo(a.context.global.fetch(b, {
                method: "GET",
                cache: "no-cache",
                keepalive: !0,
                mode: "no-cors"
            })).j(S(function(c) {
                return c.status === 200
            }))
        }))).j(Nq(function(b) {
            return b
        }), Pq())
    };
    cs.prototype.fd = function(a, b, c) {
        for (var d = D.apply(3, arguments), e = this, f = new Headers, g = y(b.entries()), h = g.next(); !h.done; h = g.next()) {
            var k = y(h.value);
            h = k.next().value;
            k = k.next().value;
            f.set(h, k)
        }
        var l, m = (l = a.keepAlive) != null ? l : !1;
        Xp.apply(null, A(d.map(function(q) {
            return Xo(e.context.global.fetch(q, Object.assign({}, {
                method: String(a.ka),
                cache: "no-cache"
            }, m ? {
                keepalive: !0
            } : {}, {
                mode: "no-cors",
                headers: f,
                body: c
            }))).j(S(function(t) {
                return t.status === 200
            }))
        }))).j(Nq(function(q) {
            return q
        }), Pq())
    };

    function ds(a) {
        this.context = a
    }
    ds.prototype.T = function(a) {
        return (a == null ? 0 : a.oc) || (a == null ? void 0 : a.ka) === "POST" || (a == null ? 0 : a.rb) || (a == null ? 0 : a.Uc) || (a == null ? 0 : a.keepAlive) ? !1 : !Zr(this.context)
    };
    ds.prototype.ping = function() {
        var a = this;
        return hp(D.apply(0, arguments).map(function(b) {
            try {
                return Jd(a.context.global, b, !1, !1, !1), !0
            } catch (c) {
                return !1
            }
        }).every(function(b) {
            return b
        }))
    };
    ds.prototype.fd = function(a, b, c) {
        this.ping.apply(this, A(D.apply(3, arguments)))
    };

    function es(a) {
        a = a.global;
        if (a.PendingGetBeacon) return a.PendingGetBeacon
    }

    function fs(a) {
        this.context = a
    }
    fs.prototype.T = function(a) {
        return gs && !Zr(this.context) && es(this.context) !== void 0 && !(a == null ? 0 : a.oc) && (a == null ? void 0 : a.ka) !== "POST" && !(a == null ? 0 : a.rb) && !(a == null ? 0 : a.Uc)
    };
    fs.prototype.O = function(a, b) {
        if (!this.T(b)) throw new fr;
        return new hs(this.context, a)
    };
    var gs = !1;

    function hs(a, b) {
        this.context = a;
        this.g = b;
        a = es(this.context);
        if (a === void 0) throw Error();
        this.i = new a(is(this), {})
    }

    function is(a) {
        a = a.g;
        return (a.slice(-1)[0] === "&" ? a : a + "&") + "pbapi=1"
    }
    hs.prototype.deactivate = function() {
        this.i.deactivate()
    };
    hs.prototype.sendNow = function() {
        this.i.sendNow()
    };
    ea.Object.defineProperties(hs.prototype, {
        url: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.g
            },
            set: function(a) {
                this.g = a;
                this.i.setURL(is(this))
            }
        },
        method: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return "GET"
            },
            set: function(a) {
                if (a !== "GET") throw new fr;
            }
        }
    });

    function js(a) {
        this.context = a
    }
    js.prototype.T = function(a) {
        if ((a == null ? 0 : a.oc) || (a == null ? void 0 : a.ka) === "GET" || (a == null ? 0 : a.rb) || (a == null ? 0 : a.Uc) || (a == null ? 0 : a.keepAlive)) return !1;
        var b;
        return !Zr(this.context) && ((b = this.context.global.navigator) == null ? void 0 : b.sendBeacon) !== void 0
    };
    js.prototype.ping = function() {
        var a = this;
        return hp(D.apply(0, arguments).map(function(b) {
            var c;
            return (c = a.context.global.navigator) == null ? void 0 : c.sendBeacon(b)
        }).every(function(b) {
            return b
        }))
    };
    js.prototype.fd = function(a, b, c) {
        this.ping.apply(this, A(D.apply(3, arguments)))
    };

    function ks(a) {
        var b = b === void 0 ? {} : b;
        if (typeof Event === "function") return new Event(a, b);
        if (typeof document !== "undefined") {
            var c = document.createEvent("CustomEvent");
            c.initCustomEvent(a, b.bubbles || !1, b.cancelable || !1, b.detail);
            return c
        }
        throw Error();
    };

    function ls(a) {
        this.value = a;
        this.l = new Q
    }

    function ms(a) {
        a.l.next();
        a.l.complete();
        a.value = void 0
    }
    ea.Object.defineProperties(ls.prototype, {
        g: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.value
            }
        },
        i: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.l
            }
        }
    });

    function ns(a, b, c) {
        if (a)
            for (var d = 0; a != null && d < 500 && !c(a); ++d) a = b(a)
    }

    function os(a, b) {
        ns(a, function(c) {
            try {
                return c === c.parent ? null : c.parent
            } catch (d) {}
            return null
        }, b)
    }

    function ps(a, b) {
        if (a.tagName == "IFRAME") b(a);
        else {
            a = a.querySelectorAll("IFRAME");
            for (var c = 0; c < a.length && !b(a[c]); ++c);
        }
    }

    function qs(a) {
        return (a = a.ownerDocument) && (a.parentWindow || a.defaultView) || null
    }

    function rs(a, b, c) {
        try {
            var d = JSON.parse(c.data)
        } catch (g) {}
        if (typeof d === "object" && d && d.type === "creativeLoad") {
            var e = qs(a);
            if (c.source && e) {
                var f;
                os(c.source, function(g) {
                    try {
                        if (g.parent === e) return f = g, !0
                    } catch (h) {}
                });
                f && ps(a, function(g) {
                    if (g.contentWindow === f) return b(d), !0
                })
            }
        }
    }

    function ss(a) {
        return typeof a === "string" ? document.getElementById(a) : a
    }

    function ts(a, b) {
        var c = ss(a);
        if (c)
            if (c.onCreativeLoad) c.onCreativeLoad(b);
            else {
                var d = b ? [b] : [],
                    e = function(f) {
                        for (var g = 0; g < d.length; ++g) try {
                            d[g](1, f)
                        } catch (h) {}
                        d = {
                            push: function(h) {
                                h(1, f)
                            }
                        }
                    };
                c.onCreativeLoad = function(f) {
                    d.push(f)
                };
                c.setAttribute("data-creative-load-listener", "");
                c.addEventListener("creativeLoad", function(f) {
                    e(f.detail)
                });
                Ia.addEventListener("message", function(f) {
                    rs(c, e, f)
                })
            }
    };

    function us(a, b) {
        var c = this;
        this.global = a;
        this.g = b;
        this.l = this.document ? Xp(hp(!0), Qp(this.document, "visibilitychange")).j(Pr(this.g.P, 748), S(function() {
            return c.document ? c.document.visibilityState : "visible"
        }), U()) : hp("visible");
        this.i = this.document ? Qp(this.document, "DOMContentLoaded").j(Pr(this.g.P, 739), Gq(1)) : hp(ks("DOMContentLoaded"))
    }

    function vs(a) {
        return a.document ? a.document.readyState : "complete"
    }

    function ws(a) {
        return a.document !== null && a.document.visibilityState !== void 0
    }
    us.prototype.querySelector = function(a) {
        return this.document ? this.document.querySelector(a) : null
    };
    us.prototype.querySelectorAll = function(a) {
        return this.document ? db(this.document.querySelectorAll(a)) : []
    };

    function xs(a, b, c) {
        function d() {
            e.next(b)
        }
        c = c === void 0 ? !1 : c;
        if (b.g === void 0 || !a.document) return hp(b).j(Pr(a.g.P, 749));
        var e = new kp(1);
        c || ts(b.g, d);
        tm(b.g, d, om());
        return e.j(Pr(a.g.P, 749), Gq(1))
    }

    function ys(a, b) {
        a = a.document;
        if (!a) return hp(!1);
        var c = Xp(hp(null), Qp(a, "DOMContentLoaded", {
                once: !0
            }), Qp(a, "load", {
                once: !0
            })),
            d = new ls({
                document: a,
                element: b
            });
        return c.j(S(function() {
            if (!d.g) return !1;
            var e = d.g,
                f = e.document;
            e = e.element;
            var g, h, k = (h = (g = f.body) != null ? g : f.children[0]) != null ? h : f;
            try {
                k.appendChild(e), ms(d)
            } catch (l) {}
            return !d.g
        }), T(function(e) {
            return e
        }), Gq(1), Dq(!1), Yq({
            complete: function() {
                return void ms(d)
            }
        }))
    }

    function zs(a, b, c) {
        var d, e, f;
        return Da(function(g) {
            if (g.i == 1) {
                d = a.global.document.createElement("iframe");
                e = new Promise(function(k) {
                    d.onload = k;
                    d.onerror = k
                });
                if (b instanceof jc) var h = b.g;
                else throw Error("");
                d.src = h.toString();
                return g.g(pp(ys(a, d)), 2)
            }
            if (g.i != 3) {
                if (!g.l) return g.return();
                d.style.display = "none";
                return g.g(e, 3)
            }
            f = d.contentWindow;
            if (!f) return g.return();
            f.postMessage(c, "*");
            return g.return(d)
        })
    }
    ea.Object.defineProperties(us.prototype, {
        document: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return yc(this.global, "document") ? this.global.document || null : null
            }
        }
    });

    function As(a) {
        return function(b) {
            return b.j(Bs(a, Qq(new Q)))
        }
    }

    function Y(a, b) {
        return function(c) {
            return c.j(Bs(a, Sq(b)))
        }
    }

    function Bs(a, b) {
        function c(d) {
            return new O(function(e) {
                return d.subscribe(function(f) {
                    po(a, function() {
                        return void e.next(f)
                    }, 3)
                }, function(f) {
                    po(a, function() {
                        return void e.error(f)
                    }, 3)
                }, function() {
                    po(a, function() {
                        return void e.complete()
                    }, 3)
                })
            })
        }
        return N(c, up(), b, rp(), c)
    };
    var Cs = {
        left: 0,
        top: 0,
        width: 0,
        height: 0
    };

    function Ds(a, b) {
        return a.left === b.left && a.top === b.top && a.width === b.width && a.height === b.height
    }

    function Es(a, b) {
        return {
            left: Math.max(a.left, b.left),
            top: Math.max(a.top, b.top),
            width: Math.max(0, Math.min(a.left + a.width, b.left + b.width) - Math.max(a.left, b.left)),
            height: Math.max(0, Math.min(a.top + a.height, b.top + b.height) - Math.max(a.top, b.top))
        }
    }

    function Fs(a, b) {
        return {
            left: Math.round(a.left + b.x),
            top: Math.round(a.top + b.y),
            width: a.width,
            height: a.height
        }
    };

    function Dg(a) {
        this.F = bg(a, void 0, void 0, 2048)
    }
    x(Dg, Qh);
    Dg.prototype.Te = function() {
        return Ig(this)
    };

    function Gs(a) {
        this.F = bg(a, void 0, void 0, 2048)
    }
    x(Gs, Qh);

    function Hs(a, b) {
        return Mg(a, 2, b)
    }

    function Is(a, b) {
        return Mg(a, 3, b)
    }

    function Js(a, b) {
        return Mg(a, 4, b)
    }

    function Ks(a, b) {
        return Mg(a, 5, b)
    }

    function Ls(a, b) {
        return Mg(a, 9, b)
    }

    function Ms(a, b) {
        ig(a);
        var c = a.F,
            d = c[K] | 0;
        if (b == null) ng(c, d, 10);
        else {
            for (var e = b === Ie ? 7 : b[K] | 0, f = e, g = vg(e), h = g || Object.isFrozen(b), k = !0, l = !0, m = 0; m < b.length; m++) {
                var q = b[m];
                g || (q = Ne(q), k && (k = !q), l && (l = q))
            }
            g || (e = k ? 13 : 5, e = l ? e & -4097 : e | 4096);
            h && e === f || (b = qf(b), f = 0, e = tg(e, d));
            e !== f && Ke(b, e);
            d = ng(c, d, 10, b);
            2 & e || !(4096 & e || 16 & e) || jg(c, d)
        }
        return a
    }

    function Ns(a, b) {
        return Jg(a, 11, b)
    }

    function Os(a, b) {
        return Mg(a, 1, b)
    }

    function Ps(a, b) {
        return Jg(a, 7, b)
    };
    var Qs = "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(" ");

    function Rs(a) {
        var b;
        return (b = a.google_tag_data) != null ? b : a.google_tag_data = {}
    }

    function Ss(a) {
        var b, c;
        return typeof((b = a.navigator) == null ? void 0 : (c = b.userAgentData) == null ? void 0 : c.getHighEntropyValues) === "function"
    }

    function Ts(a) {
        if (!Ss(a)) return null;
        var b = Rs(a);
        if (b.uach_promise) return b.uach_promise;
        a = a.navigator.userAgentData.getHighEntropyValues(Qs).then(function(c) {
            b.uach != null || (b.uach = c);
            return c
        });
        return b.uach_promise = a
    }

    function Us(a) {
        var b;
        return Ns(Ms(Ks(Hs(Os(Js(Ps(Ls(Is(new Gs, a.architecture || ""), a.bitness || ""), a.mobile || !1), a.model || ""), a.platform || ""), a.platformVersion || ""), a.uaFullVersion || ""), ((b = a.fullVersionList) == null ? void 0 : b.map(function(c) {
            var d = new Dg;
            d = Mg(d, 1, c.brand);
            return Mg(d, 2, c.version)
        })) || []), a.wow64 || !1)
    }

    function Vs(a) {
        var b, c;
        return (c = (b = Ts(a)) == null ? void 0 : b.then(function(d) {
            return Us(d)
        })) != null ? c : null
    };

    function Ws(a, b, c, d) {
        a = a === void 0 ? window : a;
        b = b === void 0 ? null : b;
        c = c === void 0 ? new no : c;
        d = d === void 0 ? Jr() : d;
        gq.call(this);
        var e = this;
        this.global = a;
        this.Pa = b;
        this.P = c;
        this.je = d;
        this.Cg = Mp(function() {
            return Qp(e.global, "pagehide")
        }).j(Pr(this.P, 941));
        this.ef = Mp(function() {
            return Qp(e.global, "load")
        }).j(Pr(this.P, 738), Gq(1));
        this.Dg = Mp(function() {
            return Qp(e.global, "resize")
        }).j(Pr(this.P, 741));
        this.onMessage = Mp(function() {
            return Qp(e.global, "message")
        }).j(Pr(this.P, 740));
        this.document = new us(this.global, this);
        this.C = new Qr(new Ur(this.W, this.P), new Tr(this.W, this.P));
        this.N = new Vr(new Xr(this), new fs(this), new tr(this, new cs(this)), new tr(this, new js(this)), new tr(this, new ds(this)))
    }
    x(Ws, gq);

    function Xs(a) {
        try {
            return !!a.global.sharedStorage
        } catch (b) {
            return b
        }
    }

    function Ys(a, b) {
        try {
            return !!a.global.localStorage
        } catch (c) {
            return (b === void 0 ? function() {} : b)(c), !1
        }
    }
    n = Ws.prototype;
    n.xc = function() {
        var a;
        return !((a = this.global.navigator) == null || !a.locks)
    };
    n.ce = function(a, b) {
        var c = this;
        return Da(function(d) {
            return c.xc() ? d.g(c.global.navigator.locks.request(a, b), 0) : d.return()
        })
    };

    function Zr(a) {
        var b = a.global;
        return !!a.global.HTMLFencedFrameElement && !!b.fence && typeof b.fence.reportEvent === "function"
    }
    n.Wb = function(a) {
        Zr(this) && this.global.fence.reportEvent(a)
    };
    n.Md = function() {
        return this.Cg.j(Pr(this.P, 942), Y(this.B, 1), S(function() {}))
    };

    function Zs(a) {
        var b = new Ws(a.global.top, a.Pa);
        b.N = a.N;
        return b
    }

    function $s(a, b) {
        b.start();
        return Qp(b, "message").j(Pr(a.P, 740))
    }
    n.postMessage = function(a, b, c) {
        c = c === void 0 ? [] : c;
        this.global.postMessage(a, b, c)
    };
    n.bb = function() {
        return td(this.global) ? this.global.width : 0
    };
    n.Za = function() {
        return td(this.global) ? this.global.height : 0
    };

    function at(a, b) {
        try {
            var c = Oj(b, a.global, wd() || vd());
            return {
                left: c.left,
                top: c.top,
                width: c.bb(),
                height: c.Za()
            }
        } catch (d) {
            return Cs
        }
    }
    n.validate = function() {
        var a = this.N.T() || Zr(this);
        return this.global && this.C.ua() && a
    };

    function bt(a) {
        return (a = Vs(a.global)) ? Xo(a) : null
    }
    ea.Object.defineProperties(Ws.prototype, {
        sharedStorage: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                try {
                    return this.global.sharedStorage
                } catch (a) {}
            }
        },
        localStorage: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                try {
                    return this.global.localStorage
                } catch (a) {}
            }
        },
        W: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return window
            }
        },
        zb: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return !td(this.global.top)
            }
        },
        Od: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.zb || this.global.top !== this.global
            }
        },
        scrollY: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.global.scrollY
            }
        },
        MutationObserver: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.W.MutationObserver
            }
        },
        ResizeObserver: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.W.ResizeObserver
            }
        },
        If: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return "vu" in this.global || "vv" in this.global
            }
        }
    });

    function ct(a) {
        this.children = a;
        this.o = !1;
        this.l = []
    }
    ct.prototype.complete = function() {
        var a = this;
        this.o = !0;
        this.l.forEach(function(b) {
            return void b(a)
        });
        this.l.splice(0)
    };

    function dt(a, b) {
        a.o ? b(a) : a.l.push(b)
    }
    ct.prototype.pb = function(a) {
        var b = this.children.map(function(c) {
            return c.pb(a)
        });
        return b.find(function(c) {
            return c !== 2
        }) === void 0 ? 2 : this.g ? 0 : b.some(function(c) {
            return c === 1
        }) ? 1 : 0
    };
    ea.Object.defineProperties(ct.prototype, {
        g: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.o
            }
        }
    });

    function et() {
        var a = D.apply(0, arguments);
        ct.call(this, a);
        var b = this;
        this.events = a;
        var c = this.events.length;
        this.events.forEach(function(d) {
            dt(d, function() {
                --c === 0 && b.complete()
            })
        })
    }
    x(et, ct);
    et.prototype.clone = function() {
        return new(Function.prototype.bind.apply(et, [null].concat(A(this.events.map(function(a) {
            return a.clone()
        })))))
    };
    et.prototype.u = function(a, b) {
        var c = this;
        if (!this.g) {
            var d = this.events.find(function(e) {
                return e.pb(a) === 1
            });
            d !== void 0 && d.u(a, function() {
                c.g || b()
            })
        }
    };

    function ft(a, b) {
        ct.call(this, []);
        this.m = a;
        this.i = Symbol(b);
        this.A = a
    }
    x(ft, ct);
    ft.prototype.clone = function() {
        var a = new ft(this.A, this.i.description);
        a.i = this.i;
        return a
    };
    ft.prototype.pb = function(a) {
        return a !== this.event ? 2 : this.g || this.m === 0 ? 0 : 1
    };
    ft.prototype.u = function(a, b) {
        this.pb(a) === 1 && (this.m--, b(), this.m === 0 && this.complete())
    };
    ea.Object.defineProperties(ft.prototype, {
        event: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.i
            }
        }
    });

    function gt(a) {
        ft.call(this, 1, a)
    }
    x(gt, ft);

    function ht(a) {
        var b = this;
        this.g = !1;
        this.l = [];
        this.i = [];
        a(function(c) {
            b.g = !0;
            b.resolution = c;
            jt(b)
        }, function(c) {
            b.m = c;
            jt(b)
        })
    }

    function kt(a) {
        return new ht(function(b, c) {
            var d = [],
                e = 0;
            a.forEach(function(f, g) {
                lt(f.then(function(h) {
                    d[g] = h;
                    ++e === a.length && b(d)
                }), function(h) {
                    c(h)
                })
            })
        })
    }

    function jt(a) {
        var b = a.resolution,
            c = a.m;
        if (c !== void 0 || a.g) a.g && a.l.forEach(function(d) {
            return void d(b)
        }), c !== void 0 && a.i.forEach(function(d) {
            return void d(c)
        }), a.l = [], a.i = []
    }
    ht.prototype.then = function(a) {
        this.l.push(a);
        jt(this);
        return this
    };

    function lt(a, b) {
        a.i.push(b);
        jt(a)
    };

    function mt(a, b, c) {
        var d = D.apply(3, arguments);
        this.g = a;
        this.o = b;
        this.m = c;
        this.l = new Set;
        this.i = d;
        if (this.g.I) this.context = this.g.I;
        else if (this.g.oa) this.context = this.g.oa;
        else throw Error("Mediator requires a Web or OMID context.");
        var e = d.reduce(function(h, k) {
            k.subscribedEvents.forEach(function(l) {
                return void h.add(l)
            });
            return h
        }, new Set);
        e = y(e.values());
        for (var f = e.next(), g = {}; !f.done; g = {
                Ne: void 0
            }, f = e.next()) {
            g.Ne = f.value;
            f = d.filter(function(h) {
                return function(k) {
                    return k.controlledEvents.indexOf(h.Ne) >= 0
                }
            }(g));
            if (f.length === 0) throw Error("Event missing corresponding producing colleague.");
            if (f.length > 1) throw Error("Event has one too many producers.");
        }
    }
    mt.prototype.start = function() {
        var a = this;
        this.i.forEach(function(b) {
            return void b.start(a.g)
        });
        this.m.start(this.g, this.u.bind(this), this.Pb.bind(this), function() {})
    };
    mt.prototype.dispose = function() {
        var a = this;
        this.m.dispose();
        this.l.forEach(function(b) {
            return void a.Pb(b)
        });
        this.i.forEach(function(b) {
            return void b.dispose()
        })
    };

    function nt(a, b) {
        b = {
            measuringCreativeIds: [].concat(A(a.l.values())).map(function(c) {
                return to(a.context.uc, c)
            }),
            hasCreativeSourceCompleted: !!a.m.gd,
            colleagues: a.i.map(function(c) {
                return {
                    name: c.name,
                    controlledEvents: c.controlledEvents.map(function(d) {
                        var e;
                        return (e = d.description) != null ? e : "n/a"
                    }),
                    subscribedEvents: c.subscribedEvents.map(function(d) {
                        var e;
                        return (e = d.description) != null ? e : "n/a"
                    })
                }
            }),
            ephemeralCreativeStateChanges: b
        };
        b = {
            specMajor: 2,
            specMinor: 0,
            specPatch: 0,
            instanceId: to(a.context.uc, a.context.Hb),
            timestamp: rr(a.context.C.now(), new pr(0, a.context.C.timeline)),
            mediatorState: b
        };
        hq(a.context, b)
    }

    function ot(a, b, c, d, e) {
        var f = {};
        nt(a, (f[b] = {
            events: [{
                timestamp: c,
                description: d,
                status: e
            }]
        }, f))
    }
    mt.prototype.u = function(a, b, c) {
        var d = this;
        if (!this.l.has(a)) {
            var e = this.o.clone();
            this.l.add(a);
            nt(this, {});
            var f = !1,
                g = [];
            this.i.forEach(function(h) {
                function k(l, m, q) {
                    var t = to(d.context.uc, a),
                        r = rr(d.context.C.now(), new pr(0, d.context.C.timeline)),
                        w, u = (w = l.description) != null ? w : "n/a";
                    if (h.controlledEvents.indexOf(l) < 0 || e.pb(l) !== 1) return q(!1), ot(d, t, r, u, 1), new ht(function(C) {
                        return void C()
                    });
                    var v = new ht(function(C) {
                        e.u(l, function() {
                            d.i.filter(function(P) {
                                return P.subscribedEvents.indexOf(l) >= 0
                            }).forEach(function(P) {
                                return void P.handleEvent(a, l, m)
                            });
                            C()
                        })
                    });
                    return new ht(function(C) {
                        v.then(function() {
                            q(!0);
                            ot(d, t, r, u, 2);
                            C()
                        })
                    })
                }
                h.Nd(a, b, c, function(l, m, q) {
                    return f ? k(l, m, q) : new ht(function(t) {
                        g.push(function() {
                            k(l, m, q).then(function() {
                                t()
                            })
                        })
                    })
                }, function(l) {
                    try {
                        d.context.N.O("https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=colleague-executed&name=" + l, {
                            ka: "GET"
                        }).sendNow()
                    } catch (m) {}
                })
            });
            f = !0;
            g.forEach(function(h) {
                return void h()
            })
        }
    };
    mt.prototype.Pb = function(a) {
        this.l.delete(a);
        this.i.forEach(function(b) {
            b.Pb(a)
        });
        nt(this, {})
    };
    var pt = {},
        qt = (pt["data-google-av-cxn"] = "_avicxn_", pt["data-google-av-cpmav"] = "_cvu_", pt["data-google-av-metadata"] = "_avm_", pt["data-google-av-adk"] = "_adk_", pt["data-google-av-btr"] = void 0, pt["data-google-av-override"] = void 0, pt["data-google-av-dm"] = void 0, pt["data-google-av-immediate"] = void 0, pt["data-google-av-aid"] = void 0, pt["data-google-av-naid"] = void 0, pt["data-google-av-inapp"] = void 0, pt["data-google-av-slift"] = void 0, pt["data-google-av-itpl"] = void 0, pt["data-google-av-ext-cxn"] = void 0, pt["data-google-av-rs"] = void 0, pt["data-google-av-flags"] = void 0, pt["data-google-av-turtlex"] = void 0, pt["data-google-av-ufs-integrator-metadata"] = void 0, pt["data-google-av-vattr"] = void 0, pt["data-google-av-vrus"] = void 0, pt),
        rt = {},
        st = (rt["data-google-av-adk"] = "googleAvAdk", rt["data-google-av-btr"] = "googleAvBtr", rt["data-google-av-cpmav"] = "googleAvCpmav", rt["data-google-av-dm"] = "googleAvDm", rt["data-google-av-ext-cxn"] = "googleAvExtCxn", rt["data-google-av-immediate"] = "googleAvImmediate", rt["data-google-av-inapp"] = "googleAvInapp", rt["data-google-av-itpl"] = "googleAvItpl", rt["data-google-av-metadata"] = "googleAvMetadata", rt["data-google-av-naid"] = "googleAvNaid", rt["data-google-av-override"] = "googleAvOverride", rt["data-google-av-rs"] = "googleAvRs", rt["data-google-av-slift"] = "googleAvSlift", rt["data-google-av-cxn"] = "googleAvCxn", rt["data-google-av-aid"] = void 0, rt["data-google-av-flags"] = "googleAvFlags", rt["data-google-av-turtlex"] = "googleAvTurtlex", rt["data-google-av-ufs-integrator-metadata"] = "googleAvUfsIntegratorMetadata", rt["data-google-av-vattr"] = "googleAvVattr", rt["data-google-av-vrus"] = "googleAvVurs", rt);

    function tt(a, b) {
        if (a.g === void 0) return null;
        try {
            var c;
            var d = (c = a.g.getAttribute(b)) != null ? c : null;
            if (d !== null) return d
        } catch (g) {}
        try {
            var e = qt[b];
            if (e && (d = a.g[e], d !== void 0)) return d
        } catch (g) {}
        try {
            var f = st[b];
            if (f) return Ec(a.g, f)
        } catch (g) {}
        return null
    }

    function ut(a) {
        return S(function(b) {
            return tt(b, a)
        })
    };
    var vt = N(function(a) {
        return S(function(b) {
            return a.map(function(c) {
                return tt(b, c)
            })
        })
    }(["data-google-av-cxn", "data-google-av-turtlex"]), S(function(a) {
        var b = y(a);
        a = b.next().value;
        b = b.next().value;
        if (!a) {
            if (b !== null) return [];
            throw new jr;
        }
        return a.split("|")
    }));

    function wt() {
        return N(Jp(function(a) {
            return a.element.j(vt, zq(function() {
                return hp([""])
            })).j(S(function(b) {
                return {
                    xa: b,
                    Sc: a
                }
            }))
        }), Iq(function(a) {
            return a.xa.sort().join(";")
        }), S(function(a) {
            return a.Sc
        }))
    };

    function Z(a) {
        this.value = a
    }

    function xt(a, b) {
        return hp(a.value).j(Y(b, 1))
    }
    var yt = new Z(!1);

    function zt() {
        return Jp(function(a) {
            return Xo(At(a)).j(As(a.B))
        })
    }

    function At(a) {
        return a.document.querySelectorAll(".GoogleActiveViewElement,.GoogleActiveViewClass").map(function(b) {
            return new ls(b)
        })
    };

    function Bt(a) {
        var b = a.ef,
            c = a.document.i;
        return Xp(hp({}), c, b).j(S(function() {
            return a
        }))
    };

    function Ct() {
        return N(T(function(a) {
            return a !== void 0
        }), S(function(a) {
            return a
        }))
    };

    function Dt() {
        return function(a) {
            var b = [];
            return a.j(T(function(c) {
                if (c.g === void 0 || b.some(function(d) {
                        return d.g === c.g
                    })) return !1;
                b.push(c);
                return !0
            }))
        }
    };

    function Et(a, b) {
        b = b === void 0 ? Mo : b;
        return Xp(Bt(a), b).j(zt(), Dt(), Ct(), Y(a.B, 1))
    };

    function Ft(a) {
        a = a.global;
        if (typeof a.__google_lidar_ === "undefined") return a.__google_lidar_ = 1, !1;
        a.__google_lidar_ = Number(a.__google_lidar_) + 1;
        var b = a.__google_lidar_adblocks_count_;
        if (typeof b === "number" && b > 0 && (a = a.__google_lidar_radf_, typeof a === "function")) try {
            a()
        } catch (c) {}
        return !0
    }

    function Gt(a) {
        var b = a.global;
        b.osdlfm = function() {
            return b.__google_lidar_radf_
        };
        if (b.__google_lidar_radf_ !== void 0) return Mo;
        b.__google_lidar_adblocks_count_ = 1;
        var c = new Q;
        b.__google_lidar_radf_ = function() {
            return void c.next(a)
        };
        return c.j(Pr(a.P, 743))
    };
    var Ht = {
        considerOmidZOrderOcclusions: [Lm, !1],
        extraPings: [Mm, 0],
        extrapolators: [Nm, !1],
        rxlidarStatefulBeacons: [Sm, !1],
        shouldIgnoreAdChoicesIcon: [Vm, !1],
        dedicatedViewableAttributionPing: [new Jm("45389692"), 0],
        useReachIntegrationPolyfill: [Ym, !1],
        useReachIntegrationSharedStorage: [Zm, !0],
        sendBrowserIdInsteadOfVPID: [Tm, !1],
        waitForImpressionColleague: [$m, !1],
        fetchLaterBeacons: [Om, !1],
        rxInNonrx: [Rm, !1],
        addQueryIdToErrorPing: [Km, !1],
        shouldSendExplicitDisplayMeasurablePing: [Wm, !1],
        reachUseCreateWorklet: [Qm, !1],
        tosCustomTimeoutMillis: [Xm, 36E5],
        shouldCacheTimeMetricsInLocalStorage: [Um, !0],
        omakaseAdStatsResetVersion: [Pm, 2]
    };

    function It(a) {
        return Object.entries(Ht).reduce(function(b, c) {
            var d = y(c);
            c = d.next().value;
            var e = y(d.next().value);
            d = e.next().value;
            e = e.next().value;
            var f;
            b[c] = (f = a == null ? void 0 : $i(a, d)) != null ? f : e;
            return b
        }, {})
    };

    function Ag(a) {
        this.F = bg(a, void 0, void 0, 2048)
    }
    x(Ag, Qh);

    function Jt(a) {
        return Mf(kg(a, 3))
    }

    function Kt(a) {
        return xf(kg(a, 5))
    }

    function Lt(a) {
        return Gg(a, 7)
    };
    var Mt = [0, Mi, -2, Li, -1, Hi, Li];

    function Nt(a) {
        this.F = bg(a, void 0, void 0, 2048)
    }
    x(Nt, Qh);
    var Ot = Ui(Nt);

    function Pt(a) {
        this.F = bg(a, void 0, void 0, 2048)
    }
    x(Pt, Qh);
    var Qt = [0, Hi, -3];
    var Rt = [0, Ni, -4, Pi, Li, Hi, Ci, Ni, Ci, Ni, Hi, Ni, -1, Qt, Oi, Gi, Ni, Fi, -1, Hi, -1, Fi, Ci, [0, Fi, Hi, -1, Pi, Ci, Fi], Ai, Ni, [0, Hi, -6], Li, Ci, [0, Pi, -3], Qt];
    var St = [0, Mi, -1, Li, Rt, Ii, -1, Qi, Hi, Li, Hi];

    function Tt(a) {
        this.F = bg(a, void 0, void 0, 2048)
    }
    x(Tt, Qh);
    var Ut = [0, Mi, Hi];

    function Vt(a) {
        this.F = bg(a, void 0, void 0, 2048)
    }
    x(Vt, Qh);

    function Wt(a) {
        return Bg(a, Pt, 1)
    };
    var Xt = Si(Vt, [0, St, Mt, Ut]);

    function Yt(a) {
        this.i = a === void 0 ? !1 : a;
        this.Fe = new Map
    }
    Yt.prototype.start = function(a, b, c, d) {
        var e = this;
        if (this.gd === void 0 && a.I) {
            var f = a.I;
            this.g = d;
            c = !this.i && Ft(f);
            d = this.i ? Mo : Gt(f);
            d = Et(f, d);
            this.gd = (c ? Mo : d.j(S(function(g) {
                var h = h === void 0 ? Symbol() : h;
                return Object.freeze({
                    Hb: h,
                    element: xt(new Z(g), f.B)
                })
            }), wt())).subscribe(function(g) {
                var h = g.Hb;
                e.Fe.set(h, g);
                g.element.j(Gq(1)).subscribe(function(k) {
                    var l = tt(k, "data-google-av-flags"),
                        m = new Zi;
                    l !== null && aj(m, l);
                    l = It(m);
                    k = tt(k, "data-google-av-ufs-integrator-metadata");
                    a: {
                        if (k !== null) try {
                            var q = Xt(k);
                            break a
                        } catch (t) {}
                        q = new Vt
                    }
                    b(h, q, l)
                })
            });
            c && this.dispose();
            a.oa && Mr(a.oa)
        }
    };
    Yt.prototype.dispose = function() {
        var a, b;
        (a = this.gd) == null || (b = a.unsubscribe) == null || b.call(a);
        this.gd = void 0;
        var c;
        (c = this.g) == null || c.call(this);
        this.g = void 0
    };

    function Zt(a) {
        var b = bt(a);
        return b === null ? new Z(null) : b.j(S(function(c) {
            c = Rh(c);
            if (de) c = Ia.btoa(c);
            else {
                for (var d = [], e = 0, f = 0; f < c.length; f++) {
                    var g = c.charCodeAt(f);
                    g > 255 && (d[e++] = g & 255, g >>= 8);
                    d[e++] = g
                }
                c = ee(d)
            }
            return c
        }), Gq(1), Y(a.B, 1))
    };

    function $t(a) {
        var b, c, d;
        return !!a && typeof a.active === "boolean" && typeof((b = a.clock) == null ? void 0 : b.now) === "function" && ((c = a.clock) == null ? void 0 : c.timeline) !== void 0 && !((d = a.L) == null || !d.timestamp) && typeof a.ha === "function" && typeof a.ia === "function" && typeof a.Ba === "function" && typeof a.map === "function" && typeof a.Da === "function"
    };

    function au(a) {
        function b(c) {
            return typeof c === "boolean" || typeof c === "string" || typeof c === "number" || c === void 0 || c === null
        }
        return b(a) ? !0 : Array.isArray(a) ? a.every(b) : typeof a === "object" ? Object.keys(a).every(function(c) {
            return typeof c === "string"
        }) && Object.values(a).every(function(c) {
            return Array.isArray(c) ? c.every(b) : b(c)
        }) : !1
    }

    function bu(a) {
        if (au(a)) return a;
        if ($t(a)) return {
            L: {
                value: bu(a.L.value),
                timestamp: rr(a.L.timestamp, new pr(0, a.L.timestamp.timeline))
            },
            active: a.active
        };
        try {
            return JSON.parse(JSON.stringify(a))
        } catch (b) {}
        return String(a)
    };

    function cu(a, b) {
        return new O(function(c) {
            function d(q) {
                l.add(q);
                po(a, function() {
                    l.size === b.length && c.complete()
                }, 1)
            }

            function e(q, t) {
                l.add(t);
                k.add(t);
                po(a, function() {
                    c.error(q)
                }, 1)
            }

            function f(q, t) {
                a.Kg ? (h[t] = q, k.add(t), g || (g = !0, po(a, function() {
                    g = !1;
                    c.next(db(h))
                }, 1))) : c.error(new kr(t))
            }
            var g = !1,
                h = Array(b.length);
            h.fill(void 0);
            var k = new Set,
                l = new Set,
                m = b.map(function(q, t) {
                    return q.subscribe(function(r) {
                        return void f(r, t)
                    }, function(r) {
                        return void e(r, t)
                    }, function() {
                        return void d(t)
                    })
                });
            return function() {
                m.forEach(function(q) {
                    return void q.unsubscribe()
                })
            }
        })
    };

    function du(a, b, c) {
        function d() {
            if (b.Pa) {
                var v = b.Pa,
                    C = v.next;
                var P = {
                    creativeId: to(b.uc, c),
                    requiredSignals: e,
                    signals: Object.assign({}, f),
                    hasPrematurelyCompleted: g,
                    errorMessage: h,
                    erroredSignalKey: k
                };
                P = {
                    specMajor: 2,
                    specMinor: 0,
                    specPatch: 0,
                    timestamp: rr(b.C.now(), new pr(0, b.C.timeline)),
                    instanceId: to(b.uc, b.Hb),
                    creativeState: P
                };
                C.call(v, P)
            }
        }
        for (var e = Object.keys(a), f = {}, g = !1, h = null, k = null, l = {}, m = new Set, q = [], t = [], r = y(e), w = r.next(), u = {}; !w.done; u = {
                wa: void 0
            }, w = r.next()) u.wa = w.value, w = a[u.wa], w instanceof Z ? (l[u.wa] = w.value, m.add(u.wa), b.Pa && (f[String(u.wa)] = bu(w.value))) : (w = w.j(U(function(v, C) {
            return $t(v) || $t(C) ? !1 : v === C
        }), S(function(v) {
            return function(C) {
                b.Pa && (f[String(v.wa)] = bu(C), d());
                var P = {};
                return P[v.wa] = C, P
            }
        }(u)), zq(function(v) {
            return function(C) {
                if (C instanceof kr) throw new lr(String(v.wa));
                throw C;
            }
        }(u)), Yq(function(v) {
            return function() {
                m.add(v.wa)
            }
        }(u), function(v) {
            return function(C) {
                k = String(v.wa);
                h = String(C);
                d()
            }
        }(u), function(v) {
            return function() {
                m.has(v.wa) || (g = !0, d())
            }
        }(u))), t.push(u.wa), q.push(w));
        (a = Object.keys(f).length > 0) && d();
        r = cu(b.B, q).j(zq(function(v) {
            if (v instanceof kr) throw new mr(String(t[v.g]));
            throw v;
        }), S(function(v) {
            return Object.freeze(Object.assign.apply(Object, [{}, l].concat(A(v))))
        }));
        return (q = q.length > 0) && a ? Xp(hp(Object.freeze(l)), r) : q ? r : hp(Object.freeze(l))
    };

    function eu(a, b, c, d, e) {
        return a.P.bc.bind(a.P)(733, function() {
            var f = {};
            try {
                return b.j(zq(function(g) {
                    d(Object.assign({}, f, {
                        error: g
                    }));
                    return Mo
                }), Jp(function(g) {
                    try {
                        var h = c(a, g)
                    } catch (l) {
                        return d(Object.assign({}, f, {
                            error: l instanceof Error ? l : String(l)
                        })), Mo
                    }
                    var k = {};
                    return du(h, a, g.Hb).j(Yq(function(l) {
                        k = l
                    }), Sq(1), rp()).j(e, zq(function(l) {
                        d(Object.assign({}, k, {
                            error: l
                        }));
                        return Mo
                    }), Mq(void 0), S(function() {
                        return !0
                    }))
                })).j(Uq(function(g) {
                    return g + 1
                }, 0), zq(function(g) {
                    d(Object.assign({}, f, {
                        error: g
                    }));
                    return Mo
                }))
            } catch (g) {
                return d(Object.assign({}, f, {
                    error: g
                })), Mo
            }
        })()
    };

    function fu(a, b) {
        return N(X(function(c) {
            var d = a(c),
                e = b(c),
                f = {};
            return d && e && f ? new O(function(g) {
                e(d, f, function(h) {
                    g.next(Object.assign({}, c, {
                        pb: h
                    }));
                    g.complete()
                });
                return function() {}
            }) : Yp
        }), T(function(c) {
            return c.pb
        }))
    };
    var gu = N(T(function(a) {
        var b = a.N;
        var c = a.rc;
        var d = a.cc;
        var e = a.Wb;
        var f = a.Bb;
        var g = a.Ya;
        a = a.qc;
        return g !== void 0 && a !== void 0 && b !== void 0 && c !== void 0 && d !== void 0 && (!f || e !== void 0)
    }), Xq(function(a) {
        return !(a.Xe === !1 && a.Hd !== void 0)
    }, !1), T(function(a) {
        var b = a.Xe;
        var c = a.wc;
        var d = a.Xg;
        a = a.rc;
        return d ? !!c && a !== void 0 && (a == null ? void 0 : a.length) > 0 : !!b
    }), fu(function(a) {
        return a.qc
    }, function(a) {
        return a.Ya
    }), S(function(a) {
        a.Bb || a.cc(a.rc, a).forEach(function(b) {
            a.N.O(b).sendNow()
        })
    }), Gq(1), Eq());

    function hu(a) {
        var b = b === void 0 ? {} : b;
        this.i = a;
        this.config = {
            maxAdKeys: b.maxAdKeys || 50,
            maxHourlyEvents: b.maxHourlyEvents || 2,
            maxDailyEvents: b.maxDailyEvents || 2,
            maxWeeklyEvents: b.maxWeeklyEvents || 2
        };
        this.g = new Map
    }

    function iu(a) {
        try {
            var b = JSON.stringify(Array.from(a.g.entries()));
            a.i.setItem("adStatsCache", b)
        } catch (c) {
            a.i.reportError(c)
        }
    }

    function ju(a, b, c) {
        return Da(function(d) {
            return d.g(a.i.performExclusiveLockedOperation("avOmakaseLock", function() {
                a: {
                    var e = a.i.getItem("adStatsCache");
                    if (e) try {
                        var f = new Map(JSON.parse(e));
                        break a
                    } catch (h) {
                        a.i.reportError(h)
                    }
                    f = new Map
                }
                a.g = f;f = a.g.get(b) || {
                    h: {},
                    d: {},
                    w: {}
                };e = f.h;
                var g = new Date;g.setMinutes(0, 0, 0);ku(e, Math.floor(g.getTime() / 1E3).toString(), c, a.config.maxHourlyEvents);e = f.d;g = new Date;g.setHours(0, 0, 0, 0);ku(e, Math.floor(g.getTime() / 1E3).toString(), c, a.config.maxDailyEvents);e = f.w;g = new Date;g = new Date(g.setDate(g.getDate() - g.getDay()));g.setHours(0, 0, 0, 0);ku(e, Math.floor(g.getTime() / 1E3).toString(), c, a.config.maxWeeklyEvents);a.g.has(b) ? a.g.delete(b) : a.g.size >= a.config.maxAdKeys && a.g.size >= a.config.maxAdKeys && (e = a.g.keys().next().value, a.g.delete(e));f.ts = Date.now();a.g.set(b, f);iu(a)
            }), 0)
        })
    }

    function lu(a, b) {
        var c = c === void 0 ? 1 : c;
        return Da(function(d) {
            return d.g(ju(a, b, {
                c: c,
                v: 0,
                cTos: 0
            }), 0)
        })
    }

    function mu(a, b) {
        var c = c === void 0 ? 1 : c;
        return Da(function(d) {
            return d.g(ju(a, b, {
                c: 0,
                v: c,
                cTos: 0
            }), 0)
        })
    }

    function nu(a, b, c) {
        return Da(function(d) {
            return d.g(ju(a, b, {
                c: 0,
                v: 0,
                cTos: c
            }), 0)
        })
    }

    function ku(a, b, c, d) {
        a[b] ? (a[b].c += c.c, a[b].cTos += c.cTos, a[b].v += c.v) : a[b] = {
            c: c.c,
            cTos: c.cTos,
            v: c.v
        };
        b = Object.keys(a);
        b.length > d && delete a[b[0]]
    }

    function ou(a, b) {
        var c;
        return Da(function(d) {
            if (d.i == 1) {
                if (!a.i.hasLocalStorageAccess()) return d.return(4);
                c = 0;
                return d.g(a.i.performExclusiveLockedOperation("avOmakaseLock", function() {
                    var e = a.i.getItem("adStatsReset");
                    b > Number(e || "0") ? (e !== null ? (a.g.clear(), iu(a), c = 1) : c = 3, a.i.setItem("adStatsReset", b.toString())) : c = 2
                }), 2)
            }
            return d.return(c)
        })
    };

    function pu(a) {
        a = a.ia().value.slice(0, 3).reduce(function(b, c) {
            return b + c
        }, 0);
        return Math.min(a, 61500)
    }

    function qu(a) {
        var b;
        return function(c) {
            var d = c.j(Xq(function(g) {
                return g.Hd === void 0
            }), Wq(function(g) {
                return g.ge === void 0
            }), Yq(function(g) {
                g.ge && b === void 0 && (b = new hu(a))
            }), Xq(function(g) {
                return !!g.ge
            }), Sq(1), rp());
            c = d.j(S(function(g) {
                return g.Gg
            }), T(function(g) {
                return g !== void 0
            }), Gq(1), Jp(function(g) {
                var h, k;
                return Da(function(l) {
                    if (l.i == 1) return l.g((h = b) == null ? void 0 : ou(h, g), 2);
                    k = l.l;
                    var m = {
                        rk: g.toString(),
                        outcome: k.toString()
                    };
                    m = m === void 0 ? {} : m;
                    var q = a.I;
                    m = m === void 0 ? {} : m;
                    var t = Object.assign({}, {
                        reason: "cache_reset_check"
                    }, m);
                    m = new ru("https://pagead2.googlesyndication.com/pagead/gen_204");
                    m.g.set("id", "av-js");
                    m.g.set("type", "omakase");
                    t = JSON.stringify(t);
                    m.g.set("jp", t);
                    m.g.set("v", "unreleased");
                    q.N.O(m.toString()).sendNow();
                    l.H()
                })
            }));
            var e = d.j(T(function(g) {
                    return !!g.wc
                }), Gq(1), Jp(function(g) {
                    var h = g.za;
                    var k;
                    return Da(function(l) {
                        return h ? l.g((k = b) == null ? void 0 : lu(k, h), 0) : l.ea(0)
                    })
                })),
                f = d.j(T(function(g) {
                    g = g.pd;
                    return !!g && g.ia().value
                }), Gq(1), Jp(function(g) {
                    var h = g.za;
                    var k;
                    return Da(function(l) {
                        return h ? l.g((k = b) == null ? void 0 : mu(k, h), 0) : l.ea(0)
                    })
                }));
            d = d.j(S(function(g) {
                return g.yg
            }), U(), Zq(d.j(S(function(g) {
                return {
                    pa: g.pa,
                    za: g.za
                }
            }))), T(function(g) {
                g = y(g);
                g.next();
                return !!g.next().value.pa
            }), S(function(g) {
                g = y(g);
                g.next();
                var h = g.next().value;
                g = h.pa;
                h = h.za;
                return {
                    ac: pu(g),
                    za: h
                }
            }), Xq(function(g) {
                return g.ac < 61500
            }, !0), U(function(g, h) {
                return g.ac === h.ac
            }), V({
                ac: 0,
                za: null
            }), Rq(), Jp(function(g) {
                g = y(g);
                var h = g.next().value.ac;
                g = g.next().value;
                var k = g.ac;
                var l = g.za;
                var m;
                return Da(function(q) {
                    return l && k ? q.g((m = b) == null ? void 0 : nu(m, l, k - h), 0) : q.ea(0)
                })
            }));
            return Xp(c, e, f, d).j(Eq())
        }
    };

    function su(a) {
        var b = new Map;
        if (typeof a !== "object" || a === null) return b;
        Object.values(a).forEach(function(c) {
            c && typeof c.ia === "function" && (b.has(c.clock.timeline) || b.set(c.clock.timeline, c.clock.now()))
        });
        return b
    };

    function tu(a, b, c) {
        var d = uu,
            e = vu;
        c = c === void 0 ? .01 : c;
        return function(f) {
            c > 0 && Math.random() <= c && (a.global.HTMLFencedFrameElement && a.global.fence && typeof a.global.fence.reportEvent === "function" && a.global.fence.reportEvent({
                eventType: "active-view-error",
                eventData: "",
                destination: ["buyer"]
            }), f = Object.assign({}, f, {
                errorMessage: f.error instanceof Error && f.error.message ? f.error.message : String(f.error),
                Le: f.error instanceof Error && f.error.stack ? String(f.error.stack) : null,
                Wf: f.error instanceof Error && f.error.name ? String(f.error.name) : null,
                Uf: String(a.P.le),
                Vf: f.escapedQueryId
            }), d(Object.assign({}, f, {
                fa: function() {
                    return function(g) {
                        try {
                            return e(Object.assign({}, g))
                        } catch (h) {
                            return {}
                        }
                    }
                }(),
                xa: [b]
            }), su(f)).forEach(function(g) {
                a.N.O(g).sendNow()
            }))
        }
    };
    var wu = N(S(function(a) {
        var b = a.N;
        var c = a.Yf;
        if (b === void 0 || c === void 0) return !1;
        if (a.Hd !== void 0) return !0;
        if (c === null) return !1;
        for (a = 0; a < c; a++) b.O("https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=extra&rnd=" + Math.floor(Math.random() * 1E7)).sendNow();
        return !0
    }), Xq(function(a) {
        return !a
    }), Eq());
    var xu = N(T(function(a) {
        return !!a.wc
    }), T(function(a) {
        var b = a.shouldSendExplicitDisplayMeasurablePing;
        a = a.xb;
        var c, d;
        return (d = b && ((c = a == null ? void 0 : a.length) != null ? c : 0) > 0) != null ? d : !1
    }), T(function(a) {
        return a.fa !== void 0 && a.xb !== void 0 && a.Ib !== void 0 && a.Sb !== void 0 && a.N !== void 0
    }), S(function(a) {
        return Object.assign({}, a, {
            jd: su(a)
        })
    }), S(function(a) {
        a.Ib(Object.assign({}, a, {
            xa: a.xb,
            fa: a.fa,
            Dc: a.Sb,
            Ic: 3,
            Ec: "m"
        }), a.jd).forEach(function(b) {
            a.N.O(b).sendNow()
        });
        return !0
    }), Xq(function(a) {
        return !a
    }), Eq());

    function vu(a) {
        return {
            id: a.Dc,
            mcvt: a.Ac,
            p: a.Tc,
            asp: a.zh,
            tm: a.jb,
            tu: a.kb,
            mtos: a.Bc,
            tos: a.pa,
            v: a.Hf,
            bin: a.Ia,
            avms: a.S,
            bs: a.Be,
            mc: a.bf,
            "if": a.Qf,
            vu: a.Sf,
            app: a.yb,
            mse: a.Zd,
            mtop: a.ae,
            itpl: a.Qd,
            adk: a.za,
            exk: a.Ff,
            rs: a.X,
            la: a.ja,
            cr: a.Rd,
            uach: a.Hc,
            vs: a.Ic,
            r: a.Ec,
            pay: a.dg,
            co: a.Jf,
            rst: a.Df,
            rpt: a.Cf,
            isd: a.ig,
            lsd: a.tg,
            context: a.Uf,
            msg: a.errorMessage,
            stack: a.Le,
            name: a.Wf,
            ec: a.eg,
            sfr: a.ke,
            met: a.sc,
            wmsd: a.re,
            pv: a.Vh,
            epv: a.Ch,
            pbe: a.We,
            fle: a.gg,
            vae: a.hg,
            spb: a.kf,
            sfl: a.jf,
            ffslot: a.ng,
            reach: a.Mg,
            io2: a.ld,
            rxdbg: a.ai,
            omida: a.Jh,
            omidp: a.Qh,
            omidpv: a.Rh,
            omidor: a.Ph,
            omidv: a.Th,
            omids: a.Sh,
            omidam: a.Ih,
            omidct: a.Kh,
            omidia: a.Nh,
            omiddc: a.Lh,
            omidlat: a.Oh,
            omiddit: a.Mh,
            qid: a.Vf
        }
    };

    function yu() {
        var a = D.apply(0, arguments);
        return function(b) {
            var c = b.j(Sq(1), rp());
            b = a.map(function(d) {
                return c.j(d, Mq(!0))
            });
            return Ep(b).j(Gq(1), Eq())
        }
    };

    function zu() {
        var a = D.apply(0, arguments);
        return function(b) {
            var c = b.j(Sq(1), rp());
            b = a.map(function(d) {
                return c.j(d, Mq(!0))
            });
            return Xp.apply(null, A(b)).j(Gq(1), Eq())
        }
    };

    function Au() {
        var a = yu(xu, Bu),
            b = Cu;
        return function(c) {
            var d = c.j(Sq(1), rp());
            c = d.j(a, Mq(!0));
            d = d.j(N(b, Sq(), rp()), Mq(!0));
            c = Ep([c, d]);
            return bq(c, d).j(Gq(1), Eq())
        }
    };

    function Cu(a) {
        var b = [];
        return a.j(S(function(c) {
            var d = c.N,
                e = c.Zf,
                f = c.pa,
                g = c.Qg,
                h = c.fa,
                k = c.Pg,
                l = c.lf,
                m = c.Ib,
                q = c.pd,
                t = c.wc,
                r = c.We,
                w = c.kf,
                u = c.jf,
                v = c.ne;
            if (!c.Se || !t || c.Bc === void 0 || f === void 0 || g === void 0 || h === void 0 || k === void 0 || m === void 0 || d === void 0) return !1;
            if (c.Bb) {
                if (l === void 0) return !1;
                g = c.Wb;
                if (!g) return !1;
                g({
                    eventType: "active-view-time-on-screen",
                    eventData: v != null ? v : "",
                    destination: ["buyer"]
                });
                return !0
            }
            if (!(r || u || l)) return !1;
            v = su(c);
            var C;
            q = (C = q == null ? void 0 : q.Ca(v).value) != null ? C : !1;
            C = m(Object.assign({}, c, {
                Dc: k,
                Ic: q ? 4 : 3,
                Ec: l != null ? l : "u",
                fa: h,
                xa: g
            }), v);
            if (r) {
                for (; b.length > g.length;) c = void 0, (c = b.shift()) == null || c.deactivate();
                C.forEach(function(J, da) {
                    da >= b.length ? b.push(d.O(J)) : b[da].url = J
                });
                return w && e && l !== void 0 ? (C.forEach(function(J) {
                    e.O(J).sendNow()
                }), !0) : l !== void 0
            }
            if (w && e && l !== void 0) return C.forEach(function(J) {
                e.O(J).sendNow()
            }), !0;
            if (u && e) {
                for (; b.length > g.length;) w = void 0, (w = b.shift()) == null || w.deactivate();
                var P = m(Object.assign({}, c, {
                    Dc: k,
                    Ic: q ? 4 : 3,
                    Ec: l != null ? l : "u",
                    fa: h,
                    xa: ["https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=fetch&later&lidartos"]
                }), v)[0];
                C.forEach(function(J, da) {
                    da >= b.length ? b.push(d.O(P, {
                        Ke: !0
                    })) : b[da].url = P
                });
                return l !== void 0 ? (C.forEach(function(J) {
                    e.O(J).sendNow()
                }), !0) : l !== void 0
            }
            return l !== void 0 ? (C.forEach(function(J) {
                d.O(J).sendNow()
            }), !0) : !1
        }), Xq(function(c) {
            return !c
        }), Eq())
    };

    function Du() {
        return function(a) {
            return a.j(S(function(b) {
                return b
            }))
        }
    };

    function Eu(a) {
        return function(b) {
            return new O(function(c) {
                var d = !1,
                    e = b.j(Du()).subscribe(function(f) {
                        d = !0;
                        c.next(f)
                    }, c.error.bind(c), c.complete.bind(c));
                po(a, function() {
                    d || c.next(null)
                }, 3);
                return e
            })
        }
    };

    function Fu(a, b) {
        return function(c) {
            return c.j(X(function(d) {
                return new O(function(e) {
                    function f() {
                        h.disconnect();
                        k.unsubscribe()
                    }
                    var g = a.MutationObserver;
                    if (g && d.g !== void 0) {
                        var h = new g(function(l) {
                            e.next(l)
                        });
                        h.observe(d.g, b);
                        var k = d.i.subscribe(f);
                        return f
                    }
                })
            }))
        }
    };
    var Gu = {
        uh: 0,
        gh: 1,
        jh: 2,
        hh: 3,
        0: "UNKNOWN",
        1: "DEFER_MEASUREMENT",
        2: "DO_NOT_DEFER_MEASUREMENT",
        3: "DEFER_MEASUREMENT_AND_PING"
    };

    function Hu(a, b) {
        var c = b.j(Fu(a, {
            attributes: !0
        }), Y(a.B, 1));
        return Ep([b, c.j(Y(a.B, 1), Eu(a.B))]).j(S(function(d) {
            return y(d).next().value
        }), ut("data-google-av-dm"), S(Iu))
    }

    function Iu(a) {
        return a && a in Gu ? Number(a) : 2
    };

    function Ju(a) {
        if (a.wg === 3) return null;
        if (a.lf !== void 0) {
            var b = a.Mf === !1 ? "n" : null;
            if (b !== null) return b
        }
        return a.Xc instanceof dr ? "msf" : a.Ed instanceof er ? "c" : a.Lf === !1 ? "pv" : a.Xc || a.Ed ? "x" : null
    }
    var Ku = N(T(function(a) {
        return a.xb !== void 0 && a.fa !== void 0 && a.Ib !== void 0 && a.Sb !== void 0 && a.N !== void 0
    }), T(function(a) {
        return Ju(a) !== null
    }), fu(function(a) {
        return a.Oc
    }, function(a) {
        return a.Ya
    }), S(function(a) {
        if (a.Bb) {
            var b = a.Wb;
            if (b) {
                var c;
                b({
                    eventType: "active-view-unmeasurable",
                    eventData: (c = a.ne) != null ? c : "",
                    destination: ["buyer"]
                })
            }
        } else {
            c = void 0;
            var d = Ju(a);
            if (d === "x") {
                var e, f = (e = a.Xc) != null ? e : a.Ed;
                f && (b = f.stack, c = f.message)
            }
            a.Ib(Object.assign({}, a, {
                xa: a.xb,
                fa: a.fa,
                Dc: a.Sb,
                Ic: 2,
                Ec: d,
                errorMessage: c,
                Le: b
            }), su(a)).forEach(function(g) {
                a.N.O(g).sendNow()
            })
        }
    }), Gq(1), Eq());

    function Lu() {
        this.startTime = Math.floor(Date.now() / 1E3 - 1704067200);
        this.g = 0
    }

    function Mu(a) {
        var b = a.g.toString(10).padStart(2, "0");
        b = "" + a.startTime + b;
        a.g < 99 && a.g++;
        return b
    };

    function Nu(a, b) {
        return typeof a === "string" ? encodeURIComponent(a) : typeof a === "number" ? String(a) : Array.isArray(a) ? a.map(function(c) {
            return Nu(c, b)
        }).join(",") : a instanceof pr ? a.toString() : a && typeof a.ia === "function" ? Nu(a.Ca(b).value, b) : a === !0 ? "1" : a === !1 ? "0" : a === void 0 || a === null ? null : a instanceof Lu ? Mu(a) : [a.top, a.left, a.top + a.height, a.left + a.width].join()
    }

    function Ou(a, b) {
        a = Object.entries(a).map(function(c) {
            var d = y(c);
            c = d.next().value;
            d = d.next().value;
            d = Nu(d, b);
            return d === null ? "" : c + "=" + d
        }).filter(function(c) {
            return c !== ""
        });
        return a.length ? a.join("&") : ""
    };

    function Pu(a, b) {
        var c = Object.assign({}, a),
            d = a.Hc;
        c = (delete c.Hc, c);
        c = a.fa(c);
        var e = Ou(c, b);
        return Va(a.xa, function(f) {
            var g = "";
            typeof d === "string" && (g = "&" + Ou({
                uach: d
            }, b));
            var h = {};
            return $l(f, (h.VIEWABILITY = e, h)) + g
        })
    };

    function uu(a, b) {
        var c = a.fa(a),
            d = Ou(c, b);
        return d ? Va(a.xa, function(e) {
            e = e.indexOf("?") >= 0 ? e : e + "?";
            e = "?&".indexOf(e.slice(-1)) >= 0 ? e : e + "&";
            return e + d
        }) : a.xa
    };

    function Qu(a, b) {
        return Va(a, function(c) {
            if (typeof b.Hc === "string") {
                var d = "&" + Ou({
                    uach: b.Hc
                }, new Map);
                return c.substring(c.length - 7) == "&adurl=" ? c.substring(0, c.length - 7) + d + "&adurl=" : c + d
            }
            return c
        })
    };
    var Bu = N(T(function(a) {
        return a.fa !== void 0 && a.xb !== void 0 && a.Ib !== void 0 && a.Sb !== void 0 && a.N !== void 0
    }), S(function(a) {
        return Object.assign({}, a, {
            jd: su(a)
        })
    }), T(function(a) {
        var b = a.pd;
        var c = a.wc;
        a = a.jd;
        var d;
        return !!c && ((d = b == null ? void 0 : b.Ca(a).value) != null ? d : !1)
    }), fu(function(a) {
        return a.Pc
    }, function(a) {
        return a.Ya
    }), S(function(a) {
        var b = a.N,
            c = a.ne;
        if (a.Bb) {
            var d = a.Wb;
            if (!d) return !1;
            d({
                eventType: "active-view-viewable",
                eventData: c != null ? c : "",
                destination: ["buyer"]
            });
            return !0
        }
        c = a.Ib(Object.assign({}, a, {
            xa: a.xb,
            fa: a.fa,
            Dc: a.Sb,
            Ic: 4,
            Ec: "v"
        }), a.jd);
        (d = a.Fd) && d.length > 0 && a.cc && a.cc(d, a).forEach(function(e) {
            b.O(e).sendNow()
        });
        (d = a.lb) && d.length > 0 && a.cc && a.cc(d, a).forEach(function(e) {
            b.O(e).sendNow()
        });
        c.forEach(function(e) {
            b.O(e, {
                oc: a.Td
            }).sendNow()
        });
        return !0
    }), Xq(function(a) {
        return !a
    }), Eq());

    function Ru(a, b, c, d) {
        var e = Object.keys(c).map(function(h) {
                return h
            }),
            f = e.filter(function(h) {
                var k = c[h];
                h = d[h];
                return k instanceof Z && h instanceof Z && k.value === h.value
            }),
            g = f.reduce(function(h, k) {
                var l = {};
                return Object.assign({}, h, (l[k] = c[k], l))
            }, {});
        return e.reduce(function(h, k) {
            if (f.indexOf(k) >= 0) return h;
            var l = {};
            return Object.assign({}, h, (l[k] = b.j(X(function(m) {
                return (m = m ? c[k] : d[k]) && (m instanceof O || M(m.Db) && M(m.subscribe)) ? m : xt(m, a)
            })), l))
        }, g)
    };

    function Su(a) {
        return N(S(function() {
            return !0
        }), V(!1), Y(a, 1))
    };
    var Tu = {
        Zg: "asmreq",
        ah: "asmres"
    };

    function Uu(a) {
        this.F = bg(a, void 0, void 0, 2048)
    }
    x(Uu, Qh);

    function Vu(a) {
        this.F = bg(a, void 0, void 0, 2048)
    }
    x(Vu, Qh);

    function Wu(a) {
        this.F = bg(a, void 0, void 0, 2048)
    }
    x(Wu, Qh);
    var Xu = Ui(Wu);

    function Yu(a, b) {
        var c = c === void 0 ? Zs(a) : c;
        var d = new MessageChannel;
        b = b.j(S(function(f) {
            return Number(f)
        }), T(function(f) {
            return !isNaN(f) && f !== 0
        }), Yq(function(f) {
            var g = new Uu;
            Kg(g, 1, f);
            f = {
                type: "asmreq",
                payload: Rh(g)
            };
            c.postMessage(f, "*", [d.port2])
        }), Gq(1));
        var e = $s(a, d.port1).j(T(function(f) {
            return typeof f.data === "object"
        }), S(function(f) {
            var g = f.data;
            if (!Object.values(Tu).includes(g.type) || !dd(g.payload) || f.data.type !== "asmres") return null;
            try {
                return Xu(f.data.payload)
            } catch (h) {
                return null
            }
        }), T(function(f) {
            return f !== null
        }), S(function(f) {
            return f
        }));
        return b.j(X(function(f) {
            return hp(f).j(Cq(e))
        }), T(function(f) {
            var g = y(f);
            f = g.next().value;
            g = g.next().value;
            if (Ef(kg(g, 1)) != null) {
                var h = h === void 0 ? 0 : h;
                var k;
                g = ((k = Ef(kg(g, 1))) != null ? k : h) === f
            } else g = !1;
            return g
        }), S(function(f) {
            f = y(f);
            f.next();
            return f.next().value
        }), As(a.B))
    };

    function Zu(a, b, c) {
        var d = b.zc.j(Gq(1), X(function() {
            return Yu(a, c)
        }), T(function(f) {
            return Gg(f, 2) && og(f, Vu, 3) && Df(kg(f, 4)) != null && Df(kg(f, 5)) != null
        }), Gq(1), As(a.B));
        b = d.j(S(function(f) {
            var g = Bg(f, Vu, 3);
            g = Hg(g, 2);
            f = Bg(f, Vu, 3);
            f = Hg(f, 1);
            return {
                x: g,
                y: f
            }
        }), U(function(f, g) {
            return f.x === g.x && f.y === g.y
        }), Y(a.B, 1));
        var e = d.j(S(function(f) {
            return Hg(f, 4)
        }), Y(a.B, 1));
        d = d.j(S(function(f) {
            return Hg(f, 5)
        }), Y(a.B, 1));
        return {
            ig: e,
            Ef: b,
            tg: d
        }
    };

    function $u(a, b) {
        return b.zc.j(Gq(1), S(function() {
            return a.C.now().round()
        }))
    };

    function av(a, b) {
        var c = a.Md().j(S(function() {
            return "b"
        }));
        return bq(b, c).j(Gq(1), Y(a.B, 1))
    };

    function bv(a, b) {
        this.a = a;
        this.b = b;
        if (a.clock.timeline !== b.clock.timeline) throw Error();
    }
    bv.prototype.ha = function(a) {
        return a instanceof bv ? this.a.ha(a.a) && this.b.ha(a.b) : !1
    };
    bv.prototype.Ba = function(a) {
        var b = this.a.Ba(a).value,
            c = this.b.Ba(a).value;
        return {
            timestamp: a,
            value: [b, c]
        }
    };
    ea.Object.defineProperties(bv.prototype, {
        active: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.a.active || this.b.active
            }
        },
        clock: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.a.clock
            }
        },
        L: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                var a = this.a.L.timestamp.maximum(this.b.L.timestamp),
                    b = this.a.L.timestamp.equals(a) ? this.a.L.value : this.a.Ba(a).value,
                    c = this.b.L.timestamp.equals(a) ? this.b.L.value : this.b.Ba(a).value;
                return {
                    timestamp: a,
                    value: [b, c]
                }
            }
        }
    });

    function cv(a, b) {
        this.input = a;
        this.g = b;
        this.L = {
            timestamp: this.input.L.timestamp,
            value: this.g(this.input.L.value)
        }
    }
    cv.prototype.ha = function(a) {
        return a instanceof cv ? this.input.ha(a.input) && this.g === a.g : !1
    };
    cv.prototype.Ba = function(a) {
        a = this.input.Ba(a);
        return {
            timestamp: a.timestamp,
            value: this.g(a.value)
        }
    };
    ea.Object.defineProperties(cv.prototype, {
        active: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.input.active
            }
        },
        clock: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.input.clock
            }
        }
    });

    function dv(a, b, c) {
        c = c === void 0 ? function(d, e) {
            return d === e
        } : c;
        return a.timestamp.equals(b.timestamp) && c(a.value, b.value)
    };

    function ev(a, b, c) {
        this.clock = a;
        this.L = b;
        this.active = c
    }
    ev.prototype.ha = function(a) {
        return a instanceof ev ? this.active === a.active && this.clock.timeline === a.clock.timeline && dv(this.L, a.L) : !1
    };
    ev.prototype.Ba = function(a) {
        return {
            timestamp: a,
            value: this.L.value + (this.active ? Math.max(0, rr(a, this.L.timestamp)) : 0)
        }
    };

    function fv() {}
    fv.prototype.ia = function() {
        return this.Ba(this.clock.now())
    };
    fv.prototype.Ca = function(a) {
        var b = this.clock.timeline,
            c, d = (c = a.get(b)) != null ? c : this.clock.now();
        a.set(b, d);
        return this.Ba(d)
    };
    fv.prototype.map = function(a) {
        return new gv(this, a)
    };
    fv.prototype.Da = function(a) {
        return new hv(this, a)
    };

    function hv() {
        bv.apply(this, arguments);
        this.map = fv.prototype.map;
        this.Da = fv.prototype.Da;
        this.ia = fv.prototype.ia;
        this.Ca = fv.prototype.Ca
    }
    x(hv, bv);

    function iv() {
        ev.apply(this, arguments);
        this.map = fv.prototype.map;
        this.Da = fv.prototype.Da;
        this.ia = fv.prototype.ia;
        this.Ca = fv.prototype.Ca
    }
    x(iv, ev);

    function gv() {
        cv.apply(this, arguments);
        this.map = fv.prototype.map;
        this.Da = fv.prototype.Da;
        this.ia = fv.prototype.ia;
        this.Ca = fv.prototype.Ca
    }
    x(gv, cv);

    function jv(a, b) {
        this.L = b;
        this.ia = fv.prototype.ia;
        this.Ca = fv.prototype.Ca;
        this.map = fv.prototype.map;
        this.Da = fv.prototype.Da;
        this.clock = a
    }
    jv.prototype.ha = function(a) {
        return a.active
    };
    jv.prototype.Ba = function() {
        return this.L
    };
    ea.Object.defineProperties(jv.prototype, {
        active: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return !1
            }
        }
    });

    function kv(a, b) {
        return b.j(S(function(c) {
            return new jv(a.C, {
                timestamp: a.C.now(),
                value: c
            })
        }))
    };
    var lv = S(function(a) {
        return [a.value.ga.width, a.value.ga.height]
    });
    var mv = {
        qa: "ns",
        va: Cs,
        ga: Cs,
        ma: new Q,
        ca: "ns",
        G: Cs,
        da: Cs,
        ya: {
            x: 0,
            y: 0
        }
    };

    function nv(a, b) {
        return Ds(a.ga, b.ga) && Ds(a.G, b.G) && Ds(a.va, b.va) && Ds(a.da, b.da) && a.ca === b.ca && a.ma === b.ma && a.qa === b.qa && a.ya.x === b.ya.x && a.ya.y === b.ya.y
    };

    function ov(a) {
        return function(b) {
            var c;
            return b.j(Yq(function(d) {
                return void(c = d.timestamp)
            }), S(function(d) {
                return d.value
            }), a, S(function(d) {
                return {
                    timestamp: c,
                    value: d
                }
            }))
        }
    };

    function pv(a) {
        return a.da.width * a.da.height / (a.G.width * a.G.height)
    }
    var qv = ov(N(S(function(a) {
            var b;
            return (b = a.Wc) != null ? b : pv(a)
        }), S(function(a) {
            return isFinite(a) ? a : 0
        }))),
        rv = ov(N(S(function(a) {
            var b;
            return (b = a.Wc) != null ? b : pv(a)
        }), S(function(a) {
            return isFinite(a) ? a : -1
        })));

    function sv(a, b) {
        return a >= 1 ? !0 : a <= 0 ? !1 : a >= b
    };

    function tv(a) {
        return function(b) {
            return b.j(Zq(a), S(function(c) {
                var d = y(c);
                c = d.next().value;
                d = d.next().value;
                return {
                    timestamp: c.timestamp,
                    value: sv(c.value, d)
                }
            }))
        }
    };
    var uv = S(function(a) {
        if (a.value.qa === "omid") {
            if (a.value.ca === "nio") return "omio";
            if (a.value.ca === "geo") return "omgeo"
        }
        return a.value.ca === "geo" || a.value.ca === "nio" ? a.value.qa : a.value.ca
    });

    function vv() {
        return N(T(function(a, b) {
            return b > 0
        }), wv, V(-1), U())
    }
    var wv = N(T(function(a) {
        return !isNaN(a)
    }), Uq(function(a, b) {
        return isNaN(a) ? b : Math.min(a, b)
    }, NaN), U());
    var xv = ov(N(S(function(a) {
        return a.da.width * a.da.height / (a.va.width * a.va.height)
    }), S(function(a) {
        return isFinite(a) ? Math.min(1, a) : 0
    })));

    function yv(a, b, c) {
        return a ? Ep([b, c]).j(T(function(d) {
            var e = y(d);
            d = e.next().value;
            e = e.next().value;
            return d.timestamp.equals(e.timestamp)
        }), S(function(d) {
            var e = y(d);
            d = e.next().value;
            e = e.next().value;
            return d.value > e.value ? d : e
        })) : b
    }

    function zv(a) {
        return function(b) {
            var c = b.j(qv),
                d = b.j(xv);
            return a instanceof O ? a.j(X(function(e) {
                return yv(e, c, d)
            })) : yv(a.value, c, d)
        }
    };
    var Av = N(ov(S(function(a) {
        a = a.Wc ? a.G.width * a.G.height * a.Wc / (a.ga.width * a.ga.height) : a.da.width * a.da.height / (a.ga.width * a.ga.height);
        return isFinite(a) ? a : 0
    })));

    function Bv(a, b, c, d) {
        var e = d.Yc,
            f = d.Id,
            g = d.rf,
            h = d.ze,
            k = d.Ud,
            l = d.cf,
            m = d.bd;
        d = d.nf;
        b = Cv(a, c, b);
        c = Dv(a, c);
        d = Ev(b, d);
        var q = Fv(a, e, l, b),
            t = q.j(S(function(z) {
                return z.value
            }), U(), Y(a, 1), Uq(function(z, W) {
                return Math.max(z, W)
            }, 0)),
            r = q.j(S(function(z) {
                return z.value
            }), vv(), Y(a, 1)),
            w = b.j(rv, S(function(z) {
                return z.value
            }), Gq(2), U(), Y(a, 1));
        g = Gv(a, b, g, h);
        var u = g.j(V(!1), U(), S(function(z) {
            return z ? k : f
        }));
        h = q.j(tv(u), U(), Y(a, 1));
        var v = Ep([h, b]).j(T(function(z) {
            var W = y(z);
            z = W.next().value;
            W = W.next().value;
            return z.timestamp.equals(W.timestamp)
        }), S(function(z) {
            var W = y(z);
            z = W.next().value;
            W = W.next().value;
            return {
                visible: z.value,
                geometry: W.value.G
            }
        }), Uq(function(z, W) {
            return !W.visible && z.visible ? z : W
        }, {
            visible: !1,
            geometry: Cs
        }), S(function(z) {
            return z.geometry
        }), V(Cs), Y(a, 1), U(Ds));
        l = l instanceof O ? l.j(U(), Fq()) : Yp;
        u = Ep([l, u]).j(Fq());
        var C = b.j(T(function(z) {
                return z.value.qa !== "ns" && z.value.ca !== "ns"
            }), Uq(function(z) {
                return z + 1
            }, 0), V(0), Y(a, 1)),
            P = c.j(Fq(!0), V(!1), Y(a, 1));
        P = Ep([m, P]).j(S(function(z) {
            var W = y(z);
            z = W.next().value;
            W = W.next().value;
            return z && !W
        }), Y(a, 1));
        var J = b.j(Av, U()),
            da = J.j(S(function(z) {
                return z.value
            }), Uq(function(z, W) {
                return Math.max(z, W)
            }, 0), U(), Y(a, 1)),
            F = J.j(S(function(z) {
                return z.value
            }), vv(), Y(a, 1));
        return {
            he: l,
            Gc: u,
            Ja: {
                Eg: b,
                S: b.j(uv),
                Tc: v.j(U(Ds)),
                visible: h.j(U(dv)),
                me: q.j(U(dv)),
                bf: t,
                Ag: r,
                Be: b.j(lv, U(hb)),
                Rg: J,
                vg: da,
                zg: F,
                Xc: c,
                ma: xt(new Z(new Q), a),
                ja: g,
                Yc: e,
                bd: m,
                Se: P,
                Tg: C,
                Vb: w,
                ld: d
            }
        }
    }

    function Dv(a, b) {
        return b.j(T(function() {
            return !1
        }), S(function(c) {
            return c
        }), zq(function(c) {
            return xt(new Z(c), a)
        }))
    }

    function Ev(a, b) {
        a = Ep([a, b]).j(S(function(e) {
            var f = y(e);
            e = f.next().value;
            if (f.next().value && e.value.isIntersecting) return e.value.af
        }), U());
        var c = a.j(S(function(e) {
                return e === void 0 ? !0 : e
            }), Uq(function(e, f) {
                return e || !f
            }, !1)),
            d = a.j(Uq(function(e, f) {
                return f === void 0 ? e : f ? !1 : e != null ? e : !0
            }, void 0), S(function(e) {
                return !!e
            }));
        return Ep([b, dq(a, c, d)]).j(S(function(e) {
            var f = y(e);
            e = f.next().value;
            var g = y(f.next().value);
            f = g.next().value;
            var h = g.next().value;
            g = g.next().value;
            var k = 0;
            if (!e) return 0;
            if (f === void 0) return 16;
            f && (k |= 1);
            f || (k |= 2);
            h && (k |= 4);
            g && (k |= 8);
            return k
        }))
    }

    function Cv(a, b, c) {
        return b.j(aq(Yp), Y(a, 1)).j(U(function(d, e) {
            return dv(d, e, nv)
        }), V({
            timestamp: c.now(),
            value: mv
        }), Y(a, 1))
    }

    function Fv(a, b, c, d) {
        c = d.j(zv(c), ov(S(function(e) {
            return Math.round(e * 100) / 100
        })), Y(a, 1));
        return b instanceof Z ? c : Ep([c, b]).j(S(function(e) {
            var f = y(e);
            e = f.next().value;
            f = f.next().value;
            return {
                timestamp: f.timestamp.maximum(e.timestamp),
                value: f.value ? 0 : e.value
            }
        }), U(dv), Y(a, 10))
    }

    function Gv(a, b, c, d) {
        b = [b.j(S(function(e) {
            return e.value.G.width * e.value.G.height >= 242500
        }))];
        c instanceof O && b.push(c.j(S(function(e) {
            return !!e
        })));
        c = Ep(b);
        return d ? c.j(S(function(e) {
            return e.some(function(f) {
                return f
            })
        }), V(!1), U(), Y(a, 1)) : xt(new Z(!1), a)
    };

    function Hv(a) {
        return a.length <= 0 ? Mo : Ep(a.map(function(b) {
            var c = 0;
            return b.j(S(function(d) {
                return {
                    index: c++,
                    value: d
                }
            }))
        })).j(T(function(b) {
            return b.every(function(c) {
                return c.index === b[0].index
            })
        }), S(function(b) {
            return b.map(function(c) {
                return c.value
            })
        }))
    };

    function Iv(a, b) {
        return function(c) {
            return Hv(b.map(function(d) {
                return c.j(a(d))
            }))
        }
    };

    function Jv(a, b) {
        a.Oa && (a.Fb = a.Oa);
        a.Oa = b;
        a.Fb && a.Fb.value ? (b = Math.max(0, rr(b.timestamp, a.Fb.timestamp)), a.totalTime += b, a.Aa += b) : a.Aa = 0;
        return a
    }

    function Kv(a) {
        return N(Uq(Jv, {
            totalTime: 0,
            Aa: 0
        }), S(function(b) {
            return new iv(a, {
                timestamp: b.Oa.timestamp,
                value: b.totalTime
            }, b.Oa.value)
        }))
    }

    function Lv(a) {
        return N(Uq(Jv, {
            totalTime: 0,
            Aa: 0
        }), S(function(b) {
            return new iv(a, {
                timestamp: b.Oa.timestamp,
                value: b.Aa
            }, b.Oa.value)
        }))
    };

    function Mv(a) {
        return N(Lv(a), S(function(b) {
            return b.map(function(c) {
                return Math.round(c)
            })
        }))
    };

    function Nv(a) {
        var b = new iv(a, {
            timestamp: a.now(),
            value: 0
        }, !1);
        return N(Lv(a), Uq(function(c, d) {
            return c.L.value > d.L.value ? new iv(a, c.L, !1) : d
        }, b), S(function(c) {
            return c.map(function(d) {
                return Math.round(d)
            })
        }))
    };

    function Ov(a) {
        return function(b) {
            return N(tv(hp(b)), Nv(a))
        }
    };

    function Pv(a) {
        return function(b) {
            return N(ov(S(function(c) {
                return sv(c, b)
            })), Kv(a), S(function(c) {
                return c.map(function(d) {
                    return Math.round(d)
                })
            }))
        }
    };

    function Qv(a) {
        return a.map(function(b) {
            return b.map(function(c) {
                return [c]
            })
        }).reduce(function(b, c) {
            return b.Da(c).map(function(d) {
                return d.flat()
            })
        })
    }

    function Rv(a, b) {
        return a.Da(b).map(function(c) {
            var d = y(c);
            c = d.next().value;
            d = d.next().value;
            return c - d
        })
    }

    function Sv(a, b, c, d, e, f) {
        var g = Tv;
        if (g.length > 1)
            for (var h = 0; h < g.length - 1; h++)
                if (g[h] < g[h + 1]) throw Error();
        h = f.j(V(void 0), X(function() {
            return d.j(Mv(a))
        }), U(function(k, l) {
            return k.ha(l)
        }), Y(b, 1));
        f = f.j(V(void 0), X(function() {
            return d.j(Nv(a))
        }), U(function(k, l) {
            return k.ha(l)
        }), Y(b, 1));
        return {
            jb: e.j(V(void 0), X(function() {
                return c.j(S(function(k) {
                    return {
                        timestamp: k.timestamp,
                        value: !0
                    }
                }), Kv(a))
            }), U(function(k, l) {
                return k.ha(l)
            }), Y(b, 1)),
            kb: e.j(V(void 0), X(function() {
                return c.j(S(function(k) {
                    return {
                        timestamp: k.timestamp,
                        value: k.value === 0
                    }
                }), Kv(a))
            }), U(function(k, l) {
                return k.ha(l)
            }), Y(b, 1)),
            Bc: e.j(V(void 0), X(function() {
                return c.j(Iv(Ov(a), g))
            }), S(Qv), U(function(k, l) {
                return k.ha(l)
            }), Y(b, 1)),
            pa: e.j(V(void 0), X(function() {
                return c.j(Iv(Pv(a), g), S(function(k) {
                    return k.map(function(l, m) {
                        return m > 0 ? Rv(l, k[m - 1]) : l
                    })
                }))
            }), S(Qv), U(function(k, l) {
                return k.ha(l)
            }), Y(b, 1)),
            Ac: f,
            qb: h.j(U(function(k, l) {
                return k.ha(l)
            }), Y(b, 1))
        }
    };

    function Uv(a) {
        this.C = a;
        this.g = null;
        this.timeout = new Q
    }

    function Vv(a, b) {
        Wv(a);
        a.g = a.C.setTimeout(function() {
            return void a.timeout.next()
        }, b)
    }

    function Wv(a) {
        a.g !== null && (a.C.clearTimeout(a.g), a.g = null)
    };

    function Xv(a, b, c, d) {
        var e = Yv.mf,
            f = new Uv(b);
        c = c.j(V(void 0), X(function() {
            Wv(f);
            return d
        })).j(S(function(g) {
            Wv(f);
            var h = g.L,
                k = g.active;
            h.value >= e || !k || (k = b.now(), k = Math.max(0, rr(k, h.timestamp)), Vv(f, Math.max(0, e - h.value - k)));
            return g.map(function(l) {
                return l >= e
            })
        }));
        return Ep([c, Xp(f.timeout, hp(void 0))]).j(S(function(g) {
            return y(g).next().value
        }), Xq(function(g) {
            return !g.ia().value
        }, !0), Y(a, 1))
    };

    function Zv(a, b, c, d) {
        var e = d.Yc,
            f = d.Id,
            g = d.rf,
            h = d.ze,
            k = d.Ud,
            l = d.cf,
            m = d.bd;
        d = d.nf;
        b = $v(a, c, b);
        c = aw(a, c);
        d = bw(b, d);
        var q = cw(a, e, l, b),
            t = q.j(S(function(F) {
                return F.value
            }), U(), Y(a, 1), Uq(function(F, z) {
                return Math.max(F, z)
            }, 0)),
            r = q.j(S(function(F) {
                return F.value
            }), vv(), Y(a, 1)),
            w = b.j(rv, S(function(F) {
                return F.value
            }), Gq(2), U(), Y(a, 1));
        g = dw(a, b, g, h);
        var u = g.j(V(!1), U(), S(function(F) {
            return F ? k : f
        }));
        h = q.j(tv(u), U(), Y(a, 1));
        var v = Ep([h, b]).j(T(function(F) {
            var z = y(F);
            F = z.next().value;
            z = z.next().value;
            return F.timestamp.equals(z.timestamp)
        }), S(function(F) {
            var z = y(F);
            F = z.next().value;
            z = z.next().value;
            return {
                visible: F.value,
                geometry: z.value.G
            }
        }), Uq(function(F, z) {
            return !z.visible && F.visible ? F : z
        }, {
            visible: !1,
            geometry: Cs
        }), S(function(F) {
            return F.geometry
        }), V(Cs), Y(a, 1), U(Ds));
        l = l instanceof O ? l.j(U(), Fq()) : Yp;
        u = Ep([l, u]).j(Fq());
        var C = b.j(T(function(F) {
                return F.value.qa !== "ns" && F.value.ca !== "ns"
            }), Uq(function(F) {
                return F + 1
            }, 0), V(0), Y(a, 1)),
            P = c.j(Fq(!0), V(!1), Y(a, 1));
        P = Ep([m, P]).j(S(function(F) {
            var z = y(F);
            F = z.next().value;
            z = z.next().value;
            return F && !z
        }), Y(a, 1));
        var J = b.j(Av, U()),
            da = J.j(S(function(F) {
                return F.value
            }), Uq(function(F, z) {
                return Math.max(F, z)
            }, 0), U(), Y(a, 1));
        a = J.j(S(function(F) {
            return F.value
        }), vv(), Y(a, 1));
        return {
            he: l,
            Gc: u,
            Ja: {
                Eg: b,
                S: b.j(uv),
                Tc: v.j(U(Ds)),
                visible: h.j(U(dv)),
                me: q.j(U(dv)),
                bf: t,
                Ag: r,
                Be: b.j(lv, U(hb)),
                Rg: J,
                vg: da,
                zg: a,
                Xc: c,
                ma: b.j(S(function(F) {
                    return F.value.ma
                })),
                ja: g,
                Yc: e,
                bd: m,
                Se: P,
                Tg: C,
                Vb: w,
                ld: d
            }
        }
    }

    function aw(a, b) {
        return b.j(T(function() {
            return !1
        }), S(function(c) {
            return c
        }), zq(function(c) {
            return xt(new Z(c), a)
        }))
    }

    function $v(a, b, c) {
        return b.j(aq(Yp), Y(a, 1)).j(U(function(d, e) {
            return dv(d, e, nv)
        }), V({
            timestamp: c.now(),
            value: mv
        }), Y(a, 1))
    }

    function cw(a, b, c, d) {
        c = d.j(zv(c), ov(S(function(e) {
            return Math.round(e * 100) / 100
        })), Y(a, 1));
        return b instanceof Z ? c : Ep([c, b]).j(S(function(e) {
            var f = y(e);
            e = f.next().value;
            f = f.next().value;
            return {
                timestamp: f.timestamp.maximum(e.timestamp),
                value: f.value ? 0 : e.value
            }
        }), U(dv), Y(a, 1))
    }

    function dw(a, b, c, d) {
        b = [b.j(S(function(e) {
            return e.value.G.width * e.value.G.height >= 242500
        }))];
        c instanceof O && b.push(c.j(S(function(e) {
            return !!e
        })));
        c = Ep(b);
        return d ? c.j(S(function(e) {
            return e.some(function(f) {
                return f
            })
        }), V(!1), U(), Y(a, 1)) : xt(new Z(!1), a)
    }

    function bw(a, b) {
        a = Ep([a, b]).j(S(function(e) {
            var f = y(e);
            e = f.next().value;
            if (f.next().value && e.value.isIntersecting) return e.value.af
        }), U());
        var c = a.j(S(function(e) {
                return e === void 0 ? !0 : e
            }), Uq(function(e, f) {
                return e || !f
            }, !1)),
            d = a.j(Uq(function(e, f) {
                return f === void 0 ? e : f ? !1 : e != null ? e : !0
            }, void 0), S(function(e) {
                return !!e
            }));
        return Ep([b, dq(a, c, d)]).j(S(function(e) {
            var f = y(e);
            e = f.next().value;
            var g = y(f.next().value);
            f = g.next().value;
            var h = g.next().value;
            g = g.next().value;
            var k = 0;
            if (!e) return 0;
            if (f === void 0) return 16;
            f && (k |= 1);
            f || (k |= 2);
            h && (k |= 4);
            g && (k |= 8);
            return k
        }))
    };
    var ew = N(ut("data-google-av-itpl"), S(function(a) {
        return Number(a)
    }), S(function(a) {
        return isNaN(a) ? 1 : a
    }));
    var gw = S(fw);

    function fw(a) {
        var b = Number(tt(a, "data-google-av-rs"));
        if (!isNaN(b) && b !== 0) return b;
        var c;
        return (a = (c = a.g) == null ? void 0 : c.id) ? a.startsWith("DfaVisibilityIdentifier") ? 6 : a.startsWith("YtKevlarVisibilityIdentifier") ? 15 : a.startsWith("YtSparklesVisibilityIdentifier") ? 17 : a.startsWith("YtKabukiVisibilityIdentifier") ? 18 : 0 : 0
    };

    function hw(a, b) {
        return N(ut("data-google-av-metadata"), S(function(c) {
            if (c === null) return b(void 0);
            c = c.split("&").map(function(d) {
                return d.split("=")
            }).filter(function(d) {
                return d[0] === a
            });
            if (c.length === 0) return b(void 0);
            c = c[0].slice(1).join("=");
            return b(c)
        }))
    };
    var iw = {
        sf: "addEventListener",
        tf: "getMaxSize",
        uf: "getScreenSize",
        vf: "getState",
        wf: "getVersion",
        yf: "removeEventListener",
        xf: "isViewable"
    };

    function jw(a, b) {
        this.Fa = null;
        this.lg = new Q;
        b = b || this.Ug;
        var c = a.Od,
            d = !a.zb;
        if (c && d) {
            var e = a.global.top.mraid;
            if (e) {
                this.Na = b(e);
                this.Fa = e;
                this.Sa = 3;
                return
            }
        }(a = a.global.mraid) ? (this.Na = b(a), this.Fa = a, this.Sa = c ? d ? 2 : 1 : 0) : (this.Sa = -1, this.Na = 2)
    }
    n = jw.prototype;
    n.addEventListener = function(a, b) {
        return this.Xb("addEventListener", a, b)
    };
    n.removeEventListener = function(a, b) {
        return this.Xb("removeEventListener", a, b)
    };
    n.Te = function() {
        var a = this.Xb("getVersion");
        return typeof a === "string" ? a : ""
    };
    n.getState = function() {
        var a = this.Xb("getState");
        return typeof a === "string" ? a : ""
    };

    function kw(a) {
        a = a.Xb("isViewable");
        return typeof a === "boolean" ? a : !1
    }

    function lw(a) {
        if (a.Fa) return a = a.Fa.AFMA_LIDAR, typeof a === "string" ? a : void 0
    }
    n.Ug = function(a) {
        return a ? a.IS_GMA_SDK ? Object.values(iw).every(function(b) {
            return typeof a[b] === "function"
        }) ? 0 : 1 : 2 : 1
    };
    n.Xb = function(a) {
        var b = D.apply(1, arguments);
        if (this.Fa) try {
            return this.Fa[a].apply(this.Fa, A(b))
        } catch (c) {
            this.lg.next(a)
        }
    };
    ea.Object.defineProperties(jw.prototype, {
        Je: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                if (this.Fa) {
                    var a = this.Fa.AFMA_LIDAR_EXP_1;
                    return a === void 0 ? void 0 : !!a
                }
            },
            set: function(a) {
                this.Fa && (this.Fa.AFMA_LIDAR_EXP_1 = a)
            }
        }
    });

    function mw(a, b) {
        return (new jw(a)).Sa !== -1 ? xt(new Z(!0), a.B) : b.j(ut("data-google-av-inapp"), S(function(c) {
            return c !== null
        }), Y(a.B, 1))
    };

    function nw(a, b) {
        return {
            za: b.j(ut("data-google-av-adk")),
            rc: b.j(ut("data-google-av-btr"), U(), S(function(c) {
                return c === null ? [] : c.split("|").filter(function(d) {
                    return d !== ""
                })
            })),
            Fd: b.j(ut("data-google-av-cpmav"), U(), S(function(c) {
                return c === null ? [] : c.split("|").filter(function(d) {
                    return d !== ""
                })
            })),
            lb: b.j(ut("data-google-av-vrus"), U(), S(function(c) {
                return c === null ? [] : c.split("|").filter(function(d) {
                    return d !== ""
                })
            })),
            Rf: Hu(a, b),
            flags: b.j(ut("data-google-av-flags"), U()),
            yb: mw(a, b),
            Rd: b.j(hw("cr", function(c) {
                return c === "1"
            }), U()),
            og: b.j(hw("omid", function(c) {
                return c === "1"
            }), U()),
            Qd: b.j(ew),
            metadata: b.j(ut("data-google-av-metadata")),
            X: b.j(gw),
            xa: b.j(vt),
            Yg: b.j(hw("la", function(c) {
                return c === "1"
            }), U()),
            Bb: b.j(ut("data-google-av-turtlex"), S(function(c) {
                return c !== null
            }), U()),
            Td: b.j(ut("data-google-av-vattr"), S(function(c) {
                return c !== null
            }), U())
        }
    };

    function ow(a, b, c, d, e) {
        c = c.j(S(function() {
            return !1
        }));
        d = Ep([e, d]).j(X(function(f) {
            f = y(f).next().value;
            return pw(b, f)
        }));
        return Xp(hp(!1), c, d).j(U(), Y(a.B, 1))
    }

    function pw(a, b) {
        return a.j(S(function(c) {
            return b || c === 0 || c === 2
        }))
    };

    function qw(a) {
        var b;
        if (b = rw(a)) b = !sw(a, "abgcp") && !sw(a, "abgc") && !(typeof a.id === "string" && a.id === "abgb") && !(typeof a.id === "string" && a.id === "mys-abgc") && !sw(a, "cbb");
        return b
    }

    function sw(a, b) {
        return a.classList ? a.classList.contains(b) : (" " + a.className + " ").indexOf(" " + b + " ") > -1
    }

    function rw(a) {
        try {
            var b = a.getBoundingClientRect();
            return b && b.height >= 30 && b.width >= 30
        } catch (c) {
            return !1
        }
    }

    function tw(a, b) {
        if (a.g === void 0 || !a.g.children) return a;
        for (var c = db(a.g.children); c.length;) {
            var d = b ? c.filter(qw) : c.filter(rw);
            if (d.length === 1) return new ls(d[0]);
            if (d.length > 1) break;
            c = lb(c, function(e) {
                return db(e.children)
            })
        }
        return a
    }

    function uw(a, b, c, d, e) {
        if (c) return {
            Sc: b,
            Gb: hp(null)
        };
        c = b.element.j(S(function(f) {
            a: if (f.g === void 0 || rw(f.g)) f = {
                    dd: f,
                    Gb: "mue"
                };
                else {
                    var g = tw(f, e);
                    if (g.g !== void 0 && rw(g.g)) f = {
                        dd: g,
                        Gb: "ie"
                    };
                    else {
                        if (d || a.Od)
                            if (g = a.document.querySelector(".GoogleActiveViewInnerContainer")) {
                                f = {
                                    dd: new ls(g),
                                    Gb: "ce"
                                };
                                break a
                            }
                        f = {
                            dd: f,
                            Gb: "mue"
                        }
                    }
                }return f
        }), Vq());
        return {
            Sc: {
                Hb: b.Hb,
                element: c.j(S(function(f) {
                    return f.dd
                }))
            },
            Gb: c.j(S(function(f) {
                return f.Gb
            }))
        }
    };
    var vw = [33, 32],
        ww = N(ew, S(function(a) {
            return vw.indexOf(a) >= 0
        }), U());

    function xw(a, b, c, d, e, f) {
        var g = c.j(S(function(k) {
                return k === 9
            })),
            h = b.element.j(ww);
        c = e.j(T(function(k) {
            return k
        }), X(function() {
            return Ep([g, h])
        }), S(function(k) {
            var l = y(k);
            k = l.next().value;
            return !l.next().value || k
        }), U());
        f = Ep([c, d.j(U()), f]).j(S(function(k) {
            var l = y(k);
            k = l.next().value;
            var m = l.next().value;
            l = l.next().value;
            return uw(a, b, !k, m, l)
        }), Sq(1), rp());
        d = f.j(S(function(k) {
            return k.Sc
        }));
        f = f.j(X(function(k) {
            return k.Gb
        }), V(null), U(), Y(a.B, 1));
        return {
            fb: d,
            sc: f
        }
    };

    function yw(a) {
        var b = b === void 0 ? !1 : b;
        return N(X(function(c) {
            return xs(a.document, c, b)
        }), Y(a.B, 1))
    };

    function zw(a, b, c, d, e, f) {
        this.zc = b.element.j(yw(a), Y(a.B, 1));
        this.g = ow(a, c, b.element, this.zc, d);
        c = xw(a, b, e, d, this.g, f);
        d = c.sc;
        this.fb = c.fb;
        this.sc = d;
        this.re = Xp(xt(new Z(1), a.B), b.element.j(Gq(1), S(function() {
            return 2
        }), Y(a.B, 1)), this.zc.j(Gq(1), S(function() {
            return 3
        }), Y(a.B, 1)), this.g.j(T(Boolean), Gq(1), S(function() {
            return 0
        }), Y(a.B, 1))).j(Xq(function(g) {
            return g !== 0
        }, !0), Y(a.B, 0))
    };

    function Aw(a) {
        var b = new dr(13);
        if (a.length < 1) return {
            chain: Mo,
            Dd: Mo
        };
        var c = new Q,
            d = a[0];
        return {
            chain: a.slice(1).reduce(function(e, f) {
                return e.j(zq(function(g) {
                    c.next(g);
                    return f
                }))
            }, d).j(zq(function(e) {
                c.next(e);
                return ip(b)
            }), Qq(new Q), rp()),
            Dd: c
        }
    };

    function Bw() {};

    function Cw(a, b) {
        this.context = a;
        this.i = b
    }
    x(Cw, Bw);
    Cw.prototype.g = function(a, b) {
        var c = this.i.map(function(f) {
                return f.g(a, b)
            }),
            d = Aw(c.map(function(f) {
                return f.sb
            })),
            e = d.Dd.j(Dw());
        return {
            sb: d.chain.j(Y(this.context.B, 1)),
            ob: Object.assign.apply(Object, [{
                ke: e,
                ci: d.Dd
            }].concat(A(c.map(function(f) {
                return f.ob
            }))))
        }
    };

    function Dw() {
        return Uq(function(a, b) {
            b instanceof dr ? a.push(b.g) : a.push(-1);
            return a
        }, [])
    };

    function Ew(a, b) {
        return function(c) {
            return function(d) {
                var e = d.j(Qq(new Q), rp());
                d = c.element.j(U());
                e = e.j(S(function(f) {
                    return f.value
                }));
                return Ep([d, e, b]).j(S(function(f) {
                    var g = y(f);
                    f = g.next().value;
                    var h = g.next().value;
                    g = g.next().value;
                    if (f.g === void 0) var k = {
                        top: 0,
                        left: 0,
                        width: 0,
                        height: 0
                    };
                    else {
                        k = f.g.getBoundingClientRect();
                        var l = ld(f.g, a.global);
                        k = {
                            top: l.y,
                            left: l.x,
                            width: k.width,
                            height: k.height
                        }
                    }
                    k = Fs(k, h.ya);
                    l = Es(k, h.va);
                    var m = a.C.now(),
                        q = Object,
                        t = q.assign;
                    a: if (g !== 2 || a.zb || l.width <= 0 || l.height <= 0) var r = !1;
                        else {
                            try {
                                var w = a.document;
                                if (w.document && w.document !== null && typeof w.document.elementFromPoint === "function") {
                                    var u = w.document.elementFromPoint(l.left + l.width / 2, l.top + l.height / 2);
                                    var v = u === null ? null : new ls(u)
                                } else v = null;
                                r = v ? !Fw(v, f) : !1;
                                break a
                            } catch (C) {
                                r = !1;
                                break a
                            }
                            r = void 0
                        }
                    return {
                        timestamp: m,
                        value: t.call(q, {}, h, {
                            ca: "geo",
                            da: r ? mv.da : l,
                            G: k
                        })
                    }
                }), As(a.B))
            }
        }
    }

    function Fw(a, b, c) {
        c = c === void 0 ? 0 : c;
        return a.g === void 0 || b.g === void 0 ? !1 : a.g === b.g || Oc(b.g, function(d) {
            return d === a.g
        }) ? !0 : b.g.ownerDocument && b.g.ownerDocument.defaultView && b.g.ownerDocument.defaultView === b.g.ownerDocument.defaultView.top ? !1 : c < 10 && b.g.ownerDocument && b.g.ownerDocument.defaultView && b.g.ownerDocument.defaultView.frameElement ? Fw(a, new ls(b.g.ownerDocument.defaultView.frameElement), c + 1) : !0
    };

    function Gw(a, b) {
        return a && b === 0 ? 15 : a || b !== 1 ? null : 14
    }

    function Hw(a, b, c) {
        return b instanceof O ? b.j(X(function(d) {
            return (d = Gw(d, c)) ? ip(new dr(d)) : a
        })) : (b = Gw(b.value, c)) ? ip(new dr(b)) : a
    };

    function Iw(a, b) {
        var c = a.j(Qq(new Q), rp());
        return X(function(d) {
            return c.j(b(d))
        })
    };

    function Jw(a, b) {
        if (a.zb) return ip(new dr(6));
        var c = new Q;
        return Xp(hp({}), b, c).j(S(function() {
            return {
                timestamp: a.C.now(),
                value: {
                    qa: "geo",
                    va: Kw(a),
                    ga: at(a, !0),
                    ma: c,
                    ya: {
                        x: 0,
                        y: 0
                    }
                }
            }
        }), As(a.B))
    }

    function Kw(a) {
        var b = at(a, !1);
        if (!a.Od || !td(a.global.parent) || a.global.parent === a.global) return b;
        var c = new Ws(a.global.parent, a.Pa);
        c.N = a.N;
        c = Kw(c);
        a = a.global.frameElement.getBoundingClientRect();
        return Es(Fs(Es(c, a), {
            x: b.left - a.left,
            y: b.top - a.top
        }), b)
    };

    function Lw(a, b) {
        this.context = a;
        this.Eb = b
    }
    x(Lw, Bw);
    Lw.prototype.g = function(a, b) {
        var c = Iw(Jw(this.context, this.Eb), Ew(this.context, b.X));
        return {
            sb: Hw(a.fb.j(c), b.yb, 0),
            ob: {}
        }
    };

    function Mw(a, b) {
        this.m = a;
        this.l = b;
        this.i = this.g = null
    }

    function Nw(a, b) {
        b ? a.i || (b = Object.assign({}, a.l, {
            delay: 100,
            trackVisibility: !0
        }), a.i = new IntersectionObserver(a.m, b)) : a.g || (a.g = new IntersectionObserver(a.m, a.l))
    }

    function Ow(a, b) {
        a = b ? a.i : a.g;
        if (!a) throw new gr;
        return a
    }
    Mw.prototype.observe = function(a, b) {
        Ow(this, a).observe(b)
    };
    Mw.prototype.unobserve = function(a, b) {
        Ow(this, a).unobserve(b)
    };
    Mw.prototype.disconnect = function(a) {
        Ow(this, a).disconnect()
    };

    function Pw(a) {
        return function(b) {
            return b.j(a.ResizeObserver ? Qw(a) : Rw(a), Sq(1), rp())
        }
    }

    function Qw(a) {
        return function(b) {
            return b.j(X(function(c) {
                var d = a.ResizeObserver;
                if (!d || c.g === void 0) return hp(mv.G);
                var e = (new O(function(f) {
                    function g() {
                        c.g !== void 0 && h.unobserve(c.g);
                        h.disconnect();
                        k.unsubscribe()
                    }
                    if (c.g === void 0) return f.complete(),
                        function() {};
                    var h = new d(function(l) {
                        l.forEach(function(m) {
                            f.next(m)
                        })
                    });
                    h.observe(c.g);
                    var k = c.i.subscribe(g);
                    return g
                })).j(Pr(a.P, 736), S(function(f) {
                    return f.contentRect
                }));
                return Xp(hp(c.g.getBoundingClientRect()), e)
            }), U(Ds))
        }
    }

    function Rw(a) {
        return function(b) {
            var c = b.j(Fu(a, {
                    attributes: !0,
                    childList: !0,
                    characterData: !0,
                    subtree: !0
                })),
                d = a.Dg;
            c = Xp(b.j(S(function() {
                return ks("resize")
            })), c, d);
            return Ep(b, c).j(Pr(a.P, 737), S(function(e) {
                e = y(e).next().value;
                return e.g === void 0 ? void 0 : e.g.getBoundingClientRect()
            }), Ct(), U(Ds))
        }
    };

    function Sw(a, b) {
        var c = Tw(a, b).j(Sq(1), rp());
        return function(d) {
            return function(e) {
                e = e.j(X(function(f) {
                    return f.element
                }), U());
                return Ep([c, e]).j(X(function(f) {
                    var g = y(f);
                    f = g.next().value;
                    g = g.next().value;
                    return Uw(a, f.mg, Pw(a), f.Bg, d, f.ag, g)
                }), As(a.B))
            }
        }
    }

    function Vw(a, b, c) {
        var d = Sw(a, c)(b);
        return function(e) {
            var f = d(hp(e));
            return function(g) {
                return Ep([g, f]).j(S(function(h) {
                    var k = y(h);
                    h = k.next().value;
                    k = k.next().value;
                    var l = Fs(k.value.G, h.value.ya),
                        m = Es(Fs(k.value.da, h.value.ya), h.value.va);
                    return {
                        timestamp: h.timestamp.maximum(k.timestamp),
                        value: Object.assign({}, h.value, {
                            ca: "nio",
                            da: m,
                            G: l
                        })
                    }
                }))
            }
        }
    }

    function Ww(a) {
        return S(function(b) {
            return b.value.qa !== "nio" ? b : Object.assign({}, b, {
                value: Object.assign({}, b.value, {
                    va: at(a, !0),
                    ga: at(a, !0)
                })
            })
        })
    }

    function Xw(a, b) {
        return hp(b).j(a, S(function() {
            return b
        }))
    }

    function Tw(a, b) {
        return a.C.timeline !== nr ? ip(new dr(2)) : a.MutationObserver ? typeof IntersectionObserver === "undefined" ? ip(new dr(0)) : (new O(function(c) {
            var d = new Q,
                e = new Mw(d.next.bind(d), {
                    threshold: [].concat(A(b))
                });
            c.next({
                Bg: d.j(Pr(a.P, 735)),
                mg: e,
                ag: function(f) {
                    f = Ow(e, f).takeRecords();
                    f.length > 0 && d.next(f)
                }
            })
        })).j(Gq(1), Sq(1), rp()) : ip(new dr(1))
    }

    function Yw(a) {
        return Wo(a.sort(function(b, c) {
            return b.time - c.time
        }), vp)
    }

    function Uw(a, b, c, d, e, f, g) {
        return new O(function(h) {
            function k() {
                w || (w = !0, g.g !== void 0 && b.unobserve(e, g.g), m.unsubscribe(), r.unsubscribe(), t.unsubscribe(), u.unsubscribe())
            }
            if (g.g !== void 0) {
                Nw(b, e);
                b.observe(e, g.g);
                var l = new Lo({
                        timestamp: a.C.now(),
                        value: Object.assign({}, mv, {
                            qa: "nio",
                            ca: "nio"
                        })
                    }),
                    m = d.j(Jp(function(v) {
                        return Yw(v)
                    }), T(function(v) {
                        return v.target === g.g
                    }), S(function(v) {
                        return {
                            timestamp: new pr(v.time, nr),
                            value: {
                                qa: "nio",
                                va: v.rootBounds || Cs,
                                ga: v.rootBounds || at(a, !0),
                                ma: q,
                                ca: "nio",
                                da: v.intersectionRect,
                                G: v.boundingClientRect,
                                ya: {
                                    x: 0,
                                    y: 0
                                },
                                isIntersecting: v.isIntersecting,
                                af: v.isVisible
                            }
                        }
                    }), Qq(l), rp()).subscribe(h),
                    q = new Q,
                    t = q.subscribe(function() {
                        f(e);
                        h.next({
                            timestamp: a.C.now(),
                            value: l.value.value
                        });
                        g.g !== void 0 && (b.unobserve(e, g.g), b.observe(e, g.g))
                    }),
                    r = Xw(c, g).subscribe(function() {
                        q.next()
                    }),
                    w = !1,
                    u = g.i.subscribe(function() {
                        return k()
                    });
                return k
            }
        })
    };

    function Zw(a, b, c) {
        c = c === void 0 ? Sw(a, b) : c;
        this.context = a;
        this.i = c
    }
    x(Zw, Bw);
    Zw.prototype.g = function(a, b) {
        var c = this.i(b.qf);
        return {
            sb: Hw(a.fb.j(c, Ww(this.context)), b.yb, 0),
            ob: {}
        }
    };

    function $w(a, b, c, d, e) {
        var f = f === void 0 ? new jw(a) : f;
        var g = g === void 0 ? br(a.C, 500) : g;
        var h = h === void 0 ? br(a.C, 100) : h;
        e = hp(f).j(ax(c), Yq(function(k) {
            d.next(k.Sa)
        }), bx(a, h), cx(a), dx(a, e), Sq(1), rp());
        f = new Q;
        b = Xp(hp({}), b, f);
        return e.j(ex(a, f, b, g, c), Y(a.B, 1))
    }

    function dx(a, b) {
        return N(function(c) {
            return Ep([c, b])
        }, Hq(function(c) {
            var d = y(c);
            c = d.next().value;
            return d.next().value !== 9 || kw(c) ? hp(!0) : fx(a, c, "viewableChange").j(T(function(e) {
                return y(e).next().value
            }), Gq(1))
        }), S(function(c) {
            return y(c).next().value
        }))
    }

    function ax(a) {
        return X(function(b) {
            if (b.Sa === -1) return a.next("if"), ip(new dr(7));
            if (b.Na !== 0) switch (b.Na) {
                case 1:
                    return a.next("mm"), ip(new dr(18));
                case 2:
                    return a.next("ng"), ip(new dr(17));
                default:
                    return a.next("i"), ip(new dr(8))
            }
            return hp(b)
        })
    }

    function bx(a, b) {
        return Hq(function() {
            var c = a.ef;
            return vs(a.document) === "complete" ? hp(!0) : c.j(Hq(function() {
                return b
            }))
        })
    }

    function cx(a) {
        return X(function(b) {
            return b.getState() !== "loading" ? hp(b) : fx(a, b, "ready").j(S(function() {
                return b
            }))
        })
    }

    function ex(a, b, c, d, e) {
        return X(function(f) {
            var g = lw(f);
            if (typeof g !== "string") return e.next("nc"), ip(new dr(9));
            f.Je !== void 0 && (f.Je = !0);
            g = fx(a, f, g, gx);
            var h = {
                version: f.Te(),
                Sa: f.Sa
            };
            g = g.j(S(function(l) {
                return hx.apply(null, [a, b, f, h].concat(A(l)))
            }));
            var k = d.j(Yq(function() {
                e.next("mt")
            }), X(function() {
                return ip(new dr(10))
            }));
            g = bq(g, k);
            return Ep([g, c]).j(S(function(l) {
                l = y(l).next().value;
                return Object.assign({}, l, {
                    timestamp: a.C.now()
                })
            }))
        })
    }

    function gx(a, b) {
        return (b === null || typeof b === "number") && (a === null || !!a && typeof a.height === "number" && typeof a.width === "number" && typeof a.x === "number" && typeof a.y === "number")
    }

    function hx(a, b, c, d, e, f) {
        e = e ? {
            left: e.x,
            top: e.y,
            width: e.width,
            height: e.height
        } : Cs;
        c = c.Xb("getMaxSize");
        var g = c != null && typeof c.width === "number" && typeof c.height === "number" ? c : {
            width: 0,
            height: 0
        };
        c = {
            left: 0,
            top: 0,
            width: -1,
            height: -1
        };
        if (g) {
            var h = Number(String(g.width));
            g = Number(String(g.height));
            c = isNaN(h) || isNaN(g) ? c : {
                left: 0,
                top: 0,
                width: h,
                height: g
            }
        }
        a = {
            value: {
                va: e,
                ga: c,
                qa: "mraid",
                ma: b,
                ya: {
                    x: 0,
                    y: 0
                }
            },
            timestamp: a.C.now()
        };
        return Object.assign({}, a, d, {
            Ah: f
        })
    }

    function fx(a, b, c, d) {
        d = d === void 0 ? function() {
            return !0
        } : d;
        return (new O(function(e) {
            var f = a.P.bc(745, function() {
                e.next(D.apply(0, arguments))
            });
            b.addEventListener(c, f);
            return function() {
                b.removeEventListener(c, f)
            }
        })).j(T(function(e) {
            return d.apply(null, A(e))
        }))
    };

    function ix(a, b) {
        this.context = a;
        this.Eb = b
    }
    x(ix, Bw);
    ix.prototype.g = function(a, b) {
        var c = new kp(1),
            d = new kp(1),
            e = Iw($w(this.context, this.Eb, c, d, b.X), Ew(this.context, b.X));
        return {
            sb: Hw(a.fb.j(e), b.yb, 1),
            ob: {
                Zd: c.j(Y(this.context.B, 1)),
                ae: d.j(Y(this.context.B, 1))
            }
        }
    };

    function jx(a) {
        return ["backgrounded", "notFound", "hidden", "noOutputDevice"].includes(a)
    };

    function kx(a, b) {
        var c = c === void 0 ? null : c;
        var d = new Q,
            e = void 0,
            f = a.Re,
            g = d.j(S(function() {
                return e ? Object.assign({}, e, {
                    timestamp: a.C.now()
                }) : null
            }), T(function(k) {
                return k !== null
            }), S(function(k) {
                return k
            }));
        b = Ep([Xp(f, g), b]);
        var h = c;
        return b.j(T(function(k) {
            k = y(k).next().value;
            h === null && (h = k.value.adSessionId);
            return k.value.adSessionId === h
        }), Yq(function(k) {
            return void(e = y(k).next().value)
        }), S(function(k) {
            var l = y(k);
            k = l.next().value;
            l = l.next().value;
            try {
                var m = k.value.data,
                    q = k.timestamp,
                    t = m.viewport,
                    r, w, u = Object.assign({}, t, {
                        width: (r = t == null ? void 0 : t.width) != null ? r : 0,
                        height: (w = t == null ? void 0 : t.height) != null ? w : 0,
                        x: 0,
                        y: 0,
                        Wh: t ? t.width * t.height : 0
                    }),
                    v = lx(u),
                    C = m.adView,
                    P = C.measuringElement && C.containerGeometry ? lx(C.containerGeometry) : lx(C.geometry),
                    J = lx(C.geometry),
                    da = C.reasons.some(jx),
                    F = da ? Cs : lx(C.onScreenGeometry),
                    z;
                l && (z = C.percentageInView / 100);
                l && da && (z = 0);
                return {
                    timestamp: q,
                    value: {
                        qa: "omid",
                        va: P,
                        ga: v,
                        ma: d,
                        ca: "omid",
                        G: J,
                        ya: {
                            x: P.left,
                            y: P.top
                        },
                        da: F,
                        Wc: z
                    }
                }
            } catch (Uc) {
                var W, Vc;
                m = (Vc = (W = Uc) == null ? void 0 : W.message) != null ? Vc : "An unknown error occurred";
                W = "Error while processing geometryChange event: " + JSON.stringify(k.value) + "; " + m;
                throw Error(W);
            }
        }), Sq(1), rp())
    }

    function lx(a) {
        var b, c, d, e;
        return {
            left: Math.floor((b = a == null ? void 0 : a.x) != null ? b : 0),
            top: Math.floor((c = a == null ? void 0 : a.y) != null ? c : 0),
            width: Math.floor((d = a == null ? void 0 : a.width) != null ? d : 0),
            height: Math.floor((e = a == null ? void 0 : a.height) != null ? e : 0)
        }
    };

    function mx(a, b, c, d) {
        c = c === void 0 ? Yp : c;
        var e = a.B;
        if (b === null) return ip(new dr(20));
        if (!b.validate()) return ip(new dr(21));
        var f;
        d = nx(e, b, d).j(S(function(g) {
            var h = g.value;
            g = g.timestamp;
            var k = b.C,
                l = a.C;
            if (k.timeline !== g.timeline) throw new ir;
            g = new pr(g.value - k.now().value + l.now().value, l.timeline);
            return f = {
                value: h,
                timestamp: g
            }
        }));
        return Xp(d, c.j(S(function() {
            return f
        }))).j(T(function(g) {
            return g !== void 0
        }), S(function(g) {
            return g
        }), Y(a.B, 1))
    }

    function nx(a, b, c) {
        return kx(b, c).j(Y(a, 1), S(function(d) {
            return {
                timestamp: d.timestamp,
                value: {
                    ya: {
                        x: d.value.G.left,
                        y: d.value.G.top
                    },
                    va: d.value.da,
                    ga: d.value.ga,
                    qa: d.value.ca,
                    ma: d.value.ma
                }
            }
        }))
    };

    function ox(a, b, c) {
        this.oa = a;
        this.I = b;
        this.Eb = c
    }
    x(ox, Bw);
    ox.prototype.g = function(a, b) {
        var c = b.X;
        b = mx(this.I, this.oa, this.Eb, b.df);
        c = Iw(b, Ew(this.I, c));
        return {
            sb: a.fb.j(c),
            ob: {}
        }
    };

    function px(a, b, c) {
        this.oa = a;
        this.I = b;
        this.i = c
    }
    x(px, Bw);
    px.prototype.g = function(a, b) {
        var c = mx(this.I, this.oa, void 0, b.df);
        b = Vw(this.I, b.qf, this.i);
        c = Iw(c, b);
        return {
            sb: a.fb.j(c),
            ob: {}
        }
    };

    function qx(a) {
        return a.document.l.j(S(function(b) {
            return b === "visible"
        }), U(), Y(a.B, 1))
    };

    function rx(a, b, c) {
        var d;
        return b.j(U(), X(function(e) {
            return c.j(S(function() {
                if (!d) {
                    d = !0;
                    try {
                        e.next()
                    } finally {
                        d = !1
                    }
                }
                return !0
            }))
        }), V(!1), Y(a.B, 1))
    };

    function sx(a, b) {
        a.Oa && (a.Fb = a.Oa);
        a.Oa = b;
        a.Fb && a.Fb.value ? (b = Math.max(0, rr(b.timestamp, a.Fb.timestamp)), a.totalTime += b, a.Aa += b) : a.Aa = 0;
        return a
    }

    function tx() {
        return N(Uq(sx, {
            totalTime: 0,
            Aa: 0
        }), S(function(a) {
            return a.totalTime
        }))
    }

    function ux() {
        return N(Uq(sx, {
            totalTime: 0,
            Aa: 0
        }), S(function(a) {
            return a.Aa
        }))
    };

    function vx() {
        var a;
        return N(Yq(function(b) {
            return void(a = b.timestamp)
        }), ux(), S(function(b) {
            return {
                timestamp: a,
                value: Math.round(b)
            }
        }))
    };

    function wx() {
        return N(ux(), Uq(function(a, b) {
            return Math.max(a, b)
        }, 0), S(function(a) {
            return Math.round(a)
        }))
    };

    function xx(a) {
        return N(tv(hp(a)), wx())
    };

    function yx(a) {
        return N(ov(S(function(b) {
            return sv(b, a)
        })), tx(), S(function(b) {
            return Math.round(b)
        }))
    };

    function zx(a, b, c, d, e) {
        var f = Tv;
        if (f.length > 1)
            for (var g = 0; g < f.length - 1; g++)
                if (f[g] < f[g + 1]) throw Error();
        g = e.j(V(void 0), X(function() {
            return c.j(vx())
        }), U(), Y(a, 1));
        e = e.j(V(void 0), X(function() {
            return c.j(wx())
        }), U(), Y(a, 1));
        return {
            jb: d.j(V(void 0), X(function() {
                return b.j(S(function(h) {
                    return {
                        timestamp: h.timestamp,
                        value: !0
                    }
                }), tx())
            }), U(), Y(a, 1)),
            kb: d.j(V(void 0), X(function() {
                return b.j(S(function(h) {
                    return {
                        timestamp: h.timestamp,
                        value: h.value === 0
                    }
                }), tx())
            }), U(), Y(a, 1)),
            Bc: d.j(V(void 0), X(function() {
                return b.j(Iv(xx, f))
            }), U(hb), Y(a, 1)),
            pa: d.j(V(void 0), X(function() {
                return b.j(Iv(yx, f), S(function(h) {
                    return h.map(function(k, l) {
                        return l > 0 ? k - h[l - 1] : k
                    })
                }))
            }), U(hb), Y(a, 1)),
            Ac: e,
            qb: g.j(U(dv), Y(a, 1))
        }
    };

    function Ax(a, b) {
        var c = this;
        this.C = a;
        this.i = this.g = null;
        this.l = b.j(U()).subscribe(function(d) {
            Bx(c);
            c.i = d
        })
    }

    function Cx(a, b) {
        Bx(a);
        a.g = a.C.setTimeout(function() {
            var c;
            return void((c = a.i) == null ? void 0 : c.next())
        }, b)
    }

    function Bx(a) {
        a.g !== null && a.C.clearTimeout(a.g);
        a.g = null
    }
    Ax.prototype.dispose = function() {
        Bx(this);
        this.l.unsubscribe();
        this.i = null
    };

    function Dx(a, b, c, d, e) {
        var f = Yv.mf;
        var g = g === void 0 ? new Ax(b, d) : g;
        return (new O(function(h) {
            var k = c.j(V(void 0), X(function() {
                return Ex(e)
            })).j(S(function(l) {
                var m = l.value;
                l = l.timestamp;
                var q = m.visible;
                m = m.qb;
                var t = m >= f;
                t || !q ? Bx(g) : (l = Math.max(0, rr(b.now(), l)), Cx(g, Math.max(0, f - m - l)));
                return t
            }), Uq(function(l, m) {
                return m || l
            }, !1), U()).subscribe(h);
            return function() {
                g.dispose();
                k.unsubscribe()
            }
        })).j(Xq(function(h) {
            return !h
        }, !0), Y(a, 1))
    }

    function Ex(a) {
        return Hv([a, a.j(vx())]).j(S(function(b) {
            var c = y(b);
            b = c.next().value;
            c = c.next().value;
            return {
                timestamp: b.timestamp,
                value: {
                    visible: b.value,
                    qb: c.value
                }
            }
        }), U(function(b, c) {
            return dv(b, c, function(d, e) {
                return d.qb === e.qb && d.visible === e.visible
            })
        }))
    };

    function Fx(a, b, c) {
        var d = c.j(S(function(e) {
            return {
                value: e,
                timestamp: a.C.now()
            }
        }), U(dv));
        return b instanceof O ? b.j(U(), X(function(e) {
            return e ? xt(new Z({
                value: !1,
                timestamp: a.C.now()
            }), a.B) : d
        })) : b.value === !1 ? d : new Z(!1)
    }

    function Gx(a, b, c, d, e, f, g) {
        var h = Yv;
        b = b instanceof O ? b.j(V(!1), U()) : b;
        var k = !(wd() || vd());
        c = Fx(a, c, d);
        a = g.fb.j(Su(a.B));
        return Object.assign({}, h, {
            Yc: c,
            rf: e,
            ze: k,
            cf: b,
            bd: a,
            nf: f
        })
    };

    function Hx(a) {
        this.F = bg(a, void 0, void 0, 2048)
    }
    x(Hx, Qh);
    var Ix = function(a) {
        return function(b) {
            return si(b, a)
        }
    }([0, Pi, -1, Mi, -3]);

    function Jx(a) {
        if (a.ub && typeof a.ub == "function") return a.ub();
        if (typeof Map !== "undefined" && a instanceof Map || typeof Set !== "undefined" && a instanceof Set) return Array.from(a.values());
        if (typeof a === "string") return a.split("");
        if (Ma(a)) {
            for (var b = [], c = a.length, d = 0; d < c; d++) b.push(a[d]);
            return b
        }
        return zb(a)
    }

    function Kx(a) {
        if (a.Ld && typeof a.Ld == "function") return a.Ld();
        if (!a.ub || typeof a.ub != "function") {
            if (typeof Map !== "undefined" && a instanceof Map) return Array.from(a.keys());
            if (!(typeof Set !== "undefined" && a instanceof Set)) {
                if (Ma(a) || typeof a === "string") {
                    var b = [];
                    a = a.length;
                    for (var c = 0; c < a; c++) b.push(c);
                    return b
                }
                b = [];
                c = 0;
                for (var d in a) b[c++] = d;
                return b
            }
        }
    }

    function Lx(a, b, c) {
        if (a.forEach && typeof a.forEach == "function") a.forEach(b, c);
        else if (Ma(a) || typeof a === "string") Array.prototype.forEach.call(a, b, c);
        else
            for (var d = Kx(a), e = Jx(a), f = e.length, g = 0; g < f; g++) b.call(c, e[g], d && d[g], a)
    };

    function ru(a) {
        this.l = this.A = this.m = "";
        this.D = null;
        this.u = this.i = "";
        this.o = !1;
        var b;
        a instanceof ru ? (this.o = a.o, Mx(this, a.m), this.A = a.A, this.l = a.l, Nx(this, a.D), this.i = a.i, Ox(this, a.g.clone()), this.u = a.u) : a && (b = String(a).match(oj)) ? (this.o = !1, Mx(this, b[1] || "", !0), this.A = Px(b[2] || ""), this.l = Px(b[3] || "", !0), Nx(this, b[4]), this.i = Px(b[5] || "", !0), Ox(this, b[6] || "", !0), this.u = Px(b[7] || "")) : (this.o = !1, this.g = new Qx(null, this.o))
    }
    ru.prototype.toString = function() {
        var a = [],
            b = this.m;
        b && a.push(Rx(b, Sx, !0), ":");
        var c = this.l;
        if (c || b == "file") a.push("//"), (b = this.A) && a.push(Rx(b, Sx, !0), "@"), a.push(encodeURIComponent(String(c)).replace(/%25([0-9a-fA-F]{2})/g, "%$1")), c = this.D, c != null && a.push(":", String(c));
        if (c = this.i) this.l && c.charAt(0) != "/" && a.push("/"), a.push(Rx(c, c.charAt(0) == "/" ? Tx : Ux, !0));
        (c = this.g.toString()) && a.push("?", c);
        (c = this.u) && a.push("#", Rx(c, Vx));
        return a.join("")
    };
    ru.prototype.resolve = function(a) {
        var b = this.clone(),
            c = !!a.m;
        c ? Mx(b, a.m) : c = !!a.A;
        c ? b.A = a.A : c = !!a.l;
        c ? b.l = a.l : c = a.D != null;
        var d = a.i;
        if (c) Nx(b, a.D);
        else if (c = !!a.i) {
            if (d.charAt(0) != "/")
                if (this.l && !this.i) d = "/" + d;
                else {
                    var e = b.i.lastIndexOf("/");
                    e != -1 && (d = b.i.slice(0, e + 1) + d)
                }
            e = d;
            if (e == ".." || e == ".") d = "";
            else if (e.indexOf("./") != -1 || e.indexOf("/.") != -1) {
                d = e.lastIndexOf("/", 0) == 0;
                e = e.split("/");
                for (var f = [], g = 0; g < e.length;) {
                    var h = e[g++];
                    h == "." ? d && g == e.length && f.push("") : h == ".." ? ((f.length > 1 || f.length == 1 && f[0] != "") && f.pop(), d && g == e.length && f.push("")) : (f.push(h), d = !0)
                }
                d = f.join("/")
            } else d = e
        }
        c ? b.i = d : c = a.g.toString() !== "";
        c ? Ox(b, a.g.clone()) : c = !!a.u;
        c && (b.u = a.u);
        return b
    };
    ru.prototype.clone = function() {
        return new ru(this)
    };

    function Mx(a, b, c) {
        a.m = c ? Px(b, !0) : b;
        a.m && (a.m = a.m.replace(/:$/, ""))
    }

    function Nx(a, b) {
        if (b) {
            b = Number(b);
            if (isNaN(b) || b < 0) throw Error("Bad port number " + b);
            a.D = b
        } else a.D = null
    }

    function Ox(a, b, c) {
        b instanceof Qx ? (a.g = b, Wx(a.g, a.o)) : (c || (b = Rx(b, Xx)), a.g = new Qx(b, a.o))
    }

    function Px(a, b) {
        return a ? b ? decodeURI(a.replace(/%25/g, "%2525")) : decodeURIComponent(a) : ""
    }

    function Rx(a, b, c) {
        return typeof a === "string" ? (a = encodeURI(a).replace(b, Yx), c && (a = a.replace(/%25([0-9a-fA-F]{2})/g, "%$1")), a) : null
    }

    function Yx(a) {
        a = a.charCodeAt(0);
        return "%" + (a >> 4 & 15).toString(16) + (a & 15).toString(16)
    }
    var Sx = /[#\/\?@]/g,
        Ux = /[#\?:]/g,
        Tx = /[#\?]/g,
        Xx = /[#\?@]/g,
        Vx = /#/g;

    function Qx(a, b) {
        this.i = this.g = null;
        this.l = a || null;
        this.m = !!b
    }

    function Zx(a) {
        a.g || (a.g = new Map, a.i = 0, a.l && pj(a.l, function(b, c) {
            a.add(decodeURIComponent(b.replace(/\+/g, " ")), c)
        }))
    }
    n = Qx.prototype;
    n.add = function(a, b) {
        Zx(this);
        this.l = null;
        a = $x(this, a);
        var c = this.g.get(a);
        c || this.g.set(a, c = []);
        c.push(b);
        this.i += 1;
        return this
    };
    n.remove = function(a) {
        Zx(this);
        a = $x(this, a);
        return this.g.has(a) ? (this.l = null, this.i -= this.g.get(a).length, this.g.delete(a)) : !1
    };
    n.clear = function() {
        this.g = this.l = null;
        this.i = 0
    };
    n.isEmpty = function() {
        Zx(this);
        return this.i == 0
    };

    function ay(a, b) {
        Zx(a);
        b = $x(a, b);
        return a.g.has(b)
    }
    n.forEach = function(a, b) {
        Zx(this);
        this.g.forEach(function(c, d) {
            c.forEach(function(e) {
                a.call(b, e, d, this)
            }, this)
        }, this)
    };
    n.Ld = function() {
        Zx(this);
        for (var a = Array.from(this.g.values()), b = Array.from(this.g.keys()), c = [], d = 0; d < b.length; d++)
            for (var e = a[d], f = 0; f < e.length; f++) c.push(b[d]);
        return c
    };
    n.ub = function(a) {
        Zx(this);
        var b = [];
        if (typeof a === "string") ay(this, a) && (b = b.concat(this.g.get($x(this, a))));
        else {
            a = Array.from(this.g.values());
            for (var c = 0; c < a.length; c++) b = b.concat(a[c])
        }
        return b
    };
    n.set = function(a, b) {
        Zx(this);
        this.l = null;
        a = $x(this, a);
        ay(this, a) && (this.i -= this.g.get(a).length);
        this.g.set(a, [b]);
        this.i += 1;
        return this
    };
    n.get = function(a, b) {
        if (!a) return b;
        a = this.ub(a);
        return a.length > 0 ? String(a[0]) : b
    };
    n.toString = function() {
        if (this.l) return this.l;
        if (!this.g) return "";
        for (var a = [], b = Array.from(this.g.keys()), c = 0; c < b.length; c++) {
            var d = b[c],
                e = encodeURIComponent(String(d));
            d = this.ub(d);
            for (var f = 0; f < d.length; f++) {
                var g = e;
                d[f] !== "" && (g += "=" + encodeURIComponent(String(d[f])));
                a.push(g)
            }
        }
        return this.l = a.join("&")
    };
    n.clone = function() {
        var a = new Qx;
        a.l = this.l;
        this.g && (a.g = new Map(this.g), a.i = this.i);
        return a
    };

    function $x(a, b) {
        b = String(b);
        a.m && (b = b.toLowerCase());
        return b
    }

    function Wx(a, b) {
        b && !a.m && (Zx(a), a.l = null, a.g.forEach(function(c, d) {
            var e = d.toLowerCase();
            d != e && (this.remove(d), this.remove(e), c.length > 0 && (this.l = null, this.g.set($x(this, e), db(c)), this.i += c.length))
        }, a));
        a.m = b
    }
    n.extend = function(a) {
        for (var b = 0; b < arguments.length; b++) Lx(arguments[b], function(c, d) {
            this.add(d, c)
        }, this)
    };

    function by(a, b) {
        var c = new Hx;
        c = Mg(c, 3, b.name);
        c = Ng(c, 2, 1);
        c = Mg(c, 4, b.message);
        c = Mg(c, 5, b.stack);
        c = Mg(c, 6, String(a.P.le));
        switch (b.name) {
            case "SecurityError":
                Ng(c, 1, 2);
                break;
            case "QuotaExceededError":
                Ng(c, 1, 1);
                break;
            case "SyntaxError":
                Ng(c, 1, 3);
                break;
            case "TypeError":
                Ng(c, 1, 4);
                break;
            case "InvalidStateError":
                Ng(c, 1, 7);
                break;
            case "AbortError":
                Ng(c, 1, 6);
                break;
            case "NotSupportedError":
                Ng(c, 1, 8);
                break;
            case "IframeError":
                Ng(c, 1, 5);
                break;
            case "LocksApiUnavailableError":
                Ng(c, 1, 9);
                break;
            default:
                Ng(c, 1, 0)
        }
        b = new ru("https://pagead2.googlesyndication.com/pagead/gen_204");
        b.g.set("id", "av-js");
        b.g.set("type", "omakase");
        c = ee(Ix(c));
        b.g.set("proto", c);
        b.g.set("v", "unreleased");
        a.N.O(b.toString(), {
            ka: "GET"
        }).sendNow()
    };

    function cy(a) {
        this.I = a
    }
    n = cy.prototype;
    n.reportError = function(a) {
        by(this.I, a)
    };
    n.setItem = function(a, b) {
        try {
            this.hasLocalStorageAccess() && this.I.localStorage.setItem(a, b)
        } catch (c) {
            this.reportError(c)
        }
    };
    n.getItem = function(a) {
        try {
            if (this.hasLocalStorageAccess()) return this.I.localStorage.getItem(a)
        } catch (b) {
            this.reportError(b)
        }
        return null
    };
    n.hasLocalStorageAccess = function() {
        return Ys(this.I)
    };
    n.xc = function() {
        return this.I.xc()
    };
    n.ce = function(a, b) {
        var c = this;
        return Da(function(d) {
            return d.g(c.I.ce(a, b), 0)
        })
    };
    n.performExclusiveLockedOperation = function(a, b) {
        var c = this,
            d;
        return Da(function(e) {
            if (e.i == 1) {
                if (!c.xc()) return b(), e.ea(0);
                e.M(3);
                return e.g(c.I.ce(a, b), 5)
            }
            if (e.i != 3) return e.V(0);
            d = e.D();
            c.reportError(d);
            e.H()
        })
    };

    function dy(a) {
        this.F = bg(a, void 0, void 0, 2048)
    }
    x(dy, Qh);

    function ey(a, b) {
        return Mg(a, 1, b)
    };
    var Yv = Object.freeze({
            mf: 1E3,
            Id: .5,
            Ud: .3
        }),
        Tv = Object.freeze([1, .75, Yv.Id, Yv.Ud, 0]);

    function fy(a, b, c, d, e) {
        this.A = a;
        this.g = void 0;
        this.o = b;
        this.qc = c;
        this.Oc = d;
        this.Pc = e;
        this.Ia = 2;
        this.name = "rxlidar";
        this.u = new kp;
        this.controlledEvents = [];
        this.subscribedEvents = [];
        this.l = new kp;
        this.i = new kp;
        this.controlledEvents.push(this.qc, this.Oc, this.Pc);
        this.subscribedEvents.push(this.o)
    }
    n = fy.prototype;
    n.start = function(a) {
        if (this.m === void 0 && a.I) {
            var b;
            if ((b = this.g) != null) var c = b;
            else {
                b = a.I;
                var d = (c = a.oa) != null ? c : null;
                c = {
                    Xf: .01,
                    xg: br(b.C, 36E5),
                    Eb: b.C.Ka(100).j(Y(b.B, 1)),
                    oa: d
                }
            }
            this.g = c;
            a = a.I;
            this.m = gy(a, this.l.j(Y(a.B, 1)), this.g.Xf, this.g.xg, this.g.Eb, this.g.oa, this.i.j(V(!1), Y(a.B, 1)), this.qc, this.Oc, this.Pc, this.Ia).subscribe(this.u)
        }
    };
    n.dispose = function() {
        this.l.complete();
        this.i.complete();
        var a;
        (a = this.m) == null || a.unsubscribe();
        this.m = void 0
    };
    n.Nd = function(a, b, c, d, e) {
        var f;
        (f = !og(b, Ag, 2)) || (f = Bg(b, Ag, 2), f = Gg(f, 4, !0));
        if (f) {
            this.l.next(Object.assign({}, this.A.Fe.get(a), {
                metadata: b,
                experimentState: c,
                di: a,
                Ya: d
            }));
            var g, h;
            e((h = (g = Bg(b, Ag, 2)) == null ? void 0 : Hg(g, 6)) != null ? h : -1)
        }
    };
    n.Pb = function() {};
    n.handleEvent = function(a, b) {
        b === this.o && (this.i.next(!0), this.i.complete())
    };

    function gy(a, b, c, d, e, f, g, h, k, l, m) {
        var q = qx(a).j(S(function(r) {
                return !r
            })),
            t = new Cw(a, [new Zw(a, Tv), new Lw(a, e), new px(f, a, Tv), new ox(f, a, e), new ix(a, e)]);
        return eu(a, b, function(r, w) {
            var u = nw(r, w.element),
                v = u.za,
                C = u.rc,
                P = u.Fd,
                J = u.lb,
                da = u.Rf,
                F = u.yb,
                z = u.og,
                W = u.Qd,
                Vc = u.Rd,
                Uc = u.X,
                Nd = u.xa,
                La = u.Yg,
                Od = u.Bb;
            u = u.Td;
            var ch, $a = (ch = Jt(zg(w.metadata))) != null ? ch : "",
                Qy = Lt(zg(w.metadata));
            ch = Rh(ey(new dy, atob($a)));
            $a = xt(new Z(w.experimentState), r.B);
            var kq = new Z(new tr(r, new cs(r))),
                lq = $a.j(S(function(E) {
                    return E.fetchLaterBeacons
                }), V(!1), U(), Y(r.B, 1)),
                Ry = lq.j(S(function(E) {
                    return E && (new Xr(r)).T({
                        Ke: !0
                    })
                }), Yq(function(E) {
                    E && kq.value.O("https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=fetch&later&start&control&fle=1&sfl=1").sendNow()
                })),
                Ye = $a.j(S(function(E) {
                    return E.shouldIgnoreAdChoicesIcon
                })),
                Ta = F.j(Cq(z), S(function(E) {
                    var ab = y(E);
                    E = ab.next().value;
                    ab = ab.next().value;
                    return E || ab || Rj()
                }));
            z = new zw(r, w, da, F, Uc, Ye);
            Ye = $a.j(S(function(E) {
                return E.considerOmidZOrderOcclusions
            }));
            var Wc, Jb = (Wc = Kt(zg(w.metadata))) != null ? Wc : !1;
            Wc = t.g(z, {
                yb: F,
                qf: Jb,
                X: Uc,
                df: Ye
            });
            var jb = Wc.sb,
                Ze = Wc.ob;
            Wc = Ze.Zd;
            Ye = Ze.ae;
            Ze = Ze.ke;
            Jb = xt(new Z(Jb), r.B);
            var Xc = Gx(r, Vc, Ta, q, La, Jb, z);
            La = Zv(r.B, r.C, jb, Xc);
            Ta = zx(r.B, La.Ja.me, La.Ja.visible, La.he, La.Gc);
            Jb = Dx(r.B, r.C, La.Gc, La.Ja.ma, La.Ja.visible);
            jb = Bv(r.B, r.C, jb, Xc);
            Xc = Sv(r.C, r.B, jb.Ja.me, jb.Ja.visible, jb.he, jb.Gc);
            var dh = {
                    pd: Xv(r.B, r.C, jb.Gc, Xc.Ac)
                },
                Ak = $a.j(S(function(E) {
                    return E.extrapolators
                }), V(!1));
            jb = Ru(r.B, Ak, Object.assign({}, jb.Ja, Xc, dh), Object.assign({}, La.Ja, {
                pd: kv(r, Jb),
                Bc: kv(r, Ta.Bc),
                pa: kv(r, Ta.pa),
                Ac: kv(r, Ta.Ac),
                qb: Ta.qb.j(S(function(E) {
                    return new jv(r.C, E)
                })),
                jb: kv(r, Ta.jb),
                kb: kv(r, Ta.kb)
            }));
            Ta = av(r, d.j(Fq("t")));
            Jb = (f !== null && f.validate() ? f.Lg : Yp).j(Y(r.B, 1), Fq("u"));
            Ta = bq(Ta, Jb);
            var mq = Ta.j(T(function(E) {
                return E !== null
            }));
            Jb = $a.j(S(function(E) {
                return E.shouldCacheTimeMetricsInLocalStorage && Qy
            }), U(), Y(r.B, 1)).j(S(function(E) {
                E && hy(r);
                return E && Ys(r, function(ab) {
                    by(r, ab)
                }) && !r.zb
            }), U(), Y(r.B, 1));
            Xc = $a.j(S(function(E) {
                return E.omakaseAdStatsResetVersion
            }), U(), Y(r.B, 1));
            var Ty = r.C.Ka(4E3).j(Cq(q), T(function(E) {
                E = y(E);
                E.next();
                return !E.next().value
            }), S(function(E) {
                return y(E).next().value
            }), Y(r.B, 1));
            dh = Jb.j(X(function(E) {
                return E ? Xp(mq, Ty) : mq
            }), U(), Y(r.B, 1));
            Ak = rx(r, jb.ma, dh);
            var nq = iy(r, z, v),
                Wy = jy(r, Ta, w.element),
                Xy = nq.Ef.j(V({
                    x: 0,
                    y: 0
                })),
                Yy = $a.j(S(function(E) {
                    return E.rxlidarStatefulBeacons
                }), V(!1), U(), Yq(function(E) {
                    gs = E
                }), Y(r.B, 1)),
                oq = W.j(S(function(E) {
                    return E === 40 || E === 41 || E === 42
                })),
                Zy = $a.j(S(function(E) {
                    return E.waitForImpressionColleague
                }), V(!1), U(), Y(r.B, 1)),
                $y = b.j(S(function(E) {
                    var ab;
                    return E.experimentState.addQueryIdToErrorPing ? (ab = Bg(E.metadata, Tt, 3)) == null ? void 0 : Mf(kg(ab, 1)) : void 0
                }));
            return Object.assign({}, {
                N: new Z(r.N),
                Sb: new Z("lidar2"),
                Pg: new Z("lidartos"),
                Hf: new Z("unreleased"),
                Ia: new Z(m),
                Ed: new Z(r.validate() ? null : new er),
                Lf: new Z(ws(r.document)),
                fa: new Z(vu),
                Hd: Ta,
                lf: Ta,
                Xh: Ak,
                wc: g,
                Xg: Zy,
                yg: dh,
                ge: Jb,
                Gg: Xc,
                Ya: new Z(w.Ya),
                qc: new Z(h),
                Oc: new Z(k),
                Pc: new Z(l),
                Qf: new Z(r.zb ? 1 : void 0),
                Sf: new Z(r.If ? 1 : void 0),
                yb: F,
                Bb: Od,
                ne: new Z(ch),
                Wb: Od.j(T(function(E) {
                    return E
                }), S(function() {
                    return r.Wb.bind(r)
                })),
                Zd: Wc.j(Y(r.B, 1)),
                ae: Ye.j(Y(r.B, 1)),
                Yf: $a.j(S(function(E) {
                    return E.extraPings
                })),
                We: Yy,
                gg: lq,
                jf: Ry,
                Td: u,
                ng: oq,
                hg: $a.j(S(function(E) {
                    return E.dedicatedViewableAttributionPing
                })),
                Zf: kq,
                kf: new Z(gs && (new fs(r)).T({
                    ka: "GET"
                })),
                Mg: new Z(Number(w.experimentState.useReachIntegrationSharedStorage) << Number(w.experimentState.useReachIntegrationPolyfill) << 1 + Number(w.experimentState.sendBrowserIdInsteadOfVPID) << 2),
                Mf: w.element.j(S(function(E) {
                    return E !== null
                })),
                xb: Nd,
                Qg: Nd,
                Fd: P.j(V([])),
                lb: J.j(V([])),
                dg: P.j(S(function(E) {
                    return E.length > 0 ? !0 : null
                }), V(null), U()),
                rc: C.j(V([]), Y(r.B, 1)),
                Eh: $a,
                shouldSendExplicitDisplayMeasurablePing: $a.j(S(function(E) {
                    return E.shouldSendExplicitDisplayMeasurablePing
                })),
                za: v,
                sc: z.sc,
                Qd: W.j(V(0), Y(r.B, 1)),
                wg: da,
                X: Uc.j(V(0), Y(r.B, 1)),
                Ib: oq.j(S(function(E) {
                    return E ? Pu : uu
                })),
                cc: new Z(Qu),
                Rd: Vc,
                Xe: z.zc.j(Su(r.B)),
                re: z.re
            }, jb, {
                Tc: Ep([jb.Tc, Xy]).j(S(function(E) {
                    var ab = y(E);
                    E = ab.next().value;
                    ab = ab.next().value;
                    return Fs(E, ab)
                }), U(Ds))
            }, nq, {
                Hc: Zt(r),
                eg: Wy,
                ke: Ze,
                ld: La.Ja.ld,
                Jf: new Z(new Lu),
                escapedQueryId: $y
            })
        }, tu(a, "https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=error&bin=" + m + "&v=unreleased", c), yu(zu(Au(), Ku), gu, wu, qu(new cy(a))))
    }

    function iy(a, b, c) {
        var d = d === void 0 ? Ia : d;
        var e, f;
        d = ((e = d.performance) == null ? void 0 : (f = e.timing) == null ? void 0 : f.navigationStart) || 0;
        return Object.assign({}, {
            Df: new Z(d),
            Cf: $u(a, b)
        }, Zu(a, b, c))
    }

    function jy(a, b, c) {
        return b.j(T(function(d) {
            return d !== null
        }), X(function() {
            return c
        }), S(function(d) {
            var e = At(a);
            return e.length > 0 && e.indexOf(d) >= 0
        }), S(function(d) {
            return !d
        }))
    }

    function hy(a) {
        if (a.zb) {
            var b = Error();
            b.name = "IframeError";
            b.message = "Failure: Omakase is running in cross origin context.";
            by(a, b)
        }
        a.xc() || (b = Error(), b.name = "LocksApiUnavailableError", b.message = "Failure: Web Locks API is not present", by(a, b))
    };

    function ky(a) {
        var b = b === void 0 ? [] : b;
        var c = c === void 0 ? [a] : c;
        this.l = a;
        this.subscribedEvents = b;
        this.controlledEvents = c;
        this.name = "impression";
        this.g = new Map
    }
    n = ky.prototype;
    n.start = function(a) {
        this.i = a
    };
    n.dispose = function() {
        this.g.clear()
    };
    n.Nd = function(a, b, c, d) {
        if (b = this.i) c = new ly(b, c, this.l, d), this.g.set(a, c)
    };
    n.Pb = function(a) {
        this.g.delete(a)
    };
    n.handleEvent = function() {};

    function ly(a, b, c, d) {
        var e = this;
        this.context = a;
        this.A = c;
        this.u = function() {};
        this.o = [];
        this.l = "&avradf=1";
        this.m = kt([]);
        this.i = new kp;
        c = a.oa;
        var f = c !== null && (c == null ? void 0 : c.validate()),
            g, h = (g = a.I) == null ? void 0 : g.B;
        this.i.j(V(!b.waitForImpressionColleague), Y(h, 1));
        this.D = f ? c == null ? void 0 : c.Ve.j(Gq(1), Fq(!0), V(!1)) : xt(new Z(!0), h);
        this.u = function(k, l) {
            e.i.next(!0);
            e.i.complete();
            Ep([e.i, e.D]).subscribe(function(m) {
                var q = y(m);
                m = q.next().value;
                q = q.next().value;
                if (!q) return Yp;
                m && q && d(e.A, k, l);
                return !0
            })
        };
        this.init(a.I)
    }
    ly.prototype.init = function(a) {
        var b = this;
        this.g = a.global.document;
        this.o.push(my(this));
        var c = {};
        this.m = kt(this.o);
        this.m.then(function() {
            b.l = "&vis=" + qd(b.g) + "&uach=0&ms=0";
            c.paramString = b.l;
            c.view_type = "DELAYED_IMPRESSION";
            b.u(c, function() {})
        })
    };

    function my(a) {
        return new ht(function(b) {
            var c = rd(a.g);
            if (c)
                if (qd(a.g) === 3) {
                    var d = function() {
                        pd(a.g, c, d);
                        b(!0)
                    };
                    od(a.g, c, d)
                } else b(!0)
        })
    };

    function ny(a) {
        var b = bt(a);
        return b ? b.j(S(function(c) {
            var d;
            c = (d = Cg(c).find(function(f) {
                return Mf(kg(f, 1)) === "Google Chrome"
            })) == null ? void 0 : Mf(kg(d, 2));
            if (!c) return !1;
            var e;
            return ((e = y(c.split(".").map(function(f) {
                return Number(f)
            })).next().value) != null ? e : 0) >= 121
        })) : xt(yt, a.B)
    };

    function oy(a, b) {
        b = "https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=reach&proto=" + encodeURIComponent(ee(b.g()));
        a.N.O(b, {
            ka: "GET"
        }).sendNow()
    };

    function py(a) {
        return [{
            Nb: 2,
            Fc: !1,
            tc: !0,
            filterIds: qy(a == null ? void 0 : a.productionFilterIds)
        }, {
            Nb: 2,
            Fc: !0,
            tc: !0,
            filterIds: qy(a == null ? void 0 : a.testFilterIds)
        }, {
            Nb: 2,
            Fc: !1,
            tc: !1,
            filterIds: qy(a == null ? void 0 : a.testFilterIds)
        }]
    }

    function qy(a) {
        if (a !== void 0 && typeof BigInt === "function") return a.map(function(b) {
            return BigInt(b)
        })
    };

    function ry(a) {
        this.F = bg(a, void 0, void 0, 2048)
    }
    x(ry, Qh);

    function sy(a, b) {
        return Ng(a, 1, b)
    }

    function ty(a, b) {
        return Mg(a, 2, b)
    }

    function uy(a, b) {
        return Mg(a, 3, b)
    };
    ry.prototype.g = Ti([0, Pi, Mi, -1, Pi, -2, Mi, -1, Hi, Mi, Rt, Qi, Hi]);

    function vy(a) {
        this.context = a;
        this.g = []
    }

    function wy(a, b) {
        Da(function(c) {
            if (c.i == 1) return c.ta(2), c.g(b(), 4);
            if (c.i != 2) return c.return(c.l);
            c.Y();
            a.flush();
            return c.Z(0)
        })
    }
    vy.prototype.flush = function() {
        if (!(this.g.length <= 0)) {
            var a = new ry;
            sy(a, 9);
            var b = py().length;
            mg(a, 13, Cf(b));
            Fg(a, 12, this.g);
            this.g.splice(0);
            oy(this.context, a)
        }
    };

    function xy() {
        this.blockSize = -1
    };

    function yy(a, b) {
        this.blockSize = -1;
        this.blockSize = 64;
        this.m = Ia.Uint8Array ? new Uint8Array(this.blockSize) : Array(this.blockSize);
        this.l = this.i = 0;
        this.g = [];
        this.u = a;
        this.o = b;
        this.A = Ia.Int32Array ? new Int32Array(64) : Array(64);
        zy === void 0 && (Ia.Int32Array ? zy = new Int32Array(Ay) : zy = Ay);
        this.reset()
    }
    Pa(yy, xy);
    for (var By = [], Cy = 0; Cy < 63; Cy++) By[Cy] = 0;
    var Dy = [].concat(128, By);
    yy.prototype.reset = function() {
        this.l = this.i = 0;
        this.g = Ia.Int32Array ? new Int32Array(this.o) : db(this.o)
    };

    function Ey(a) {
        for (var b = a.m, c = a.A, d = 0, e = 0; e < b.length;) c[d++] = b[e] << 24 | b[e + 1] << 16 | b[e + 2] << 8 | b[e + 3], e = d * 4;
        for (b = 16; b < 64; b++) d = c[b - 15] | 0, e = c[b - 2] | 0, c[b] = ((c[b - 16] | 0) + ((d >>> 7 | d << 25) ^ (d >>> 18 | d << 14) ^ d >>> 3) | 0) + ((c[b - 7] | 0) + ((e >>> 17 | e << 15) ^ (e >>> 19 | e << 13) ^ e >>> 10) | 0) | 0;
        b = a.g[0] | 0;
        d = a.g[1] | 0;
        e = a.g[2] | 0;
        for (var f = a.g[3] | 0, g = a.g[4] | 0, h = a.g[5] | 0, k = a.g[6] | 0, l = a.g[7] | 0, m = 0; m < 64; m++) {
            var q = ((b >>> 2 | b << 30) ^ (b >>> 13 | b << 19) ^ (b >>> 22 | b << 10)) + (b & d ^ b & e ^ d & e) | 0,
                t = (l + ((g >>> 6 | g << 26) ^ (g >>> 11 | g << 21) ^ (g >>> 25 | g << 7)) | 0) + (((g & h ^ ~g & k) + (zy[m] | 0) | 0) + (c[m] | 0) | 0) | 0;
            l = k;
            k = h;
            h = g;
            g = f + t | 0;
            f = e;
            e = d;
            d = b;
            b = t + q | 0
        }
        a.g[0] = a.g[0] + b | 0;
        a.g[1] = a.g[1] + d | 0;
        a.g[2] = a.g[2] + e | 0;
        a.g[3] = a.g[3] + f | 0;
        a.g[4] = a.g[4] + g | 0;
        a.g[5] = a.g[5] + h | 0;
        a.g[6] = a.g[6] + k | 0;
        a.g[7] = a.g[7] + l | 0
    }
    yy.prototype.update = function(a, b) {
        b === void 0 && (b = a.length);
        var c = 0,
            d = this.i;
        if (typeof a === "string")
            for (; c < b;) this.m[d++] = a.charCodeAt(c++), d == this.blockSize && (Ey(this), d = 0);
        else if (Ma(a))
            for (; c < b;) {
                var e = a[c++];
                if (!("number" == typeof e && 0 <= e && 255 >= e && e == (e | 0))) throw Error("message must be a byte array");
                this.m[d++] = e;
                d == this.blockSize && (Ey(this), d = 0)
            } else throw Error("message must be string or array");
        this.i = d;
        this.l += b
    };
    var Ay = [1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298],
        zy;

    function Fy() {
        yy.call(this, 8, Gy)
    }
    Pa(Fy, yy);
    var Gy = [1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225];

    function Hy(a) {
        this.F = bg(a, void 0, void 0, 2048)
    }
    x(Hy, Qh);
    Hy.prototype.g = Ti([0, xk, Li, -1, Ni, -3, Ri, Li]);
    var Iy = Si(wk, xk);

    function Jy() {
        var a;
        this.message = a = a === void 0 ? new Hy : a
    }

    function Ky(a, b) {
        var c = a.message;
        b = Iy(ge(b));
        c = Eg(c, 1, b);
        a.message = c;
        return a
    }

    function Ly(a, b) {
        var c = Jg(a.message, 2, b.Nb === 2);
        b = Jg(c, 3, !b.Fc);
        a.message = b;
        return a
    }

    function My(a, b) {
        a.message = Kg(a.message, 4, Math.max(1, b));
        return a
    }

    function Ny(a, b) {
        a.message = Fg(a.message, 8, b);
        return a
    }

    function Oy(a) {
        var b = "unreleased".match(/m\d{12}/g),
            c = "unreleased".match(/\d{8}/g);
        if (b && b.length > 0) {
            b = b[0].slice(1);
            c = a.message;
            var d = Number(b.slice(0, 8));
            c = Kg(c, 5, d);
            d = Number(b.slice(8, 10));
            c = Kg(c, 6, d);
            b = Number(b.slice(10, 12));
            b = Kg(c, 7, b);
            a.message = b;
            return a
        }
        if (c && c.length > 0) return b = Kg(a.message, 5, Number(c[0])), b = mg(b, 6), b = mg(b, 7), a.message = b, a;
        b = mg(a.message, 5);
        b = Kg(b, 6, 0);
        b = mg(b, 7);
        a.message = b;
        return a
    }

    function Py(a) {
        a = a.message;
        var b = ee(a.g());
        b.length > 64 && (a = Kg(a, 4, 1), b = ee(a.g()));
        b.length > 64 && (a = mg(a, 6), b = ee(a.g()));
        b.length > 64 && (a = mg(a, 7), b = ee(a.g()));
        b.length > 64 && (a = mg(a, 5), b = ee(a.g()));
        return b
    };

    function Sy(a, b) {
        if (b === void 0 || b.length === 0) return oy(a, sy(new ry, 7)), [iq(0)].filter(function(d) {
            return d !== void 0
        });
        var c = iq(-2147483648);
        return c === void 0 ? [] : b.map(function(d) {
            var e = d % c;
            d !== e && oy(a, sy(new ry, 6));
            return e
        })
    };

    function Uy(a, b) {
        var c = c === void 0 ? BigInt(0) : c;
        return {
            bucket: a,
            value: b ? 1 : 16384,
            filteringId: c
        }
    };

    function Vy(a) {
        for (var b = [], c = 0, d = 0; d < a.length; d++) {
            var e = a.charCodeAt(d);
            e < 128 ? b[c++] = e : (e < 2048 ? b[c++] = e >> 6 | 192 : ((e & 64512) == 55296 && d + 1 < a.length && (a.charCodeAt(d + 1) & 64512) == 56320 ? (e = 65536 + ((e & 1023) << 10) + (a.charCodeAt(++d) & 1023), b[c++] = e >> 18 | 240, b[c++] = e >> 12 & 63 | 128) : b[c++] = e >> 12 | 224, b[c++] = e >> 6 & 63 | 128), b[c++] = e & 63 | 128)
        }
        if (b.length >= 24) throw Error("String too long for CBOR encoder.");
        return [96 | b.length].concat(A(b))
    }

    function az(a) {
        if (a.length >= 24) throw Error("Map too long for CBOR encoder.");
        return [160 | a.length].concat(A(a.sort(bz).map(function(b) {
            return [].concat(A(b[0]), A(b[1]))
        }).flat()))
    }

    function cz(a) {
        if (a.length >= 24) throw Error("Array too long for CBOR encoder.");
        return [128 | a.length].concat(A(a.flat()))
    }

    function dz(a, b) {
        for (var c = []; a > 0;) c.push(Number(a % BigInt(255))), a /= BigInt(255);
        for (; c.length < b;) c.push(0);
        return c.reverse()
    }

    function bz(a, b) {
        a = a[0];
        b = b[0];
        if (a.length !== b.length) return a.length - b.length;
        for (var c = 0; c < a.length; c++)
            if (a[c] !== b[c]) return a[c] - b[c];
        return 0
    };

    function ez(a, b, c, d) {
        var e = Uy(BigInt(c), d);
        b = {
            shared_info: JSON.stringify({
                api: "shared-storage",
                report_id: "PRE_WORKLET_ERROR",
                reporting_origin: "https://www.googleadservices.com",
                scheduled_report_time: String((new Date).getUTCSeconds()),
                version: "polyfill"
            }),
            aggregation_service_payloads: [],
            context_id: b,
            aggregation_coordinator_origin: "https://publickeyservice.msmt.gcp.privacysandboxservices.com"
        };
        d ? (b.debug_key = "0", b.aggregation_service_payloads.push({
            payload: String(c),
            key_id: "0",
            debug_cleartext_payload: fz([e])
        })) : b.aggregation_service_payloads.push({
            payload: String(c),
            key_id: "0"
        });
        try {
            var f, g;
            (f = a.global) == null || (g = f.fetch) == null || g.call(f, "https://www.googleadservices.com/.well-known/private-aggregation/report-shared-storage", {
                method: "POST",
                cache: "no-cache",
                keepalive: !0,
                mode: "no-cors",
                headers: {
                    "content-type": "application/json"
                },
                body: JSON.stringify(b)
            }).catch(function() {})
        } catch (h) {}
    }

    function fz(a) {
        a = az([
            [Vy("data"), cz(a.map(function(b) {
                return az([
                    [Vy("value"), [68].concat(A(dz(BigInt(b.value), 4)))],
                    [Vy("bucket"), [80].concat(A(dz(b.bucket, 16)))],
                    [Vy("filteringId"), [68].concat(A(dz(b.filteringId, 4)))]
                ])
            }))],
            [Vy("operation"), Vy("histogram")]
        ]);
        return btoa(String.fromCharCode.apply(String, A(new Uint8Array(a))))
    };
    var gz = {},
        hz = (gz[2] = "prod", gz[1] = "canary", gz);

    function iz(a, b, c, d) {
        var e, f, g, h, k, l, m, q;
        return Da(function(t) {
            switch (t.i) {
                case 1:
                    e = py(c);
                    f = function(r) {
                        e.forEach(function(w) {
                            var u, v = Py(My(Oy(Ly(Ny(Ky(new Jy, c.escapedQueryId), (u = c.trafficTypes) != null ? u : [0]), w)), -1));
                            ez(a, v, r, w.tc)
                        })
                    };
                    g = Xs(a);
                    if (g instanceof Error) return f(-16), h = uy(ty(sy(new ry, 8), g.name), g.message), oy(a, h), t.return();
                    d.g.push(7);
                    k = jz(a, c, e);
                    return t.g(c.experimentState.reachUseCreateWorklet ? kz(a, b, f) : lz(a, b, f), 2);
                case 2:
                    return l = t.l, t.g(k, 3);
                case 3:
                    return m = t.l, d.g.push(8), q = e.map(function(r) {
                        var w, u, v;
                        return mz(a, l, r, m, (w = c.deviceType) != null ? w : 1, c.escapedQueryId, (u = c.trafficTypes) != null ? u : [0], (v = c.isProductSplitVpidLogsExperiment) != null ? v : !1, function(C) {
                            var P, J = Py(Oy(Ly(My(Ny(Ky(new Jy, c.escapedQueryId), (P = c.trafficTypes) != null ? P : [0]), -1), r)));
                            ez(a, J, C, r.tc)
                        })
                    }), t.g(Promise.all(q), 4);
                case 4:
                    d.g.push(9), t.H()
            }
        })
    }

    function lz(a, b, c) {
        var d, e, f;
        return Da(function(g) {
            switch (g.i) {
                case 1:
                    d = a.sharedStorage;
                    if (!d) return g.return(Promise.reject(Error("no shared storage API")));
                    g.M(2);
                    return g.g(d.worklet.addModule(b), 4);
                case 4:
                    g.V(3);
                    break;
                case 2:
                    e = g.D(), c(-17), f = uy(ty(sy(new ry, 1), e.name), e.message), oy(a, f);
                case 3:
                    return g.return(d)
            }
        })
    }

    function kz(a, b, c) {
        var d, e, f;
        return Da(function(g) {
            if (g.i == 1) {
                d = a.sharedStorage;
                if (!d) return g.return(Promise.reject(Error("no shared storage API")));
                g.M(2);
                return g.g(d.createWorklet(b, {
                    dataOrigin: "script-origin"
                }), 4)
            }
            if (g.i != 2) return g.return(g.l);
            e = g.D();
            c(-17);
            f = uy(ty(sy(new ry, 1), e.name), e.message);
            oy(a, f);
            return g.return(Promise.reject(e))
        })
    }

    function jz(a, b, c) {
        var d, e, f;
        return Da(function(g) {
            if (g.i == 1) return d = [].concat(A(new Set(c.map(function(h) {
                return h.Nb
            })))), e = d.map(function(h) {
                return nz(a, b, h)
            }), g.g(Promise.all(e), 2);
            f = g.l;
            return g.return(new Map(f.map(function(h, k) {
                return [d[k], h]
            })))
        })
    }

    function nz(a, b, c) {
        var d, e, f, g, h, k, l, m, q;
        return Da(function(t) {
            switch (t.i) {
                case 1:
                    e = (d = b.clientsideModelFilename) != null ? d : "model_person_country_code_XX_person_region_code_5858.json";
                    f = void 0;
                    g = 1;
                    h = {
                        method: "GET"
                    };
                    k = 200;
                    l = b.geoTargetMessage ? Ot(b.geoTargetMessage) : void 0;
                    var r = new ry;
                    r = Mg(r, 10, b.escapedQueryId);
                    m = Eg(r, 11, l);
                    t.M(2);
                    return t.g(a.global.fetch(oz(c, e), h), 4);
                case 4:
                    f = t.l;
                    k = f.status;
                    if (f.ok) {
                        t.ea(5);
                        break
                    }
                    return t.g(a.global.fetch(oz(c, "model_person_country_code_XX_person_region_code_5858.json"), h), 6);
                case 6:
                    f = t.l, g = 2;
                case 5:
                    t.V(3);
                    break;
                case 2:
                    q = t.D(), k = -1, q instanceof Error && uy(ty(m, q.name), q.message);
                case 3:
                    r = sy(m, 2);
                    mg(r, 9, Cf(k));
                    if (!f || !f.ok) return r = Ng(m, 4, 4), r = Mg(r, 8, e), Mg(r, 7, ""), oy(a, m), t.return();
                    r = Ng(m, 4, g);
                    Mg(r, 7, g === 1 ? e : "");
                    oy(a, m);
                    return t.g(f.text(), 7);
                case 7:
                    return t.return(t.l)
            }
        })
    }

    function oz(a, b) {
        return "https://www.googletagservices.com/agrp/" + hz[a] + "/" + b
    }

    function mz(a, b, c, d, e, f, g, h, k) {
        var l, m, q, t, r, w, u;
        return Da(function(v) {
            switch (v.i) {
                case 1:
                    l = d.get(c.Nb);
                    if (l === void 0) return v.return();
                    var C = iq(-2147483648);
                    if (C === void 0) C = -1;
                    else {
                        var P = Number,
                            J = new Fy;
                        J.update(l);
                        var da = [],
                            F = J.l * 8;
                        J.i < 56 ? J.update(Dy, 56 - J.i) : J.update(Dy, J.blockSize - (J.i - 56));
                        for (var z = 63; z >= 56; z--) J.m[z] = F & 255, F /= 256;
                        Ey(J);
                        for (z = F = 0; z < J.u; z++)
                            for (var W = 24; W >= 0; W -= 8) da[F++] = J.g[z] >> W & 255;
                        J = BigInt(0);
                        da = y(da);
                        for (F = da.next(); !F.done; F = da.next()) J = (J * BigInt(256) + BigInt(F.value)) % C;
                        C = P(J)
                    }
                    m = C;
                    C = Oy(My(Ly(Ny(Ky(new Jy, f), g), c), m));
                    C.message = Jg(C.message, 9, h);
                    q = Py(C);
                    t = {
                        contextId: q,
                        aggregationCoordinatorOrigin: "https://publickeyservice.msmt.gcp.privacysandboxservices.com",
                        filteringIdMaxBytes: 4
                    };
                    r = {
                        modelJson: l,
                        modelHash: m,
                        deviceType: e,
                        enableDebugMode: c.tc,
                        reportBrowserIdInsteadOfVPID: c.Fc,
                        filterIds: Sy(a, c.filterIds)
                    };
                    w = b.run("google_reach", {
                        privateAggregationConfig: t,
                        data: r,
                        keepAlive: !0
                    });
                    if (w === void 0) {
                        v.ea(2);
                        break
                    }
                    v.M(3);
                    return v.g(w, 5);
                case 5:
                    v.V(2);
                    break;
                case 3:
                    u = v.D(), k(-18), C = u, J = uy(ty(sy(new ry, 3), (P = C == null ? void 0 : C.name) != null ? P : "unknown"), (da = C == null ? void 0 : C.message) != null ? da : ""), oy(a, J);
                case 2:
                    C = sy(new ry, 5), C = Ng(C, 5, c.Nb === 1 ? 1 : 2), C = Ng(C, 6, c.Fc ? 1 : 2), oy(a, C), v.H()
            }
        })
    };

    function pz(a) {
        var b = b === void 0 ? [] : b;
        var c = c === void 0 ? [a] : c;
        this.i = a;
        this.subscribedEvents = b;
        this.controlledEvents = c;
        this.name = "reach";
        this.g = new Map
    }
    n = pz.prototype;
    n.start = function(a) {
        a.I && (this.context = a.I)
    };
    n.dispose = function() {
        this.g.forEach(function(a) {
            return void a.dispose()
        });
        this.g.clear()
    };
    n.Nd = function(a, b, c, d, e) {
        var f = this,
            g = this.context;
        if (g) {
            var h = new vy(g);
            wy(h, function() {
                var k, l, m, q;
                return Da(function(t) {
                    if (t.i == 1) {
                        h.g.push(1);
                        var r;
                        if (r = og(b, Pt, 1)) r = Wt(b), r = !Gg(r, 3, !0);
                        if (r) return t.return();
                        h.g.push(2);
                        return Xs(g) ? t.g(pp(ny(g)), 2) : t.return()
                    }
                    if (t.i != 3) {
                        k = t.l;
                        if (!k) return t.return();
                        h.g.push(3);
                        l = new qz(g, b, f.i, c, d, h);
                        f.g.set(a, l);
                        return t.g(l.run(), 3)
                    }
                    e((q = (m = Wt(b)) == null ? void 0 : Hg(m, 10)) != null ? q : -1);
                    t.H()
                })
            })
        }
    };
    n.Pb = function(a) {
        var b;
        (b = this.g.get(a)) == null || b.dispose();
        this.g.delete(a)
    };
    n.handleEvent = function() {};

    function qz(a, b, c, d, e, f) {
        this.context = a;
        this.metadata = b;
        this.i = c;
        this.experimentState = d;
        this.Ya = e;
        this.g = f
    }
    qz.prototype.run = function() {
        var a = this,
            b, c;
        return Da(function(d) {
            if (d.i == 1) return b = {}, d.g(new Promise(function(e) {
                a.Ya(a.i, b, e)
            }), 2);
            c = d.l;
            if (!c) return d.return();
            a.g.g.push(4);
            return d.g(rz(a), 0)
        })
    };

    function rz(a) {
        var b, c, d, e, f, g, h, k, l, m, q, t, r, w, u, v, C, P;
        return Da(function(J) {
            var da = a.experimentState,
                F = (l = (b = Wt(a.metadata)) == null ? void 0 : Ig(b)) != null ? l : "",
                z;
            (c = Wt(a.metadata)) == null ? z = void 0 : z = qg(c, 7, Bf, void 0 === Pe ? 2 : 4);
            z = (m = z) != null ? m : void 0;
            var W = (d = Wt(a.metadata)) == null ? void 0 : Mf(kg(d, 1)),
                Vc = (q = (e = Wt(a.metadata)) == null ? void 0 : (f = Bg(e, Nt, 4)) == null ? void 0 : Rh(f)) != null ? q : void 0,
                Uc = (t = (g = Wt(a.metadata)) == null ? void 0 : Hg(g, 8)) != null ? t : void 0,
                Nd = sz,
                La;
            (h = Wt(a.metadata)) == null ? La = void 0 : La = qg(h, 5, Df, Pe === Pe ? 2 : 4);
            La = Nd(a, (r = La) != null ? r : void 0);
            Nd = sz;
            var Od;
            (k = Wt(a.metadata)) == null ? Od = void 0 : Od = qg(k, 6, Df, Pe === Pe ? 2 : 4);
            u = {
                experimentState: da,
                escapedQueryId: F,
                trafficTypes: z,
                isProductSplitVpidLogsExperiment: !0,
                clientsideModelFilename: W,
                geoTargetMessage: Vc,
                deviceType: Uc,
                productionFilterIds: La,
                testFilterIds: Nd(a, (w = Od) != null ? w : void 0)
            };
            if (a.experimentState.reachUseCreateWorklet) return P = a.context.je[2], a.g.g.push(10), J.g(iz(a.context, P, u, a.g), 0);
            v = a.context.je[0];
            C = btoa(JSON.stringify(u));
            return J.g(zs(a.context.document, v, C), 0)
        })
    }

    function sz(a, b) {
        if (b !== void 0) return b.map(function(c) {
            var d;
            return String((d = iq(c)) != null ? d : 0)
        })
    }
    qz.prototype.dispose = function() {};

    function tz(a) {
        var b = new gt("impression"),
            c = new gt("begin to render"),
            d = new gt("unmeasurable"),
            e = new gt("viewable"),
            f = new gt("reach vpid"),
            g = new et(b, f, c, e, d),
            h = new Yt,
            k = new ky(b.event);
        b = new fy(h, b.event, c.event, d.event, e.event);
        (new mt(a, g, h, k, b, new pz(f.event))).start()
    };
    var uz = {
        rxInNonrx: !1,
        fetchLaterBeacons: !1,
        addQueryIdToErrorPing: !1,
        shouldSendExplicitDisplayMeasurablePing: !1,
        dedicatedViewableAttributionPing: 0,
        shouldIgnoreAdChoicesIcon: !1,
        considerOmidZOrderOcclusions: !1,
        extraPings: 0,
        extrapolators: !1,
        rxlidarStatefulBeacons: !1,
        tosCustomTimeoutMillis: 36E5,
        shouldCacheTimeMetricsInLocalStorage: !0,
        omakaseAdStatsResetVersion: 2,
        waitForImpressionColleague: !1,
        reachUseCreateWorklet: !1,
        useReachIntegrationPolyfill: !1,
        useReachIntegrationSharedStorage: !0,
        sendBrowserIdInsteadOfVPID: !1
    };

    function vz(a) {
        return new ht(function(b) {
            function c() {
                return void b(uz)
            }
            try {
                (new Yt(!0)).start(a, function(k, l, m) {
                    b(m)
                }, function() {}, c);
                var d, e, f, g, h = (g = (f = a == null ? void 0 : (d = a.oa) == null ? void 0 : d.C) != null ? f : a == null ? void 0 : (e = a.I) == null ? void 0 : e.C) != null ? g : void 0;
                h !== void 0 ? h.setTimeout(c, 10) : c()
            } catch (k) {
                c()
            }
        })
    };
    (function() {
        var a = Jr(),
            b = Or(a),
            c = {
                I: new Ws(void 0, void 0, void 0, a),
                oa: b
            };
        vz(c).then(function(d) {
            d.rxInNonrx ? tz(c) : Aj(378, function() {
                var e = D.apply(0, arguments),
                    f;
                return (f = Md(mo)).sg.apply(f, A(e))
            })
        })
    })();
}).call(this, this, this.document);