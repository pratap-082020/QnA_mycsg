(function(sttc) {
    'use strict';
    var r, aa, ba = Object.create,
        ca = Object.defineProperty,
        ea = globalThis,
        fa = typeof Symbol === "function" && typeof Symbol("x") === "symbol",
        ha = {},
        ia = {};

    function ja(a, b, c) {
        if (!c || a != null) {
            c = ia[b];
            if (c == null) return a[b];
            c = a[c];
            return c !== void 0 ? c : a[b]
        }
    }

    function la(a, b, c) {
        if (b) a: {
            var d = a.split(".");a = d.length === 1;
            var e = d[0],
                f;!a && e in ha ? f = ha : f = ea;
            for (e = 0; e < d.length - 1; e++) {
                var g = d[e];
                if (!(g in f)) break a;
                f = f[g]
            }
            d = d[d.length - 1];c = fa && c === "es6" ? f[d] : null;b = b(c);b != null && (a ? ca(ha, d, {
                configurable: !0,
                writable: !0,
                value: b
            }) : b !== c && (ia[d] === void 0 && (a = Math.random() * 1E9 >>> 0, ia[d] = fa ? ea.Symbol(d) : "$jscp$" + a + "$" + d), ca(f, ia[d], {
                configurable: !0,
                writable: !0,
                value: b
            })))
        }
    }
    var ma = Object.setPrototypeOf;

    function oa(a, b) {
        a.prototype = ba(b.prototype);
        a.prototype.constructor = a;
        ma(a, b);
        a.On = b.prototype
    }
    la("Symbol.dispose", function(a) {
        return a ? a : Symbol("Symbol.dispose")
    }, "es_next");
    la("String.prototype.replaceAll", function(a) {
        return a ? a : function(b, c) {
            if (b instanceof RegExp && !b.global) throw new TypeError("String.prototype.replaceAll called with a non-global RegExp argument.");
            return b instanceof RegExp ? this.replace(b, c) : this.replace(new RegExp(String(b).replace(/([-()\[\]{}+?*.$\^|,:#<!\\])/g, "\\$1").replace(/\x08/g, "\\x08"), "g"), c)
        }
    }, "es_2021");
    la("Promise.withResolvers", function(a) {
        return a ? a : function() {
            var b, c;
            return {
                promise: new Promise(function(d, e) {
                    b = d;
                    c = e
                }),
                resolve: b,
                reject: c
            }
        }
    }, "es_next");
    la("AggregateError", function(a) {
        function b(c, d) {
            d = Error(d);
            "stack" in d && (this.stack = d.stack);
            this.errors = c;
            this.message = d.message
        }
        if (a) return a;
        oa(b, Error);
        b.prototype.name = "AggregateError";
        return b
    }, "es_2021");
    la("Promise.any", function(a) {
        return a ? a : function(b) {
            b = b instanceof Array ? b : Array.from(b);
            return Promise.all(b.map(function(c) {
                return Promise.resolve(c).then(function(d) {
                    throw d;
                }, function(d) {
                    return d
                })
            })).then(function(c) {
                throw new ha.AggregateError(c, "All promises were rejected");
            }, function(c) {
                return c
            })
        }
    }, "es_2021");
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    var t = this || self;

    function pa(a, b) {
        a: {
            var c = ["CLOSURE_FLAGS"];
            for (var d = t, e = 0; e < c.length; e++)
                if (d = d[c[e]], d == null) {
                    c = null;
                    break a
                }
            c = d
        }
        a = c && c[a];
        return a != null ? a : b
    }

    function qa(a) {
        var b = typeof a;
        return b != "object" ? b : a ? Array.isArray(a) ? "array" : b : "null"
    }

    function ra(a) {
        var b = typeof a;
        return b == "object" && a != null || b == "function"
    }

    function sa(a) {
        return Object.prototype.hasOwnProperty.call(a, ta) && a[ta] || (a[ta] = ++ua)
    }
    var ta = "closure_uid_" + (Math.random() * 1E9 >>> 0),
        ua = 0;

    function wa(a, b, c) {
        return a.call.apply(a.bind, arguments)
    }

    function xa(a, b, c) {
        if (!a) throw Error();
        if (arguments.length > 2) {
            var d = Array.prototype.slice.call(arguments, 2);
            return function() {
                var e = Array.prototype.slice.call(arguments);
                Array.prototype.unshift.apply(e, d);
                return a.apply(b, e)
            }
        }
        return function() {
            return a.apply(b, arguments)
        }
    }

    function za(a, b, c) {
        za = Function.prototype.bind && Function.prototype.bind.toString().indexOf("native code") != -1 ? wa : xa;
        return za.apply(null, arguments)
    }

    function Aa(a, b) {
        var c = Array.prototype.slice.call(arguments, 1);
        return function() {
            var d = c.slice();
            d.push.apply(d, arguments);
            return a.apply(this, d)
        }
    }

    function Ba(a, b, c) {
        a = a.split(".");
        c = c || t;
        for (var d; a.length && (d = a.shift());) a.length || b === void 0 ? c[d] && c[d] !== Object.prototype[d] ? c = c[d] : c = c[d] = {} : c[d] = b
    }

    function Ca(a) {
        return a
    }

    function Fa(a, b) {
        function c() {}
        c.prototype = b.prototype;
        a.On = b.prototype;
        a.prototype = new c;
        a.prototype.constructor = a;
        a.sp = function(d, e, f) {
            for (var g = Array(arguments.length - 2), h = 2; h < arguments.length; h++) g[h - 2] = arguments[h];
            return b.prototype[e].apply(d, g)
        }
    };
    var Ga = {
        ap: 0,
        Zo: 1,
        Yo: 2
    };
    var Ha;
    let Ia;

    function Ja(a) {
        t.setTimeout(() => {
            throw a;
        }, 0)
    };

    function Ka(a) {
        return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
    };
    var La = pa(610401301, !1),
        Ma = pa(748402147, !0);

    function Na() {
        var a = t.navigator;
        return a && (a = a.userAgent) ? a : ""
    }
    var Oa;
    const Pa = t.navigator;
    Oa = Pa ? Pa.userAgentData || null : null;

    function Qa(a) {
        if (!La || !Oa) return !1;
        for (let b = 0; b < Oa.brands.length; b++) {
            let {
                brand: c
            } = Oa.brands[b];
            if (c && c.indexOf(a) != -1) return !0
        }
        return !1
    }

    function Ra(a) {
        return Na().indexOf(a) != -1
    };

    function Sa() {
        return La ? !!Oa && Oa.brands.length > 0 : !1
    }

    function Ta() {
        return Sa() ? !1 : Ra("Opera")
    }

    function Ua() {
        return Ra("Firefox") || Ra("FxiOS")
    }

    function Va() {
        return Ra("Safari") && !(Za() || (Sa() ? 0 : Ra("Coast")) || Ta() || (Sa() ? 0 : Ra("Edge")) || (Sa() ? Qa("Microsoft Edge") : Ra("Edg/")) || (Sa() ? Qa("Opera") : Ra("OPR")) || Ua() || Ra("Silk") || Ra("Android"))
    }

    function Za() {
        return Sa() ? Qa("Chromium") : (Ra("Chrome") || Ra("CriOS")) && !(Sa() ? 0 : Ra("Edge")) || Ra("Silk")
    };

    function $a(a, b) {
        if (typeof a === "string") return typeof b !== "string" || b.length != 1 ? -1 : a.indexOf(b, 0);
        for (let c = 0; c < a.length; c++)
            if (c in a && a[c] === b) return c;
        return -1
    }

    function ab(a, b) {
        var c = a.length,
            d = typeof a === "string" ? a.split("") : a;
        for (let e = 0; e < c; e++) e in d && b.call(void 0, d[e], e, a)
    }

    function bb(a, b) {
        var c = a.length,
            d = typeof a === "string" ? a.split("") : a;
        for (--c; c >= 0; --c) c in d && b.call(void 0, d[c], c, a)
    }

    function cb(a, b) {
        var c = a.length,
            d = [],
            e = 0,
            f = typeof a === "string" ? a.split("") : a;
        for (let g = 0; g < c; g++)
            if (g in f) {
                let h = f[g];
                b.call(void 0, h, g, a) && (d[e++] = h)
            }
        return d
    }

    function db(a, b) {
        var c = a.length,
            d = Array(c),
            e = typeof a === "string" ? a.split("") : a;
        for (let f = 0; f < c; f++) f in e && (d[f] = b.call(void 0, e[f], f, a));
        return d
    }

    function eb(a, b) {
        var c = 1;
        ab(a, function(d, e) {
            c = b.call(void 0, c, d, e, a)
        });
        return c
    }

    function fb(a, b) {
        var c = a.length,
            d = typeof a === "string" ? a.split("") : a;
        for (let e = 0; e < c; e++)
            if (e in d && b.call(void 0, d[e], e, a)) return !0;
        return !1
    }

    function hb(a, b) {
        return $a(a, b) >= 0
    }

    function ib(a, b) {
        b = $a(a, b);
        var c;
        (c = b >= 0) && Array.prototype.splice.call(a, b, 1);
        return c
    }

    function kb(a, b) {
        var c = 0;
        bb(a, function(d, e) {
            b.call(void 0, d, e, a) && Array.prototype.splice.call(a, e, 1).length == 1 && c++
        })
    }

    function lb(a) {
        return Array.prototype.concat.apply([], arguments)
    }

    function mb(a) {
        var b = a.length;
        if (b > 0) {
            let c = Array(b);
            for (let d = 0; d < b; d++) c[d] = a[d];
            return c
        }
        return []
    }

    function nb(a, b) {
        for (let d = 1; d < arguments.length; d++) {
            let e = arguments[d];
            var c = qa(e);
            if (c == "array" || c == "object" && typeof e.length == "number") {
                c = a.length || 0;
                let f = e.length || 0;
                a.length = c + f;
                for (let g = 0; g < f; g++) a[c + g] = e[g]
            } else a.push(e)
        }
    }

    function ob(a, b, c) {
        c = c || pb;
        for (var d = 0, e = a.length, f; d < e;) {
            let g = d + (e - d >>> 1),
                h;
            h = c(b, a[g]);
            h > 0 ? d = g + 1 : (e = g, f = !h)
        }
        return f ? d : -d - 1
    }

    function pb(a, b) {
        return a > b ? 1 : a < b ? -1 : 0
    }

    function qb(a, b) {
        b = b || Math.random;
        for (let c = a.length - 1; c > 0; c--) {
            let d = Math.floor(b() * (c + 1)),
                e = a[c];
            a[c] = a[d];
            a[d] = e
        }
    };

    function rb(a) {
        rb[" "](a);
        return a
    }
    rb[" "] = function() {};

    function sb(a, b) {
        try {
            return rb(a[b]), !0
        } catch (c) {}
        return !1
    };
    var tb = Sa() ? !1 : Ra("Trident") || Ra("MSIE"),
        ub = Ra("Edge") || tb,
        vb = Ra("Gecko") && !(Na().toLowerCase().indexOf("webkit") != -1 && !Ra("Edge")) && !(Ra("Trident") || Ra("MSIE")) && !Ra("Edge"),
        xb = Na().toLowerCase().indexOf("webkit") != -1 && !Ra("Edge");
    const yb = {};
    let zb = null;

    function Ab(a) {
        var b = 3;
        b === void 0 && (b = 0);
        Bb();
        b = yb[b];
        for (var c = Array(Math.floor(a.length / 3)), d = b[64] || "", e = 0, f = 0; e < a.length - 2; e += 3) {
            var g = a[e],
                h = a[e + 1],
                k = a[e + 2],
                l = b[g >> 2];
            g = b[(g & 3) << 4 | h >> 4];
            h = b[(h & 15) << 2 | k >> 6];
            k = b[k & 63];
            c[f++] = l + g + h + k
        }
        l = 0;
        k = d;
        switch (a.length - e) {
            case 2:
                l = a[e + 1], k = b[(l & 15) << 2] || d;
            case 1:
                a = a[e], c[f] = b[a >> 2] + b[(a & 3) << 4 | l >> 4] + k + d
        }
        return c.join("")
    }

    function Cb(a) {
        var b = [];
        Db(a, function(c) {
            b.push(c)
        });
        return b
    }

    function Db(a, b) {
        function c(e) {
            for (; d < a.length;) {
                let f = a.charAt(d++),
                    g = zb[f];
                if (g != null) return g;
                if (!/^[\s\xa0]*$/.test(f)) throw Error("Unknown base64 encoding at char: " + f);
            }
            return e
        }
        Bb();
        for (var d = 0;;) {
            let e = c(-1),
                f = c(0),
                g = c(64),
                h = c(64);
            if (h === 64 && e === -1) break;
            b(e << 2 | f >> 4);
            g != 64 && (b(f << 4 & 240 | g >> 2), h != 64 && b(g << 6 & 192 | h))
        }
    }

    function Bb() {
        if (!zb) {
            zb = {};
            var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""),
                b = ["+/=", "+/", "-_=", "-_.", "-_"];
            for (let c = 0; c < 5; c++) {
                let d = a.concat(b[c].split(""));
                yb[c] = d;
                for (let e = 0; e < d.length; e++) {
                    let f = d[e];
                    zb[f] === void 0 && (zb[f] = e)
                }
            }
        }
    };
    var Eb = typeof structuredClone != "undefined";

    function Fb(a, b) {
        a.__closure__error__context__984382 || (a.__closure__error__context__984382 = {});
        a.__closure__error__context__984382.severity = b
    };
    let Hb = void 0,
        Ib;

    function Jb(a) {
        if (Ib) throw Error("");
        Ib = b => {
            t.setTimeout(() => {
                a(b)
            }, 0)
        }
    }

    function Mb(a) {
        if (Ib) try {
            Ib(a)
        } catch (b) {
            throw b.cause = a, b;
        }
    }

    function Nb() {
        var a = Error();
        Fb(a, "incident");
        Ib ? Mb(a) : Ja(a)
    }

    function Ob(a) {
        a = Error(a);
        Fb(a, "warning");
        Mb(a);
        return a
    }

    function Pb(a, b) {
        if (a != null) {
            var c = Hb ? ? (Hb = {});
            var d = c[a] || 0;
            d >= b || (c[a] = d + 1, Nb())
        }
    };

    function Qb(a, b = !1) {
        return b && Symbol.for && a ? Symbol.for(a) : a != null ? Symbol(a) : Symbol()
    }
    var Rb = Qb(),
        Sb = Qb(),
        Tb = Qb(),
        Ub = Qb(),
        Wb = Qb(),
        Xb = Qb("m_m", !0);
    const v = Qb("jas", !0);
    var Yb;
    const Zb = [];
    Zb[v] = 7;
    Yb = Object.freeze(Zb);

    function $b(a, b) {
        a[v] |= b
    }

    function ac(a) {
        if (4 & a) return 512 & a ? 512 : 1024 & a ? 1024 : 0
    }

    function bc(a) {
        $b(a, 34);
        return a
    }

    function cc(a) {
        $b(a, 8192);
        return a
    }

    function dc(a) {
        $b(a, 32);
        return a
    };
    var ec = {};

    function hc(a, b) {
        return b === void 0 ? a.l !== ic && !!(2 & (a.aa[v] | 0)) : !!(2 & b) && a.l !== ic
    }
    const ic = {};
    class jc {
        constructor(a, b, c) {
            this.g = a;
            this.j = b;
            this.l = c
        }
        next() {
            var a = this.g.next();
            a.done || (a.value = this.j.call(this.l, a.value));
            return a
        }[Symbol.iterator]() {
            return this
        }
    }
    var kc = Object.freeze({});

    function lc(a, b, c) {
        var d = b & 128 ? 0 : -1,
            e = a.length,
            f;
        if (f = !!e) f = a[e - 1], f = f != null && typeof f === "object" && f.constructor === Object;
        var g = e + (f ? -1 : 0);
        for (b = b & 128 ? 1 : 0; b < g; b++) c(b - d, a[b]);
        if (f) {
            a = a[e - 1];
            for (let h in a) Object.prototype.hasOwnProperty.call(a, h) && !isNaN(h) && c(+h, a[h])
        }
    }
    var mc = {};

    function nc(a) {
        a.yp = !0;
        return a
    };
    var oc = nc(a => typeof a === "number"),
        x = nc(a => typeof a === "string"),
        pc = nc(a => typeof a === "boolean"),
        qc = nc(a => typeof a === "function"),
        rc = nc(a => !!a && (typeof a === "object" || typeof a === "function"));

    function sc() {
        return tc(nc((a, b) => a === void 0 ? !0 : x(a, b)))
    }

    function tc(a) {
        a.Fm = !0;
        return a
    }
    var uc = nc(a => Array.isArray(a));

    function vc() {
        return nc(a => uc(a) ? a.every(b => oc(b)) : !1)
    };

    function wc(a) {
        if (x(a)) {
            if (!/^\s*(?:-?[1-9]\d*|0)?\s*$/.test(a)) throw Error(String(a));
        } else if (oc(a) && !Number.isSafeInteger(a)) throw Error(String(a));
        return BigInt(a)
    }
    var Dc = nc(a => a >= Bc && a <= Cc);
    const Bc = BigInt(Number.MIN_SAFE_INTEGER),
        Cc = BigInt(Number.MAX_SAFE_INTEGER);
    let Ec = 0,
        Fc = 0,
        Gc;

    function Hc(a) {
        var b = a >>> 0;
        Ec = b;
        Fc = (a - b) / 4294967296 >>> 0
    }

    function Ic(a) {
        if (a < 0) {
            Hc(-a);
            a = Ec;
            var b = Fc;
            b = ~b;
            a ? a = ~a + 1 : b += 1;
            let [c, d] = [a, b];
            Ec = c >>> 0;
            Fc = d >>> 0
        } else Hc(a)
    }

    function Jc(a, b) {
        var c = b * 4294967296 + (a >>> 0);
        return Number.isSafeInteger(c) ? c : Kc(a, b)
    }

    function Kc(a, b) {
        b >>>= 0;
        a >>>= 0;
        var c;
        b <= 2097151 ? c = "" + (4294967296 * b + a) : c = "" + (BigInt(b) << BigInt(32) | BigInt(a));
        return c
    }

    function Lc() {
        var a = Ec,
            b = Fc,
            c;
        b & 2147483648 ? c = "" + (BigInt(b | 0) << BigInt(32) | BigInt(a >>> 0)) : c = Kc(a, b);
        return c
    }

    function Mc(a) {
        a.length < 16 ? Ic(Number(a)) : (a = BigInt(a), Ec = Number(a & BigInt(4294967295)) >>> 0, Fc = Number(a >> BigInt(32) & BigInt(4294967295)))
    };

    function Qc(a, b = `unexpected value ${a}!`) {
        throw Error(b);
    };
    const Rc = typeof BigInt === "function" ? BigInt.asIntN : void 0,
        Sc = typeof BigInt === "function" ? BigInt.asUintN : void 0,
        Tc = Number.isSafeInteger,
        Uc = Number.isFinite,
        Vc = Math.trunc;

    function Wc(a) {
        if (a != null && typeof a !== "number") throw Error(`Value of float/double field must be a number, found ${typeof a}: ${a}`);
        return a
    }

    function Xc(a) {
        if (a == null || typeof a === "number") return a;
        if (a === "NaN" || a === "Infinity" || a === "-Infinity") return Number(a)
    }

    function Yc(a) {
        if (typeof a !== "boolean") throw Error(`Expected boolean but got ${qa(a)}: ${a}`);
        return a
    }

    function Zc(a) {
        if (a == null || typeof a === "boolean") return a;
        if (typeof a === "number") return !!a
    }
    const cd = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;

    function dd(a) {
        switch (typeof a) {
            case "bigint":
                return !0;
            case "number":
                return Uc(a);
            case "string":
                return cd.test(a);
            default:
                return !1
        }
    }

    function ed(a) {
        if (!Uc(a)) throw Ob("enum");
        return a | 0
    }

    function fd(a) {
        return a == null ? a : Uc(a) ? a | 0 : void 0
    }

    function gd(a) {
        if (typeof a !== "number") throw Ob("int32");
        if (!Uc(a)) throw Ob("int32");
        return a | 0
    }

    function hd(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return Uc(a) ? a | 0 : void 0
    }

    function id(a) {
        if (typeof a !== "number") throw Ob("uint32");
        if (!Uc(a)) throw Ob("uint32");
        return a >>> 0
    }

    function jd(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return Uc(a) ? a >>> 0 : void 0
    }

    function kd(a, b) {
        b ? ? (b = 1024);
        if (!dd(a)) throw Ob("int64");
        var c = typeof a;
        switch (b) {
            case 512:
                switch (c) {
                    case "string":
                        return ld(a);
                    case "bigint":
                        return String(Rc(64, a));
                    default:
                        return md(a)
                }
            case 1024:
                switch (c) {
                    case "string":
                        return nd(a);
                    case "bigint":
                        return wc(Rc(64, a));
                    default:
                        return od(a)
                }
            case 0:
                switch (c) {
                    case "string":
                        return ld(a);
                    case "bigint":
                        return wc(Rc(64, a));
                    default:
                        return pd(a)
                }
            default:
                return Qc(b, "Unknown format requested type for int64")
        }
    }

    function pd(a) {
        a = Vc(a);
        if (!Tc(a)) {
            Ic(a);
            var b = Ec,
                c = Fc;
            if (a = c & 2147483648) b = ~b + 1 >>> 0, c = ~c >>> 0, b == 0 && (c = c + 1 >>> 0);
            b = Jc(b, c);
            a = typeof b === "number" ? a ? -b : b : a ? "-" + b : b
        }
        return a
    }

    function qd(a) {
        a = Vc(a);
        a >= 0 && Tc(a) || (Ic(a), a = Jc(Ec, Fc));
        return a
    }

    function md(a) {
        a = Vc(a);
        Tc(a) ? a = String(a) : (Ic(a), a = Lc());
        return a
    }

    function td(a) {
        a = Vc(a);
        a >= 0 && Tc(a) ? a = String(a) : (Ic(a), a = Kc(Ec, Fc));
        return a
    }

    function ld(a) {
        var b = Vc(Number(a));
        if (Tc(b)) return String(b);
        b = a.indexOf(".");
        b !== -1 && (a = a.substring(0, b));
        b = a.length;
        (a[0] === "-" ? b < 20 || b === 20 && a <= "-9223372036854775808" : b < 19 || b === 19 && a <= "9223372036854775807") || (Mc(a), a = Lc());
        return a
    }

    function nd(a) {
        var b = Vc(Number(a));
        if (Tc(b)) return wc(b);
        b = a.indexOf(".");
        b !== -1 && (a = a.substring(0, b));
        return wc(Rc(64, BigInt(a)))
    }

    function od(a) {
        return Tc(a) ? wc(pd(a)) : wc(md(a))
    }

    function ud(a) {
        return Tc(a) ? wc(qd(a)) : wc(td(a))
    }

    function vd(a) {
        var b = Vc(Number(a));
        if (Tc(b) && b >= 0) return String(b);
        b = a.indexOf(".");
        b !== -1 && (a = a.substring(0, b));
        a[0] === "-" ? b = !1 : (b = a.length, b = b < 20 ? !0 : b === 20 && a <= "18446744073709551615");
        b || (Mc(a), a = Kc(Ec, Fc));
        return a
    }

    function wd(a) {
        var b = Vc(Number(a));
        if (Tc(b) && b >= 0) return wc(b);
        b = a.indexOf(".");
        b !== -1 && (a = a.substring(0, b));
        return wc(Sc(64, BigInt(a)))
    }

    function xd(a) {
        if (a == null) return a;
        if (typeof a === "bigint") return Dc(a) ? a = Number(a) : (a = Rc(64, a), a = Dc(a) ? Number(a) : String(a)), a;
        if (dd(a)) return typeof a === "number" ? pd(a) : ld(a)
    }

    function yd(a) {
        var b = typeof a;
        if (a == null) return a;
        if (b === "bigint") return wc(Rc(64, a));
        if (dd(a)) return b === "string" ? nd(a) : od(a)
    }

    function zd(a, b) {
        b ? ? (b = 1024);
        if (!dd(a)) throw Ob("uint64");
        var c = typeof a;
        switch (b) {
            case 512:
                switch (c) {
                    case "string":
                        return vd(a);
                    case "bigint":
                        return String(Sc(64, a));
                    default:
                        return td(a)
                }
            case 1024:
                switch (c) {
                    case "string":
                        return wd(a);
                    case "bigint":
                        return wc(Sc(64, a));
                    default:
                        return ud(a)
                }
            case 0:
                switch (c) {
                    case "string":
                        return vd(a);
                    case "bigint":
                        return wc(Sc(64, a));
                    default:
                        return qd(a)
                }
            default:
                return Qc(b, "Unknown format requested type for int64")
        }
    }

    function Ad(a) {
        var b = typeof a;
        if (a == null) return a;
        if (b === "bigint") return wc(Sc(64, a));
        if (dd(a)) return b === "string" ? wd(a) : ud(a)
    }

    function Bd(a) {
        if (a == null) return a;
        var b = typeof a;
        if (b === "bigint") return String(Rc(64, a));
        if (dd(a)) {
            if (b === "string") return ld(a);
            if (b === "number") return pd(a)
        }
    }

    function Cd(a) {
        if (a == null) return a;
        var b = typeof a;
        if (b === "bigint") return String(Sc(64, a));
        if (dd(a)) {
            if (b === "string") return vd(a);
            if (b === "number") return qd(a)
        }
    }

    function Dd(a) {
        if (typeof a !== "string") throw Error();
        return a
    }

    function Ed(a) {
        if (a != null && typeof a !== "string") throw Error();
        return a
    }

    function Fd(a) {
        return a == null || typeof a === "string" ? a : void 0
    }

    function Gd(a, b, c, d) {
        if (a != null && a[Xb] === ec) return a;
        if (!Array.isArray(a)) return c ? d & 2 ? b[Rb] || (b[Rb] = Hd(b)) : new b : void 0;
        c = a[v] | 0;
        d = c | d & 32 | d & 2;
        d !== c && (a[v] = d);
        return new b(a)
    }

    function Hd(a) {
        a = new a;
        bc(a.aa);
        return a
    }

    function Id(a, b, c) {
        return b ? Dd(a) : Fd(a) ? ? (c ? "" : void 0)
    }

    function Jd(a, b, c) {
        a = b ? ed(a) : fd(a);
        return a == null ? c ? 0 : void 0 : a
    };

    function Kd(a) {
        return a
    };
    const Ld = {},
        Md = (() => class extends Map {
            constructor() {
                super()
            }
        })();

    function Nd(a) {
        return a
    }

    function Od(a) {
        if (a.ld & 2) throw Error("Cannot mutate an immutable Map");
    }
    var Rd = class extends Md {
        constructor(a, b, c = Nd, d = Nd) {
            super();
            this.ld = a[v] | 0;
            this.ed = b;
            this.Gf = c;
            this.Ak = this.ed ? Pd : d;
            for (let e = 0; e < a.length; e++) {
                let f = a[e],
                    g = c(f[0], !1, !0),
                    h = f[1];
                b ? h === void 0 && (h = null) : h = d(f[1], !1, !0, void 0, void 0, this.ld);
                super.set(g, h)
            }
        }
        Bi(a) {
            return cc(Array.from(super.entries(), a))
        }
        clear() {
            Od(this);
            super.clear()
        }
        delete(a) {
            Od(this);
            return super.delete(this.Gf(a, !0, !1))
        }
        entries() {
            if (this.ed) {
                var a = super.keys();
                a = new jc(a, Qd, this)
            } else a = super.entries();
            return a
        }
        values() {
            if (this.ed) {
                var a =
                    super.keys();
                a = new jc(a, Rd.prototype.get, this)
            } else a = super.values();
            return a
        }
        forEach(a, b) {
            this.ed ? super.forEach((c, d, e) => {
                a.call(b, e.get(d), d, e)
            }) : super.forEach(a, b)
        }
        set(a, b) {
            Od(this);
            a = this.Gf(a, !0, !1);
            return a == null ? this : b == null ? (super.delete(a), this) : super.set(a, this.Ak(b, !0, !0, this.ed, !1, this.ld))
        }
        has(a) {
            return super.has(this.Gf(a, !1, !1))
        }
        get(a) {
            a = this.Gf(a, !1, !1);
            var b = super.get(a);
            if (b !== void 0) {
                var c = this.ed;
                return c ? (c = this.Ak(b, !1, !0, c, this.tl, this.ld), c !== b && super.set(a, c), c) : b
            }
        }[Symbol.iterator]() {
            return this.entries()
        }
    };
    Rd.prototype.toJSON = void 0;

    function Pd(a, b, c, d, e, f) {
        a = Gd(a, d, c, f);
        e && (a = Sd(a));
        return a
    }

    function Qd(a) {
        return [a, this.get(a)]
    }
    let Td;

    function Ud() {
        return Td || (Td = new Rd(bc([]), void 0, void 0, void 0, Ld))
    };

    function Vd(a, b, c, d) {
        var e = d !== void 0;
        d = !!d;
        var f = [],
            g = a.length,
            h = 4294967295,
            k = !1,
            l = !!(b & 64),
            m = l ? b & 128 ? 0 : -1 : void 0;
        if (!(b & 1)) {
            var n = g && a[g - 1];
            n != null && typeof n === "object" && n.constructor === Object ? (g--, h = g) : n = void 0;
            !l || b & 128 || e || (k = !0, h = (Wd ? ? Kd)(h - m, m, a, n, void 0) + m)
        }
        b = void 0;
        for (e = 0; e < g; e++) {
            let p = a[e];
            if (p != null && (p = c(p, d)) != null)
                if (l && e >= h) {
                    let q = e - m;
                    (b ? ? (b = {}))[q] = p
                } else f[e] = p
        }
        if (n)
            for (let p in n) {
                if (!Object.prototype.hasOwnProperty.call(n, p)) continue;
                a = n[p];
                if (a == null || (a = c(a, d)) == null) continue;
                g = +p;
                let q;
                l && !Number.isNaN(g) && (q = g + m) < h ? f[q] = a : (b ? ? (b = {}))[p] = a
            }
        b && (k ? f.push(b) : f[h] = b);
        return f
    }

    function Xd(a) {
        a[0] = Yd(a[0]);
        a[1] = Yd(a[1]);
        return a
    }

    function Yd(a) {
        switch (typeof a) {
            case "number":
                return Number.isFinite(a) ? a : "" + a;
            case "bigint":
                return Dc(a) ? Number(a) : "" + a;
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (Array.isArray(a)) {
                    let b = a[v] | 0;
                    return a.length === 0 && b & 1 ? void 0 : Vd(a, b, Yd)
                }
                if (a != null && a[Xb] === ec) return Zd(a);
                if (a instanceof Rd) return a = a.size !== 0 ? a.Bi(Xd) : void 0, a;
                return
        }
        return a
    }
    var $d = Eb ? structuredClone : a => Vd(a, 0, Yd);
    let Wd;

    function Zd(a) {
        a = a.aa;
        return Vd(a, a[v] | 0, Yd)
    };
    let ae, be;

    function ce(a) {
        switch (typeof a) {
            case "boolean":
                return ae || (ae = [0, void 0, !0]);
            case "number":
                return a > 0 ? void 0 : a === 0 ? be || (be = [0, void 0]) : [-a, void 0];
            case "string":
                return [0, a];
            case "object":
                return a
        }
    }

    function de(a, b, c, d = 0) {
        if (a == null) {
            var e = 32;
            c ? (a = [c], e |= 128) : a = [];
            b && (e = e & -16760833 | (b & 1023) << 14)
        } else {
            if (!Array.isArray(a)) throw Error("narr");
            e = a[v] | 0;
            if (Ma && 1 & e) throw Error("rfarr");
            2048 & e && !(2 & e) && ge();
            if (e & 256) throw Error("farr");
            if (e & 64) return (e | d) !== e && (a[v] = e | d), a;
            if (c && (e |= 128, c !== a[0])) throw Error("mid");
            a: {
                c = a;e |= 64;
                var f = c.length;
                if (f) {
                    var g = f - 1;
                    let k = c[g];
                    if (k != null && typeof k === "object" && k.constructor === Object) {
                        b = e & 128 ? 0 : -1;
                        g -= b;
                        if (g >= 1024) throw Error("pvtlmt");
                        for (var h in k) {
                            if (!Object.prototype.hasOwnProperty.call(k,
                                    h)) continue;
                            f = +h;
                            if (f < g) c[f + b] = k[h], delete k[h];
                            else break
                        }
                        e = e & -16760833 | (g & 1023) << 14;
                        break a
                    }
                }
                if (b) {
                    h = Math.max(b, f - (e & 128 ? 0 : -1));
                    if (h > 1024) throw Error("spvt");
                    e = e & -16760833 | (h & 1023) << 14
                }
            }
        }
        a[v] = e | 64 | d;
        return a
    }

    function ge() {
        if (Ma) throw Error("carr");
        Pb(Wb, 5)
    };

    function he(a, b) {
        if (typeof a !== "object") return a;
        if (Array.isArray(a)) {
            var c = a[v] | 0;
            return a.length === 0 && c & 1 ? void 0 : ie(a, c, b)
        }
        if (a != null && a[Xb] === ec) return je(a);
        if (a instanceof Rd) {
            c = a.ld;
            if (c & 2) return a;
            if (a.size) {
                b = bc(a.Bi());
                if (a.ed)
                    for (a = 0; a < b.length; a++) {
                        let d = b[a],
                            e = d[1];
                        e == null || typeof e !== "object" ? e = void 0 : e != null && e[Xb] === ec ? e = je(e) : Array.isArray(e) ? e = ie(e, e[v] | 0, !!(c & 32)) : e = void 0;
                        d[1] = e
                    }
                return b
            }
        }
    }

    function ie(a, b, c) {
        if (b & 2) return a;
        !c || 4096 & b || 16 & b ? a = ke(a, b, !1, c && !(b & 16)) : ($b(a, 34), b & 4 && Object.freeze(a));
        return a
    }

    function le(a, b, c) {
        a = new a.constructor(b);
        c && (a.l = ic);
        a.D = ic;
        return a
    }

    function je(a) {
        var b = a.aa,
            c = b[v] | 0;
        return hc(a, c) ? a : me(a, b, c) ? le(a, b) : ke(b, c)
    }

    function ne(a) {
        var b = a.aa,
            c = b[v] | 0;
        return me(a, b, c) ? le(a, b, !0) : new a.constructor(ke(b, c, !1))
    }

    function ke(a, b, c, d) {
        d ? ? (d = !!(34 & b));
        a = Vd(a, b, he, d);
        d = 32;
        c && (d |= 2);
        b = b & 16769217 | d;
        a[v] = b;
        return a
    }

    function Sd(a) {
        var b = a.aa,
            c = b[v] | 0;
        return hc(a, c) ? me(a, b, c) ? le(a, b, !0) : new a.constructor(ke(b, c, !1)) : a
    }

    function oe(a) {
        var b = a.aa,
            c = b[v] | 0;
        return hc(a, c) ? a : me(a, b, c) ? le(a, b) : new a.constructor(ke(b, c, !0))
    }

    function pe(a) {
        if (a.l !== ic) return !1;
        var b = a.aa;
        b = ke(b, b[v] | 0);
        $b(b, 2048);
        a.aa = b;
        a.l = void 0;
        a.D = void 0;
        return !0
    }

    function qe(a) {
        if (!pe(a) && hc(a, a.aa[v] | 0)) throw Error();
    }

    function re(a, b) {
        b === void 0 && (b = a[v] | 0);
        b & 32 && !(b & 4096) && (a[v] = b | 4096)
    }

    function me(a, b, c) {
        return c & 2 ? !0 : c & 32 && !(c & 4096) ? (b[v] = c | 2, a.l = ic, !0) : !1
    };
    const se = wc(0),
        te = {};

    function ue(a, b, c, d, e) {
        b = ve(a.aa, b, c, e);
        if (b !== null || d && a.D !== ic) return b
    }

    function ve(a, b, c, d) {
        if (b === -1) return null;
        var e = b + (c ? 0 : -1),
            f = a.length - 1;
        if (!(f < 1 + (c ? 0 : -1))) {
            if (e >= f) {
                var g = a[f];
                if (g != null && typeof g === "object" && g.constructor === Object) {
                    c = g[b];
                    var h = !0
                } else if (e === f) c = g;
                else return
            } else c = a[e];
            if (d && c != null) {
                d = d(c);
                if (d == null) return d;
                if (!Object.is(d, c)) return h ? g[b] = d : a[e] = d, d
            }
            return c
        }
    }

    function we(a, b, c) {
        qe(a);
        var d = a.aa;
        xe(d, d[v] | 0, b, c);
        return a
    }

    function xe(a, b, c, d, e) {
        var f = c + (e ? 0 : -1),
            g = a.length - 1;
        if (g >= 1 + (e ? 0 : -1) && f >= g) {
            let h = a[g];
            if (h != null && typeof h === "object" && h.constructor === Object) return h[c] = d, b
        }
        if (f <= g) return a[f] = d, b;
        d !== void 0 && (g = (b ? ? (b = a[v] | 0)) >> 14 & 1023 || 536870912, c >= g ? d != null && (a[g + (e ? 0 : -1)] = {
            [c]: d
        }) : a[f] = d);
        return b
    }

    function ye(a, b, c) {
        a = a.aa;
        return ze(a, a[v] | 0, b, c) !== void 0
    }

    function Ae(a, b, c, d) {
        var e = a.aa;
        return ze(e, e[v] | 0, b, Be(a, d, c)) !== void 0
    }

    function Ce(a, b, c) {
        return ue(a, b, void 0, c, Xc)
    }

    function De(a) {
        return a === kc ? 2 : 4
    }

    function Ee(a, b, c, d, e, f, g) {
        var h = a.aa,
            k = h[v] | 0;
        d = hc(a, k) ? 1 : d;
        e = !!e || d === 3;
        d === 2 && pe(a) && (h = a.aa, k = h[v] | 0);
        var l = Fe(h, b, g),
            m = l === Yb ? 7 : l[v] | 0,
            n = Ge(m, k);
        var p = n;
        4 & p ? f == null ? a = !1 : (!e && f === 0 && (512 & p || 1024 & p) && (a.constructor[Tb] = (a.constructor[Tb] | 0) + 1) < 5 && Nb(), a = f === 0 ? !1 : !(f & p)) : a = !0;
        if (a) {
            4 & n && (l = [...l], m = 0, n = He(n, k), k = xe(h, k, b, l, g));
            let q = p = 0;
            for (; p < l.length; p++) {
                let u = c(l[p]);
                u != null && (l[q++] = u)
            }
            q < p && (l.length = q);
            c = (n | 4) & -513;
            n = c &= -1025;
            f && (n |= f);
            n &= -4097
        }
        n !== m && (l[v] = n, 2 & n && Object.freeze(l));
        return l =
            Je(l, n, h, k, b, g, d, a, e)
    }

    function Je(a, b, c, d, e, f, g, h, k) {
        var l = b;
        g === 1 || (g !== 4 ? 0 : 2 & b || !(16 & b) && 32 & d) ? Ke(b) || (b |= !a.length || h && !(4096 & b) || 32 & d && !(4096 & b || 16 & b) ? 2 : 256, b !== l && (a[v] = b), Object.freeze(a)) : (g === 2 && Ke(b) && (a = [...a], l = 0, b = He(b, d), d = xe(c, d, e, a, f)), Ke(b) || (k || (b |= 16), b !== l && (a[v] = b)));
        2 & b || !(4096 & b || 16 & b) || re(c, d);
        return a
    }

    function Fe(a, b, c) {
        a = ve(a, b, c);
        return Array.isArray(a) ? a : Yb
    }

    function Ge(a, b) {
        2 & b && (a |= 2);
        return a | 1
    }

    function Ke(a) {
        return !!(2 & a) && !!(4 & a) || !!(256 & a)
    }

    function Le(a, b, c, d) {
        var e = a.aa,
            f = e[v] | 0;
        var g = hc(a, f);
        a: {!g && pe(a) && (e = a.aa, f = e[v] | 0);
                var h = ve(e, b);a = !1;
                if (h == null) {
                    if (g) {
                        b = Ud();
                        break a
                    }
                    h = []
                } else if (h.constructor === Rd)
                    if (h.ld & 2 && !g) h = h.Bi();
                    else {
                        b = h;
                        break a
                    }
                else Array.isArray(h) ? a = !!((h[v] | 0) & 2) : h = [];
                if (g) {
                    if (!h.length) {
                        b = Ud();
                        break a
                    }
                    a || (a = !0, bc(h))
                } else if (a) {
                    a = !1;
                    cc(h);
                    h = [...h];
                    for (let k = 0; k < h.length; k++) {
                        let l = h[k] = [...h[k]];
                        Array.isArray(l[1]) && (l[1] = bc(l[1]))
                    }
                    h = cc(h)
                }!a && f & 32 && dc(h);d = new Rd(h, c, Id, d);f = xe(e, f, b, d);a || re(e, f);b = d
            }!g && c &&
            (b.tl = !0);
        return b
    }

    function Me(a, b) {
        this.set(b, a)
    }

    function Ne(a, b, c, d) {
        qe(a);
        var e = a.aa,
            f = e[v] | 0;
        if (c == null) return xe(e, f, b), a;
        var g = c === Yb ? 7 : c[v] | 0,
            h = g,
            k = Ke(g),
            l = k || Object.isFrozen(c);
        k || (g = 0);
        l || (c = [...c], h = 0, g = He(g, f), l = !1);
        g |= 5;
        k = ac(g) ? ? 1024;
        g |= k;
        for (let m = 0; m < c.length; m++) {
            let n = c[m],
                p = d(n, k);
            Object.is(n, p) || (l && (c = [...c], h = 0, g = He(g, f), l = !1), c[m] = p)
        }
        g !== h && (l && (c = [...c], g = He(g, f)), c[v] = g);
        xe(e, f, b, c);
        return a
    }

    function Oe(a, b, c, d) {
        qe(a);
        var e = a.aa;
        xe(e, e[v] | 0, b, (d === "0" ? Number(c) === 0 : c === d) ? void 0 : c);
        return a
    }

    function Pe(a, b, c, d) {
        qe(a);
        var e = a.aa,
            f = e[v] | 0;
        if (d == null) {
            var g = Qe(e);
            if (Re(g, e, f, c) === b) g.set(c, 0);
            else return a
        } else {
            g = Qe(e);
            let h = Re(g, e, f, c);
            h !== b && (h && (f = xe(e, f, h)), g.set(c, b))
        }
        xe(e, f, b, d);
        return a
    }

    function Be(a, b, c) {
        return Se(a, b) === c ? c : -1
    }

    function Se(a, b) {
        a = a.aa;
        return Re(Qe(a), a, void 0, b)
    }

    function Qe(a) {
        return a[Sb] ? ? (a[Sb] = new Map)
    }

    function Re(a, b, c, d) {
        var e = a.get(d);
        if (e != null) return e;
        e = 0;
        for (let f = 0; f < d.length; f++) {
            let g = d[f];
            ve(b, g) != null && (e !== 0 && (c = xe(b, c, e)), e = g)
        }
        a.set(d, e);
        return e
    }

    function ze(a, b, c, d) {
        var e = !1;
        d = ve(a, d, void 0, f => {
            var g = Gd(f, c, !1, b);
            e = g !== f && g != null;
            return g
        });
        if (d != null) return e && !hc(d) && re(a, b), d
    }

    function Te(a, b, c) {
        a = a.aa;
        return ze(a, a[v] | 0, b, c) || b[Rb] || (b[Rb] = Hd(b))
    }

    function y(a, b, c) {
        var d = a.aa,
            e = d[v] | 0;
        b = ze(d, e, b, c);
        if (b == null) return b;
        e = d[v] | 0;
        if (!hc(a, e)) {
            let f = Sd(b);
            f !== b && (pe(a) && (d = a.aa, e = d[v] | 0), b = f, e = xe(d, e, c, b), re(d, e))
        }
        return b
    }

    function Ue(a, b, c, d, e, f, g, h, k) {
        var l = hc(a, c);
        f = l ? 1 : f;
        h = !!h || f === 3;
        l = k && !l;
        (f === 2 || l) && pe(a) && (b = a.aa, c = b[v] | 0);
        a = Fe(b, e, g);
        var m = a === Yb ? 7 : a[v] | 0,
            n = Ge(m, c);
        if (k = !(4 & n)) {
            var p = a,
                q = c;
            let u = !!(2 & n);
            u && (q |= 2);
            let w = !u,
                B = !0,
                G = 0,
                K = 0;
            for (; G < p.length; G++) {
                let H = Gd(p[G], d, !1, q);
                if (H instanceof d) {
                    if (!u) {
                        let L = hc(H);
                        w && (w = !L);
                        B && (B = L)
                    }
                    p[K++] = H
                }
            }
            K < G && (p.length = K);
            n |= 4;
            n = B ? n & -4097 : n | 4096;
            n = w ? n | 8 : n & -9
        }
        n !== m && (a[v] = n, 2 & n && Object.freeze(a));
        if (l && !(8 & n || !a.length && (f === 1 || (f !== 4 ? 0 : 2 & n || !(16 & n) && 32 & c)))) {
            Ke(n) && (a = [...a], n = He(n, c), c = xe(b, c, e, a, g));
            d = a;
            l = n;
            for (m = 0; m < d.length; m++) p = d[m], n = Sd(p), p !== n && (d[m] = n);
            l |= 8;
            n = l = d.length ? l | 4096 : l & -4097;
            a[v] = n
        }
        return a = Je(a, n, b, c, e, g, f, k, h)
    }

    function Ve(a, b, c, d) {
        var e = a.aa;
        return Ue(a, e, e[v] | 0, b, c, d, void 0, !1, !0)
    }

    function We(a) {
        a == null && (a = void 0);
        return a
    }

    function z(a, b, c) {
        c = We(c);
        we(a, b, c);
        c && !hc(c) && re(a.aa);
        return a
    }

    function A(a, b, c, d) {
        d = We(d);
        Pe(a, b, c, d);
        d && !hc(d) && re(a.aa);
        return a
    }

    function Xe(a, b, c) {
        qe(a);
        var d = a.aa,
            e = d[v] | 0;
        if (c == null) return xe(d, e, b), a;
        var f = c === Yb ? 7 : c[v] | 0,
            g = f,
            h = Ke(f),
            k = h || Object.isFrozen(c),
            l = !0,
            m = !0;
        for (let p = 0; p < c.length; p++) {
            var n = c[p];
            h || (n = hc(n), l && (l = !n), m && (m = n))
        }
        h || (f = l ? 13 : 5, f = m ? f & -4097 : f | 4096);
        k && f === g || (c = [...c], g = 0, f = He(f, e));
        f !== g && (c[v] = f);
        e = xe(d, e, b, c);
        2 & f || !(4096 & f || 16 & f) || re(d, e);
        return a
    }

    function He(a, b) {
        return a = (2 & b ? a | 2 : a & -3) & -273
    }

    function Ye(a, b, c, d, e, f, g, h) {
        qe(a);
        b = Ee(a, b, e, 2, !0, void 0, f);
        e = ac(b === Yb ? 7 : b[v] | 0) ? ? 1024;
        if (h)
            if (Array.isArray(d))
                for (g = d.length, h = 0; h < g; h++) b.push(c(d[h], e));
            else
                for (let k of d) b.push(c(k, e));
        else {
            if (g) throw Error();
            b.push(c(d, e))
        }
        return a
    }

    function Ze(a, b, c, d) {
        var e = d;
        qe(a);
        d = a.aa;
        b = Ue(a, d, d[v] | 0, c, b, 2, void 0, !0);
        e = e != null ? e : new c;
        b.push(e);
        var f = c = b === Yb ? 7 : b[v] | 0;
        (e = hc(e)) ? (c &= -9, b.length === 1 && (c &= -4097)) : c |= 4096;
        c !== f && (b[v] = c);
        e || re(d);
        return a
    }

    function $e(a, b) {
        var c = af;
        qe(a);
        var d = a.aa;
        c = Ue(a, d, d[v] | 0, c, 2, 2, void 0, !0);
        var e = 0,
            f = 0;
        if (Array.isArray(b)) {
            var g = b.length;
            for (let k = 0; k < g; k++) {
                var h = b[k];
                c.push(h);
                (h = hc(h)) && !e++ && (c[v] &= -9);
                h || f++ || $b(c, 4096)
            }
        } else
            for (g of b) b = g, c.push(b), (b = hc(b)) && !e++ && (c[v] &= -9), b || f++ || $b(c, 4096);
        f && re(d);
        return a
    }

    function bf(a, b) {
        return xd(ue(a, b, void 0, void 0, yd))
    }

    function cf(a, b, c) {
        return ue(a, b, void 0, c, yd)
    }

    function df(a, b) {
        return Ee(a, b, yd, 1, void 0, 1024)
    }

    function ef(a, b, c, d) {
        return Zc(ue(a, b, c, d))
    }

    function ff(a, b, c) {
        return hd(ue(a, b, void 0, c))
    }

    function C(a, b) {
        return ef(a, b) ? ? !1
    }

    function gf(a, b) {
        return ff(a, b) ? ? 0
    }

    function hf(a, b) {
        return cf(a, b) ? ? se
    }

    function jf(a, b, c = 0) {
        return Ce(a, b) ? ? c
    }

    function D(a, b) {
        return Fd(ue(a, b)) ? ? ""
    }

    function E(a, b) {
        return fd(ue(a, b)) ? ? 0
    }

    function kf(a) {
        {
            a = ue(a, 10, void 0, void 0, Ad);
            let b = typeof a;
            a = a == null ? a : b === "bigint" ? String(Sc(64, a)) : dd(a) ? b === "string" ? vd(a) : qd(a) : void 0
        }
        return a ? ? "0"
    }

    function lf(a, b) {
        return Ee(a, b, hd, De())
    }

    function mf(a, b) {
        return Ee(a, b, Fd, De())
    }

    function nf(a, b) {
        return Ee(a, b, fd, De())
    }

    function of (a, b, c, d) {
        return y(a, b, Be(a, d, c))
    }

    function pf(a, b) {
        return ef(a, b, void 0, te)
    }

    function qf(a, b) {
        return Fd(ue(a, b, void 0, te))
    }

    function rf(a, b) {
        return fd(ue(a, b, void 0, te))
    }

    function sf(a, b, c) {
        return we(a, b, c == null ? c : Yc(c))
    }

    function tf(a, b, c) {
        return Oe(a, b, c == null ? c : Yc(c), !1)
    }

    function uf(a, b, c) {
        return we(a, b, c == null ? c : gd(c))
    }

    function vf(a, b, c) {
        return Oe(a, b, c == null ? c : gd(c), 0)
    }

    function wf(a, b, c) {
        return we(a, b, c == null ? c : kd(c, void 0))
    }

    function xf(a, b, c) {
        return Oe(a, b, c == null ? c : kd(c, void 0), "0")
    }

    function yf(a, b, c, d) {
        return Pe(a, b, c, d == null ? d : kd(d, void 0))
    }

    function If(a, b, c) {
        return Oe(a, b, c == null ? c : zd(c, void 0), "0")
    }

    function Jf(a, b, c) {
        return we(a, b, Ed(c))
    }

    function Kf(a, b, c) {
        return Oe(a, b, Ed(c), "")
    }

    function Lf(a, b, c) {
        return we(a, b, c == null ? c : ed(c))
    }

    function F(a, b, c) {
        return Oe(a, b, c == null ? c : ed(c), 0)
    }

    function Mf(a, b, c) {
        return Ne(a, b, c, ed)
    }

    function Nf(a, b) {
        return Fd(ue(a, b)) != null
    }

    function Of(a, b) {
        b = Be(a, Pf, b);
        return Fd(ue(a, b)) != null
    };

    function Qf(a) {
        if (!a) return Rf || (Rf = new Sf(0, 0));
        if (!/^\d+$/.test(a)) return null;
        Mc(a);
        return new Sf(Ec, Fc)
    }
    var Sf = class {
        constructor(a, b) {
            this.j = a >>> 0;
            this.g = b >>> 0
        }
    };
    let Rf;

    function Tf(a) {
        if (!a) return Uf || (Uf = new Vf(0, 0));
        if (!/^-?\d+$/.test(a)) return null;
        Mc(a);
        return new Vf(Ec, Fc)
    }
    var Vf = class {
        constructor(a, b) {
            this.j = a >>> 0;
            this.g = b >>> 0
        }
    };
    let Uf;

    function Wf(a, b, c) {
        for (; c > 0 || b > 127;) a.g.push(b & 127 | 128), b = (b >>> 7 | c << 25) >>> 0, c >>>= 7;
        a.g.push(b)
    }

    function Xf(a, b) {
        for (; b > 127;) a.g.push(b & 127 | 128), b >>>= 7;
        a.g.push(b)
    }

    function Yf(a, b) {
        if (b >= 0) Xf(a, b);
        else {
            for (let c = 0; c < 9; c++) a.g.push(b & 127 | 128), b >>= 7;
            a.g.push(1)
        }
    }
    var Zf = class {
        constructor() {
            this.g = []
        }
        length() {
            return this.g.length
        }
        end() {
            var a = this.g;
            this.g = [];
            return a
        }
    };

    function $f(a, b) {
        b.length !== 0 && (a.l.push(b), a.j += b.length)
    }

    function ag(a, b, c) {
        Xf(a.g, b * 8 + c)
    }

    function bg(a, b) {
        ag(a, b, 2);
        b = a.g.end();
        $f(a, b);
        b.push(a.j);
        return b
    }

    function cg(a, b) {
        var c = b.pop();
        for (c = a.j + a.g.length() - c; c > 127;) b.push(c & 127 | 128), c >>>= 7, a.j++;
        b.push(c);
        a.j++
    }
    var dg = class {
        constructor() {
            this.l = [];
            this.j = 0;
            this.g = new Zf
        }
    };

    function eg() {
        var a = class {
            constructor() {
                throw Error();
            }
        };
        Object.setPrototypeOf(a, a.prototype);
        return a
    }
    var fg = eg(),
        gg = eg(),
        hg = eg(),
        ig = eg(),
        jg = eg(),
        kg = eg(),
        lg = eg(),
        mg = eg(),
        ng = eg();

    function og(a) {
        return Sd(a)
    }

    function pg(a) {
        return JSON.stringify(Zd(a))
    }

    function qg(a) {
        return oe(a)
    }
    var I = class {
        constructor(a) {
            this.aa = de(a, void 0, void 0, 2048)
        }
        toJSON() {
            return Zd(this)
        }
    };
    I.prototype[Xb] = ec;

    function rg(a, b) {
        if (b == null) return new a;
        if (!Array.isArray(b)) throw Error();
        if (Object.isFrozen(b) || Object.isSealed(b) || !Object.isExtensible(b)) throw Error();
        return new a(dc(b))
    };
    var sg = class {
        constructor(a, b) {
            this.g = a;
            a = Ca(fg);
            this.j = !!a && b === a || !1
        }
    };

    function tg(a, b, c, d, e) {
        b = ug(b, d);
        b != null && (c = bg(a, c), e(b, a), cg(a, c))
    }
    const vg = new sg(tg, fg),
        wg = new sg(tg, fg);
    var xg = Symbol(),
        yg = Symbol();
    let zg, Ag;

    function Bg(a) {
        var b = Cg,
            c = Dg,
            d = a[xg];
        if (d) return d;
        d = {};
        d.tp = a;
        d.Nj = ce(a[0]);
        var e = a[1],
            f = 1;
        e && e.constructor === Object && (d.Zl = e, e = a[++f], typeof e === "function" && (d.Em = !0, zg ? ? (zg = e), Ag ? ? (Ag = a[f + 1]), e = a[f += 2]));
        for (var g = {}; e && Array.isArray(e) && e.length && typeof e[0] === "number" && e[0] > 0;) {
            for (var h = 0; h < e.length; h++) g[e[h]] = e;
            e = a[++f]
        }
        for (h = 1; e !== void 0;) {
            typeof e === "number" && (h += e, e = a[++f]);
            let m;
            var k = void 0;
            e instanceof sg ? m = e : (m = vg, f--);
            if (m ? .j) {
                e = a[++f];
                k = a;
                var l = f;
                typeof e === "function" && (e = e(), k[l] =
                    e);
                k = e
            }
            e = a[++f];
            l = h + 1;
            typeof e === "number" && e < 0 && (l -= e, e = a[++f]);
            for (; h < l; h++) {
                let n = g[h];
                k ? c(d, h, m, k, n) : b(d, h, m, n)
            }
        }
        return a[xg] = d
    }

    function ug(a, b) {
        if (a instanceof I) return a.aa;
        if (Array.isArray(a)) return de(a, b[0], b[1])
    };

    function Cg(a, b, c) {
        a[b] = c.g
    }

    function Dg(a, b, c, d) {
        var e, f, g = c.g;
        a[b] = (h, k, l) => g(h, k, l, f || (f = Bg(d).Nj), e || (e = Eg(d)))
    }

    function Eg(a) {
        var b = a[yg];
        if (!b) {
            let c = Bg(a);
            b = (d, e) => Fg(d, e, c);
            a[yg] = b
        }
        return b
    }

    function Fg(a, b, c) {
        lc(a, a[v] | 0, (d, e) => {
            if (e != null) {
                var f = Gg(c, d);
                f ? f(b, e, d) : d < 500 || Pb(Ub, 3)
            }
        })
    }

    function Gg(a, b) {
        var c = a[b];
        if (c) return c;
        if (c = a.Zl)
            if (c = c[b]) {
                c = Array.isArray(c) ? c[0] instanceof sg ? c : [wg, c] : [c, void 0];
                var d = c[0].g;
                if (c = c[1]) {
                    let e = Eg(c),
                        f = Bg(c).Nj;
                    c = a.Em ? Ag(f, e) : (g, h, k) => d(g, h, k, f, e)
                } else c = d;
                return a[b] = c
            }
    };
    var Hg = (a, b) => {
        var c = new dg;
        Fg(a.aa, c, Bg(b));
        $f(c, c.g.end());
        a = new Uint8Array(c.j);
        b = c.l;
        var d = b.length,
            e = 0;
        for (let f = 0; f < d; f++) {
            let g = b[f];
            a.set(g, e);
            e += g.length
        }
        c.l = [a];
        return a
    };

    function Ig(a, b) {
        return new sg(a, b)
    }
    var Jg = Ig(function(a, b, c) {
            b = Xc(b);
            b != null && (ag(a, c, 5), a = a.g, c = Gc || (Gc = new DataView(new ArrayBuffer(8))), c.setFloat32(0, +b, !0), Fc = 0, b = Ec = c.getUint32(0, !0), a.g.push(b >>> 0 & 255), a.g.push(b >>> 8 & 255), a.g.push(b >>> 16 & 255), a.g.push(b >>> 24 & 255))
        }, mg),
        Kg = Ig(function(a, b, c) {
            b = Bd(b);
            if (b != null) {
                switch (typeof b) {
                    case "string":
                        Tf(b)
                }
                if (b != null) switch (ag(a, c, 0), typeof b) {
                    case "number":
                        a = a.g;
                        Ic(b);
                        Wf(a, Ec, Fc);
                        break;
                    case "bigint":
                        c = BigInt.asUintN(64, b);
                        c = new Vf(Number(c & BigInt(4294967295)), Number(c >> BigInt(32)));
                        Wf(a.g, c.j, c.g);
                        break;
                    default:
                        c = Tf(b), Wf(a.g, c.j, c.g)
                }
            }
        }, kg),
        Lg = Ig(function(a, b, c) {
            b = Cd(b);
            if (b != null) {
                switch (typeof b) {
                    case "string":
                        Qf(b)
                }
                if (b != null) switch (ag(a, c, 0), typeof b) {
                    case "number":
                        a = a.g;
                        Ic(b);
                        Wf(a, Ec, Fc);
                        break;
                    case "bigint":
                        c = BigInt.asUintN(64, b);
                        c = new Sf(Number(c & BigInt(4294967295)), Number(c >> BigInt(32)));
                        Wf(a.g, c.j, c.g);
                        break;
                    default:
                        c = Qf(b), Wf(a.g, c.j, c.g)
                }
            }
        }, lg),
        Mg = Ig(function(a, b, c) {
            b = hd(b);
            b != null && b != null && (ag(a, c, 0), Yf(a.g, b))
        }, ig),
        Ng = Ig(function(a, b, c) {
            b = Zc(b);
            b != null && (ag(a,
                c, 0), a.g.g.push(b ? 1 : 0))
        }, gg),
        Og = Ig(function(a, b, c) {
            b = Fd(b);
            b != null && (b = (Ia || (Ia = new TextEncoder)).encode(b), ag(a, c, 2), Xf(a.g, b.length), $f(a, a.g.end()), $f(a, b))
        }, hg),
        Pg = function(a, b, c = fg) {
            return new sg(b, c)
        }(function(a, b, c, d, e) {
            if (a.g() !== 2) return !1;
            var f = a.j;
            d = de(void 0, d[0], d[1]);
            var g = b[v] | 0;
            if (g & 2) throw Error();
            var h = g & 128 ? mc : void 0,
                k = Fe(b, c, h),
                l = k === Yb ? 7 : k[v] | 0,
                m = Ge(l, g);
            if (2 & m || Ke(m) || 16 & m) m === l || Ke(m) || (k[v] = m), k = [...k], l = 0, m = He(m, g), xe(b, g, c, k, h);
            m &= -13;
            m !== l && (k[v] = m);
            k.push(d);
            f.call(a, d,
                e);
            return !0
        }, function(a, b, c, d, e) {
            if (Array.isArray(b)) {
                for (let l = 0; l < b.length; l++) {
                    var f = a,
                        g = c,
                        h = e,
                        k = ug(b[l], d);
                    k != null && (g = bg(f, g), h(k, f), cg(f, g))
                }
                a = b[v] | 0;
                a & 1 || (b[v] = a | 1)
            }
        }),
        Qg = Ig(function(a, b, c) {
            b = jd(b);
            b != null && b != null && (ag(a, c, 0), Xf(a.g, b))
        }, jg),
        Rg = Ig(function(a, b, c) {
            b = hd(b);
            b != null && (b = parseInt(b, 10), ag(a, c, 0), Yf(a.g, b))
        }, ng),
        Sg;
    Sg = new sg(function(a, b, c) {
        if (Array.isArray(b)) {
            var d = b[v] | 0;
            if (!(d & 4)) {
                for (var e = 0, f = 0; e < b.length; e++) {
                    let g = hd(b[e]);
                    g != null && (b[f++] = g)
                }
                f < e && (b.length = f);
                e = (d | 5) & -1537;
                e !== d && (b[v] = e);
                e & 2 && Object.freeze(b)
            }
        } else b = void 0;
        if (b != null && b.length) {
            c = bg(a, c);
            for (d = 0; d < b.length; d++) Yf(a.g, b[d]);
            cg(a, c)
        }
    }, ng);

    function Tg(a) {
        return () => a[Rb] || (a[Rb] = Hd(a))
    }

    function qh(a) {
        return b => {
            if (b == null || b == "") b = new a;
            else {
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error("dnarr");
                b = new a(dc(b))
            }
            return b
        }
    };
    var rh = class extends I {};
    var sh = class extends I {};
    var th = class extends I {
        getLevel() {
            return E(this, 1)
        }
    };

    function uh(a) {
        return D(a, 1)
    }

    function vh(a) {
        var b = new wh;
        return Jf(b, 1, a)
    }
    var wh = class extends I {};
    var xh = class extends I {};

    function yh(a, b) {
        return A(a, 2, zh, b)
    }
    var Ah = class extends I {},
        zh = [1, 2, 3, 5];

    function Bh(a) {
        var b = new Ch;
        return Xe(b, 1, a)
    }
    var Ch = class extends I {};
    var Dh = class extends I {};
    var Eh = class extends I {
        Bb() {
            return y(this, Ch, 1)
        }
        setContent(a) {
            return z(this, 1, a)
        }
        g() {
            return ye(this, Ch, 1)
        }
        wf() {
            return E(this, 3)
        }
    };
    /* 
     
     Copyright Google LLC 
     SPDX-License-Identifier: Apache-2.0 
    */
    var Fh = class {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g
        }
    };

    function Gh(a) {
        return new Fh(a[0].toLowerCase())
    };
    let Hh = globalThis.trustedTypes,
        Ih;

    function Jh() {
        var a = null;
        if (!Hh) return a;
        try {
            let b = c => c;
            a = Hh.createPolicy("goog#html", {
                createHTML: b,
                createScript: b,
                createScriptURL: b
            })
        } catch (b) {}
        return a
    }

    function Kh() {
        Ih === void 0 && (Ih = Jh());
        return Ih
    };
    var Lh = class {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g + ""
        }
    };

    function Mh(a) {
        var b = Kh();
        a = b ? b.createHTML(a) : a;
        return new Lh(a)
    }

    function Nh(a) {
        if (a instanceof Lh) return a.g;
        throw Error("");
    };
    var Oh = class {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g
        }
    };

    function Ph(a) {
        if (a instanceof Oh) return a.g;
        throw Error("");
    };

    function Qh(a) {
        return new Oh(a[0])
    };
    var Rh = class {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g + ""
        }
    };

    function Sh(a) {
        var b = Kh();
        a = b ? b.createScriptURL(a) : a;
        return new Rh(a)
    }

    function Th(a) {
        if (a instanceof Rh) return a.g;
        throw Error("");
    };
    var Uh = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;

    function Vh(a) {
        if (Uh.test(a)) return a
    };

    function Wh(a) {
        return a instanceof Lh ? a : Mh(String(a).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;"))
    }

    function Xh(a) {
        return Yh(a)
    }

    function Yh(a) {
        var b = Wh("");
        return Mh(a.map(c => Nh(Wh(c))).join(Nh(b).toString()))
    }
    const Zh = /^[a-z][a-z\d-]*$/i,
        $h = "APPLET BASE EMBED IFRAME LINK MATH META OBJECT SCRIPT STYLE SVG TEMPLATE".split(" ");
    var ai = "AREA BR COL COMMAND HR IMG INPUT KEYGEN PARAM SOURCE TRACK WBR".split(" ");
    const bi = ["action", "formaction", "href"];

    function ci(a) {
        if (!Zh.test(a)) throw Error("");
        if ($h.indexOf(a.toUpperCase()) !== -1) throw Error("");
    }

    function di(a, b, c) {
        ci(a);
        var d = `<${a}`;
        b && (d += ei(b));
        Array.isArray(c) || (c = c === void 0 ? [] : [c]);
        ai.indexOf(a.toUpperCase()) !== -1 ? d += ">" : (b = Xh(c.map(e => e instanceof Lh ? e : Wh(String(e)))), d += ">" + b.toString() + "</" + a + ">");
        return Mh(d)
    }

    function ei(a) {
        var b = "",
            c = Object.keys(a);
        for (let f = 0; f < c.length; f++) {
            var d = c[f],
                e = a[d];
            if (!Zh.test(d)) throw Error("");
            if (e !== void 0 && e !== null) {
                if (/^on./i.test(d)) throw Error("");
                bi.indexOf(d.toLowerCase()) !== -1 && (e = Vh(String(e)) || "about:invalid#zClosurez");
                e = `${d}="${Wh(String(e))}"`;
                b += " " + e
            }
        }
        return b
    };

    function fi(a, ...b) {
        if (b.length === 0) return Sh(a[0]);
        var c = a[0];
        for (let d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return Sh(c)
    }

    function gi(a, b) {
        a = Th(a).toString();
        var c = a.split(/[?#]/),
            d = /[?]/.test(a) ? "?" + c[1] : "";
        return hi(c[0], d, /[#]/.test(a) ? "#" + (d ? c[2] : c[1]) : "", b)
    }

    function hi(a, b, c, d) {
        function e(g, h) {
            g != null && (Array.isArray(g) ? g.forEach(k => e(k, h)) : (b += f + encodeURIComponent(h) + "=" + encodeURIComponent(g), f = "&"))
        }
        var f = b.length ? "&" : "?";
        d.constructor === Object && (d = Object.entries(d));
        Array.isArray(d) ? d.forEach(g => e(g[1], g[0])) : d.forEach(e);
        return Sh(a + b + c)
    };
    fi `https://www.google.com/recaptcha/api2/aframe`;
    let ii = [];

    function ji() {
        var a = ii;
        ii = [];
        for (let b of a) try {
            b()
        } catch {}
    };

    function ki() {
        return !1
    }

    function li() {
        return !0
    }

    function mi(a) {
        var b = arguments,
            c = b.length;
        return function() {
            for (let d = 0; d < c; d++)
                if (!b[d].apply(this, arguments)) return !1;
            return !0
        }
    }

    function ni(a) {
        return function() {
            return !a.apply(this, arguments)
        }
    }

    function oi(a) {
        var b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    }

    function pi(a) {
        var b = a;
        return function() {
            if (b) {
                let c = b;
                b = null;
                c()
            }
        }
    }

    function qi(a, b) {
        var c = 0;
        return function(d) {
            t.clearTimeout(c);
            var e = arguments;
            c = t.setTimeout(function() {
                a.apply(b, e)
            }, 63)
        }
    }

    function ri(a, b, c) {
        function d() {
            f = t.setTimeout(e, b);
            var k = h;
            h = [];
            a.apply(c, k)
        }

        function e() {
            f = 0;
            g && (g = !1, d())
        }
        var f = 0,
            g = !1,
            h = [];
        return function(k) {
            h = arguments;
            f ? g = !0 : d()
        }
    };

    function si(a, b) {
        return Math.min(Math.max(a, 0), b)
    }

    function ti(a) {
        return Array.prototype.reduce.call(arguments, function(b, c) {
            return b + c
        }, 0)
    }

    function ui(a) {
        return ti.apply(null, arguments) / arguments.length
    };

    function vi(a, b) {
        this.x = a !== void 0 ? a : 0;
        this.y = b !== void 0 ? b : 0
    }
    r = vi.prototype;
    r.equals = function(a) {
        return a instanceof vi && (this == a ? !0 : this && a ? this.x == a.x && this.y == a.y : !1)
    };
    r.ceil = function() {
        this.x = Math.ceil(this.x);
        this.y = Math.ceil(this.y);
        return this
    };
    r.floor = function() {
        this.x = Math.floor(this.x);
        this.y = Math.floor(this.y);
        return this
    };
    r.round = function() {
        this.x = Math.round(this.x);
        this.y = Math.round(this.y);
        return this
    };
    r.scale = function(a, b) {
        this.x *= a;
        this.y *= typeof b === "number" ? b : a;
        return this
    };

    function wi(a, b) {
        this.width = a;
        this.height = b
    }

    function xi(a, b) {
        return a == b ? !0 : a && b ? a.width == b.width && a.height == b.height : !1
    }
    r = wi.prototype;
    r.aspectRatio = function() {
        return this.width / this.height
    };
    r.isEmpty = function() {
        return !(this.width * this.height)
    };
    r.ceil = function() {
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    r.floor = function() {
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    r.round = function() {
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    r.scale = function(a, b) {
        this.width *= a;
        this.height *= typeof b === "number" ? b : a;
        return this
    };

    function yi(a, b) {
        for (let c in a) b.call(void 0, a[c], c, a)
    }

    function zi(a, b) {
        var c = {};
        for (let d in a) b.call(void 0, a[d], d, a) && (c[d] = a[d]);
        return c
    }

    function Ai(a, b) {
        for (let c in a)
            if (b.call(void 0, a[c], c, a)) return !0;
        return !1
    }

    function Bi(a) {
        var b = Ci;
        a: {
            for (let c in b)
                if (b[c] == a) {
                    a = !0;
                    break a
                }
            a = !1
        }
        return a
    }

    function Di(a) {
        var b = [],
            c = 0;
        for (let d in a) b[c++] = a[d];
        return b
    }

    function Ei(a) {
        var b = {};
        for (let c in a) b[c] = a[c];
        return b
    }
    const Fi = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");

    function Gi(a, b) {
        for (let e = 1; e < arguments.length; e++) {
            var c = arguments[e];
            for (d in c) a[d] = c[d];
            for (let f = 0; f < Fi.length; f++) {
                var d = Fi[f];
                Object.prototype.hasOwnProperty.call(c, d) && (a[d] = c[d])
            }
        }
    };

    function Hi(a, b) {
        b = Vh(b);
        b !== void 0 && (a.href = b)
    };

    function Ii(a, b) {
        a.src = Th(b).toString()
    };

    function Ji(a = document) {
        a = a.querySelector ? .("script[nonce]");
        return a == null ? "" : a.nonce || a.getAttribute("nonce") || ""
    };

    function Ki(a, b) {
        a.src = Th(b);
        (b = Ji(a.ownerDocument)) && a.setAttribute("nonce", b)
    };

    function Li(a, b) {
        if (a.nodeType === 1 && /^(script|style)$/i.test(a.tagName)) throw Error("");
        a.innerHTML = Nh(b)
    }

    function Mi(a, b, c) {
        var d = [Gh `width`, Gh `height`];
        if (d.length === 0) throw Error("");
        d = d.map(f => {
            if (f instanceof Fh) f = f.g;
            else throw Error("");
            return f
        });
        var e = b.toLowerCase();
        if (d.every(f => e.indexOf(f) !== 0)) throw Error(`Attribute "${b}" does not match any of the allowed prefixes.`);
        a.setAttribute(b, c)
    }

    function Ni(a, b, c) {
        if (a.namespaceURI !== "http://www.w3.org/1999/xhtml") throw Error(`Cannot set attribute '${b}' on '${a.tagName}'.Element is not in the HTML namespace`);
        b = b.toLowerCase();
        switch (`${a.tagName} ${b}`) {
            case "A href":
                Hi(a, c);
                break;
            case "AREA href":
                b = Vh(c);
                b !== void 0 && (a.href = b);
                break;
            case "BASE href":
                a.href = Th(c);
                break;
            case "BUTTON formaction":
                b = Vh(c);
                b !== void 0 && (a.formAction = b);
                break;
            case "EMBED src":
                a.src = Th(c);
                break;
            case "FORM action":
                b = Vh(c);
                b !== void 0 && (a.action = b);
                break;
            case "IFRAME src":
                Ii(a,
                    c);
                break;
            case "IFRAME srcdoc":
                a.srcdoc = Nh(c);
                break;
            case "IFRAME sandbox":
                throw Error("Can't set 'sandbox' on iframe tags. Use setIframeSrcWithIntent or setIframeSrcdocWithIntent instead");
            case "INPUT formaction":
                b = Vh(c);
                b !== void 0 && (a.formAction = b);
                break;
            case "LINK href":
                throw Error("Can't set 'href' attribute on link tags. Use setLinkHrefAndRel instead");
            case "LINK rel":
                throw Error("Can't set 'rel' attribute on link tags. Use setLinkHrefAndRel instead");
            case "OBJECT data":
                a.data = Th(c);
                break;
            case "SCRIPT src":
                Ki(a,
                    c);
                break;
            default:
                if (/^on./.test(b)) throw Error(`Attribute "${b}" looks like an event handler attribute. Please use a safe alternative like addEventListener instead.`);
                a.setAttribute(b, c)
        }
    };

    function Oi(a, b) {
        var c = {
            "&amp;": "&",
            "&lt;": "<",
            "&gt;": ">",
            "&quot;": '"'
        };
        var d = b ? b.createElement("div") : t.document.createElement("div");
        return a.replace(Pi, function(e, f) {
            var g = c[e];
            if (g) return g;
            f.charAt(0) == "#" && (f = Number("0" + f.slice(1)), isNaN(f) || (g = String.fromCharCode(f)));
            g || (Li(d, Mh(e + " ")), g = d.firstChild.nodeValue.slice(0, -1));
            return c[e] = g
        })
    }
    var Pi = /&([^;\s<&]+);?/g;

    function Qi(a) {
        var b = 0;
        for (let c = 0; c < a.length; ++c) b = 31 * b + a.charCodeAt(c) >>> 0;
        return b
    }

    function Ri(a) {
        return String(a).replace(/\-([a-z])/g, function(b, c) {
            return c.toUpperCase()
        })
    }

    function Si(a) {
        return a.replace(RegExp("(^|[\\s]+)([a-z])", "g"), function(b, c, d) {
            return c + d.toUpperCase()
        })
    };

    function Ti(a) {
        return a ? new hj(ij(a)) : Ha || (Ha = new hj)
    }

    function jj(a, b) {
        yi(b, function(c, d) {
            d == "style" ? a.style.cssText = c : d == "class" ? a.className = c : d == "for" ? a.htmlFor = c : kj.hasOwnProperty(d) ? a.setAttribute(kj[d], c) : d.lastIndexOf("aria-", 0) == 0 || d.lastIndexOf("data-", 0) == 0 ? a.setAttribute(d, c) : a[d] = c
        })
    }
    var kj = {
        cellpadding: "cellPadding",
        cellspacing: "cellSpacing",
        colspan: "colSpan",
        frameborder: "frameBorder",
        height: "height",
        maxlength: "maxLength",
        nonce: "nonce",
        role: "role",
        rowspan: "rowSpan",
        type: "type",
        usemap: "useMap",
        valign: "vAlign",
        width: "width"
    };

    function lj(a) {
        a = a.document;
        a = a.compatMode == "CSS1Compat" ? a.documentElement : a.body;
        return new wi(a.clientWidth, a.clientHeight)
    }

    function mj(a) {
        return a.scrollingElement ? a.scrollingElement : xb || a.compatMode != "CSS1Compat" ? a.body || a.documentElement : a.documentElement
    }

    function nj(a) {
        return a ? a.defaultView : window
    }

    function oj(a, b) {
        b = String(b);
        a.contentType === "application/xhtml+xml" && (b = b.toLowerCase());
        return a.createElement(b)
    }

    function pj(a) {
        a && a.parentNode && a.parentNode.removeChild(a)
    }

    function qj(a) {
        var b, c = arguments.length;
        if (!c) return null;
        if (c == 1) return arguments[0];
        var d = [],
            e = Infinity;
        for (b = 0; b < c; b++) {
            for (var f = [], g = arguments[b]; g;) f.unshift(g), g = g.parentNode;
            d.push(f);
            e = Math.min(e, f.length)
        }
        f = null;
        for (b = 0; b < e; b++) {
            g = d[0][b];
            for (let h = 1; h < c; h++)
                if (g != d[h][b]) return f;
            f = g
        }
        return f
    }

    function ij(a) {
        return a.nodeType == 9 ? a : a.ownerDocument || a.document
    }
    var rj = {
            SCRIPT: 1,
            STYLE: 1,
            HEAD: 1,
            IFRAME: 1,
            OBJECT: 1
        },
        sj = {
            IMG: " ",
            BR: "\n"
        };

    function tj(a) {
        var b = [];
        uj(a, b, !0);
        a = b.join("");
        a = a.replace(/ \xAD /g, " ").replace(/\xAD/g, "");
        a = a.replace(/\u200B/g, "");
        a = a.replace(/ +/g, " ");
        a != " " && (a = a.replace(/^\s*/, ""));
        return a
    }

    function uj(a, b, c) {
        if (!(a.nodeName in rj))
            if (a.nodeType == 3) c ? b.push(String(a.nodeValue).replace(/(\r\n|\r|\n)/g, "")) : b.push(a.nodeValue);
            else if (a.nodeName in sj) b.push(sj[a.nodeName]);
        else
            for (a = a.firstChild; a;) uj(a, b, c), a = a.nextSibling
    }

    function vj(a, b, c) {
        if (!b && !c) return null;
        var d = b ? String(b).toUpperCase() : null;
        return wj(a, function(e) {
            return (!d || e.nodeName == d) && (!c || typeof e.className === "string" && hb(e.className.split(/\s+/), c))
        })
    }

    function wj(a, b) {
        for (var c = 0; a;) {
            if (b(a)) return a;
            a = a.parentNode;
            c++
        }
        return null
    }

    function hj(a) {
        this.g = a || t.document || document
    }
    hj.prototype.j = function(a) {
        var b = this.g;
        return typeof a === "string" ? b.getElementById(a) : a
    };
    hj.prototype.l = hj.prototype.j;

    function xj(a, b) {
        return oj(a.g, b)
    }

    function yj(a, b) {
        var c = a.g;
        a = oj(c, "DIV");
        Li(a, b);
        if (a.childNodes.length == 1) b = a.removeChild(a.firstChild);
        else
            for (b = c.createDocumentFragment(); a.firstChild;) b.appendChild(a.firstChild);
        return b
    }
    hj.prototype.ua = function() {
        return this.g.defaultView
    };
    hj.prototype.contains = function(a, b) {
        return a && b ? a == b || a.contains(b) : !1
    };

    function zj(a, b, c, d) {
        this.top = a;
        this.right = b;
        this.bottom = c;
        this.left = d
    }
    r = zj.prototype;
    r.getWidth = function() {
        return this.right - this.left
    };
    r.getHeight = function() {
        return this.bottom - this.top
    };

    function Aj(a) {
        return new zj(a.top, a.right, a.bottom, a.left)
    }
    r.contains = function(a) {
        return this && a ? a instanceof zj ? a.left >= this.left && a.right <= this.right && a.top >= this.top && a.bottom <= this.bottom : a.x >= this.left && a.x <= this.right && a.y >= this.top && a.y <= this.bottom : !1
    };
    r.ceil = function() {
        this.top = Math.ceil(this.top);
        this.right = Math.ceil(this.right);
        this.bottom = Math.ceil(this.bottom);
        this.left = Math.ceil(this.left);
        return this
    };
    r.floor = function() {
        this.top = Math.floor(this.top);
        this.right = Math.floor(this.right);
        this.bottom = Math.floor(this.bottom);
        this.left = Math.floor(this.left);
        return this
    };
    r.round = function() {
        this.top = Math.round(this.top);
        this.right = Math.round(this.right);
        this.bottom = Math.round(this.bottom);
        this.left = Math.round(this.left);
        return this
    };
    r.scale = function(a, b) {
        b = typeof b === "number" ? b : a;
        this.left *= a;
        this.right *= a;
        this.top *= b;
        this.bottom *= b;
        return this
    };

    function Cj(a, b, c, d) {
        this.left = a;
        this.top = b;
        this.width = c;
        this.height = d
    }

    function Dj(a) {
        return new zj(a.top, a.left + a.width, a.top + a.height, a.left)
    }

    function Ej(a, b) {
        var c = Math.max(a.left, b.left),
            d = Math.min(a.left + a.width, b.left + b.width);
        if (c <= d) {
            let e = Math.max(a.top, b.top);
            a = Math.min(a.top + a.height, b.top + b.height);
            if (e <= a) return new Cj(c, e, d - c, a - e)
        }
        return null
    }
    r = Cj.prototype;
    r.contains = function(a) {
        return a instanceof vi ? a.x >= this.left && a.x <= this.left + this.width && a.y >= this.top && a.y <= this.top + this.height : this.left <= a.left && this.left + this.width >= a.left + a.width && this.top <= a.top && this.top + this.height >= a.top + a.height
    };
    r.ceil = function() {
        this.left = Math.ceil(this.left);
        this.top = Math.ceil(this.top);
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    r.floor = function() {
        this.left = Math.floor(this.left);
        this.top = Math.floor(this.top);
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    r.round = function() {
        this.left = Math.round(this.left);
        this.top = Math.round(this.top);
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    r.scale = function(a, b) {
        b = typeof b === "number" ? b : a;
        this.left *= a;
        this.width *= a;
        this.top *= b;
        this.height *= b;
        return this
    };

    function Fj(a, b, c) {
        if (typeof b === "string") Gj(a, c, b);
        else
            for (let d in b) Gj(a, b[d], d)
    }
    var Hj = /^--.+/;

    function Gj(a, b, c) {
        (c = Ij(a, c)) && (Hj.test(c) ? a.style.setProperty(c, b) : a.style[c] = b)
    }
    var Jj = {};

    function Ij(a, b) {
        var c = Jj[b];
        if (!c) {
            var d = Ri(b);
            c = d;
            a.style[d] === void 0 && (d = (xb ? "Webkit" : vb ? "Moz" : null) + Si(d), a.style[d] !== void 0 && (c = d));
            Jj[b] = c
        }
        return c
    }

    function Kj(a, b) {
        var c = a.style[Ri(b)];
        return typeof c !== "undefined" ? c : a.style[Ij(a, b)] || ""
    }

    function Lj(a, b) {
        a: {
            var c = ij(a);
            if (c.defaultView && c.defaultView.getComputedStyle && (c = c.defaultView.getComputedStyle(a, null))) {
                c = c[b] || c.getPropertyValue(b) || "";
                break a
            }
            c = ""
        }
        return c || (a.currentStyle ? a.currentStyle[b] : null) || a.style && a.style[b]
    }

    function Mj(a) {
        try {
            return a.getBoundingClientRect()
        } catch (b) {
            return {
                left: 0,
                top: 0,
                right: 0,
                bottom: 0
            }
        }
    }

    function Qj(a) {
        var b = ij(a),
            c = Lj(a, "position"),
            d = c == "fixed" || c == "absolute";
        for (a = a.parentNode; a && a != b; a = a.parentNode)
            if (a.nodeType == 11 && a.host && (a = a.host), c = Lj(a, "position"), d = d && c == "static" && a != b.documentElement && a != b.body, !d && (a.scrollWidth > a.clientWidth || a.scrollHeight > a.clientHeight || c == "fixed" || c == "absolute" || c == "relative")) return a;
        return null
    }

    function Rj(a) {
        var b = ij(a),
            c = new vi(0, 0);
        if (a == (b ? ij(b) : document).documentElement) return c;
        a = Mj(a);
        var d = Ti(b).g;
        b = mj(d);
        d = d.defaultView;
        b = new vi(d ? .pageXOffset || b.scrollLeft, d ? .pageYOffset || b.scrollTop);
        c.x = a.left + b.x;
        c.y = a.top + b.y;
        return c
    }

    function Sj(a) {
        typeof a == "number" && (a = Math.round(a) + "px");
        return a
    }

    function Tj(a) {
        var b = Uj;
        if (Lj(a, "display") != "none") return b(a);
        var c = a.style,
            d = c.display,
            e = c.visibility,
            f = c.position;
        c.visibility = "hidden";
        c.position = "absolute";
        c.display = "inline";
        a = b(a);
        c.display = d;
        c.position = f;
        c.visibility = e;
        return a
    }

    function Uj(a) {
        var b = a.offsetWidth,
            c = a.offsetHeight,
            d = xb && !b && !c;
        return (b === void 0 || d) && a.getBoundingClientRect ? (a = Mj(a), new wi(a.right - a.left, a.bottom - a.top)) : new wi(b, c)
    };
    var Vj = {
            passive: !0
        },
        Wj = oi(() => {
            var a = !1;
            try {
                let b = Object.defineProperty({}, "passive", {
                    get() {
                        a = !0
                    }
                });
                t.addEventListener("test", null, b)
            } catch (b) {}
            return a
        });

    function Xj(a) {
        return a ? a.passive && Wj() ? a : a.capture || !1 : !1
    }

    function Yj(a, b, c, d) {
        return typeof a.addEventListener === "function" ? (a.addEventListener(b, c, Xj(d)), !0) : !1
    }

    function Zj(a, b, c, d) {
        return typeof a.removeEventListener === "function" ? (a.removeEventListener(b, c, Xj(d)), !0) : !1
    }

    function ak(a, b) {
        a.document.readyState === "complete" ? (ii.push(b), ii.length === 1 && (window.Promise ? Promise.resolve().then(ji) : (a = window.setImmediate, qc(a) ? a(ji) : setTimeout(ji, 0)))) : a.addEventListener("load", b)
    };

    function bk(a) {
        var b = window;
        new Promise((c, d) => {
            function e() {
                f.onload = null;
                f.onerror = null;
                f.parentElement ? .removeChild(f)
            }
            var f = b.document.createElement("script");
            f.onload = () => {
                e();
                c()
            };
            f.onerror = () => {
                e();
                d(void 0)
            };
            f.type = "text/javascript";
            Ki(f, a);
            b.document.readyState !== "complete" ? Yj(b, "load", () => {
                b.document.body.appendChild(f)
            }) : b.document.body.appendChild(f)
        })
    };

    function ck() {
        dk || (dk = new ek);
        return dk
    }
    async function fk() {
        try {
            await window.android.webview.getExperimentalMediaIntegrityTokenProvider({
                cloudProjectNumber: 187810013193
            })
        } catch (a) {
            a.mediaIntegrityErrorName || a.code && a.code()
        }
    }
    var ek = class {
            constructor() {
                this.Kb = !1
            }
        },
        dk;
    async function gk(a) {
        var b = `${a.Ac?"https://ep1.adtrafficquality.google/getconfig/sodar":"https://pagead2.googlesyndication.com/getconfig/sodar"}?sv=200&tid=${a.j}&tv=${a.l}&st=${a.g==="cr"&&a.yc==="env"?a.g+"_"+a.yc:a.yc}${a.Rc?`&sjk=${a.Rc}`:""}${a.B?"&sde=1":""}`,
            c = void 0;
        try {
            c = await hk(b)
        } catch (g) {}
        if (c && !a.C) {
            b = a.Rc || c.sodar_query_id;
            var d = c.rc_enable !== void 0 && a.A ? c.rc_enable : "n",
                e = c.bg_snapshot_delay_ms === void 0 ? "0" : c.bg_snapshot_delay_ms,
                f = c.is_gen_204 === void 0 ? "1" : c.is_gen_204;
            if (b && c.bg_hash_basename &&
                c.bg_binary) return c = {
                context: a.g,
                nl: c.bg_hash_basename,
                ml: c.bg_binary,
                Hm: a.j + "_" + a.l,
                Rc: b,
                yc: a.yc,
                Ff: d,
                cg: e,
                Df: f,
                Ac: a.Ac,
                Ge: a.Ge
            }, a.Kb ? { ...c,
                Kb: !0
            } : c
        }
    }
    let hk = a => new Promise((b, c) => {
        var d = new XMLHttpRequest;
        d.onreadystatechange = () => {
            d.readyState === d.DONE && (d.status >= 200 && d.status < 300 ? b(JSON.parse(d.responseText)) : c())
        };
        d.open("GET", a, !0);
        d.send()
    });
    async function ik(a) {
        if (a.Kb) {
            ck().Kb = !0;
            var b = ck();
            window.android && window.android.webview && window.android.webview.getExperimentalMediaIntegrityTokenProvider && b.Kb && fk()
        }
        if (a = await gk(a)) {
            b = window;
            var c = b.GoogleGcLKhOms;
            c && typeof c.push === "function" || (c = b.GoogleGcLKhOms = []);
            let d = {
                _ctx_: a.context,
                _bgv_: a.nl,
                _bgp_: a.ml,
                _li_: a.Hm,
                _jk_: a.Rc,
                _st_: a.yc,
                _rc_: a.Ff,
                _dl_: a.cg,
                _g2_: a.Df,
                _atqg_: a.Ac ? "1" : "0",
                _sic_: a.Ge ? "1" : "0"
            };
            a.Kb && (d._wvp_ = "1");
            c.push(d);
            if (c = b.GoogleDX5YKUSk) b.GoogleDX5YKUSk = void 0, c[1]();
            a = a.Ac ? fi `https://ep2.adtrafficquality.google/sodar/${"sodar2"}.js` : fi `https://tpc.googlesyndication.com/sodar/${"sodar2"}.js`;
            bk(a)
        }
    };
    var jk = class extends I {
        g() {
            return D(this, 1)
        }
    };
    var kk = class extends I {};

    function lk(a) {
        switch (a) {
            case 1:
                return "gda";
            case 2:
                return "gpt";
            case 3:
                return "ima";
            case 4:
                return "pal";
            case 5:
                return "xfad";
            case 6:
                return "dv3n";
            case 7:
                return "spa";
            case 8:
                return "afs";
            case 9:
                return "oos";
            default:
                return "unk"
        }
    }
    var mk = class {
            constructor(a) {
                this.j = a.B;
                this.l = a.A;
                this.g = a.C;
                this.Rc = a.Rc;
                this.win = a.ua();
                this.yc = a.yc;
                this.Ff = a.Ff;
                this.cg = a.cg;
                this.Df = a.Df;
                this.A = a.j;
                this.Ac = a.Ac;
                this.Kb = a.Kb;
                this.B = a.g;
                this.Ge = a.Ge;
                this.C = a.l
            }
        },
        nk = class {
            constructor(a, b, c) {
                this.B = a;
                this.A = b;
                this.C = c;
                this.win = window;
                this.yc = "env";
                this.Ff = "n";
                this.cg = "0";
                this.Df = "1";
                this.j = !0;
                this.l = this.Ge = this.g = this.Kb = this.Ac = !1
            }
            ua() {
                return this.win
            }
            build() {
                return new mk(this)
            }
        };
    var ok = class extends I {
            hb() {
                return D(this, 1)
            }
        },
        Pf = [2, 3, 5];

    function pk() {
        var a = new qk;
        return Jf(a, 1, "")
    }

    function rk(a) {
        return Ve(a, ok, 2, De())
    }

    function sk(a, b) {
        return Xe(a, 2, b)
    }
    var qk = class extends I {};
    var tk = class extends I {};

    function uk(a) {
        var b = new vk;
        return Jf(b, 1, a)
    }
    var vk = class extends I {
        getValue() {
            return D(this, 1)
        }
        getVersion() {
            return E(this, 5)
        }
    };
    var wk = class extends I {};

    function xk(a) {
        var b = new yk;
        return Lf(b, 1, a)
    }
    var yk = class extends I {};

    function zk(a) {
        var b = new Ak;
        return Jf(b, 1, a)
    }

    function Bk(a) {
        var b = window.Date.now();
        b = Number.isFinite(b) ? Math.round(b) : 0;
        return wf(a, 3, b)
    }
    var Ak = class extends I {
            hb() {
                return qf(this, 1)
            }
            g() {
                return Nf(this, 2)
            }
            j() {
                return Fd(ue(this, 2))
            }
            setError(a) {
                return z(this, 10, a)
            }
        },
        Ck = qh(Ak);
    var Dk = class extends I {};
    Dk.prototype.g = function(a) {
        return function() {
            return Hg(this, a)
        }
    }([0, Pg, [0, 1, [0, Lg, -2], -1, Og, -1, Ng, [0, 3, Rg, Og], Kg, Sg, Qg], Pg, [0, Og, -1, Kg, Mg, -2, Kg, Jg, Ng, [0, Rg], Ng]]);
    var Ek = class extends I {};

    function Fk(a, b) {
        if (a)
            for (let c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    }

    function Gk(a) {
        var b = [];
        Fk(a, c => {
            b.push(c)
        });
        return b
    };

    function Hk(a) {
        var b = a.location.href;
        if (a === a.top) return {
            url: b,
            Jh: !0
        };
        var c = !1,
            d = a.document;
        d && d.referrer && (b = d.referrer, a.parent === a.top && (c = !0));
        (a = a.location.ancestorOrigins) && (a = a[a.length - 1]) && b ? .indexOf(a) === -1 && (c = !1, b = a);
        return {
            url: b,
            Jh: c
        }
    }

    function Ik(a) {
        try {
            return !!a && a.location.href != null && sb(a, "foo")
        } catch {
            return !1
        }
    }

    function Jk(a, b = t) {
        b = Kk(b);
        for (var c = 0; b && c++ < 40 && !a(b);) b = Kk(b)
    }

    function Kk(a) {
        try {
            let b = a.parent;
            if (b && b !== a) return b
        } catch {}
        return null
    }

    function Lk(a) {
        return Ik(a.top) ? a.top : null
    }

    function Mk(a) {
        for (var b = a; a && a !== a.parent;) a = a.parent, Ik(a) && (b = a);
        return b
    };

    function Nk() {
        return La && Oa ? Oa.mobile : !Ok() && (Ra("iPod") || Ra("iPhone") || Ra("Android") || Ra("IEMobile"))
    }

    function Ok() {
        return La && Oa ? !Oa.mobile && (Ra("iPad") || Ra("Android") || Ra("Silk")) : Ra("iPad") || Ra("Android") && !Ra("Mobile") || Ra("Silk")
    };

    function Pk(a) {
        return Na().indexOf(a) != -1
    }

    function Qk(a) {
        return Za() && Nk() ? Rk(a) : 1
    }
    var Sk = oi(() => Nk() ? 2 : Ok() ? 1 : 0);

    function Rk(a) {
        var b = Lk(a);
        if (!b) return 1;
        a = Sk() === 0;
        var c = !!b.document.querySelector('meta[name=viewport][content*="width=device-width"]'),
            d = b.innerWidth;
        b = b.outerWidth;
        if (d === 0) return 1;
        var e = Math.round((b / d + Number.EPSILON) * 100) / 100;
        return e === 1 ? 1 : a || c ? e : Math.round((b / d / .4 + Number.EPSILON) * 100) / 100
    }
    var Tk = oi(() => {
        var a = Math.random;
        return ["Google Web Preview", "Mediapartners-Google", "Google-Read-Aloud", "Google-Adwords"].some(Pk) || a() < 1E-4
    });

    function Uk() {
        if (!globalThis.crypto) return Math.random();
        try {
            let a = new Uint32Array(1);
            globalThis.crypto.getRandomValues(a);
            return a[0] / 65536 / 65536
        } catch (a) {
            return Math.random()
        }
    };
    let Vk, Wk = 64;

    function Xk() {
        try {
            return Vk ? ? (Vk = new Uint32Array(64)), Wk >= 64 && (crypto.getRandomValues(Vk), Wk = 0), Vk[Wk++]
        } catch (a) {
            return Math.floor(Math.random() * 2 ** 32)
        }
    };

    function Yk(a, b) {
        if (!oc(a.goog_pvsid)) try {
            let c = Xk() + (Xk() & 2 ** 21 - 1) * 2 ** 32;
            Object.defineProperty(a, "goog_pvsid", {
                value: c,
                configurable: !1
            })
        } catch (c) {
            b.Ja({
                methodName: 784,
                eb: c
            })
        }
        a = Number(a.goog_pvsid);
        (!a || a <= 0) && b.Ja({
            methodName: 784,
            eb: Error(`Invalid correlator, ${a}`)
        });
        return a || -1
    };

    function Zk(a, b) {
        var c = $k("SCRIPT", a);
        Ki(c, b);
        (a = a.getElementsByTagName("script")[0]) && a.parentNode && a.parentNode.insertBefore(c, a)
    }

    function al(a, b) {
        return b.getComputedStyle ? b.getComputedStyle(a, null) : a.currentStyle
    }
    var bl = /^([0-9.]+)px$/,
        cl = /^(-?[0-9.]{1,30})$/;

    function dl(a) {
        if (!cl.test(a)) return null;
        a = Number(a);
        return isNaN(a) ? null : a
    }

    function el(a) {
        return (a = bl.exec(a)) ? +a[1] : null
    }
    var fl = {
        Zn: "allow-forms",
        ao: "allow-modals",
        bo: "allow-orientation-lock",
        co: "allow-pointer-lock",
        eo: "allow-popups",
        fo: "allow-popups-to-escape-sandbox",
        ho: "allow-presentation",
        io: "allow-same-origin",
        jo: "allow-scripts",
        ko: "allow-top-navigation",
        lo: "allow-top-navigation-by-user-activation"
    };
    const gl = oi(() => Gk(fl));

    function hl(a) {
        var b = gl();
        return a.length ? cb(b, c => !hb(a, c)) : b
    }

    function il() {
        var a = $k("IFRAME"),
            b = {};
        ab(gl(), c => {
            a.sandbox && a.sandbox.supports && a.sandbox.supports(c) && (b[c] = !0)
        });
        return b
    }
    var jl = () => {
            var a = il();
            return !(!a["allow-top-navigation-by-user-activation"] || !a["allow-popups-to-escape-sandbox"])
        },
        kl = (a, b) => {
            try {
                return !(!a.frames || !a.frames[b])
            } catch {
                return !1
            }
        },
        ll = (a, b) => {
            for (let c = 0; c < 50; ++c) {
                if (kl(a, b)) return a;
                if (!(a = Kk(a))) break
            }
            return null
        },
        J = (a, b) => {
            Fk(b, (c, d) => {
                a.style.setProperty(d, c, "important")
            })
        },
        nl = (a, b) => {
            if ("length" in a.style) {
                a = a.style;
                let c = a.length;
                for (let d = 0; d < c; d++) {
                    let e = a[d];
                    b(a[e], e, a)
                }
            } else a = ml(a.style.cssText), Fk(a, b)
        },
        ml = a => {
            var b = {};
            if (a) {
                let c = /\s*:\s*/;
                ab((a || "").split(/\s*;\s*/), d => {
                    if (d) {
                        var e = d.split(c);
                        d = e[0];
                        e = e[1];
                        d && e && (b[d.toLowerCase()] = e)
                    }
                })
            }
            return b
        },
        ol = (a, b = () => !0, c = !1) => {
            var d = /!\s*important/i;
            nl(a, (e, f) => {
                !d.test(e) && b(f, e) ? (c && a.style.removeProperty(f), a.style.setProperty(f, e, "important")) : d.test(e) && !b(f, e) && a.style.setProperty(f, e, "")
            })
        };
    const pl = {
            ["http://googleads.g.doubleclick.net"]: !0,
            ["http://pagead2.googlesyndication.com"]: !0,
            ["https://googleads.g.doubleclick.net"]: !0,
            ["https://pagead2.googlesyndication.com"]: !0
        },
        ql = /\.proxy\.(googleprod|googlers)\.com(:\d+)?$/,
        rl = /.*domain\.test$/,
        sl = /\.prod\.google\.com(:\d+)?$/;
    var tl = a => pl[a] || ql.test(a) || rl.test(a) || sl.test(a),
        ul = (a, b) => Yk(a, {
            Ja: ({
                methodName: c,
                eb: d
            }) => void b ? .Da(c, d)
        }),
        vl = (a, b) => new Promise(c => {
            setTimeout(() => void c(b), a)
        }),
        wl = a => a.top == a ? 0 : Ik(a.top) ? 1 : 2;

    function $k(a, b = document) {
        return b.createElement(String(a).toLowerCase())
    };

    function xl(a, b, c = null, d = !1, e = !1) {
        yl(a, b, c, d, e)
    }

    function yl(a, b, c, d, e = !1) {
        a.google_image_requests || (a.google_image_requests = []);
        var f = $k("IMG", a.document);
        if (c || d) {
            let g = h => {
                c && c(h);
                d && ib(a.google_image_requests, f);
                Zj(f, "load", g);
                Zj(f, "error", g)
            };
            Yj(f, "load", g);
            Yj(f, "error", g)
        }
        e && (f.attributionSrc = "");
        f.src = b;
        a.google_image_requests.push(f)
    }

    function zl(a, b) {
        var c = `https://pagead2.googlesyndication.com/pagead/gen_204?id=${b}`;
        Fk(a, (d, e) => {
            if (d || d === 0) c += `&${e}=${encodeURIComponent(String(d))}`
        });
        Al(c)
    }

    function Al(a) {
        var b = window;
        b.fetch ? b.fetch(a, {
            keepalive: !0,
            credentials: "include",
            redirect: "follow",
            method: "get",
            mode: "no-cors"
        }) : xl(b, a, void 0, !1, !1)
    };
    let Bl = null;
    var Cl = window;
    var Dl = class extends I {};
    var El = class extends I {
        getCorrelator() {
            return hf(this, 1)
        }
        setCorrelator(a) {
            return xf(this, 1, a)
        }
    };
    var Fl = class extends I {};
    let Gl = null,
        Hl = null;

    function Il() {
        if (Gl != null) return Gl;
        Gl = !1;
        try {
            let a = Lk(t);
            a && a.location.hash.indexOf("google_logging") !== -1 && (Gl = !0)
        } catch (a) {}
        return Gl
    }

    function Jl() {
        if (Hl != null) return Hl;
        Hl = !1;
        try {
            let a = Lk(t);
            a && a.location.hash.indexOf("auto_ads_logging") !== -1 && (Hl = !0)
        } catch (a) {}
        return Hl
    }
    var Kl = (a, b = []) => {
        var c = !1;
        t.google_logging_queue || (c = !0, t.google_logging_queue = []);
        t.google_logging_queue.push([a, b]);
        c && Il() && Zk(t.document, fi `https://pagead2.googlesyndication.com/pagead/js/logging_library.js`)
    };
    var Ll = class {
        constructor(a, b) {
            this.error = a;
            this.meta = {};
            this.context = b.context;
            this.msg = b.message || "";
            this.id = b.id || "jserror"
        }
    };

    function Ml(a) {
        return new Ll(a, {
            message: Nl(a)
        })
    }

    function Nl(a) {
        var b = a.toString();
        a.name && b.indexOf(a.name) == -1 && (b += ": " + a.name);
        a.message && b.indexOf(a.message) == -1 && (b += ": " + a.message);
        a.stack && (b = Ol(a.stack, b));
        return b
    }

    function Ol(a, b) {
        try {
            a.indexOf(b) == -1 && (a = b + "\n" + a);
            let c;
            for (; a != c;) c = a, a = a.replace(RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"), "$1");
            return a.replace(RegExp("\n *", "g"), "\n")
        } catch (c) {
            return b
        }
    };
    const Pl = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)");
    var Ql = class {
            constructor(a, b) {
                this.g = a;
                this.j = b
            }
        },
        Rl = class {
            constructor(a, b, c) {
                this.url = a;
                this.win = b;
                this.g = !!c;
                this.depth = null
            }
        };
    let Sl = null;

    function Tl() {
        var a = window;
        if (Sl === null) {
            Sl = "";
            try {
                let b = "";
                try {
                    b = a.top.location.hash
                } catch (c) {
                    b = a.location.hash
                }
                if (b) {
                    let c = b.match(/\bdeid=([\d,]+)/);
                    Sl = c ? c[1] : ""
                }
            } catch (b) {}
        }
        return Sl
    };

    function Ul() {
        var a = t.performance;
        return a && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : Date.now()
    }

    function Vl() {
        var a = t.performance;
        return a && a.now ? a.now() : null
    };
    var Wl = class {
        constructor(a, b) {
            var c = Vl() || Ul();
            this.label = a;
            this.type = b;
            this.value = c;
            this.duration = 0;
            this.taskId = this.slotId = void 0;
            this.uniqueId = Math.random()
        }
    };
    const Xl = t.performance,
        Yl = !!(Xl && Xl.mark && Xl.measure && Xl.clearMarks),
        Zl = oi(() => {
            var a;
            if (a = Yl) a = Tl(), a = !!a.indexOf && a.indexOf("1337") >= 0;
            return a
        });

    function $l(a) {
        a && Xl && Zl() && (Xl.clearMarks(`goog_${a.label}_${a.uniqueId}_start`), Xl.clearMarks(`goog_${a.label}_${a.uniqueId}_end`))
    }

    function am(a) {
        a.g = !1;
        a.events !== a.j.google_js_reporting_queue && (Zl() && ab(a.events, $l), a.events.length = 0)
    }
    var bm = class {
        constructor(a) {
            this.events = [];
            this.j = a || t;
            var b = null;
            a && (a.google_js_reporting_queue = a.google_js_reporting_queue || [], this.events = a.google_js_reporting_queue, b = a.google_measure_js_timing);
            this.g = Zl() || (b != null ? b : Math.random() < 1)
        }
        start(a, b) {
            if (!this.g) return null;
            a = new Wl(a, b);
            b = `goog_${a.label}_${a.uniqueId}_start`;
            Xl && Zl() && Xl.mark(b);
            return a
        }
        end(a) {
            if (this.g && oc(a.value)) {
                a.duration = (Vl() || Ul()) - a.value;
                var b = `goog_${a.label}_${a.uniqueId}_end`;
                Xl && Zl() && Xl.mark(b);
                !this.g || this.events.length >
                    2048 || this.events.push(a)
            }
        }
    };

    function cm(a, b) {
        var c = {};
        c[a] = b;
        return [c]
    }

    function dm(a, b, c, d, e) {
        var f = [];
        Fk(a, (g, h) => {
            (g = em(g, b, c, d, e)) && f.push(`${h}=${g}`)
        });
        return f.join(b)
    }

    function em(a, b, c, d, e) {
        if (a == null) return "";
        b = b || "&";
        c = c || ",$";
        x(c) && (c = c.split(""));
        if (a instanceof Array) {
            if (d || (d = 0), d < c.length) {
                let f = [];
                for (let g = 0; g < a.length; g++) f.push(em(a[g], b, c, d + 1, e));
                return f.join(c[d])
            }
        } else if (typeof a === "object") return e || (e = 0), e < 2 ? encodeURIComponent(dm(a, b, c, d, e + 1)) : "...";
        return encodeURIComponent(String(a))
    }

    function fm(a) {
        var b = 1;
        for (let c in a.j) c.length > b && (b = c.length);
        return 3997 - b - a.l.length - 1
    }

    function gm(a, b, c, d) {
        b = b + "//" + c + d;
        var e = fm(a) - d.length;
        if (e < 0) return "";
        a.g.sort((f, g) => f - g);
        d = null;
        c = "";
        for (let f = 0; f < a.g.length; f++) {
            let g = a.g[f],
                h = a.j[g];
            for (let k = 0; k < h.length; k++) {
                if (!e) {
                    d = d == null ? g : d;
                    break
                }
                let l = dm(h[k], a.l, ",$");
                if (l) {
                    l = c + l;
                    if (e >= l.length) {
                        e -= l.length;
                        b += l;
                        c = a.l;
                        break
                    }
                    d = d == null ? g : d
                }
            }
        }
        a = "";
        d != null && (a = `${c}trn=${d}`);
        return b + a
    }
    var hm = class {
        constructor() {
            this.l = "&";
            this.j = {};
            this.B = 0;
            this.g = []
        }
    };
    const Bm = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");

    function Cm(a, b, c) {
        if (Array.isArray(b))
            for (let d = 0; d < b.length; d++) Cm(a, String(b[d]), c);
        else b != null && c.push(a + (b === "" ? "" : "=" + encodeURIComponent(String(b))))
    }

    function Dm(a, b, c) {
        c = c != null ? "=" + encodeURIComponent(String(c)) : "";
        if (b += c) {
            c = a.indexOf("#");
            c < 0 && (c = a.length);
            let d = a.indexOf("?"),
                e;
            d < 0 || d > c ? (d = c, e = "") : e = a.substring(d + 1, c);
            a = [a.slice(0, d), e, a.slice(c)];
            c = a[1];
            a[1] = b ? c ? c + "&" + b : b : c;
            a = a[0] + (a[1] ? "?" + a[1] : "") + a[2]
        }
        return a
    }
    const Em = /#|$/;

    function Fm(a, b) {
        var c = a.search(Em);
        a: {
            var d = 0;
            for (var e = b.length;
                (d = a.indexOf(b, d)) >= 0 && d < c;) {
                var f = a.charCodeAt(d - 1);
                if (f == 38 || f == 63)
                    if (f = a.charCodeAt(d + e), !f || f == 61 || f == 38 || f == 35) break a;
                d += e + 1
            }
            d = -1
        }
        if (d < 0) return null;
        e = a.indexOf("&", d);
        if (e < 0 || e > c) e = c;
        d += b.length + 1;
        return decodeURIComponent(a.slice(d, e !== -1 ? e : 0).replace(/\+/g, " "))
    };
    var Im = class {
        constructor(a = null) {
            this.F = Gm;
            this.j = a;
            this.g = null;
            this.B = !1;
            this.qa = this.Da
        }
        l(a) {
            this.g = a
        }
        A(a) {
            this.B = a
        }
        Yb(a, b, c) {
            try {
                if (this.j && this.j.g) {
                    var d = this.j.start(a.toString(), 3);
                    var e = b();
                    this.j.end(d)
                } else e = b()
            } catch (f) {
                b = !0;
                try {
                    $l(d), b = this.qa(a, Ml(f), void 0, c)
                } catch (g) {
                    this.Da(217, g)
                }
                if (b) window.console ? .error ? .(f);
                else throw f;
            }
            return e
        }
        Zb(a, b, c, d) {
            return (...e) => this.Yb(a, () => b.apply(c, e), d)
        }
        Da(a, b, c, d, e) {
            e = e || "jserror";
            var f = void 0;
            try {
                let L = new hm;
                var g = L;
                g.g.push(1);
                g.j[1] = cm("context",
                    a);
                b.error && b.meta && b.id || (b = Ml(b));
                g = b;
                if (g.msg) {
                    b = L;
                    var h = g.msg.substring(0, 512);
                    b.g.push(2);
                    b.j[2] = cm("msg", h)
                }
                var k = g.meta || {};
                h = k;
                if (this.g) try {
                    this.g(h)
                } catch (ka) {}
                if (d) try {
                    d(h)
                } catch (ka) {}
                d = L;
                k = [k];
                d.g.push(3);
                d.j[3] = k;
                var l;
                if (!(l = p)) {
                    d = t;
                    k = [];
                    h = null;
                    do {
                        var m = d;
                        if (Ik(m)) {
                            var n = m.location.href;
                            h = m.document && m.document.referrer || null
                        } else n = h, h = null;
                        k.push(new Rl(n || "", m));
                        try {
                            d = m.parent
                        } catch (ka) {
                            d = null
                        }
                    } while (d && m !== d);
                    for (let ka = 0, Da = k.length - 1; ka <= Da; ++ka) k[ka].depth = Da - ka;
                    m = t;
                    if (m.location &&
                        m.location.ancestorOrigins && m.location.ancestorOrigins.length === k.length - 1)
                        for (n = 1; n < k.length; ++n) {
                            let ka = k[n];
                            ka.url || (ka.url = m.location.ancestorOrigins[n - 1] || "", ka.g = !0)
                        }
                    l = k
                }
                var p = l;
                let S = new Rl(t.location.href, t, !1);
                l = null;
                let da = p.length - 1;
                for (m = da; m >= 0; --m) {
                    var q = p[m];
                    !l && Pl.test(q.url) && (l = q);
                    if (q.url && !q.g) {
                        S = q;
                        break
                    }
                }
                q = null;
                let Ea = p.length && p[da].url;
                S.depth !== 0 && Ea && (q = p[da]);
                f = new Ql(S, q);
                if (f.j) {
                    p = L;
                    var u = f.j.url || "";
                    p.g.push(4);
                    p.j[4] = cm("top", u)
                }
                var w = {
                    url: f.g.url || ""
                };
                if (f.g.url) {
                    let ka =
                        f.g.url.match(Bm);
                    var B = ka[1],
                        G = ka[3],
                        K = ka[4];
                    u = "";
                    B && (u += B + ":");
                    G && (u += "//", u += G, K && (u += ":" + K));
                    var H = u
                } else H = "";
                B = L;
                w = [w, {
                    url: H
                }];
                B.g.push(5);
                B.j[5] = w;
                Hm(this.F, e, L, this.B, c)
            } catch (L) {
                try {
                    Hm(this.F, e, {
                        context: "ecmserr",
                        rctx: a,
                        msg: Nl(L),
                        url: f ? .g.url ? ? ""
                    }, this.B, c)
                } catch (S) {}
            }
            return !0
        }
        sa(a, b, c) {
            b.catch(d => {
                d = d ? d : "unknown rejection";
                this.Da(a, d instanceof Error ? d : Error(d), void 0, c || this.g || void 0)
            })
        }
    };
    var Jm = class extends I {};

    function Km(a, b) {
        try {
            let c = d => [{
                [d.hg]: d.Mf
            }];
            return JSON.stringify([a.filter(d => d.re).map(c), Zd(b), a.filter(d => !d.re).map(c)])
        } catch (c) {
            return Lm(c, b), ""
        }
    }

    function Lm(a, b) {
        try {
            zl({
                m: Nl(a instanceof Error ? a : Error(String(a))),
                b: E(b, 1) || null,
                v: D(b, 2) || null
            }, "rcs_internal")
        } catch (c) {}
    }

    function Mm(a) {
        if (a.C) {
            var b = a.B,
                c = Set;
            var d = lf(a.B, 3);
            c = [...(new c([...d, ...a.C()]))];
            Ne(b, 3, c, gd)
        }
        return oe(a.B)
    }
    var Nm = class {
        constructor(a, b, c) {
            this.C = c;
            c = new Jm;
            a = F(c, 1, a);
            this.B = Kf(a, 2, b)
        }
    };

    function Om(a) {
        return Math.round(a)
    }

    function Pm(a) {
        var b = new CompressionStream("gzip"),
            c = (new Response(b.readable)).arrayBuffer(),
            d = b.writable.getWriter(),
            e = typeof a === "string" ? (new TextEncoder).encode(a) : a;
        return d.ready.then(() => d.write(e)).then(() => d.close()).then(() => c).then(f => new Uint8Array(f))
    };

    function Qm(a, b) {
        return Pe(a, 1, bn, Ed(b))
    }

    function cn(a, b) {
        return yf(a, 2, bn, b)
    }

    function dn(a, b) {
        return Pe(a, 3, bn, b == null ? b : Yc(b))
    }
    var M = class extends I {},
        bn = [1, 2, 3];

    function en(a, b) {
        return yf(a, 2, fn, b)
    }

    function gn(a, b) {
        return Pe(a, 4, fn, Wc(b))
    }
    var hn = class extends I {},
        fn = [2, 4];

    function jn(a) {
        var b = new kn;
        return Kf(b, 1, a)
    }

    function ln(a, b) {
        return z(a, 3, b)
    }

    function N(a, b) {
        return Ze(a, 4, M, b)
    }
    var kn = class extends I {};
    var mn = class extends I {
        j() {
            return D(this, 2)
        }
        getWidth() {
            return D(this, 3)
        }
        getHeight() {
            return D(this, 4)
        }
    };
    var nn = class extends I {};
    var on = class extends I {};
    var pn = class extends I {};
    var qn = class extends I {},
        rn = [5, 6];
    var sn = class extends I {
        getValue() {
            return E(this, 1)
        }
    };

    function tn(a) {
        var b = new un;
        return Lf(b, 1, a)
    }
    var un = class extends I {
        getValue() {
            return E(this, 1)
        }
    };
    var vn = class extends I {
        getValue() {
            return E(this, 1)
        }
    };
    var wn = class extends I {
        getHeight() {
            return gf(this, 2)
        }
    };

    function xn(a, b) {
        return uf(a, 1, b)
    }

    function yn(a, b) {
        return Xe(a, 2, b)
    }
    var zn = class extends I {};
    var An = class extends I {};
    var Bn = class extends I {};
    var Dn = class extends I {
            setError(a) {
                return A(this, 3, Cn, a)
            }
        },
        Cn = [2, 3];

    function En(a, b) {
        return xf(a, 1, b)
    }

    function Fn(a, b) {
        return xf(a, 2, b)
    }

    function Gn(a, b) {
        return xf(a, 3, b)
    }

    function Hn(a, b) {
        return xf(a, 4, b)
    }

    function In(a, b) {
        return xf(a, 5, b)
    }

    function Jn(a, b) {
        return Oe(a, 8, Wc(b), 0)
    }

    function Kn(a, b) {
        return Oe(a, 9, Wc(b), 0)
    }
    var Ln = class extends I {};

    function Mn(a, b) {
        return xf(a, 1, b)
    }

    function Nn(a, b) {
        return xf(a, 2, b)
    }
    var On = class extends I {};

    function Pn(a, b) {
        Ze(a, 1, On, b)
    }
    var Qn = class extends I {};
    var Rn = class extends I {};

    function Sn(a, b) {
        return Ne(a, 1, b, Dd)
    }

    function Tn(a, b) {
        return Ne(a, 12, b, zd)
    }

    function Un() {
        var a = new Vn;
        return Ye(a, 2, Dd, "irr", Fd)
    }

    function Wn(a, b) {
        return tf(a, 3, b)
    }

    function Xn(a, b) {
        return tf(a, 4, b)
    }

    function Yn(a, b) {
        return tf(a, 5, b)
    }

    function Zn(a, b) {
        return tf(a, 7, b)
    }

    function $n(a, b) {
        return tf(a, 8, b)
    }

    function ao(a, b) {
        return xf(a, 9, b)
    }

    function bo(a, b) {
        return Xe(a, 10, b)
    }

    function co(a, b) {
        return Ne(a, 11, b, kd)
    }
    var Vn = class extends I {};

    function eo(a) {
        var b = fo();
        z(a, 1, b)
    }

    function go(a, b) {
        return xf(a, 2, b)
    }

    function ho(a, b) {
        return Xe(a, 3, b)
    }

    function io(a, b) {
        return Xe(a, 4, b)
    }

    function jo(a, b) {
        return Ze(a, 4, un, b)
    }

    function ko(a, b) {
        return Xe(a, 5, b)
    }

    function lo(a, b) {
        return Ne(a, 6, b, Dd)
    }

    function mo(a, b) {
        return xf(a, 7, b)
    }

    function no(a, b) {
        return xf(a, 8, b)
    }

    function oo(a, b) {
        z(a, 9, b)
    }

    function po(a, b) {
        return tf(a, 10, b)
    }

    function qo(a, b) {
        return tf(a, 11, b)
    }

    function ro(a, b) {
        return tf(a, 12, b)
    }
    var so = class extends I {};
    var to = class extends I {};
    var uo = class extends I {};
    var vo = class extends I {
        setLocation(a) {
            return F(this, 2, a)
        }
    };

    function wo(a, b) {
        return Jf(a, 1, b)
    }

    function xo(a, b) {
        return Jf(a, 2, b)
    }
    var yo = class extends I {};
    var zo = class extends I {};

    function Ao(a) {
        var b = new Bo;
        return F(b, 1, a)
    }
    var Bo = class extends I {};
    var Co = class extends I {};
    var Do = class extends I {};
    var Eo = class extends I {};
    var Fo = class extends I {},
        Go = [1, 2];
    var Ho = class extends I {};
    var Io = class extends I {},
        Jo = [1];
    var Ko = class extends I {};
    var Lo = class extends I {};
    var Mo = class extends I {};
    var No = class extends I {};
    var Oo = class extends I {};
    var Po = class extends I {};
    var Qo = class extends I {};
    var Ro = class extends I {};
    var So = class extends I {};
    var To = class extends I {
        getContentUrl() {
            return D(this, 1)
        }
    };
    var Uo = class extends I {};

    function Vo(a) {
        var b = new Wo;
        return Mf(b, 1, a)
    }
    var Wo = class extends I {};
    var Xo = class extends I {};

    function Yo() {
        var a = new Zo,
            b = new Xo;
        return A(a, 1, $o, b)
    }

    function ap() {
        var a = new Zo,
            b = new Xo;
        return A(a, 9, $o, b)
    }

    function bp() {
        var a = new Zo,
            b = new Xo;
        return A(a, 13, $o, b)
    }

    function cp(a, b) {
        return A(a, 14, $o, b)
    }
    var Zo = class extends I {},
        $o = [1, 9, 13, 14];
    var dp = class extends I {};
    var ep = class extends I {};
    var fp = class extends I {};
    var gp = class extends I {};

    function hp(a, b) {
        return If(a, 10, b)
    }

    function ip(a, b) {
        return F(a, 1, b)
    }

    function jp(a, b) {
        return Kf(a, 4, b)
    }

    function kp(a, b) {
        return tf(a, 13, b)
    }
    var af = class extends I {};

    function lp(a) {
        return Ve(a, af, 2, De())
    }
    var mp = class extends I {};
    var np = class extends I {};
    var pp = class extends I {
            j() {
                return of(this, mp, 4, op)
            }
            g() {
                return Ae(this, mp, 4, op)
            }
        },
        op = [4, 5];
    var qp = class extends I {
        wf() {
            return E(this, 2)
        }
    };
    var rp = class extends I {},
        sp = [3];

    function tp(a) {
        var b = new up;
        return Kf(b, 4, a)
    }

    function vp(a, b) {
        return we(a, 6, b == null ? b : zd(b, void 0))
    }

    function wp(a, b) {
        return z(a, 10, b)
    }
    var up = class extends I {};
    var xp = class extends I {};
    var yp = class extends I {
        j() {
            return y(this, mp, 1)
        }
        g() {
            return ye(this, mp, 1)
        }
    };
    var zp = class extends I {};
    var Ap = class extends I {};
    var Bp = class extends I {};
    var Cp = class extends I {};
    var Dp = class extends I {};

    function Ep(a, b) {
        return xf(a, 1, b)
    }
    var Fp = class extends I {},
        Gp = [2, 3, 4];
    var Ip = class extends I {
            j() {
                return of(this, mp, 4, Hp)
            }
            g() {
                return Ae(this, mp, 4, Hp)
            }
        },
        Hp = [4, 6];
    var Jp = class extends I {},
        Kp = [3, 4, 5, 6, 7, 8, 9, 12, 14, 16, 17, 19, 20, 21, 22, 23, 24, 25, 26];

    function Lp(a, b) {
        return vf(a, 1, b)
    }

    function Mp(a, b) {
        return vf(a, 2, b)
    }

    function Np(a, b) {
        return vf(a, 3, b)
    }

    function Op(a, b) {
        return vf(a, 4, b)
    }
    var Pp = class extends I {};
    var Qp = class extends I {
        j() {
            return y(this, Pp, 2)
        }
    };
    var Rp = class extends I {
        j() {
            return y(this, Pp, 2)
        }
    };

    function Sp(a, b) {
        return Xe(a, 1, b)
    }

    function Tp(a, b) {
        return Xe(a, 2, b)
    }
    var Up = class extends I {};

    function Vp(a, b) {
        return xf(a, 3, b)
    }
    var Wp = class extends I {},
        Xp = [4, 5, 6, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24];
    var Yp = class extends I {};

    function Zp() {
        var a = og($p());
        return Kf(a, 1, aq())
    }
    var bq = class extends I {};
    var cq = class extends I {};
    var dq = class extends I {
        getTagSessionCorrelator() {
            return hf(this, 1)
        }
    };
    var eq = class extends I {},
        fq = [1, 7],
        gq = [4, 6, 8];
    var hq = class extends I {
            getTagSessionCorrelator() {
                return hf(this, 2)
            }
        },
        iq = [6, 7];
    class jq {
        constructor(a) {
            this.F = a;
            this.hc = new kq(this.F)
        }
    }
    class kq {
        constructor(a) {
            this.F = a;
            this.Qe = new lq(this.F);
            this.Rk = new mq(this.F);
            this.xf = new nq(this.F)
        }
    }
    class lq {
        constructor(a) {
            this.F = a;
            this.g = new oq(this.F);
            this.qk = new pq(this.F)
        }
    }
    class oq {
        constructor(a) {
            this.F = a;
            this.j = new qq(this.F);
            this.g = new rq(this.F)
        }
    }
    class qq {
        constructor(a) {
            this.F = a
        }
        Td(a) {
            sq(this.F, ln(N(jn("xR0Czf"), Qm(new M, a.status)), gn(new hn, a.Zc)))
        }
    }
    class rq {
        constructor(a) {
            this.F = a
        }
        Td(a) {
            sq(this.F, ln(N(jn("jM4CPd"), cn(new M, Om(a.Sn))), gn(new hn, a.Zc)))
        }
    }
    class pq {
        constructor(a) {
            this.F = a;
            this.Sk = new tq(this.F);
            this.Wk = new uq(this.F);
            this.zg = new vq(this.F);
            this.Xk = new wq(this.F);
            this.Yk = new xq(this.F);
            this.Zk = new yq(this.F);
            this.al = new zq(this.F);
            this.Ag = new Aq(this.F);
            this.xl = new Bq(this.F);
            this.hm = new Cq(this.F);
            this.mn = new Dq(this.F);
            this.Gn = new Eq(this.F);
            this.si = new Fq(this.F);
            this.Hn = new Gq(this.F);
            this.ui = new Hq(this.F);
            this.In = new Iq(this.F)
        }
    }
    class tq {
        constructor(a) {
            this.F = a
        }
        wa(a) {
            sq(this.F, ln(N(N(jn("VEDP7d"), Qm(new M, a.language)), cn(new M, a.Oa)), en(new hn, Om(a.da))))
        }
    }
    class uq {
        constructor(a) {
            this.F = a
        }
        wa(a) {
            sq(this.F, ln(N(N(jn("igjuhc"), Qm(new M, a.language)), cn(new M, a.Oa)), en(new hn, Om(a.da))))
        }
    }
    class vq {
        constructor(a) {
            this.F = a
        }
        Td(a) {
            sq(this.F, ln(N(N(N(N(N(jn("i3zJEd"), Qm(new M, a.language)), cn(new M, a.Oa)), cn(new M, a.outcome)), dn(new M, a.sc)), dn(new M, a.Nc)), gn(new hn, a.Zc)))
        }
    }
    class wq {
        constructor(a) {
            this.F = a
        }
        wa(a) {
            sq(this.F, ln(N(N(N(N(N(jn("JN0hVd"), Qm(new M, a.language)), cn(new M, a.Oa)), cn(new M, a.outcome)), dn(new M, a.sc)), dn(new M, a.Nc)), en(new hn, Om(a.da))))
        }
    }
    class xq {
        constructor(a) {
            this.F = a
        }
        wa(a) {
            sq(this.F, ln(N(N(N(jn("rmHfOd"), Qm(new M, a.language)), cn(new M, a.Oa)), cn(new M, a.reason)), en(new hn, Om(a.da))))
        }
    }
    class yq {
        constructor(a) {
            this.F = a
        }
        wa(a) {
            sq(this.F, ln(N(N(N(jn("VEyQic"), Qm(new M, a.language)), cn(new M, a.Oa)), cn(new M, a.format)), en(new hn, Om(a.da))))
        }
    }
    class zq {
        constructor(a) {
            this.F = a
        }
        wa(a) {
            sq(this.F, ln(N(N(N(jn("QFcNxc"), Qm(new M, a.language)), cn(new M, a.Oa)), cn(new M, a.format)), en(new hn, Om(a.da))))
        }
    }
    class Aq {
        constructor(a) {
            this.F = a
        }
        wa(a) {
            sq(this.F, ln(N(N(N(N(jn("SIhp4"), Qm(new M, a.language)), cn(new M, a.Oa)), cn(new M, a.format)), dn(new M, a.sc)), en(new hn, Om(a.da))))
        }
    }
    class Bq {
        constructor(a) {
            this.F = a
        }
        wa(a) {
            sq(this.F, ln(N(N(N(jn("Eeiun"), Qm(new M, a.language)), cn(new M, a.Oa)), cn(new M, a.format)), en(new hn, Om(a.da))))
        }
    }
    class Cq {
        constructor(a) {
            this.F = a
        }
        wa(a) {
            sq(this.F, ln(N(N(N(N(jn("pVNWme"), Qm(new M, a.language)), cn(new M, a.Oa)), cn(new M, a.Mb)), cn(new M, a.format)), en(new hn, Om(a.da))))
        }
    }
    class Dq {
        constructor(a) {
            this.F = a
        }
        wa(a) {
            sq(this.F, ln(N(N(N(jn("pYLGPe"), Qm(new M, a.language)), cn(new M, a.Oa)), cn(new M, a.type)), en(new hn, Om(a.da))))
        }
    }
    class Eq {
        constructor(a) {
            this.F = a
        }
        wa(a) {
            sq(this.F, ln(N(N(jn("OyfJgf"), Qm(new M, a.language)), cn(new M, a.Oa)), en(new hn, Om(a.da))))
        }
    }
    class Fq {
        constructor(a) {
            this.F = a
        }
        Td(a) {
            sq(this.F, ln(N(N(N(N(jn("vkypFe"), Qm(new M, a.language)), cn(new M, a.Oa)), cn(new M, a.outcome)), dn(new M, a.Nc)), gn(new hn, a.Zc)))
        }
    }
    class Gq {
        constructor(a) {
            this.F = a
        }
        wa(a) {
            sq(this.F, ln(N(N(N(N(jn("U2cYzb"), Qm(new M, a.language)), cn(new M, a.Oa)), cn(new M, a.outcome)), dn(new M, a.Nc)), en(new hn, Om(a.da))))
        }
    }
    class Hq {
        constructor(a) {
            this.F = a
        }
        wa(a) {
            sq(this.F, ln(N(N(N(jn("PsAR8b"), Qm(new M, a.language)), cn(new M, a.Oa)), cn(new M, a.format)), en(new hn, Om(a.da))))
        }
    }
    class Iq {
        constructor(a) {
            this.F = a
        }
        wa(a) {
            sq(this.F, ln(N(N(jn("Ah4H"), Qm(new M, a.language)), cn(new M, a.Oa)), en(new hn, Om(a.da))))
        }
    }
    class mq {
        constructor(a) {
            this.F = a;
            this.Fl = new Jq(this.F)
        }
    }
    class Jq {
        constructor(a) {
            this.F = a
        }
        wa(a) {
            sq(this.F, ln(N(N(N(jn("pA20Lb"), Qm(new M, a.Mk)), Qm(new M, a.El)), Qm(new M, a.Ym)), en(new hn, Om(a.da))))
        }
    }
    class nq {
        constructor(a) {
            this.F = a;
            this.autoRefresh = new Kq(this.F);
            this.Ab = new Lq(this.F);
            this.outstream = new Mq(this.F);
            this.request = new Nq(this.F);
            this.threadYield = new Oq(this.F)
        }
    }
    class Kq {
        constructor(a) {
            this.F = a
        }
    }
    class Lq {
        constructor(a) {
            this.F = a;
            this.lf = new Pq(this.F)
        }
    }
    class Pq {
        constructor(a) {
            this.F = a
        }
        wa(a) {
            sq(this.F, ln(N(jn("Ka9ewd"), cn(new M, a.dg)), en(new hn, Om(a.da))))
        }
    }
    class Mq {
        constructor(a) {
            this.F = a
        }
    }
    class Nq {
        constructor(a) {
            this.F = a
        }
    }
    class Oq {
        constructor(a) {
            this.F = a
        }
    }
    class Qq extends Nm {
        constructor() {
            super(...arguments);
            this.Xb = new jq(this)
        }
    }

    function sq(a, ...b) {
        a.l(...b.map(c => ({
            re: !1,
            hg: 1,
            Mf: Zd(c)
        })))
    }

    function Rq(a, ...b) {
        a.l(...b.map(c => ({
            re: !0,
            hg: 3,
            Mf: Zd(c)
        })))
    }

    function Sq(a, ...b) {
        a.l(...b.map(c => ({
            re: !0,
            hg: 7,
            Mf: Zd(c)
        })))
    }

    function Tq(a, ...b) {
        a.l(...b.map(c => ({
            re: !0,
            hg: 37,
            Mf: Zd(c)
        })))
    }
    var Uq = class extends Qq {};

    function Vq(a, b) {
        globalThis.fetch(a, {
            method: "POST",
            body: b,
            keepalive: b.length < 65536,
            credentials: "omit",
            mode: "no-cors",
            redirect: "follow"
        }).catch(() => {})
    }

    function Wq(a, b, c = 1, d = !1) {
        var e = typeof CompressionStream === "function";
        typeof document !== "undefined" && document.visibilityState !== "hidden" && d && e ? Pm(b).then(f => {
            Vq(`${a}?e=${c===1?5:6}`, f)
        }).catch(() => {
            Vq(`${a}?e=${c}`, b)
        }) : Vq(`${a}?e=${c}`, b)
    }
    var Xq = class extends Uq {
            constructor(a) {
                super(2, a, void 0);
                this.g = Wq
            }
            l(...a) {
                try {
                    let b = Km(a, Mm(this));
                    this.g("https://pagead2.googlesyndication.com/pagead/ping", b, 1, !1)
                } catch (b) {
                    Lm(b, Mm(this))
                }
            }
        },
        Yq = class extends Xq {};

    function Zq(a) {
        a.j !== null && (clearTimeout(a.j), a.j = null);
        if (a.g.length) {
            var b = Km(a.g, Mm(a));
            a.O("https://pagead2.googlesyndication.com/pagead/ping", b, 1, !1);
            a.g = []
        }
    }
    var br = class extends Uq {
            constructor(a, b, c, d, e) {
                super(2, a, $q);
                this.O = Wq;
                this.P = b;
                this.G = c;
                this.J = d;
                this.A = e;
                this.g = [];
                this.j = null;
                this.D = !1
            }
            l(...a) {
                try {
                    this.J && Km(this.g.concat(a), Mm(this)).length >= 65536 && Zq(this), this.A && !this.D && (this.D = !0, ar(this.A, () => {
                        Zq(this)
                    })), this.g.push(...a), this.g.length >= this.G && Zq(this), this.g.length && this.j === null && (this.j = setTimeout(() => {
                        Zq(this)
                    }, this.P))
                } catch (b) {
                    Lm(b, Mm(this))
                }
            }
        },
        cr = class extends br {
            constructor(a, b = 1E3, c = 100, d = !1, e) {
                super(a, b, c, d && !0, e)
            }
        };
    var dr = a => {
        var b = "Oc";
        if (a.Oc && a.hasOwnProperty(b)) return a.Oc;
        b = new a;
        return a.Oc = b
    };

    function er(a, b, c) {
        return b[a] || c
    };

    function fr(a, b) {
        a.j = (c, d) => er(2, b, () => [])(c, 1, d);
        a.g = c => er(3, b, () => [])(c ? ? 1)
    }
    class gr {
        j() {
            return []
        }
        g() {
            return []
        }
    }

    function hr(a, b) {
        return dr(gr).j(a, b)
    }

    function $q(a) {
        return dr(gr).g(a)
    };

    function Hm(a, b, c, d = !1, e) {
        if ((d ? a.g : Math.random()) < (e || .01)) try {
            let f;
            c instanceof hm ? f = c : (f = new hm, Fk(c, (h, k) => {
                var l = f,
                    m = l.B++;
                h = cm(k, h);
                l.g.push(m);
                l.j[m] = h
            }));
            let g = gm(f, a.protocol, a.domain, a.path + b + "&");
            g && xl(t, g)
        } catch (f) {}
    }

    function ir(a, b) {
        b >= 0 && b <= 1 && (a.g = b)
    }
    var jr = class {
        constructor() {
            this.domain = "pagead2.googlesyndication.com";
            this.path = "/pagead/gen_204?id=";
            this.protocol = "https:";
            this.g = Math.random()
        }
    };
    let Gm, kr;
    const lr = new bm(window);
    (function(a) {
        Gm = a ? ? new jr;
        typeof window.google_srt !== "number" && (window.google_srt = Math.random());
        ir(Gm, window.google_srt);
        kr = new Im(lr);
        kr.l(() => {});
        kr.A(!0);
        window.document.readyState === "complete" ? window.google_measure_js_timing || am(lr) : lr.g && Yj(window, "load", () => {
            window.google_measure_js_timing || am(lr)
        })
    })();

    function mr(a) {
        kr.sa(1085, a)
    };
    const nr = {
        "AMP-CAROUSEL": "ac",
        "AMP-FX-FLYING-CARPET": "fc",
        "AMP-LIGHTBOX": "lb",
        "AMP-STICKY-AD": "sa"
    };

    function or(a = t) {
        var b = a.context || a.AMP_CONTEXT_DATA;
        if (!b) try {
            b = a.parent.context || a.parent.AMP_CONTEXT_DATA
        } catch {}
        return b ? .pageViewId && b ? .canonicalUrl ? b : null
    }

    function pr(a = or()) {
        return a && a.mode ? +a.mode.version || null : null
    }

    function qr(a = or()) {
        if (a && a.container) {
            a = a.container.split(",");
            let b = [];
            for (let c = 0; c < a.length; c++) b.push(nr[a[c]] || "x");
            return b.join()
        }
        return null
    }

    function rr() {
        var a = or();
        return a && a.initialIntersection
    }

    function sr() {
        var a = rr();
        return a && a.rootBounds && ra(a.rootBounds) ? new wi(a.rootBounds.width, a.rootBounds.height) : null
    }

    function tr(a = or()) {
        return a ? Ik(a.master) ? a.master : null : null
    }

    function ur(a, b) {
        var c = a.ampInaboxIframes = a.ampInaboxIframes || [],
            d = () => {},
            e = () => {};
        b && (c.push(b), e = () => {
            a.AMP && a.AMP.inaboxUnregisterIframe && a.AMP.inaboxUnregisterIframe(b);
            ib(c, b);
            d()
        });
        if (a.ampInaboxInitialized) return e;
        a.ampInaboxPendingMessages = a.ampInaboxPendingMessages || [];
        var f = g => {
            if (a.ampInaboxInitialized) g = !0;
            else {
                var h, k = g.data === "amp-ini-load";
                a.ampInaboxPendingMessages && !k && (h = /^amp-(\d{15,20})?/.exec(g.data)) && (a.ampInaboxPendingMessages.push(g), g = h[1], a.ampInaboxInitialized || g && !/^\d{15,20}$/.test(g) ||
                    a.document.querySelector('script[src$="amp4ads-host-v0.js"]') || Zk(a.document, g ? fi `https://cdn.ampproject.org/rtv/${g}/amp4ads-host-v0.js` : fi `https://cdn.ampproject.org/amp4ads-host-v0.js`));
                g = !1
            }
            g && d()
        };
        c.google_amp_listener_added || (c.google_amp_listener_added = !0, Yj(a, "message", f), d = () => {
            Zj(a, "message", f)
        });
        return e
    };

    function vr(a, b) {
        a = wr(a);
        if (!a) return b;
        var c = b.slice(-1);
        return b + (c === "?" || c === "#" ? "" : "&") + a
    }

    function wr(a) {
        var b = {};
        Fk(a, (c, d) => {
            if (c || c === 0 || c === !1) pc(c) && (c = c ? 1 : 0), b[d] = c
        });
        return Object.entries(b).map(([c, d]) => `${c}=${encodeURIComponent(String(d))}`).join("&")
    }

    function xr(a) {
        if (a === "localhost") return ["localhost"];
        a = a.split(".");
        if (a.length < 2) return [];
        var b = [];
        for (let c = 0; c < a.length - 1; ++c) b.push(a.slice(c).join("."));
        return b
    };
    var yr = a => {
            a = a.google_unique_id;
            return oc(a) ? a : 0
        },
        zr = a => (a = a.google_ad_format) ? a.indexOf("_0ads") > 0 : !1,
        Ar = a => {
            var b = Number(a.google_ad_width),
                c = Number(a.google_ad_height);
            if (!(b > 0 && c > 0)) {
                a: {
                    try {
                        let e = String(a.google_ad_format);
                        if (e && e.match) {
                            let f = e.match(/(\d+)x(\d+)/i);
                            if (f) {
                                let g = parseInt(f[1], 10),
                                    h = parseInt(f[2], 10);
                                if (g > 0 && h > 0) {
                                    var d = {
                                        width: g,
                                        height: h
                                    };
                                    break a
                                }
                            }
                        }
                    } catch (e) {}
                    d = null
                }
                a = d;
                if (!a) return null;b = b > 0 ? b : a.width;c = c > 0 ? c : a.height
            }
            return {
                width: b,
                height: c
            }
        },
        Br = a => {
            if (!a) return "";
            a = a.toLowerCase();
            a.substring(0, 3) != "ca-" && (a = "ca-" + a);
            return a
        };
    let Cr = (new Date).getTime();

    function Dr(a) {
        a = parseInt(a, 10);
        return isNaN(a) ? 0 : a
    };
    var Er = {
        Ko: 0,
        Jo: 1,
        Go: 2,
        Bo: 3,
        Ho: 4,
        Co: 5,
        Io: 6,
        Eo: 7,
        Fo: 8,
        Ao: 9,
        Do: 10,
        Lo: 11
    };
    var Fr = {
        No: 0,
        Oo: 1,
        Mo: 2
    };

    function Gr(a, b) {
        return a.left < b.right && b.left < a.right && a.top < b.bottom && b.top < a.bottom
    }

    function Hr(a) {
        a = a.map(b => new zj(b.top, b.right, b.bottom, b.left));
        a = Ir(a);
        return {
            top: a.top,
            right: a.right,
            bottom: a.bottom,
            left: a.left
        }
    }

    function Ir(a) {
        if (!a.length) throw Error("pso:box:m:nb");
        return a.slice(1).reduce((b, c) => {
            b.left = Math.min(b.left, c.left);
            b.top = Math.min(b.top, c.top);
            b.right = Math.max(b.right, c.right);
            b.bottom = Math.max(b.bottom, c.bottom);
            return b
        }, Aj(a[0]))
    };
    var Ci = {
        bp: 0,
        so: 1,
        wo: 2,
        uo: 3,
        vo: 4,
        zo: 8,
        hp: 9,
        Vo: 10,
        Wo: 11,
        gp: 16,
        ro: 17,
        qo: 24,
        Uo: 25,
        no: 26,
        mo: 27,
        Ik: 30,
        Qo: 32,
        To: 40,
        jp: 41,
        ip: 42,
        po: 43
    };
    var Jr = {
            overlays: 1,
            interstitials: 2,
            vignettes: 2,
            inserts: 3,
            immersives: 4,
            list_view: 5,
            full_page: 6,
            side_rails: 7
        },
        hs = {
            [1]: 1,
            [2]: 1,
            [3]: 7,
            [4]: 7,
            [8]: 2,
            [27]: 3,
            [9]: 4,
            [30]: 5
        };
    var is = 728 * 1.38;

    function js(a, b = -1) {
        if (a !== a.top) {
            if (b < 0) a = !1;
            else {
                var c = ks(a, !0, !0),
                    d = ls(a, !0);
                a = c > 0 && d > 0 && Math.abs(1 - a.screen.width / c) <= b && Math.abs(1 - a.screen.height / d) <= b
            }
            a = a ? 0 : 512
        } else a = 0;
        return a
    }

    function ms(a, b = 420, c = !1, d = !1) {
        return (a = ks(a, c, d)) ? a > b ? 32768 : a < 320 ? 65536 : 0 : 16384
    }

    function ns(a) {
        return Math.max(0, os(a, !0) - ls(a))
    }

    function ps(a) {
        a = a.document;
        var b = {};
        a && (b = a.compatMode == "CSS1Compat" ? a.documentElement : a.body);
        return b || {}
    }

    function ls(a, b = !1) {
        var c = ps(a).clientHeight;
        return b ? c * Qk(a) : c
    }

    function ks(a, b = !1, c = !1) {
        c = ps(a).clientWidth ? ? (c ? a.innerWidth : void 0);
        return b ? c * Qk(a) : c
    }

    function os(a, b) {
        var c = ps(a);
        return b ? (a = ls(a), c.scrollHeight === a ? c.offsetHeight : c.scrollHeight) : c.offsetHeight
    }

    function qs(a, b) {
        return rs(b) || b === 10 || !a.adCount ? !1 : b === 1 || b === 2 ? !(!a.adCount[1] && !a.adCount[2]) : (a = a.adCount[b]) ? a >= 1 : !1
    }

    function ss(a, b) {
        return a && a.source ? a.source === b || a.source.parent === b : !1
    }

    function ts(a) {
        return a.pageYOffset === void 0 ? (a.document.documentElement || a.document.body.parentNode || a.document.body).scrollTop : a.pageYOffset
    }

    function us(a) {
        return a.pageXOffset === void 0 ? (a.document.documentElement || a.document.body.parentNode || a.document.body).scrollLeft : a.pageXOffset
    }

    function vs(a) {
        var b = {},
            c;
        Array.isArray(a) ? c = a : a && a.key_value && (c = a.key_value);
        if (c)
            for (a = 0; a < c.length; a++) {
                let d = c[a];
                if ("key" in d && "value" in d) {
                    let e = d.value;
                    b[d.key] = e == null ? null : String(e)
                }
            }
        return b
    }

    function ws(a, b, c, d) {
        Hm(c, b, {
            c: d.data.substring(0, 500),
            u: a.location.href.substring(0, 500)
        }, !0, .1);
        return !0
    }

    function xs(a, b) {
        var c = {
            bottom: "auto",
            clear: "none",
            display: "inline",
            "float": "none",
            height: "auto",
            left: "auto",
            margin: 0,
            "margin-bottom": 0,
            "margin-left": 0,
            "margin-right": "0",
            "margin-top": 0,
            "max-height": "none",
            "max-width": "none",
            opacity: 1,
            overflow: "visible",
            padding: 0,
            "padding-bottom": 0,
            "padding-left": 0,
            "padding-right": 0,
            "padding-top": 0,
            position: "static",
            right: "auto",
            top: "auto",
            "vertical-align": "baseline",
            visibility: "visible",
            width: "auto",
            "z-index": "auto"
        };
        ab(Object.keys(c), d => {
            Kj(a, d) || Fj(a, d, c[d])
        });
        ol(a, void 0, b)
    }

    function rs(a) {
        return a === 26 || a === 27 || a === 40 || a === 41
    };

    function ys(a, b) {
        zs(a).forEach(b, void 0)
    }

    function zs(a) {
        var b = [],
            c = a.length;
        for (let d = 0; d < c; d++) b.push(a[d]);
        return b
    };

    function As(a, b) {
        return a.g[Bs(b)] !== void 0
    }

    function Cs(a) {
        var b = [];
        for (let c in a.g) a.g[c] !== void 0 && a.g.hasOwnProperty(c) && b.push(a.j[c]);
        return b
    }

    function Ds(a) {
        var b = [];
        for (let c in a.g) a.g[c] !== void 0 && a.g.hasOwnProperty(c) && b.push(a.g[c]);
        return b
    }
    var Es = class {
        constructor() {
            this.g = {};
            this.j = {}
        }
        set(a, b) {
            var c = Bs(a);
            this.g[c] = b;
            this.j[c] = a
        }
        get(a, b) {
            a = Bs(a);
            return this.g[a] !== void 0 ? this.g[a] : b
        }
        Mc() {
            return Cs(this).length
        }
        clear() {
            this.g = {};
            this.j = {}
        }
    };

    function Bs(a) {
        return a instanceof Object ? String(sa(a)) : a + ""
    };
    var Fs = class {
        constructor(a) {
            this.g = new Es;
            if (a)
                for (let b = 0; b < a.length; ++b) this.add(a[b])
        }
        add(a) {
            this.g.set(a, !0)
        }
        contains(a) {
            return As(this.g, a)
        }
    };
    class Gs {
        constructor(a, b) {
            this.g = a[t.Symbol.iterator]();
            this.j = b
        }[Symbol.iterator]() {
            return this
        }
        next() {
            var a = this.g.next();
            return {
                value: a.done ? void 0 : this.j.call(void 0, a.value),
                done: a.done
            }
        }
    }

    function Hs(a, b) {
        return new Gs(a, b)
    };

    function Is() {}
    Is.prototype.next = function() {
        return Js
    };
    const Js = {
        done: !0,
        value: void 0
    };
    Is.prototype.hd = function() {
        return this
    };

    function Ks(a) {
        if (a instanceof Ls || a instanceof Ms || a instanceof Ns) return a;
        if (typeof a.next == "function") return new Ls(() => a);
        if (typeof a[Symbol.iterator] == "function") return new Ls(() => a[Symbol.iterator]());
        if (typeof a.hd == "function") return new Ls(() => a.hd());
        throw Error("Not an iterator or iterable.");
    }
    class Ls {
        constructor(a) {
            this.g = a
        }
        hd() {
            return new Ms(this.g())
        }[Symbol.iterator]() {
            return new Ns(this.g())
        }
        j() {
            return new Ns(this.g())
        }
    }
    class Ms extends Is {
        constructor(a) {
            super();
            this.g = a
        }
        next() {
            return this.g.next()
        }[Symbol.iterator]() {
            return new Ns(this.g)
        }
        j() {
            return new Ns(this.g)
        }
    }
    class Ns extends Ls {
        constructor(a) {
            super(() => a);
            this.l = a
        }
        next() {
            return this.l.next()
        }
    };

    function Os(a, b) {
        this.j = {};
        this.g = [];
        this.l = this.size = 0;
        var c = arguments.length;
        if (c > 1) {
            if (c % 2) throw Error("Uneven number of arguments");
            for (var d = 0; d < c; d += 2) this.set(arguments[d], arguments[d + 1])
        } else if (a)
            if (a instanceof Os)
                for (c = Ps(a), d = 0; d < c.length; d++) this.set(c[d], a.get(c[d]));
            else
                for (d in a) this.set(d, a[d])
    }
    r = Os.prototype;
    r.Mc = function() {
        return this.size
    };

    function Ps(a) {
        Qs(a);
        return a.g.concat()
    }
    r.has = function(a) {
        return Rs(this.j, a)
    };
    r.equals = function(a, b) {
        if (this === a) return !0;
        if (this.size != a.Mc()) return !1;
        b = b || Ss;
        Qs(this);
        var c;
        for (let d = 0; c = this.g[d]; d++)
            if (!b(this.get(c), a.get(c))) return !1;
        return !0
    };

    function Ss(a, b) {
        return a === b
    }
    r.isEmpty = function() {
        return this.size == 0
    };
    r.clear = function() {
        this.j = {};
        this.l = this.size = this.g.length = 0
    };
    r.delete = function(a) {
        return Rs(this.j, a) ? (delete this.j[a], --this.size, this.l++, this.g.length > 2 * this.size && Qs(this), !0) : !1
    };

    function Qs(a) {
        if (a.size != a.g.length) {
            for (var b = 0, c = 0; b < a.g.length;) {
                var d = a.g[b];
                Rs(a.j, d) && (a.g[c++] = d);
                b++
            }
            a.g.length = c
        }
        if (a.size != a.g.length) {
            b = {};
            for (d = c = 0; c < a.g.length;) {
                let e = a.g[c];
                Rs(b, e) || (a.g[d++] = e, b[e] = 1);
                c++
            }
            a.g.length = d
        }
    }
    r.get = function(a, b) {
        return Rs(this.j, a) ? this.j[a] : b
    };
    r.set = function(a, b) {
        Rs(this.j, a) || (this.size += 1, this.g.push(a), this.l++);
        this.j[a] = b
    };
    r.forEach = function(a, b) {
        var c = Ps(this);
        for (let d = 0; d < c.length; d++) {
            let e = c[d],
                f = this.get(e);
            a.call(b, f, e, this)
        }
    };
    r.keys = function() {
        return Ks(this.hd(!0)).j()
    };
    r.values = function() {
        return Ks(this.hd(!1)).j()
    };
    r.entries = function() {
        var a = this;
        return Hs(this.keys(), function(b) {
            return [b, a.get(b)]
        })
    };
    r.hd = function(a) {
        Qs(this);
        var b = 0,
            c = this.l,
            d = this,
            e = new Is;
        e.next = function() {
            if (c != d.l) throw Error("The map has changed since the iterator was created");
            if (b >= d.g.length) return Js;
            var f = d.g[b++];
            return {
                value: a ? f : d.j[f],
                done: !1
            }
        };
        return e
    };

    function Rs(a, b) {
        return Object.prototype.hasOwnProperty.call(a, b)
    };

    function Ts(a) {
        return a.g != a.l.l && a.g.parentNode ? Us(a.l, a.g.parentNode) : null
    }

    function Vs(a, b) {
        if (a.g.nodeType != 1) return null;
        a.j = a.j || a.ua().getComputedStyle(a.g);
        return a.j ? a.j[b] || a.j.getPropertyValue(b) || "" : ""
    }

    function Ws(a) {
        return a.g.nodeType != 1 || (a = parseInt(Vs(a, "z-index"), 10), isNaN(a)) ? 0 : a
    }
    var Xs = class {
        constructor(a, b) {
            this.g = a;
            this.l = b;
            this.j = null;
            new Os
        }
        ua() {
            if (!this.g.ownerDocument) throw Error("Wrapped node should have an owner document.");
            var a = this.g.ownerDocument;
            return a.defaultView || a.parentWindow
        }
        toString() {
            switch (this.g.nodeType) {
                case 1:
                    let a = this.g,
                        b = a.tagName;
                    a.id && (b += "#" + a.id);
                    a.className && typeof a.className.split === "function" && (b += "." + a.className.split(/\s+/).join("."));
                    return b;
                case 3:
                    return "TEXT#" + this.g.textContent.substr(0, 10);
                default:
                    return "HtmlNode"
            }
        }
    };

    function Us(a, b) {
        var c = sa(b),
            d = a.g.get(c);
        if (d) return d;
        if (Ys(a, b)) return null;
        b = new Xs(b, a);
        a.g.set(c, b);
        return b
    }

    function Ys(a, b) {
        var c = sa(b),
            d = a.j.get(c);
        if (typeof d === "boolean") return d;
        d = b.nodeType == 3 ? !/\S/.test(b.data) : b.nodeType != 1 && b.nodeType != 3 && b.nodeType != 9 || b.tagName && (b.tagName == "SCRIPT" || b.tagName == "STYLE") ? !0 : !1;
        !d && b.parentNode && b != a.l && (d = Ys(a, b.parentNode));
        a.j.set(c, d);
        return d
    }
    var Zs = class {
        constructor() {
            this.l = document.body;
            this.j = new Es;
            this.g = new Es
        }
    };
    const $s = new Fs("IMG AMP-IMG IFRAME AMP-IFRAME HR EMBED OBJECT VIDEO AMP-VIDEO INPUT BUTTON SVG".split(" "));

    function at(a) {
        var b = Ts(a.g);
        return b ? bt(a.j, b) : null
    }
    var ct = class {
            constructor(a, b) {
                this.g = a;
                this.j = b
            }
        },
        tt = class {
            constructor() {
                this.g = new rt
            }
            compare(a, b) {
                var c = bt(this.g, a),
                    d = bt(this.g, b);
                c = st(c, d);
                if (!c) return 0;
                switch (c.sg) {
                    case 0:
                        return Ws(a) - Ws(c.Uf.g);
                    case 1:
                        return Ws(c.Tf.g) - Ws(b);
                    case 2:
                        return Ws(c.Tf.g) - Ws(c.Uf.g);
                    default:
                        throw Error("Unhandled adjacency.");
                }
            }
        };

    function bt(a, b) {
        var c = sa(b),
            d = a.g.get(c);
        if (d) return d;
        d = Ts(b);
        var e;
        if (!(e = !d))
            if (b.g.nodeType == 1) {
                e = b.g;
                var f = Vs(b, "position");
                e.tagName == "HTML" || f == "fixed" || Vs(b, "z-index") != "auto" && (f == "absolute" || f == "relative") ? e = !0 : (e = Vs(b, "opacity"), e = e != "1" && e != "" ? !0 : !1)
            } else e = !1;
        b = e ? new ct(b, a) : bt(a, d);
        a.g.set(c, b);
        return b
    }
    var rt = class {
        constructor() {
            this.g = new Es
        }
    };

    function st(a, b) {
        if (a == b) return null;
        for (var c = new Es, d = b, e; e = at(d);) {
            if (a == e) return {
                Tf: a,
                sg: 0,
                Uf: d
            };
            c.set(sa(e), d);
            d = e
        }
        for (; e = at(a);) {
            if (e == b) return {
                Tf: a,
                sg: 1,
                Uf: b
            };
            if (d = c.get(sa(e))) return {
                Tf: a,
                sg: 2,
                Uf: d
            };
            a = e
        }
        throw Error("Contexts not in same DOM.");
    };

    function ut(a) {
        rb(a.document.body.offsetHeight)
    };

    function vt(a) {
        a && typeof a.dispose == "function" && a.dispose()
    };

    function O() {
        this.B = this.B;
        this.O = this.O
    }
    O.prototype.B = !1;
    O.prototype.dispose = function() {
        this.B || (this.B = !0, this.g())
    };
    O.prototype[ja(Symbol, "dispose")] = function() {
        this.dispose()
    };

    function wt(a, b) {
        xt(a, Aa(vt, b))
    }

    function xt(a, b) {
        a.B ? b() : (a.O || (a.O = []), a.O.push(b))
    }
    O.prototype.g = function() {
        if (this.O)
            for (; this.O.length;) this.O.shift()()
    };

    function yt(a) {
        a.j.forEach((b, c) => {
            if (b.overrides.delete(a)) {
                b = Array.from(b.overrides.values()).pop() || b.originalValue;
                var d = a.element;
                b ? d.style.setProperty(c, b.value, b.priority) : d.style.removeProperty(c)
            }
        })
    }

    function zt(a, b, c) {
        c = {
            value: c,
            priority: "important"
        };
        var d = a.j.get(b);
        if (!d) {
            d = a.element;
            var e = d.style.getPropertyValue(b);
            d = {
                originalValue: e ? {
                    value: e,
                    priority: d.style.getPropertyPriority(b)
                } : null,
                overrides: new Map
            };
            a.j.set(b, d)
        }
        d.overrides.delete(a);
        d.overrides.set(a, c);
        a = a.element;
        c ? a.style.setProperty(b, c.value, c.priority) : a.style.removeProperty(b)
    }
    var At = class extends O {
        constructor(a, b) {
            super();
            this.element = b;
            a = a.googTempStyleOverrideInfo = a.googTempStyleOverrideInfo || new Map;
            var c = a.get(b);
            c ? b = c : (c = new Map, a.set(b, c), b = c);
            this.j = b
        }
        g() {
            yt(this);
            super.g()
        }
    };

    function Bt(a) {
        var b = new Ct(a.getValue());
        a.listen(c => b.g(c));
        return b
    }

    function Dt(a, b) {
        var c = new Ct({
            first: a.V,
            second: b.V
        });
        a.listen(() => c.g({
            first: a.V,
            second: b.V
        }));
        b.listen(() => c.g({
            first: a.V,
            second: b.V
        }));
        return c
    }

    function Et(a, b) {
        var c = 0,
            d = 0,
            e = new Ct({
                first: a.V,
                second: b.V
            }),
            f = () => setTimeout(() => {
                d < c && (d = c, e.g({
                    first: a.V,
                    second: b.V
                }))
            }, 0),
            g = () => {
                c++;
                f()
            };
        a.listen(g);
        b.listen(g);
        return e
    }

    function Ft(...a) {
        var b = [...a],
            c = () => b.every(f => f.V),
            d = new Ct(c()),
            e = () => {
                d.g(c())
            };
        b.forEach(f => f.listen(e));
        return Gt(d)
    }

    function Ht(...a) {
        var b = [...a],
            c = () => b.findIndex(f => f.V) !== -1,
            d = new Ct(c()),
            e = () => {
                d.g(c())
            };
        b.forEach(f => f.listen(e));
        return Gt(d)
    }

    function Gt(a, b = It) {
        var c = a.V,
            d = new Ct(a.V);
        a.listen(e => {
            b(e, c) || (c = e, d.g(e))
        });
        return d
    }

    function Jt(a, b, c) {
        return a.j(d => {
            d === b && c()
        })
    }

    function Kt(a, b, c) {
        if (a.V === b) return c(), () => {};
        var d = {
            Yd: null
        };
        d.Yd = Jt(a, b, () => {
            d.Yd && (d.Yd(), d.Yd = null);
            c()
        });
        return d.Yd
    }

    function Lt(a, b, c) {
        Gt(a).listen(d => {
            d === b && c()
        })
    }

    function Mt(a, b) {
        a.B && a.B();
        a.B = b.listen(c => a.g(c), !0)
    }

    function Nt(a) {
        return {
            listen: b => a.listen(b),
            getValue: () => a.V
        }
    }
    var Ct = class {
        constructor(a) {
            this.V = a;
            this.l = new Map;
            this.C = 1;
            this.B = null
        }
        listen(a, b = !1) {
            var c = this.C++;
            this.l.set(c, a);
            b && a(this.V);
            return () => {
                this.l.delete(c)
            }
        }
        j(a) {
            return this.listen(a, !0)
        }
        A() {
            return this.V
        }
        g(a) {
            this.V = a;
            this.l.forEach(b => {
                b(this.V)
            })
        }
        map(a) {
            var b = new Ct(a(this.V));
            this.listen(c => b.g(a(c)));
            return b
        }
    };

    function It(a, b) {
        return a == b
    };

    function Ot(a) {
        return new Pt(a)
    }

    function Qt(a, b) {
        ab(a.g, c => {
            c(b)
        })
    }
    var Rt = class {
        constructor() {
            this.g = []
        }
    };
    class Pt {
        constructor(a) {
            this.g = a
        }
        listen(a) {
            this.g.g.push(a)
        }
        map(a) {
            var b = new Rt;
            this.listen(c => Qt(b, a(c)));
            return Ot(b)
        }
        delay(a, b) {
            var c = new Rt;
            this.listen(d => {
                a.setTimeout(() => {
                    Qt(c, d)
                }, b)
            });
            return Ot(c)
        }
    }

    function St(...a) {
        var b = new Rt;
        a.forEach(c => {
            c.listen(d => {
                Qt(b, d)
            })
        });
        return Ot(b)
    };

    function Tt(a) {
        return Gt(Dt(a.g, a.l).map(b => {
            var c = b.first;
            b = b.second;
            return c == null || b == null ? null : Ut(c, b)
        }))
    }
    var Wt = class {
        constructor(a) {
            this.j = a;
            this.g = new Ct(null);
            this.l = new Ct(null);
            this.B = new Rt;
            this.D = b => {
                this.g.V == null && b.touches.length == 1 && this.g.g(b.touches[0])
            };
            this.A = b => {
                var c = this.g.V;
                c != null && (b = Vt(c, b.changedTouches), b != null && (this.g.g(null), this.l.g(null), Qt(this.B, Ut(c, b))))
            };
            this.C = b => {
                var c = this.g.V;
                c != null && (c = Vt(c, b.changedTouches), c != null && (this.l.g(c), b.preventDefault()))
            }
        }
    };

    function Ut(a, b) {
        return {
            Ck: b.pageX - a.pageX,
            Dk: b.pageY - a.pageY
        }
    }

    function Vt(a, b) {
        if (b == null) return null;
        for (let c = 0; c < b.length; ++c)
            if (b[c].identifier == a.identifier) return b[c];
        return null
    };

    function Xt(a) {
        return Gt(Dt(a.g, a.j).map(b => {
            var c = b.first;
            b = b.second;
            return c == null || b == null ? null : Yt(c, b)
        }))
    }
    var Zt = class {
        constructor(a, b) {
            this.B = a;
            this.A = b;
            this.g = new Ct(null);
            this.j = new Ct(null);
            this.l = new Rt;
            this.O = c => {
                this.g.g(c)
            };
            this.C = c => {
                var d = this.g.V;
                d != null && (this.g.g(null), this.j.g(null), Qt(this.l, Yt(d, c)))
            };
            this.D = c => {
                this.g.V != null && (this.j.g(c), c.preventDefault())
            }
        }
    };

    function Yt(a, b) {
        return {
            Ck: b.screenX - a.screenX,
            Dk: b.screenY - a.screenY
        }
    };
    var bu = (a, b, c) => {
        var d = new $t(a, b, c);
        return () => au(d)
    };

    function au(a) {
        if (a.g) return !1;
        if (a.j == null) return cu(a), !0;
        var b = a.j + a.A - (new Date).getTime();
        if (b < 1) return cu(a), !0;
        du(a, b);
        return !0
    }

    function cu(a) {
        a.j = (new Date).getTime();
        a.B()
    }

    function du(a, b) {
        a.g = !0;
        a.l.setTimeout(() => {
            a.g = !1;
            cu(a)
        }, b)
    }
    class $t {
        constructor(a, b, c) {
            this.l = a;
            this.A = b;
            this.B = c;
            this.j = null;
            this.g = !1
        }
    };

    function eu(a) {
        return fu(Xt(a.g), Tt(a.j))
    }

    function gu(a) {
        return St(Ot(a.g.l), Ot(a.j.B))
    }
    var hu = class {
        constructor(a, b) {
            this.g = a;
            this.j = b
        }
    };

    function fu(a, b) {
        return Dt(a, b).map(({
            first: c,
            second: d
        }) => c || d || null)
    };

    function iu(a) {
        a.C == null && (a.C = new Ct(a.J(a.l, a.D)));
        return a.C
    }
    var ju = class extends O {
        constructor(a, b, c) {
            super();
            this.l = a;
            this.D = b;
            this.J = c ? ? ((d, e) => e.getBoundingClientRect());
            this.G = !1;
            this.C = null;
            this.A = bu(a, 200, () => {
                iu(this).g(this.J(this.l, this.D))
            })
        }
        j() {
            this.G || (this.G = !0, this.l.addEventListener("resize", this.A), this.l.addEventListener("scroll", this.A));
            return iu(this)
        }
        g() {
            this.l.removeEventListener("resize", this.A);
            this.l.removeEventListener("scroll", this.A);
            super.g()
        }
    };

    function ku(a, b) {
        return new lu(a, b)
    }

    function mu(a) {
        a.win.requestAnimationFrame(() => {
            a.B || a.l.g(new wi(a.element.offsetWidth, a.element.offsetHeight))
        })
    }

    function nu(a) {
        a.j || (a.j = !0, a.A.observe(a.element));
        return Gt(a.l, xi)
    }
    var lu = class extends O {
        constructor(a, b) {
            super();
            this.win = a;
            this.element = b;
            this.j = !1;
            this.l = new Ct(new wi(this.element.offsetWidth, this.element.offsetHeight));
            this.A = new ResizeObserver(() => {
                mu(this)
            })
        }
        g() {
            this.A.disconnect();
            super.g()
        }
    };

    function ou(a, b) {
        return {
            top: a.g - b,
            right: a.l + a.j,
            bottom: a.g + b,
            left: a.l
        }
    }
    var pu = class {
        constructor(a, b, c) {
            this.l = a;
            this.g = b;
            this.j = c
        }
    };

    function qu(a, b) {
        a = a.getBoundingClientRect();
        return new ru(a.top + ts(b), a.bottom - a.top)
    }

    function su(a) {
        return new ru(Math.round(a.g), Math.round(a.j))
    }
    var ru = class {
        constructor(a, b) {
            this.g = a;
            this.j = b
        }
        getHeight() {
            return this.j
        }
    };
    var uu = (a, b) => {
        var c = a.google_pso_loaded_fonts || (a.google_pso_loaded_fonts = []),
            d = new Fs(c);
        b = b.filter(e => !d.contains(e));
        b.length && (tu(a, b), nb(c, b))
    };

    function tu(a, b) {
        for (let d of b) {
            let e = $k("LINK", a.document);
            e.type = "text/css";
            b = e;
            var c = fi `//fonts.googleapis.com/css?family=${d}`;
            b.href = Th(c).toString();
            b.rel = "stylesheet";
            (a.document.head ? ? a.document.body).append(e)
        }
    };

    function vu(a, b) {
        a.G ? b(a.A) : a.l.push(b)
    }

    function wu(a, b) {
        a.G = !0;
        a.A = b;
        a.l.forEach(c => {
            c(a.A)
        });
        a.l = []
    }
    var xu = class extends O {
        constructor(a) {
            super();
            this.j = a;
            this.l = [];
            this.G = !1;
            this.D = this.A = null;
            this.J = bu(a, 1E3, () => {
                if (this.D != null) {
                    var b = os(this.j, !0) - this.D;
                    b > 1E3 && wu(this, b)
                }
            });
            this.C = null
        }
        init(a, b) {
            a == null ? (this.D = a = os(this.j, !0), this.j.addEventListener("scroll", this.J), b != null && b(a)) : this.C = this.j.setTimeout(() => {
                this.init(void 0, b)
            }, a)
        }
        g() {
            this.C != null && this.j.clearTimeout(this.C);
            this.j.removeEventListener("scroll", this.J);
            this.l = [];
            this.A = null;
            super.g()
        }
    };
    var yu = (a, b) => a.reduce((c, d) => c.concat(b(d)), []);
    var zu = class {
        constructor(a = 1) {
            this.g = a
        }
        next() {
            var a = 48271 * this.g % 2147483647;
            this.g = a * 2147483647 < 0 ? a + 2147483647 : a;
            return this.g / 2147483647
        }
    };

    function Au(a, b, c) {
        var d = [];
        for (let e of a.g) b(e) ? d.push(e) : c(e);
        return new Bu(d)
    }

    function Cu(a) {
        return a.g.slice(0)
    }

    function Du(a, b = 1) {
        a = Cu(a);
        var c = new zu(b);
        qb(a, () => c.next());
        return new Bu(a)
    }
    var Bu = class {
        constructor(a) {
            this.g = a.slice(0)
        }
        forEach(a) {
            this.g.forEach((b, c) => void a(b, c, this))
        }
        filter(a) {
            return new Bu(cb(this.g, a))
        }
        apply(a) {
            return new Bu(a(Cu(this)))
        }
        sort(a) {
            return new Bu(Cu(this).sort(a))
        }
        get(a) {
            return this.g[a]
        }
        add(a) {
            var b = Cu(this);
            b.push(a);
            return new Bu(b)
        }
    };
    var Eu = class {
        constructor(a) {
            this.g = new Fs(a)
        }
        contains(a) {
            return this.g.contains(a)
        }
    };

    function Fu(a) {
        return new Gu({
            value: a
        }, null)
    }

    function Hu(a) {
        return new Gu(null, a)
    }

    function Iu(a) {
        try {
            return Fu(a())
        } catch (b) {
            return Hu(b)
        }
    }

    function Ju(a) {
        return a.j != null
    }

    function Ku(a) {
        return Ju(a) ? a.getValue() : null
    }

    function Lu(a, b) {
        Ju(a) && b(a.getValue());
        return a
    }

    function Mu(a, b) {
        return Ju(a) ? a : Hu(b(a.g))
    }

    function Nu(a, b) {
        return Mu(a, c => Error(`${b}${c.message}`))
    }

    function Ou(a, b) {
        Ju(a) || b(a.g);
        return a
    }
    var Gu = class {
        constructor(a, b) {
            this.j = a;
            this.g = b
        }
        getValue() {
            return this.j.value
        }
        map(a) {
            return Ju(this) ? (a = a(this.getValue()), a instanceof Gu ? a : Fu(a)) : this
        }
    };
    var Pu = class {
        constructor() {
            this.g = new Es
        }
        set(a, b) {
            var c = this.g.get(a);
            c || (c = new Fs, this.g.set(a, c));
            c.add(b)
        }
    };

    function Qu(a) {
        return !a
    }

    function Ru(a) {
        return b => {
            for (let c of a) c(b)
        }
    };
    var Su = class extends I {
        getId() {
            return qf(this, 3)
        }
    };
    var Tu = class {
        constructor(a, {
            Ri: b,
            Pk: c,
            xm: d,
            jk: e
        }) {
            this.A = a;
            this.l = c;
            this.B = new Bu(b || []);
            this.j = e;
            this.g = d
        }
    };

    function Uu(a) {
        var b = a.length;
        if (b === 0) return 0;
        var c = 305419896;
        for (let d = 0; d < b; d++) c ^= (c << 5) + (c >> 2) + a.charCodeAt(d) & 4294967295;
        return c > 0 ? c : 4294967296 + c
    };
    var Vu = a => {
            var b = a.split("~").filter(c => c.length > 0);
            a = new Es;
            for (let c of b) b = c.indexOf("."), b == -1 ? a.set(c, "") : a.set(c.substring(0, b), c.substring(b + 1));
            return a
        },
        Xu = a => {
            var b = Wu(a);
            a = [];
            for (let c of b) b = String(c.be), a.push(c.dd + "." + (b.length <= 20 ? b : b.slice(0, 19) + "_"));
            return a.join("~")
        };
    const Wu = a => {
            var b = [],
                c = a.B;
            c && c.g.length && b.push({
                dd: "a",
                be: Yu(c)
            });
            a.l != null && b.push({
                dd: "as",
                be: a.l
            });
            a.g != null && b.push({
                dd: "i",
                be: String(a.g)
            });
            a.j != null && b.push({
                dd: "rp",
                be: String(a.j)
            });
            b.sort(function(d, e) {
                return d.dd.localeCompare(e.dd)
            });
            b.unshift({
                dd: "t",
                be: Zu(a.A)
            });
            return b
        },
        Zu = a => {
            switch (a) {
                case 0:
                    return "aa";
                case 1:
                    return "ma";
                default:
                    throw Error("Invalid slot type" + a);
            }
        },
        Yu = a => {
            a = Cu(a).map($u);
            a = JSON.stringify(a);
            return Uu(a)
        },
        $u = a => {
            var b = {};
            Nf(a, 7) && (b.q = qf(a, 7));
            ff(a, 2) != null && (b.o =
                ff(a, 2, te));
            ff(a, 5) != null && (b.p = ff(a, 5, te));
            return b
        };

    function av() {
        var a = new bv;
        return Lf(a, 2, 1)
    }
    var bv = class extends I {
        setLocation(a) {
            return Lf(this, 1, a)
        }
        g() {
            return fd(ue(this, 1))
        }
    };

    function cv(a) {
        var b = [].slice.call(arguments).filter(ni(e => e === null));
        if (!b.length) return null;
        var c = [],
            d = {};
        b.forEach(e => {
            c = c.concat(e.bj || []);
            d = Object.assign(d, e.oe())
        });
        return new dv(c, d)
    }

    function ev(a) {
        switch (a) {
            case 1:
                return new dv(null, {
                    google_ad_semantic_area: "mc"
                });
            case 2:
                return new dv(null, {
                    google_ad_semantic_area: "h"
                });
            case 3:
                return new dv(null, {
                    google_ad_semantic_area: "f"
                });
            case 4:
                return new dv(null, {
                    google_ad_semantic_area: "s"
                });
            default:
                return null
        }
    }

    function fv(a) {
        return a == null ? null : new dv(null, {
            google_ml_rank: a
        })
    }

    function gv(a) {
        return a == null ? null : new dv(null, {
            google_placement_id: Xu(a)
        })
    }

    function hv({
        Hl: a,
        Yl: b = null
    }) {
        if (a == null) return null;
        a = {
            google_daaos_ts: a
        };
        b != null && (a.google_erank = b + 1);
        return new dv(null, a)
    }
    var dv = class {
        constructor(a, b) {
            this.bj = a;
            this.g = b
        }
        oe() {
            return this.g
        }
    };
    var P = class {
            constructor(a, b = !1) {
                this.g = a;
                this.defaultValue = b
            }
        },
        Q = class {
            constructor(a, b = 0) {
                this.g = a;
                this.defaultValue = b
            }
        },
        iv = class {
            constructor(a, b = "") {
                this.g = a;
                this.defaultValue = b
            }
        },
        jv = class {
            constructor(a, b = []) {
                this.g = a;
                this.defaultValue = b
            }
        };
    var kv = new Q(619278254, 10),
        lv = new Q(45696523),
        mv = new Q(1386),
        nv = new jv(1385),
        ov = new P(1397),
        pv = new Q(1359),
        qv = new Q(1358),
        rv = new P(1360),
        sv = new Q(1357),
        tv = new P(1345),
        uv = new P(799525383),
        vv = new jv(1387),
        wv = new P(687716473),
        xv = new P(854186941),
        yv = new P(906386022),
        zv = new P(854181049),
        Av = new P(1377),
        Bv = new P(45693370),
        Cv = new P(682658313, !0),
        Dv = new P(1392),
        Ev = new P(910193038),
        Fv = new P(745713445),
        Gv = new Q(1130, 100),
        Hv = new Q(1340, .2),
        Iv = new Q(1338, .3),
        Jv = new Q(1339, .3),
        Kv = new P(1337),
        Lv = new Q(1032, 200),
        Mv = new P(736254284),
        Nv = new iv(14),
        Ov = new Q(1224, .01),
        Pv = new Q(1346, 6),
        Qv = new Q(1347, 3),
        Rv = new P(1342, !0),
        Sv = new P(1344),
        Tv = new Q(846334470, 1E3),
        Uv = new P(828527831),
        Vv = new P(1260),
        Wv = new P(1393, !0),
        Xv = new Q(1394, 120),
        Yv = new Q(1396, 1E3),
        Zv = new Q(1395, 500),
        $v = new P(316),
        aw = new P(1290),
        bw = new P(1389),
        cw = new P(1390),
        dw = new P(334),
        ew = new P(1383),
        fw = new Q(1263, -1),
        gw = new Q(1388),
        hw = new Q(54),
        iw = new Q(1323, -1),
        jw = new Q(1265, -1),
        kw = new Q(1264, -1),
        lw = new P(1291),
        mw = new P(1267, !0),
        nw = new P(1266),
        ow = new P(313),
        pw = new Q(66, -1),
        qw = new Q(65, -1),
        rw = new P(1256),
        sw = new P(369),
        tw = new P(1241, !0),
        uw = new P(368),
        vw = new P(1402),
        ww = new P(1300, !0),
        xw = new jv(1273, ["en", "de", "fr", "es", "ja"]),
        yw = new jv(1261, ["44786015", "44786016"]),
        zw = new P(812820063, !0),
        Aw = new P(1361),
        Bw = new P(290),
        Cw = new Q(770241922, 1E3),
        Dw = new P(1354),
        Ew = new P(45719801),
        Fw = new P(789511913, !0),
        Gw = new P(823552246),
        Hw = new P(1350),
        Iw = new P(1356),
        Jw = new Q(812862057, 1E3),
        Kw = new Q(835164910),
        Lw = new Q(822918959),
        Mw = new P(566279275),
        Nw = new P(622128248),
        Ow = new P(566279276),
        Pw = new P(903704925),
        Qw = new P(882071067, !0),
        Rw = new P(882516810, !0),
        Sw = new P(882001608, !0),
        Tw = new P(837564849),
        Uw = new P(842638817, !0),
        Vw = new P(882071066, !0),
        Ww = new P(884402455, !0),
        Xw = new P(882516809, !0),
        Yw = new P(858671852),
        Zw = new P(882001607, !0),
        $w = new P(861100860),
        ax = new P(898846159),
        bx = new P(829415421, !0),
        cx = new P(767123927, !0),
        dx = new Q(799568408, 10),
        ex = new jv(712458671, " ar bn en es fr hi id ja ko mr pt ru sr te th tr uk vi zh".split(" ")),
        fx = new Q(872325350),
        gx = new Q(855152761, .6),
        hx = new class {
            constructor(a,
                b = []) {
                this.g = a;
                this.defaultValue = b
            }
        }(683929765),
        ix = new iv(872996096, "calc(<SW> / 1.2)"),
        jx = new Q(868282444, 1200),
        kx = new iv(834418652, "calc(max(<DH> - 150px, 50px))"),
        lx = new P(886202086),
        mx = new iv(874614210),
        nx = new iv(834418651, "calc(max(<DH> - 150px, 50px))"),
        ox = new P(886669062),
        px = new P(839747468, !0),
        qx = new P(506914611),
        rx = new P(901281191),
        sx = new P(899601681, !0),
        tx = new Q(775999093, 1),
        ux = new P(824550200, !0),
        vx = new Q(9604),
        wx = new Q(717888910),
        xx = new Q(618163195, 8E3),
        yx = new Q(624950166, 3E3),
        zx = new Q(623405755,
            300),
        Ax = new Q(508040914, 622),
        Bx = new Q(547455356, 49),
        Cx = new Q(9605),
        Dx = new Q(717888911),
        Ex = new Q(9606),
        Fx = new Q(717888912),
        Gx = new Q(9603, 4),
        Hx = new Q(650548030, 3),
        Ix = new Q(650548032, 300),
        Jx = new Q(650548031, 1),
        Kx = new Q(469675170, 68040),
        Lx = new Q(836239785, .6),
        Mx = new P(45721294),
        Nx = new P(676460084),
        Ox = new Q(824002820),
        Px = new P(732272249),
        Qx = new P(803207304),
        Rx = new P(827615816),
        Sx = new jv(754933824),
        Tx = new iv(754933823, "1-0-45"),
        Ux = new P(834350237),
        Vx = new Q(63, 30),
        Wx = new Q(550718588, 250),
        Xx = new Q(624290870,
            50),
        Yx = new Q(815871887, .8),
        Zx = new P(77),
        $x = new P(78),
        ay = new P(83),
        by = new P(80),
        cy = new P(76),
        dy = new P(84),
        ey = new P(188);

    function fy(a) {
        return D(a, 1)
    }
    var gy = class extends I {
        Bb() {
            return y(this, Eh, 10)
        }
        setContent(a) {
            return z(this, 10, a)
        }
    };

    function hy(a) {
        return Ve(a, gy, 15, De())
    }
    var iy = class extends I {
            g() {
                return lf(this, 24)
            }
        },
        jy = qh(iy);
    var ky = class extends I {},
        ly = qh(ky);
    var my = {},
        ny = {},
        oy = {},
        py = {},
        qy = {};

    function ry() {
        throw Error("Do not instantiate directly");
    }
    ry.prototype.dj = null;
    ry.prototype.Bb = function() {
        return this.content
    };
    ry.prototype.toString = function() {
        return this.content
    };
    ry.prototype.Fb = function() {
        if (this.ej !== my) throw Error("Sanitized content was not of kind HTML.");
        return Mh(this.toString())
    };

    function sy() {
        ry.call(this)
    }
    Fa(sy, ry);
    sy.prototype.ej = my;

    function ty(a) {
        if (a != null) switch (a.dj) {
            case 1:
                return 1;
            case -1:
                return -1;
            case 0:
                return 0
        }
        return null
    }

    function uy(a) {
        return vy(a, my) ? a : a instanceof Lh ? wy(Nh(a).toString()) : wy(String(String(a)).replace(xy, yy), ty(a))
    }
    var wy = function(a) {
        function b(c) {
            this.content = c
        }
        b.prototype = a.prototype;
        return function(c, d) {
            c = new b(String(c));
            d !== void 0 && (c.dj = d);
            return c
        }
    }(sy);

    function zy(a) {
        return uy(a)
    }

    function Ay(a) {
        return By(String(a), () => "").replace(Cy, "&lt;")
    }
    const Dy = RegExp.prototype.hasOwnProperty("sticky"),
        Ey = new RegExp((Dy ? "" : "^") + "(?:!|/?([a-zA-Z][a-zA-Z0-9:-]*))", Dy ? "gy" : "g");

    function By(a, b) {
        for (var c = [], d = a.length, e = 0, f = [], g, h, k = 0; k < d;) {
            switch (e) {
                case 0:
                    var l = a.indexOf("<", k);
                    if (l < 0) {
                        if (c.length === 0) return a;
                        c.push(a.substring(k));
                        k = d
                    } else c.push(a.substring(k, l)), h = l, k = l + 1, Dy ? (Ey.lastIndex = k, l = Ey.exec(a)) : (Ey.lastIndex = 0, l = Ey.exec(a.substring(k))), l ? (f = ["<", l[0]], g = l[1], e = 1, k += l[0].length) : c.push("<");
                    break;
                case 1:
                    l = a.charAt(k++);
                    switch (l) {
                        case "'":
                        case '"':
                            let m = a.indexOf(l, k);
                            m < 0 ? k = d : (f.push(l, a.substring(k, m + 1)), k = m + 1);
                            break;
                        case ">":
                            f.push(l);
                            c.push(b(f.join(""),
                                g));
                            e = 0;
                            f = [];
                            h = g = null;
                            break;
                        default:
                            f.push(l)
                    }
                    break;
                default:
                    throw Error();
            }
            e === 1 && k >= d && (k = h + 1, c.push("<"), e = 0, f = [], h = g = null)
        }
        return c.join("")
    }

    function Fy(a, b) {
        a = a.replace(/<\//g, "<\\/").replace(/\]\]>/g, "]]\\>");
        return b ? a.replace(/{/g, " \\{").replace(/}/g, " \\}").replace(/\/\*/g, "/ *").replace(/\\$/, "\\ ") : a
    }

    function R(a) {
        vy(a, my) ? (a = Ay(a.Bb()), a = String(a).replace(Gy, yy)) : a = String(a).replace(xy, yy);
        return a
    }

    function Hy(a) {
        a = String(a);
        for (var b = (d, e, f) => {
                var g = Math.min(e.length - f, d.length);
                for (let k = 0; k < g; k++) {
                    var h = e[f + k];
                    if (d[k] !== ("A" <= h && h <= "Z" ? h.toLowerCase() : h)) return !1
                }
                return !0
            }, c = 0;
            (c = a.indexOf("<", c)) != -1;) {
            if (b("\x3c/script", a, c) || b("\x3c!--", a, c)) return "zSoyz";
            c += 1
        }
        return a
    }

    function Iy(a) {
        if (a == null) return " null ";
        if (vy(a, ny)) return a.Bb();
        switch (typeof a) {
            case "boolean":
            case "number":
                return " " + a + " ";
            default:
                return "'" + String(String(a)).replace(Jy, Ky) + "'"
        }
    }
    const Ly = /['()]/g;

    function My(a) {
        return "%" + a.charCodeAt(0).toString(16)
    }

    function Ny(a) {
        a = encodeURIComponent(String(a));
        Ly.lastIndex = 0;
        return Ly.test(a) ? a.replace(Ly, My) : a
    }

    function Oy(a) {
        vy(a, oy) || vy(a, py) ? a = String(a).replace(Py, Qy) : a instanceof Rh ? (a = Th(a).toString(), a = String(a).replace(Py, Qy)) : (a = String(a), a = Ry.test(a) ? a.replace(Py, Qy) : "about:invalid#zSoyz");
        return a
    }

    function T(a) {
        return vy(a, qy) ? Fy(a.Bb(), !1) : a == null ? "" : a instanceof Oh ? Fy(Ph(a), !1) : Fy(String(a), !0)
    }

    function vy(a, b) {
        return a != null && a.ej === b
    }

    function Sy(a, b) {
        a.g !== void 0 ? a.g.push(b) : a.content += b;
        return a
    }

    function Ty(a, b) {
        a.g !== void 0 ? a.g.push(b) : b instanceof Uy ? b.content !== void 0 ? a.content += b.Bb() : (a.g = [a.content, b], a.content = void 0) : a.content += b;
        return a
    }
    class Uy extends sy {
        Bb() {
            if (this.content !== void 0) return this.content;
            var a = "";
            for (let b of this.g) a += b;
            return a
        }
        toString() {
            return this.Bb()
        }
    }
    const Vy = (() => {
            function a() {
                this.content = ""
            }
            a.prototype = Uy.prototype;
            return function() {
                return new a
            }
        })(),
        Wy = {
            "\x00": "&#0;",
            "\t": "&#9;",
            "\n": "&#10;",
            "\v": "&#11;",
            "\f": "&#12;",
            "\r": "&#13;",
            " ": "&#32;",
            '"': "&quot;",
            "&": "&amp;",
            "'": "&#39;",
            "-": "&#45;",
            "/": "&#47;",
            "<": "&lt;",
            "=": "&#61;",
            ">": "&gt;",
            "`": "&#96;",
            "\u0085": "&#133;",
            "\u00a0": "&#160;",
            "\u2028": "&#8232;",
            "\u2029": "&#8233;"
        };

    function yy(a) {
        return Wy[a]
    }
    const Xy = {
        "\x00": "\\x00",
        "\b": "\\x08",
        "\t": "\\t",
        "\n": "\\n",
        "\v": "\\x0b",
        "\f": "\\f",
        "\r": "\\r",
        '"': "\\x22",
        $: "\\x24",
        "&": "\\x26",
        "'": "\\x27",
        "(": "\\x28",
        ")": "\\x29",
        "*": "\\x2a",
        "+": "\\x2b",
        ",": "\\x2c",
        "-": "\\x2d",
        ".": "\\x2e",
        "/": "\\/",
        ":": "\\x3a",
        "<": "\\x3c",
        "=": "\\x3d",
        ">": "\\x3e",
        "?": "\\x3f",
        "[": "\\x5b",
        "\\": "\\\\",
        "]": "\\x5d",
        "^": "\\x5e",
        "{": "\\x7b",
        "|": "\\x7c",
        "}": "\\x7d",
        "\u0085": "\\x85",
        "\u2028": "\\u2028",
        "\u2029": "\\u2029"
    };

    function Ky(a) {
        return Xy[a]
    }
    const Yy = {
        "\x00": "%00",
        "\u0001": "%01",
        "\u0002": "%02",
        "\u0003": "%03",
        "\u0004": "%04",
        "\u0005": "%05",
        "\u0006": "%06",
        "\u0007": "%07",
        "\b": "%08",
        "\t": "%09",
        "\n": "%0A",
        "\v": "%0B",
        "\f": "%0C",
        "\r": "%0D",
        "\u000e": "%0E",
        "\u000f": "%0F",
        "\u0010": "%10",
        "\u0011": "%11",
        "\u0012": "%12",
        "\u0013": "%13",
        "\u0014": "%14",
        "\u0015": "%15",
        "\u0016": "%16",
        "\u0017": "%17",
        "\u0018": "%18",
        "\u0019": "%19",
        "\u001a": "%1A",
        "\u001b": "%1B",
        "\u001c": "%1C",
        "\u001d": "%1D",
        "\u001e": "%1E",
        "\u001f": "%1F",
        " ": "%20",
        '"': "%22",
        "'": "%27",
        "(": "%28",
        ")": "%29",
        "<": "%3C",
        ">": "%3E",
        "\\": "%5C",
        "{": "%7B",
        "}": "%7D",
        "\u007f": "%7F",
        "\u0085": "%C2%85",
        "\u00a0": "%C2%A0",
        "\u2028": "%E2%80%A8",
        "\u2029": "%E2%80%A9",
        "\uff01": "%EF%BC%81",
        "\uff03": "%EF%BC%83",
        "\uff04": "%EF%BC%84",
        "\uff06": "%EF%BC%86",
        "\uff07": "%EF%BC%87",
        "\uff08": "%EF%BC%88",
        "\uff09": "%EF%BC%89",
        "\uff0a": "%EF%BC%8A",
        "\uff0b": "%EF%BC%8B",
        "\uff0c": "%EF%BC%8C",
        "\uff0f": "%EF%BC%8F",
        "\uff1a": "%EF%BC%9A",
        "\uff1b": "%EF%BC%9B",
        "\uff1d": "%EF%BC%9D",
        "\uff1f": "%EF%BC%9F",
        "\uff20": "%EF%BC%A0",
        "\uff3b": "%EF%BC%BB",
        "\uff3d": "%EF%BC%BD"
    };

    function Qy(a) {
        return Yy[a]
    }
    const xy = /[\x00\x22\x26\x27\x3c\x3e]/g,
        Gy = /[\x00\x22\x27\x3c\x3e]/g,
        Jy = /[\x00\x08-\x0d\x22\x26\x27\/\x3c-\x3e\x5b-\x5d\x7b\x7d\x85\u2028\u2029]/g,
        Py = /[\x00- \x22\x27-\x29\x3c\x3e\\\x7b\x7d\x7f\x85\xa0\u2028\u2029\uff01\uff03\uff04\uff06-\uff0c\uff0f\uff1a\uff1b\uff1d\uff1f\uff20\uff3b\uff3d]/g,
        Ry = /^(?!javascript:)(?:[a-z0-9+.-]+:|[^&:\/?#]*(?:[\/?#]|$))/i,
        Zy = /^[a-zA-Z0-9+\/_-]+={0,2}$/;

    function $y(a) {
        a = String(a);
        return Zy.test(a) ? a : "zSoyz"
    }
    const Cy = /</g;
    /* 
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    function az(a) {
        return ra(a) ? a.Fb && (a = a.Fb(), a instanceof Lh) ? a : Wh("zSoyz") : Wh(String(a))
    }
    const bz = {};

    function cz(a, b) {
        return dz(b ? ? {}, a.Ne, a.nb, a.hf, a.jf, a.id, a.Fj, a.rsToken, a.searchTerm, a.za, a.Aa, a.Nk, a.Ok, a.Mh, a.Md, a.Nd, a.kn)
    }

    function dz(a, b, c, d, e, f, g, h, k, l, m, n, p, q, u, w, B) {
        n = n === void 0 ? 0 : n;
        p = p === void 0 ? 0 : p;
        q = q === void 0 ? "" : q;
        u = u === void 0 ? -1 : u;
        w = w === void 0 ? -1 : w;
        B = B === void 0 ? !1 : B;
        a = a && a.rb;
        return wy("<style" + (a ? ' nonce="' + R($y(a)) + '"' : "") + ">#" + T(f) + " {display: inline-block; height: " + T(l) + "; width: " + T(m) + ';}</style><ins id="' + R(f) + '" class="adsbygoogle" data-ad-client="' + R(c) + '" data-ad-intent-query="' + R(k) + '" data-ad-intent-rs-token="' + R(h) + '"' + (B ? ' data-ad-intents-ad-position="' + R(p) + '"' : "") + ' data-ad-intents-format="' +
            R(b) + '"' + (q !== "" ? ' data-kw="' + R(q) + '"' : "") + ' data-query-targeted="' + R(g) + '"' + (u !== -1 ? ' data-override-adx="' + R(u) + '"' : "") + (w !== -1 ? ' data-override-ady="' + R(w) + '"' : "") + (n !== 0 ? ' data-ad-intents-in-drawer-format="' + R(n) + '"' : "") + (d ? ' data-ad-intents-encoded-browseonomy-ids="' + R(d) + '"' : "") + (e ? ' data-ad-intents-encoded-verticals4-ids="' + R(e) + '"' : "") + "></ins>")
    };

    function ez(a) {
        return `zdmmCctpVIa${Uu(a)}`
    }
    var fz = class {
        constructor() {
            this.g = new Map
        }
        clear() {
            this.g.clear()
        }
    };

    function gz(a, b) {
        return hz(b ? ? {}, a.id, a.searchTerm, a.title)
    }

    function hz(a, b, c, d) {
        a = a && a.rb;
        a = "<style" + (a ? ' nonce="' + R($y(a)) + '"' : "") + ">.fallback-title-wrapper {display: flex; flex-direction: column; flex-shrink: 0; height: min-content; bottom: 0; left: 0; right: 0; margin: 16px 25px; padding: 3px 12px; align-items: center; border-radius: 8px; background: #e8f0fe;}.fallback-title {font-size: 14px; font-weight: 400; font-style: normal; color: #3c4043; font-family: 'Google Sans', Roboto, Arial, sans-serif; font-display: optional; text-align: center; line-height: 15px;}</style>";
        d =
            d.split("TERM");
        a += '<div id="' + R(b) + '" class="fallback-title-wrapper" aria-label="' + R(d[0]) + R(c) + R(d[1]) + '"><h1 class="fallback-title" aria-hidden="true">' + uy(d[0]) + "<b>" + uy(c) + "</b>" + uy(d[1]) + "</h1></div>";
        return wy(a)
    };

    function iz(a, b) {
        b = b ? ? {};
        var c = a.ih,
            d = a.searchTerm;
        a = a.title;
        var e = b && b.rb;
        return Sy(Ty(Sy(Vy(), '<div id="double-no-fill-container" class="container"><style' + (e ? ' nonce="' + R($y(e)) + '"' : "") + '>#double-no-fill-container {height: 100%; width: 100%; display: flex; flex-direction: column;}#double-no-fill-icon {flex-grow: 1; margin: 0 auto;}</style><svg width="224px" height="224px" viewBox="0 0 224 224" fill="none" xmlns="http://www.w3.org/2000/svg" id="double-no-fill-icon"><path d="M105.193 168.361H138.469L138.93 149.246L135.445 149.233L105.193 168.361Z" fill="#3C4043" stroke="#3C4043" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M13.7761 168.361H20.3717V100.563L13.7761 168.361Z" fill="#3C4043"/><path d="M47.5502 168.361H53.5608V100.563L47.5502 168.361Z" fill="#3C4043"/><path d="M5.59998 168.361H217.255" stroke="#3C4043" stroke-miterlimit="10" stroke-linecap="round"/><path d="M91.8401 56.6221H68.0215V168.361H91.8401V56.6221Z" fill="white" stroke="#3C4043" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M85.6676 147.666H74.1938V161.778H85.6676V147.666Z" fill="#DADCE0" stroke="#DADCE0" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M83.4153 69.4521H76.434V83.5641H83.4153V69.4521Z" fill="#DADCE0" stroke="#DADCE0" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M76.434 99.8164V139.004" stroke="#3C4043" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M83.4279 115.621V139.004" stroke="#3C4043" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M44.1904 98.2363H20.3717V168.361H44.1904V98.2363Z" fill="white" stroke="#3C4043" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M44.1904 152.668H20.3717V158.928H44.1904V152.668Z" fill="#DADCE0" stroke="#DADCE0" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M44.1904 98.2363H20.3717V168.361H44.1904V98.2363Z" stroke="#3C4043" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M68.0089 81.0137H53.5858V168.361H68.0089V81.0137Z" fill="white" stroke="#3C4043" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M68.0089 95.0381H53.5858V154.348H68.0089V95.0381Z" fill="#DADCE0"/><path d="M68.0089 81.0137H53.5858V168.361H68.0089V81.0137Z" stroke="#3C4043" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M60.8036 114.775V146.932" stroke="#3C4043" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M209.057 168.369V149.242H138.933V168.369H209.057Z" fill="white" stroke="#3C4043" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M197.571 168.369V149.242H150.406V168.369H197.571Z" fill="#DADCE0" stroke="#DADCE0" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M209.057 168.369V149.242H138.933V168.369H209.057Z" stroke="#3C4043" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M138.93 160.284V149.233H181.315L138.93 160.284Z" fill="#3C4043"/><path d="M180.271 122.351L172.686 109.574L97.5756 154.165L105.161 166.942L180.271 122.351Z" fill="#8AB4F8" stroke="#8AB4F8" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M174.075 126.03L166.49 113.253L103.771 150.487L111.357 163.264L174.075 126.03Z" stroke="#8AB4F8" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M147.454 133.193L119.803 149.608" stroke="white" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M174.074 126.019L166.488 113.242L161.106 116.438L168.691 129.215L174.074 126.019Z" fill="white" stroke="#8AB4F8" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M116.735 160.067L109.149 147.29L103.767 150.486L111.352 163.263L116.735 160.067Z" fill="white" stroke="#8AB4F8" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/></svg>'),
            hz(b, c, d, a)), "</div>")
    };

    function jz(a) {
        a = (a = a ? ? {}) && a.rb;
        return wy("<style" + (a ? ' nonce="' + R($y(a)) + '"' : "") + ">#dogtags-container-navigation-wrapper {display: flex; position: relative; height: 82px; bottom: 0; left: 0; right: 0; align-items: center;}#dogtags-container {display: none; flex-grow: 1; position: fixed; width: 100%; bottom: 0; left: 0; right: 0; padding: 23px 25px; box-sizing: border-box; align-items: flex-start; gap: 6px; overflow-x: scroll; scroll-behavior: smooth; scroll-width: none; -ms-overflow-style: none; &::-webkit-scrollbar { display: none; }box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.30), 0 1px 3px 1px rgba(0, 0, 0, 0.15);}#left-arrow-span, #right-arrow-span {display: flex; position: absolute; z-index: 100; height: 100%; width: 70px; align-items: center; opacity: 0; transition: opacity 0.2s ease-in-out;}#left-arrow-span {left: 0; justify-content: left; background: linear-gradient(90deg, #FFF 0.3%, #FFF 72.34%, rgba(243, 248, 255, 0.00) 99.66%); border-bottom-left-radius: 20px;}#right-arrow-span {right: 0; justify-content: right; background: linear-gradient(270deg, #FFF 0.3%, #FFF 72.34%, rgba(243, 248, 255, 0.00) 99.66%); border-bottom-right-radius: 20px;}#left-arrow, #right-arrow {margin-top: 10px; cursor: pointer;}#left-arrow {margin-left: 8px;}#right-arrow {margin-right: 8px;}</style>")
    };

    function kz(a, b, c, d, e, f, g, h, k, l, m, n, p, q, u, w, B, G, K, H, L) {
        H = H === void 0 ? -1 : H;
        L = L === void 0 ? -1 : L;
        var S = a && a.rb,
            da = a && a.Ng;
        return Sy(Ty(Sy(Ty(Sy(Vy(), (K ? "" : '<link href="https://fonts.googleapis.com/css?family=Google+Sans:500" rel="stylesheet"' + (S ? ' nonce="' + R($y(S)) + '"' : "") + ">") + (k !== -1 ? "<script" + (da ? ' nonce="' + R($y(da)) + '"' : "") + ">window[" + Hy(Iy("goog_pvsid")) + "] = " + Hy(Iy(k)) + ";\x3c/script>" : "") + (f !== "" ? '<meta name="google-adsense-platform-account" content="' + R(f) + '">' : "") + "<style" + (S ? ' nonce="' + R($y(S)) +
                '"' : "") + '>.container {display: none !important;}</style><div id="display-slot-container"><div id="' + R(G) + '">'), dz(a, b, c, d, e, "display-slot", !0, q, u, w, B, void 0, void 0, void 0, H, L)), "</div></div>"), g ? Sy(Ty(Sy(Vy(), '<div id="dogtags-container">'), jz(a)), "</div>") : Sy(Ty(Sy(Vy(), '<div id="dogtags-container-navigation-wrapper"><span id="left-arrow-span" aria-label="' + R(h) + '"><svg width="50" height="50" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" id="left-arrow" aria-hidden="true"><g filter="url(#filter0-d-1125-2720)"><circle cx="20" cy="16" r="16" transform="rotate(-180 20 16)" fill="white"/></g><path d="M20 24L21.41 22.59L15.83 17L28 17L28 15L15.83 15L21.41 9.41L20 8L12 16L20 24Z" fill="#5F6368"/><defs><filter id="filter0-d-1125-2720" x="0" y="2.79753e-06" width="40" height="40" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB"><feFlood flood-opacity="0" result="BackgroundImageFix"/><feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/><feOffset dy="4"/><feGaussianBlur stdDeviation="2"/><feComposite in2="hardAlpha" operator="out"/><feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.1 0"/><feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_1125_2720"/><feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_1125_2720" result="shape"/></filter></defs></svg></span><div id="dogtags-container">'),
                jz(a)), '</div><span id="right-arrow-span" aria-label="' + R(p) + '"><svg width="50" height="50" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" id="right-arrow" aria-hidden="true"><g filter="url(#filter0-d-1125-2701)"><circle cx="20" cy="16" r="16" fill="white"/></g><path d="M20 8L18.59 9.41L24.17 15H12V17H24.17L18.59 22.59L20 24L28 16L20 8Z" fill="#5F6368"/><defs><filter id="filter0-d-1125-2701" x="0" y="0" width="40" height="40" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB"><feFlood flood-opacity="0" result="BackgroundImageFix"/><feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/><feOffset dy="4"/><feGaussianBlur stdDeviation="2"/><feComposite in2="hardAlpha" operator="out"/><feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.1 0"/><feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_1125_2701"/><feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_1125_2701" result="shape"/></filter></defs></svg></span></div>')),
            (m ? "<script" + (da ? ' nonce="' + R($y(da)) + '"' : "") + ">(adsbygoogle=window.adsbygoogle||[]).requestNonPersonalizedAds=1;\x3c/script>" : "") + "<script" + (da ? ' nonce="' + R($y(da)) + '"' : "") + ">parent.postMessage({'action':'sgda-ready'}, parent.location.origin);\x3c/script>" + (K ? "<script" + (da ? ' nonce="' + R($y(da)) + '"' : "") + ">parent.fakeAdsByGoogle(window);\x3c/script>" : '<script data-ad-intent-query="' + R(u) + '"' + (d ? ' data-ad-intents-encoded-browseonomy-ids="' + R(d) + '"' : "") + (e ? ' data-ad-intents-encoded-verticals4-ids="' +
                R(e) + '"' : "") + ' data-ad-intent-rs-token="' + R(q) + '" data-page-url="' + R(Oy(l)) + '" data-ad-intents-format="' + R(b) + '"' + (n ? ' data-adtest="on"' : "") + ' async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=' + Ny(c) + '" crossorigin="anonymous"' + (da ? ' nonce="' + R($y(da)) + '"' : "") + ">\x3c/script>"))
    };

    function lz(a, b) {
        b = b ? ? {};
        var c = a.searchTerm,
            d = a.za,
            e = a.Aa,
            f = a.title,
            g = a.Mh,
            h = a.Md,
            k = a.Nd,
            l = a.Ne,
            m = a.nb;
        a = a.ih;
        g = g === void 0 ? "" : g;
        h = h === void 0 ? -1 : h;
        k = k === void 0 ? -1 : k;
        var n = b && b.rb;
        return Sy(Ty(Sy(Ty(Sy(Vy(), '<div id="fallback-container" class="container"><style' + (n ? ' nonce="' + R($y(n)) + '"' : "") + '>#fallback-container {height: 100%; display: flex; flex-direction: column;}#ad-slot-wrapper {display: flex; flex-grow: 1; justify-content: center; margin-inline: 16px;}</style><div id="ad-slot-wrapper">'), dz(b,
            l, m, "", "", "display-slot", !1, "", "", d, e, void 0, void 0, g, h, k)), "</div>"), hz(b, a, c, f)), "</div>")
    };
    const mz = RegExp("(^| )adsbygoogle($| )");
    var nz = class {
        constructor() {
            var a = {};
            this.j = (b, c) => a[b] != null ? a[b] : c;
            this.B = (b, c) => a[b] != null ? a[b] : c;
            this.A = (b, c) => a[b] != null ? a[b] : c;
            this.C = (b, c) => a[b] != null ? a[b] : c;
            this.l = (b, c) => a[b] != null ? c.concat(a[b]) : c;
            this.g = () => {}
        }
    };

    function U(a) {
        return dr(nz).j(a.g, a.defaultValue)
    }

    function V(a) {
        return dr(nz).B(a.g, a.defaultValue)
    }

    function oz(a) {
        return dr(nz).A(a.g, a.defaultValue)
    }

    function pz(a) {
        return dr(nz).C(a.g, a.defaultValue)
    };
    const qz = ["-webkit-text-fill-color"];

    function rz(a) {
        if (ub) {
            {
                let c = al(a.document.body, a);
                if (c) {
                    a = {};
                    var b = c.length;
                    for (let d = 0; d < b; ++d) a[c[d]] = "initial";
                    a = sz(a)
                } else a = tz()
            }
        } else a = tz();
        return a
    }

    function tz() {
        var a = {
            all: "initial"
        };
        ab(qz, b => {
            a[b] = "unset"
        });
        return a
    }

    function sz(a) {
        ab(qz, b => {
            delete a[b]
        });
        return a
    };

    function uz(a) {
        var b = a[0] / 255,
            c = a[1] / 255;
        a = a[2] / 255;
        return (b <= .03928 ? b / 12.92 : Math.pow((b + .055) / 1.055, 2.4)) * .2126 + (c <= .03928 ? c / 12.92 : Math.pow((c + .055) / 1.055, 2.4)) * .7152 + (a <= .03928 ? a / 12.92 : Math.pow((a + .055) / 1.055, 2.4)) * .0722
    }
    var vz = (a, b) => {
        a = uz(a);
        b = uz(b);
        return (Math.max(a, b) + .05) / (Math.min(a, b) + .05)
    };
    const wz = [255, 255, 255];

    function xz(a) {
        function b(d) {
            return [Number(d[1]), Number(d[2]), Number(d[3]), d.length > 4 ? Number(d[4]) : 1]
        }
        var c = a.match(/rgb\(([0-9]+),\s*([0-9]+),\s*([0-9]+)\)/);
        if (c || (c = a.match(/rgba\(([0-9]+),\s*([0-9]+),\s*([0-9]+),\s*([0-9\\.]+)\)/))) return b(c);
        if (a === "transparent" || a === "") return [0, 0, 0, 0];
        c = document.createElement("canvas");
        c.width = c.height = 1;
        if (c = c.getContext("2d", {
                willReadFrequently: !0
            })) return c.fillStyle = a, c.fillRect(0, 0, 1, 1), a = c.getImageData(0, 0, 1, 1).data, [a[0], a[1], a[2], a[3] / 255];
        throw Error(`Invalid color: ${a}`);
    }

    function yz(a) {
        return zz(xz(getComputedStyle(a).color))
    }

    function Az(a, b) {
        var c = getComputedStyle(a);
        if (c.backgroundImage !== "none") return null;
        c = xz(c.backgroundColor);
        var d = zz(c);
        if (d) return d;
        b = (a = a.parentElement) ? Az(a, b) : wz;
        if (!b) return null;
        a = c[3];
        return [Math.round(a * c[0] + (1 - a) * b[0]), Math.round(a * c[1] + (1 - a) * b[1]), Math.round(a * c[2] + (1 - a) * b[2])]
    }

    function zz(a) {
        return a[3] === 1 ? [a[0], a[1], a[2]] : null
    };

    function Bz(a, b) {
        b = a.document.createElement(b);
        J(b, rz(a));
        J(b, {
            color: "inherit",
            cursor: "inherit",
            direction: "inherit",
            "font-family": "inherit",
            "font-size": "inherit",
            "font-weight": "inherit",
            "text-align": "inherit",
            "text-orientation": "inherit",
            visibility: "inherit",
            "writing-mode": "inherit"
        });
        return b
    }

    function Cz(a, b) {
        a = a.document.createElementNS("http://www.w3.org/2000/svg", b);
        J(a, {
            animation: "initial",
            background: "initial",
            border: "0",
            "box-shadow": "none",
            color: "inherit",
            cursor: "inherit",
            direction: "inherit",
            display: "inline",
            fill: "currentcolor",
            filter: "initial",
            "float": "none",
            margin: "0",
            opacity: "initial",
            outline: "0",
            overflow: "initial",
            padding: "0",
            stroke: "initial",
            transform: "initial",
            "vertical-align": "initial",
            visibility: "inherit"
        });
        return a
    }

    function Dz(a) {
        a.dataset.googleVignette = "false";
        a.dataset.googleInterstitial = "false"
    }

    function Ez(a) {
        return a[0] === 255 && a[1] === 255 && a[2] === 255 || a[0] === 0 && a[1] === 0 && a[2] === 0
    }

    function Fz(a, b) {
        var c = a.document.createElement("div");
        c.style.color = b;
        c.style.display = "none";
        a.document.body.appendChild(c);
        b = a.getComputedStyle(c).color;
        a.document.body.removeChild(c);
        a = xz(b);
        return a[3] > 0 ? a : null
    }

    function Gz(a, b, c) {
        if (!b) return null;
        if (c.Xi) {
            var d = a.document.querySelector('meta[name="theme-color"]');
            if (d && (d = d.getAttribute("content")) && (d = Fz(a, d))) return `rgba(${d[0]}, ${d[1]}, ${d[2]}, ${b})`;
            d = a.getComputedStyle(a.document.documentElement);
            var e = ["--primary-color", "--brand-color", "--theme-color"];
            for (var f of e)
                if (e = d.getPropertyValue(f).trim())
                    if (e = Fz(a, e)) return `rgba(${e[0]}, ${e[1]}, ${e[2]}, ${b})`
        }
        if (c.Yi) {
            if (f = a.document.querySelector("header, nav, .header, #header"))
                if (f = a.getComputedStyle(f).backgroundColor,
                    f = xz(f), f[3] > 0 && !Ez(f)) return `rgba(${f[0]}, ${f[1]}, ${f[2]}, ${b})`;
            if (f = a.document.querySelector('button[type="submit"], .btn-primary, button'))
                if (f = a.getComputedStyle(f).backgroundColor, f = xz(f), f[3] > 0 && !Ez(f)) return `rgba(${f[0]}, ${f[1]}, ${f[2]}, ${b})`
        }
        if (c.Zi) {
            c = a.document.querySelectorAll("a");
            for (let g of c) {
                if (g.getAttribute("href") ? .startsWith("#")) continue;
                c = a.getComputedStyle(g).color;
                c = xz(c);
                if (c[3] !== 0) return `rgba(${c[0]}, ${c[1]}, ${c[2]}, ${b})`
            }
        }
        return `rgba(26, 115, 232, ${b})`
    };

    function Hz(a, b) {
        return a ? .95 * b.innerHeight - 30 : b.innerHeight - 24 - 20
    };

    function Iz(a, b) {
        a = Jz(a, "20px", b);
        a.classList.add("google-anno-sa-intent-icon");
        return a
    }

    function Kz(a, b, c) {
        a = Lz(a, "0 -960 960 960", "20px", "20px", "m256-200-56-56 224-224-224-224 56-56 224 224 224-224 56 56-224 224 224 224-56 56-224-224-224 224Z");
        J(a, {
            left: "13px",
            right: "",
            "pointer-events": "initial",
            position: "absolute",
            top: "15px",
            transform: "none",
            fill: c
        });
        a.role = "button";
        a.ariaLabel = b;
        a.tabIndex = 0;
        return a
    }

    function Jz(a, b, c) {
        a = Lz(a, "0 -960 960 960", b, b, "M168-144q-29.7 0-50.85-21.15Q96-186.3 96-216v-528q0-29.7 21.15-50.85Q138.3-816 168-816h624q29.7 0 50.85 21.15Q864-773.7 864-744v528q0 29.7-21.15 50.85Q821.7-144 792-144H168Zm0-72h624v-528H168v528Zm72-96h480v-72H240v72Zm0-144h168v-216H240v216Zm240 0h240v-72H480v72Zm0-144h240v-72H480v72ZM168-216v-528 528Z");
        J(a, {
            fill: c,
            cursor: "inherit"
        });
        return a
    }

    function Lz(a, b, c, d, e) {
        var f = Cz(a, "svg");
        f.setAttribute("viewBox", b);
        f.setAttribute("width", c);
        f.setAttribute("height", d);
        f.appendChild(Cz(a, "path")).setAttribute("d", e);
        return f
    };

    function W(a) {
        return `${a}px`
    }

    function Mz(a, b, c, d, e) {
        a.g.push(new Nz(b, c, d, e))
    }

    function Oz(a) {
        for (let c = a.g.length - 1; c >= 0; c--) {
            var b = a.g[c];
            b.j ? (b.element.style.removeProperty(b.g), b.element.style.setProperty(b.g, String(b.l), b.B)) : b.element.style[b.g] = b.l
        }
        a.g.length = 0
    }
    var Pz = class {
            constructor() {
                this.g = []
            }
        },
        Nz = class {
            constructor(a, b, c, d) {
                this.element = a;
                this.g = b;
                this.g = (this.j = !(d === void 0 || !a.style || !a.style.getPropertyPriority)) ? String(b).replace(/([A-Z])/g, "-$1").toLowerCase() : b;
                this.l = this.j ? a.style.getPropertyValue(this.g) : a.style[this.g];
                this.B = this.j ? a.style.getPropertyPriority(this.g) : void 0;
                this.j ? (a.style.removeProperty(this.g), a.style.setProperty(this.g, String(c), d)) : a.style[this.g] = String(c)
            }
        };

    function Qz(a, b, c) {
        var d = a.g ? a.g.getData() : {};
        a = a.j || Ti();
        (b = b(c || bz, d)) && b.j ? a = b.j() : (b = az(b), a = yj(a, b));
        return a
    }

    function Rz(a, b, c) {
        var d = a.g ? a.g.getData() : {};
        a = a.j;
        a: {
            b = b(c || bz, d);c = a || Ti();b && b.j ? c = b.j() : (c = xj(c, "DIV"), b = az(b), c.innerHTML = Nh(b));
            if (c.childNodes.length == 1 && (b = c.firstChild, b.nodeType == 1)) break a;b = c
        }
        return b
    }
    class Sz {
        constructor(a, b) {
            this.j = b || Ti();
            this.g = a || null
        }
        render(a, b) {
            a = a(b || {}, this.g ? this.g.getData() : {});
            return String(a)
        }
    };

    function Tz(a, b, c, d, e, f) {
        if (b.data.action === "sgda-ready") {
            var g = c.contentDocument;
            if (g ? .body && c.contentWindow) {
                var h = g.getElementById("display-slot-container");
                h && (a.Xd = new MutationObserver((k, l) => {
                    k = g.getElementById("display-slot");
                    if (k.getAttribute("data-ad-status") === "filled") {
                        if (a.Pb.g.has(ez(a.na))) return;
                        l.disconnect();
                        Uz(a, !0);
                        d.Vc();
                        if (k.getAttribute("data-query-targeted") === "true") a.Pb.g.set(ez(a.na), 0);
                        else {
                            a.Pb.g.set(ez(a.na), 1);
                            let m = g.getElementById("fallback-container");
                            Vz(m)
                        }
                        Wz(a, g)
                    }
                    k.getAttribute("data-ad-status") ===
                        "unfilled" && k.getAttribute("data-query-targeted") === "true" ? g.getElementById("fallback-container") ? (l.disconnect(), Uz(a, !0), d.Vc(), k.remove(), Xz(a, "fallback-container", a.na, D(d.T, 25), g), a.Pb.g.set(ez(a.na), 1)) : (g.getElementById(ez(a.na)).remove(), l = Rz(a.ec, lz, {
                            Ne: d.format,
                            nb: a.nb,
                            ih: ez(a.na),
                            Mh: U(ox) ? a.na : "",
                            searchTerm: a.na,
                            za: f,
                            Aa: e,
                            title: D(d.T, 25),
                            Md: a.Md,
                            Nd: a.Nd
                        }), h.appendChild(l), l = c.contentWindow, l.adsbygoogle = l.adsbygoogle || [], l.adsbygoogle.push({})) : k.getAttribute("data-ad-status") === "unfilled" &&
                        k.getAttribute("data-query-targeted") === "false" && (g.getElementById("fallback-container").remove(), l.disconnect(), Uz(a, !0), d.Vc(), a.Pb.g.set(ez(a.na), 2), g.getElementById("double-no-fill-container") ? Xz(a, "double-no-fill-container", a.na, D(d.T, 26), g) : (l = Rz(a.ec, iz, {
                            ih: ez(a.na),
                            searchTerm: a.na,
                            title: D(d.T, 26)
                        }), h.appendChild(l), Vz(l)), Yz(a, g), Wz(a, g))
                }), Zz(a, g), d.Yc(() => void a.Xd ? .disconnect()))
            }
        }
    }

    function $z(a, b, c, d, e, f) {
        if (b.data.action === "sgda-ready") {
            var g = c.contentDocument;
            if (g ? .body && c.contentWindow) {
                var h = g.getElementById("display-slot-container");
                if (h && (J(h, {
                        height: W(d.Ic - 83)
                    }), b = g.getElementById("dogtags-container"))) {
                    var k = d.T,
                        l = hy(k).filter(n => fy(n) === d.searchTerm).map(n => oe(n))[0],
                        m = aA(a, c.contentWindow, fy(l));
                    m.addEventListener("click", () => {
                        bA(a, l, d, c, g, h, m, e, f)
                    });
                    Dz(m);
                    b.appendChild(m);
                    cA(m);
                    k = hy(k).filter(n => D(n, 13)).map(n => oe(n));
                    for (let n of k) {
                        if (fy(n) === d.searchTerm) continue;
                        let p = aA(a, c.contentWindow, fy(n));
                        p.addEventListener("click", () => {
                            bA(a, n, d, c, g, h, p, e, f)
                        });
                        Dz(p);
                        b.appendChild(p)
                    }
                    d.ka || dA(g, d, b);
                    Uz(a, !1)
                }
            }
        }
    }

    function Uz(a, b) {
        a.kj = b;
        for (let [c, d] of a.ge) c !== a.na && J(d, {
            cursor: b ? "pointer" : "default"
        })
    }

    function Wz(a, b) {
        a.mh || (a.mh = !0, J(b.getElementById("dogtags-container"), {
            display: "flex"
        }))
    }

    function Xz(a, b, c, d, e) {
        if (b = e.getElementById(b)) Vz(b), a = Rz(a.ec, gz, {
            id: ez(c),
            searchTerm: c,
            title: d
        }), b.appendChild(a)
    }

    function Zz(a, b) {
        (b = b.getElementById("display-slot-container")) && a.Xd && a.Xd.observe(b, {
            subtree: !0,
            childList: !0,
            attributes: !0,
            attributeFilter: ["data-ad-status", "data-query-targeted"]
        })
    }

    function aA(a, b, c) {
        var d = Bz(b, "div"),
            e = Bz(b, "span");
        d.classList.add("google-anno-skip", "google-anno-sc");
        e.appendChild(b.document.createTextNode(c));
        d.appendChild(e);
        J(e, {
            position: "relative",
            "padding-inline": "3px",
            "white-space": "nowrap",
            "font-family": "'Google Sans', Roboto, Arial, sans-serif",
            "font-weight": "500",
            "font-size": "14px",
            color: "#202124"
        });
        J(d, {
            display: "inline-block",
            "flex-shrink": "0",
            padding: "1px 16px 8px 16px",
            border: "1px solid #bdc1c6",
            "border-radius": "100px",
            "white-space": "nowrap",
            cursor: "pointer",
            transition: "background 0.25s linear",
            "-webkit-tap-highlight-color": "transparent"
        });
        a.ge.set(c, d);
        a = Jz(b, "22px", "#202124");
        J(a, {
            position: "relative",
            top: "6px",
            "margin-inline": "-5px -22px",
            opacity: "0",
            transition: "margin-inline-end 0.25s ease-out, opacity 0.2s ease-in"
        });
        b = Bz(b, "span");
        J(b, {
            display: "inline-block"
        });
        a.classList.add("intent-icon-dogtag");
        b.classList.add("intent-icon-span-dogtag");
        b.appendChild(a);
        d.insertBefore(b, d.firstChild);
        e.ariaHidden = "true";
        a.ariaHidden = "true";
        b.ariaHidden = "true";
        d.ariaLabel = c;
        return d
    }

    function bA(a, b, c, d, e, f, g, h, k) {
        if (fy(b) !== a.na && a.kj) {
            eA(e.getElementById(ez(a.na)));
            eA(e.getElementById("fallback-container"));
            eA(e.getElementById("double-no-fill-container"));
            var l = e.getElementById("display-slot");
            l && (l.id = "");
            a.ge.has(a.na) && (l = a.ge.get(a.na), J(l.querySelector(".intent-icon-dogtag"), {
                "margin-inline-end": "-22px",
                opacity: "0"
            }), J(l, {
                padding: "1px 16px 8px 16px",
                border: "1px solid #bdc1c6",
                background: "#fff",
                cursor: "pointer"
            }));
            cA(g);
            a.na = fy(b);
            if (a.Pb.g.has(ez(a.na))) {
                a.Xd.disconnect();
                d =
                    a.na;
                if (a.Pb.g.has(ez(d))) switch (Vz(e.getElementById(ez(d))), a.Pb.g.get(ez(d))) {
                    case 1:
                        Vz(e.getElementById("fallback-container"));
                        break;
                    case 2:
                        Vz(e.getElementById("double-no-fill-container")), Yz(a, e)
                }
                c.Vc()
            } else Zz(a, e), Uz(a, !1), c = Rz(a.ec, cz, {
                    id: "display-slot",
                    nb: a.nb,
                    searchTerm: a.na,
                    Ne: c.format,
                    rsToken: D(b, 13),
                    Fj: !0,
                    Aa: h,
                    za: k,
                    Nk: 1,
                    hf: mf(b, 4).join("~"),
                    jf: mf(b, 2).join("~")
                }), e = e.createElement("div"), e.id = ez(a.na), e.classList.add("container"), e.appendChild(c), f.appendChild(e), Vz(e), a = d.contentWindow,
                a.adsbygoogle = a.adsbygoogle || [], a.adsbygoogle.push({})
        }
    }

    function cA(a) {
        J(a.querySelector(".intent-icon-dogtag"), {
            "margin-inline-end": "0",
            opacity: "1"
        });
        J(a, {
            border: "1px solid #aecbfa",
            background: "#aecbfa",
            cursor: "default"
        })
    }

    function dA(a, b, c) {
        var d = a.getElementById("dogtags-container-navigation-wrapper"),
            e = a.getElementById("left-arrow-span"),
            f = a.getElementById("right-arrow-span");
        d.addEventListener("mouseover", () => {
            (b.X ? -c.scrollLeft < c.scrollWidth - c.clientWidth - 1 : c.scrollLeft > 0) && fA(e);
            (b.X ? c.scrollLeft < 0 : c.scrollLeft < c.scrollWidth - c.clientWidth - 1) && fA(f)
        });
        d.addEventListener("mouseleave", () => {
            gA(e, b);
            gA(f, b)
        });
        c.addEventListener("scroll", () => {
            (b.X ? -c.scrollLeft < c.scrollWidth - c.clientWidth - 1 : c.scrollLeft > 0) ? fA(e): gA(e,
                b);
            (b.X ? c.scrollLeft < 0 : c.scrollLeft < c.scrollWidth - c.clientWidth - 1) ? fA(f): gA(f, b)
        });
        a.getElementById("left-arrow").addEventListener("click", () => {
            c.scrollLeft -= 100
        });
        a.getElementById("right-arrow").addEventListener("click", () => {
            c.scrollLeft += 100
        })
    }

    function Yz(a, b) {
        var c = b.getElementById("double-no-fill-icon");
        b.getElementById(ez(a.na)).getBoundingClientRect().height > 40 ? J(c, {
            "padding-top": "15px"
        }) : J(c, {
            "padding-top": "0"
        })
    }

    function fA(a) {
        J(a, {
            display: "flex"
        });
        a.offsetHeight;
        J(a, {
            opacity: "1"
        })
    }

    function gA(a, b) {
        J(a, {
            opacity: "0"
        });
        b.uc(999, b.win, () => {
            J(a, {
                display: "none"
            })
        }, 200)
    }
    var hA = class {
        constructor(a, b, c, d) {
            this.nb = a;
            this.th = b;
            this.bi = c;
            this.Pa = d;
            this.ec = new Sz;
            this.ge = new Map;
            this.na = "";
            this.Xd = null;
            this.mh = this.kj = !1;
            this.Nd = this.Md = -1;
            this.Pb = new fz
        }
        Dg(a) {
            var b = a.Ic - 83 - 16;
            this.Md = a.ka ? 0 : Math.round(a.win.innerWidth - a.rd);
            this.Nd = a.ka ? Math.round(a.win.innerHeight - Hz(a.ka, a.win)) : 32;
            var c = {
                    Ng: Ji(a.win.document)
                },
                d = a.searchTerm,
                e = this.nb,
                f = this.th ? ? "",
                g = W(a.rd),
                h = W(b),
                k = ez(a.searchTerm),
                l = !!C(a.T, 13),
                m = C(a.T, 3),
                n = a.kk ? ? !1,
                p = this.bi,
                q = this.Pa,
                u = a.format,
                w = a.rsToken,
                B =
                a.hf,
                G = a.jf,
                K = a.ka,
                H = D(a.T, 27),
                L = D(a.T, 28);
            c = kz(c ? ? {}, u, e, B, G, f, K, H, p, q, n, m, L, w, d, h, g, k, l, a.ka ? -1 : this.Md, a.ka ? this.Nd : -1);
            c = di("body", {
                dir: a.X ? "rtl" : "ltr",
                lang: D(a.T, 7),
                style: "margin:0;height:100%;padding-top:0;overflow:hidden"
            }, c.Fb());
            var S = a.win.document.createElement("iframe");
            J(S, {
                display: "block",
                border: "0",
                width: "100%",
                height: W(a.Ic)
            });
            this.na = a.searchTerm;
            this.ge.clear();
            this.Pb.clear();
            this.mh = !1;
            var da = a.Ic - 83 - 60 - 27,
                Ea = a.rd - 32,
                ka = a.Pe(999, a.win, Da => {
                    Tz(this, Da, S, a, W(Ea), W(da));
                    $z(this, Da,
                        S, a, W(a.rd), W(b))
                });
            a.Yc(() => {
                a.win.removeEventListener("message", ka)
            });
            S.srcdoc = Nh(c);
            return S
        }
    };

    function Vz(a) {
        a && J(a, {
            display: "flex"
        })
    }

    function eA(a) {
        a && J(a, {
            display: "none"
        })
    };

    function iA(a, b, c, d, e, f, g, h, k, l, m, n, p, q, u, w, B, G, K) {
        w = w === void 0 ? "" : w;
        B = B === void 0 ? -1 : B;
        var H = G === void 0 ? -1 : G,
            L = K === void 0 ? !1 : K;
        K = a && a.rb;
        G = a && a.Ng;
        d = Ty(Sy(Ty(Sy(Vy(), "<style" + (K ? ' nonce="' + R($y(K)) + '"' : "") + ">body {font-family: 'Google Sans', Roboto, Arial, sans-serif; margin: 0; padding-block-start: 8px; overflow: hidden;}.display-slot-container {line-height: 0;}#original-content {padding-block-end: 24px; overflow: hidden; background-image: linear-gradient(#e9f1fe 0px, transparent 300px); min-height: 300px;}.header {line-height: 35px; font-size: 25px; font-weight: 400; padding-inline-start: 24px; padding-inline-end: 24px; padding-block-start: 24px;}#gda-search-term {color: #4285f4;}@supports (background-clip: text) {#gda-search-term {background-image: linear-gradient(90deg, #4285f4, #33a1ce); background-clip: text; color: transparent;}}.generated-by {font-size: 14px; font-weight: 500; color: #1f1f1f; padding: 16px 24px 0; display: flex; align-items: center; gap: 8px; height: 24px;}.icon {flex-shrink: 0;}[dir=\"rtl\"] .icon {transform: scaleX(-1);}.generated-by span {margin-bottom: -2px;}#original-content .display-slot-container {float: left; padding-block-start: 16px;}p,ul,h1,h2,h3 {margin: 0 24px; font-size: 16px; font-weight: 400; line-height: 25px; color: #5c5f5e; clear: both;}h1,h2,h3 {font-size: 20px; font-weight: 500; color: #1f1f1f; padding-block-start: 24px;}p, ul {padding-block-start: 16px;}.item-title {font-weight: 500; color: #1f1f1f;}.disclaimer {font-size: 12px; line-height: 16px; color: #5c5f5e; padding: 16px 24px 0;}</style>" +
            (f !== -1 ? "<script" + (G ? ' nonce="' + R($y(G)) + '"' : "") + ">window[" + Hy(Iy("goog_pvsid")) + "] = " + Hy(Iy(f)) + ";\x3c/script>" : "") + (d !== "" ? '<meta name="google-adsense-platform-account" content="' + R(d) + '">' : "") + '<div id="display-slot-container" class="display-slot-container" style="position:absolute">'), dz(a, b, c, "", "", "display-slot", !1, "", "", p, q, void 0, 1, w, B, H, L)), '</div><div id="original-content"><div class="header" role="heading" aria-level="1"><span id="gda-search-term">' + uy(l) + "</span></div>"), m !== "" ? Sy(Ty(Sy(Vy(),
            '<div id="intro-text"></div><div id="display-slot-container-2" class="display-slot-container" style="position:absolute">'), dz(a, b, c, "", "", "display-slot-2", !1, "", "", m, n, void 0, 2, w, e ? B : -1, e ? H : -1, L)), "<script" + (G ? ' nonce="' + R($y(G)) + '"' : "") + ">(adsbygoogle=window.adsbygoogle||[]).push({});\x3c/script></div>") : "");
        a = (a = a ? ? {}) && a.rb;
        a = wy("<style" + (a ? ' nonce="' + R($y(a)) + '"' : "") + '>@keyframes skeleton-enter {0% {opacity: 0;}100% {opacity: 1;}}@keyframes skeleton-stretch-in {0% {transform: scaleX(0);}100% {transform: scaleX(1);}}@keyframes inline-shimmer {0% {background-position: 0% 0%;}100% {background-position: -200% 0%;}}#skeleton-loader {display: flex; flex-direction: column; align-items: flex-start; gap: 8px; padding: 16px; box-sizing: border-box; width: 100%;}.loader {inline-size: var(--line-width, 100%); block-size: 16px; border-radius: 8px; animation: inline-shimmer 2100ms calc(var(--order, 0) * 100ms) linear infinite both; background: linear-gradient( 90deg, #f0f4f9 20%, #f0f4f9, #d3dbe5,  #f0f4f9); background-size: 200% 100%; transform-origin: left; animation-name: skeleton-enter, skeleton-stretch-in, inline-shimmer; animation-duration: 350ms, 600ms, 2100ms; animation-delay: 200ms, 250ms, 50ms; animation-fill-mode: both; animation-timing-function: linear, cubic-bezier(0.2, 0, 0, 1), linear; animation-iteration-count: 1, 1, infinite;}</style><div id="skeleton-loader"><div class="loader" style="--order: 1;"></div><div class="loader" style="--order: 2; --line-width: 85%"></div><div class="loader" style="--order: 3; --line-width: 65%"></div></div>');
        return Sy(Ty(d, a), "</div>" + (h ? "<script" + (G ? ' nonce="' + R($y(G)) + '"' : "") + ">(adsbygoogle=window.adsbygoogle||[]).requestNonPersonalizedAds=1;\x3c/script>" : "") + "<script" + (G ? ' nonce="' + R($y(G)) + '"' : "") + ">parent.postMessage({'action':'sgda-ready'}, parent.location.origin);\x3c/script>" + (u ? "<script" + (G ? ' nonce="' + R($y(G)) + '"' : "") + ">parent.fakeAdsByGoogle(window);\x3c/script>" : '<script data-ad-intent-query="" data-ad-intent-rs-token="" data-page-url="' + R(Oy(g)) + '" data-ad-intents-format="' + R(b) + '"' + (k ? ' data-adtest="on"' :
            "") + ' async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=' + Ny(c) + '" crossorigin="anonymous"' + (G ? ' nonce="' + R($y(G)) + '"' : "") + '>\x3c/script><link href="https://fonts.googleapis.com/css?family=Google+Sans:400,500" rel="stylesheet"' + (K ? ' nonce="' + R($y(K)) + '"' : "") + ">"))
    }

    function jA(a) {
        var b = a.tj,
            c = a.Wc;
        a = a.qh;
        return Ty(Ty(Vy(), wy('<div class="generated-by"><svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg" class="icon"><path d="M14 21L11 18L14 15L17 18L14 21ZM6 18L0 12L6 6L12 12L6 18ZM15.5 11C15.5 9.46667 14.9667 8.16667 13.9 7.1C12.8333 6.03333 11.5333 5.5 10 5.5C11.5333 5.5 12.8333 4.96667 13.9 3.9C14.9667 2.83333 15.5 1.53333 15.5 0C15.5 1.53333 16.0333 2.83333 17.1 3.9C18.1667 4.96667 19.4667 5.5 21 5.5C19.4667 5.5 18.1667 6.03333 17.1 7.1C16.0333 8.16667 15.5 9.46667 15.5 11Z" fill="url(#spark-gradient)"/><defs><linearGradient id="spark-gradient" x1="0" y1="10.5" x2="21" y2="10.5" gradientUnits="userSpaceOnUse"><stop stop-color="#4285f4ff"/><stop offset="1" stop-color="#2daeb8ff"/></linearGradient></defs></svg><span>' + uy(b) +
            "</span></div>")), kA(c, a))
    }

    function lA(a) {
        return kA(a.Wc, a.qh)
    }

    function kA(a, b) {
        var c = "";
        a = Ve(a, Ah, 1, De());
        var d = a.length;
        for (let h = 0; h < d; h++) {
            var e = a[h];
            if ( of (e, th, 1, zh)) e = of (e, th, 1, zh), e = e.getLevel() === 1 ? "<h1>" + zy(D(e, 2)) + "</h1>" : e.getLevel() === 2 ? "<h2>" + zy(D(e, 2)) + "</h2>" : "<h3>" + zy(D(e, 2)) + "</h3>", c += e;
            else if ( of (e, wh, 2, zh)) c += "<p>" + zy(uh( of (e, wh, 2, zh))) + "</p>";
            else if ( of (e, xh, 3, zh)) {
                c += "<ul>";
                e = of (e, xh, 3, zh);
                e = mf(e, 1);
                var f = e.length;
                for (var g = 0; g < f; g++) c += "<li>" + uy(e[g]) + "</li>";
                c += "</ul>"
            } else if ( of (e, sh, 5, zh)) {
                c += "<ul>";
                e = of (e, sh, 5, zh);
                e = Ve(e, rh, 1, De());
                f = e.length;
                for (g = 0; g < f; g++) {
                    let k = e[g];
                    c += "<li>" + (D(k, 1) ? '<span class="item-title">' + zy(D(k, 1)) + "</span> " : "") + zy(D(k, 2)) + "</li>"
                }
                c += "</ul>"
            }
        }
        c += b ? '<div class="disclaimer">' + uy(b) + "</div>" : "";
        return wy(c)
    };

    function mA(a, b) {
        var c = Ve(a, Ah, 1, De()),
            d = c.findIndex(e => Ae(e, wh, 2, zh));
        if (d === -1) return [a, new Ch];
        a = c[d];
        c = c.slice(d + 1);
        d = uh( of (a, wh, 2, zh));
        b = nA(d, b);
        if (!b || b.length > d.length - 10) return [Bh([a]), Bh(c)];
        a = d.substring(b.length).trimStart();
        return [Bh([yh(new Ah, vh(b))]), Bh([yh(new Ah, vh(a)), ...c])]
    }

    function nA(a, b) {
        try {
            return (new Intl.Segmenter(b, {
                granularity: "sentence"
            })).segment(a)[Symbol.iterator]().next().value.segment.trimEnd()
        } catch (c) {}
        return (a = a.match(/^.*?[.!?\u3002\u0964\u0589\u1362\uff1f\uff01]+/)) ? a[0] : null
    };

    function oA(a, b) {
        return D(a, 10).replace("TERM", b)
    };
    const pA = ["P", "UL", "DIV"],
        qA = ["DIV"];
    var uA = class {
        constructor(a, b, c, d, e) {
            this.nb = a;
            this.th = b;
            this.bi = c;
            this.Pa = d;
            this.g = e
        }
        fk(a, b) {
            if (b ? .g()) {
                var c = new qp;
                var d = b.aa;
                d = ze(d, d[v] | 0, Dh, 2);
                c = z(c, 1, d);
                b = rA(b.wf());
                b = F(c, 2, b);
                A(a, 3, sp, b)
            } else this.g.fk ? .(a, b)
        }
        Dg(a) {
            var b = a.content;
            if (!b ? .g()) return this.g.Dg(a);
            var {
                Aa: c,
                za: d
            } = sA(a, oz(nx)), {
                Aa: e,
                za: f
            } = sA(a, oz(mx)), g = {
                Ng: Ji(a.win.document)
            }, h = a.searchTerm, k = this.nb, l = this.th ? ? "", m = !!C(a.T, 13), n = C(a.T, 3), p = a.kk ? ? !1, q = this.bi, u = this.Pa, w = U(ox) ? a.searchTerm : "", B = a.format, G = a.ka ? -1 : Math.round(a.win.innerWidth -
                a.rd), K = a.ka ? Math.round(a.win.innerHeight - Hz(a.ka, a.win)) : -1, H = U(lx), L = U(rx);
            g = iA(g ? ? {}, B, k, l, H, q, u, p, n, h, f, e, d, c, m, w, G, K, L);
            g = di("body", {
                dir: a.X ? "rtl" : "ltr",
                lang: D(a.T, 7)
            }, g.Fb());
            var S = a.win.document.createElement("iframe");
            S.title = oA(a.T, a.searchTerm);
            J(S, {
                display: "block",
                border: "0",
                width: "100%",
                height: W(a.Ic)
            });
            var da, Ea = a.Pe(999, a.win, ka => {
                ka.data.action === "sgda-ready" && S.contentWindow && ka.source === S.contentWindow && !da && (da = new tA(this.nb, a, S, Te(b, Ch, 1), D(a.T, 7)))
            });
            a.Yc(() => {
                da ? .dispose();
                a.win.removeEventListener("message",
                    Ea)
            });
            S.srcdoc = Nh(g);
            return S
        }
    };

    function vA(a) {
        var b = () => {
            J(a.L, {
                height: W(a.l.body.scrollHeight)
            })
        };
        b();
        var c = new a.A.ResizeObserver(() => void b());
        c.observe(a.l.body);
        xt(a, () => void c.disconnect())
    }

    function wA(a, b) {
        var c = b.querySelector("ins");
        return new Promise(d => {
            var e = new MutationObserver((f, g) => {
                f = c.getAttribute("data-ad-status");
                f === "filled" && (g.disconnect(), b.style.position = "", d(f));
                f === "unfilled" && (g.disconnect(), b.style.position === "absolute" && b.remove(), d(f))
            });
            e.observe(c, {
                attributeFilter: ["data-ad-status"]
            });
            xt(a, () => void e.disconnect())
        })
    }

    function xA(a, b, c, d, e, f) {
        var {
            Aa: g,
            za: h
        } = sA(a.j, d);
        d = Rz(a.ec, cz, {
            id: e,
            nb: a.nb,
            searchTerm: "",
            Ne: a.j.format,
            rsToken: "",
            hf: "",
            jf: "",
            Fj: !1,
            Mh: U(ox) ? a.j.searchTerm : "",
            Ok: f,
            kn: U(rx),
            Aa: g,
            za: h
        });
        d.classList.add("display-slot-container");
        b.insertBefore(d, c);
        a = a.A;
        a.adsbygoogle = a.adsbygoogle || [];
        a.adsbygoogle.push({})
    }
    class tA extends O {
        constructor(a, b, c, d, e) {
            super();
            this.nb = a;
            this.j = b;
            this.L = c;
            this.Wc = d;
            this.D = e;
            this.A = this.L.contentWindow;
            this.l = this.L.contentDocument;
            this.ec = new Sz(void 0, new hj(this.l));
            b.sa(999, this.init())
        }
        async init() {
            vA(this);
            var a = this.l.getElementById("display-slot-container"),
                b = this.l.getElementById("display-slot-container-2");
            if (b) {
                let d = this.j.sa(999, wA(this, a));
                if (await wA(this, b) === "filled") {
                    this.j.Vc();
                    if (a.parentNode) {
                        a.style.position = "";
                        let [e, f] = mA(this.Wc, this.D);
                        this.C = f;
                        if (a =
                            this.l.getElementById("intro-text")) b = D(this.j.T, 9), b = Qz(this.ec, jA, {
                            tj: b,
                            Wc: e
                        }), a.appendChild(b)
                    }
                    await this.delay()
                } else a = await d, this.j.Vc(), a === "filled" && await this.delay()
            } else a = await wA(this, a), this.j.Vc(), a === "filled" && await this.delay();
            this.l.getElementById("skeleton-loader") ? .remove();
            if (a = this.l.getElementById("original-content"))
                if (this.C ? b = Qz(this.ec, lA, {
                        Wc: this.C,
                        qh: D(this.j.T, 11)
                    }) : (b = D(this.j.T, 9), b = Qz(this.ec, jA, {
                        tj: b,
                        Wc: this.Wc,
                        qh: D(this.j.T, 11)
                    })), a.appendChild(b), a = this.l.getElementById("original-content")) {
                    a: {
                        b =
                        a.querySelectorAll("ins");b = (b = b[b.length - 1]) ? b.getBoundingClientRect().bottom : a.getBoundingClientRect().top;
                        for (c of a.children)
                            if (pA.includes(c.tagName) && !qA.includes(c.nextElementSibling ? .tagName ? ? "") && c.getBoundingClientRect().bottom + 16 - b >= this.j.Ic) {
                                var c = c.nextElementSibling;
                                break a
                            }
                        c = null
                    }
                    xA(this, a, c, oz(kx), "display-slot-3", 3);b = oz(ix);c && b && xA(this, a, null, b, "display-slot-4", 4)
                }
        }
        delay() {
            return new Promise(a => {
                var b = this.j.uc(999, this.j.win, a, V(jx));
                xt(this, () => {
                    this.j.win.clearTimeout(b)
                })
            })
        }
    }

    function sA(a, b) {
        if (!b) return {
            Aa: "",
            za: ""
        };
        var c = a.rd,
            d = oj(document, "DIV");
        d.style.cssText = "overflow:auto;position:absolute;top:0;width:100px;height:100px";
        var e = oj(document, "DIV"),
            f = "200px";
        if (f instanceof wi) {
            var g = f.height;
            f = f.width
        } else g = "200px";
        e.style.width = Sj(f);
        e.style.height = Sj(g);
        d.appendChild(e);
        document.body.appendChild(d);
        e = d.offsetWidth - d.clientWidth;
        pj(d);
        c = W(c - e);
        a = (aa = ja(b, "replaceAll").call(b, "<SW>", c), ja(aa, "replaceAll")).call(aa, "<DH>", W(a.Ic));
        return {
            Aa: c,
            za: a
        }
    }

    function rA(a) {
        switch (a) {
            case 1:
                return 1;
            case 2:
                return 2;
            case 3:
                return 3;
            default:
                return 0
        }
    };
    var yA = class {
        constructor(a) {
            this.Jd = a.Jd ? ? [];
            this.Te = a.Te ? ? 0;
            this.Se = a.Se ? ? 0;
            this.Vf = a.Vf ? ? !0;
            this.gf = !!a.gf;
            this.eh = !!a.eh;
            this.Yg = !!a.Yg;
            this.kb = a.kb ? ? 0;
            this.bh = !!a.bh;
            this.Zg = !!a.Zg;
            this.ah = !!a.ah;
            this.Wh = a.Wh ? ? 0;
            this.Xg = !!a.Xg;
            this.Vg = !!a.Vg;
            this.Wg = !!a.Wg;
            this.ef = !!a.ef;
            this.ff = !!a.ff;
            this.df = !!a.df;
            this.kg = !!a.kg;
            this.Tb = !!a.Tb
        }
    };

    function zA(a) {
        return new yA({
            Jd: a,
            Te: V(Lw),
            Se: V(Kw),
            Vf: U(ux),
            gf: U(ax),
            eh: U(Tw),
            Yg: U(Uw),
            kb: V(gx),
            bh: U(Zw),
            Zg: U(Vw),
            ah: U(Xw),
            Wh: V(fx),
            Xg: U(Sw),
            Vg: U(Qw),
            Wg: U(Rw),
            ef: U(Yw),
            ff: U($w),
            df: U(Ww),
            kg: U(sx),
            Tb: U(Pw)
        })
    }

    function AA(a, b, c, d, e, f) {
        return {
            T: BA(a) ? ? Te(b, iy, 1),
            Pa: c,
            sb: d,
            Mb: 1,
            M: zA(e),
            Jc: f
        }
    }

    function CA(a, b, c, d, e, f) {
        return {
            T: BA(a) ? ? Te(b, iy, 1),
            Pa: c,
            sb: d,
            Mb: 1,
            M: zA(e),
            Jc: f
        }
    }

    function DA() {
        return { ...EA(),
            Jm: V(dx)
        }
    }

    function EA() {
        return {
            Oj: new Set(pz(ex))
        }
    }

    function BA(a) {
        try {
            a = a ? .location ? .hash ? .match(/\bgoog_cpmi=([^&]*)/);
            if (!a) return null;
            let c = decodeURIComponent(a[1]),
                d = jy(c);
            for (let e of hy(d)) {
                var b = we(e, 14);
                we(b, 10)
            }
            return d
        } catch (c) {
            return null
        }
    };

    function aq() {
        return "m202605130101"
    };

    function FA(a, b) {
        Fk(a, (c, d) => {
            b[d] = c
        })
    }

    function GA(a) {
        if (a === a.top) return 0;
        for (let b = a; b && b !== b.top && Ik(b); b = b.parent) {
            if (a.sf_) return 2;
            if (a.$sf) return 3;
            if (a.inGptIF) return 4;
            if (a.inDapIF) return 5
        }
        return 1
    };

    function HA() {
        if (IA) return IA;
        var a = tr() || window,
            b = a.google_persistent_state_async;
        return b != null && typeof b == "object" && b.S != null && typeof b.S == "object" ? IA = b : a.google_persistent_state_async = IA = new JA
    }

    function KA(a, b, c) {
        b = LA[b] || `google_ps_${b}`;
        a = a.S;
        var d = a[b];
        return d === void 0 ? (a[b] = c(), a[b]) : d
    }

    function MA(a, b, c) {
        return KA(a, b, () => c)
    }

    function NA(a, b, c) {
        return a.S[LA[b] || `google_ps_${b}`] = c
    }

    function OA(a, b) {
        return NA(a, b, MA(a, b, 0) + 1)
    }

    function PA() {
        var a = HA();
        return MA(a, 20, {})
    }

    function QA() {
        var a = HA(),
            b = MA(a, 41, !1);
        b || NA(a, 41, !0);
        return !b
    }

    function RA(a) {
        return MA(a, 24)
    }

    function SA() {
        var a = HA();
        return MA(a, 28, [])
    }
    var JA = class {
            constructor() {
                this.S = {}
            }
        },
        IA = null;
    const LA = {
        [8]: "google_prev_ad_formats_by_region",
        [9]: "google_prev_ad_slotnames_by_region"
    };

    function TA(a = null) {
        ({
            googletag: a
        } = a ? ? window);
        return a ? .apiReady ? a : void 0
    };

    function UA(a, b) {
        var c = VA(b, ".google-auto-placed"),
            d = WA(b),
            e = XA(b),
            f = YA(b),
            g = ZA(b),
            h = $A(b),
            k = VA(b, "div.googlepublisherpluginad"),
            l = VA(b, "html > ins.adsbygoogle"),
            m = [].concat(...VA(b, "iframe[id^=aswift_],iframe[id^=google_ads_frame]"), ...VA(b, "body ins.adsbygoogle")),
            n = [];
        a.vp && (n = n.concat(VA(b, "ins.adsbygoogle[data-ad-hi]")));
        for (let [p, q] of [
                [a.Bf, c],
                [a.Bd, d],
                [a.vm, e],
                [a.zh, f],
                [a.Ah, g],
                [a.sm, h],
                [a.um, k],
                [a.wm, l]
            ]) b = q, p === !1 ? n = n.concat(b) : m = m.concat(b);
        m = aB(m);
        n = aB(n);
        m = m.slice(0);
        for (let p of n)
            for (n =
                0; n < m.length; n++)(p.contains(m[n]) || m[n].contains(p)) && m.splice(n, 1);
        return a.Wl ? bB(m) : m
    }

    function cB(a) {
        return !!a.className && a.className.indexOf("google-auto-placed") != -1
    }

    function dB(a) {
        var b = TA(a);
        return b ? cb(db(b.pubads().getSlots(), c => a.document.getElementById(c.getSlotElementId())), c => c != null) : null
    }

    function VA(a, b) {
        return mb(a.document.querySelectorAll(b))
    }

    function WA(a) {
        return VA(a, "ins.adsbygoogle[data-anchor-status]")
    }

    function XA(a) {
        return VA(a, "ins.adsbygoogle[data-ad-format=autorelaxed]")
    }

    function YA(a) {
        return (dB(a) || VA(a, "div[id^=div-gpt-ad]")).concat(VA(a, "iframe[id^=google_ads_iframe]"))
    }

    function ZA(a) {
        return VA(a, "div.trc_related_container,div.OUTBRAIN,div[id^=rcjsload],div[id^=ligatusframe],div[id^=crt-],iframe[id^=cto_iframe],div[id^=yandex_], div[id^=Ya_sync],iframe[src*=adnxs],div.advertisement--appnexus,div[id^=apn-ad],div[id^=amzn-native-ad],iframe[src*=amazon-adsystem],iframe[id^=ox_],iframe[src*=openx],img[src*=openx],div[class*=adtech],div[id^=adtech],iframe[src*=adtech],div[data-content-ad-placement=true],div.wpcnt div[id^=atatags-]")
    }

    function $A(a) {
        return VA(a, "ins.adsbygoogle-ablated-ad-slot")
    }

    function bB(a) {
        return a.filter(b => !b.querySelector('[data-google-ad-efd="true"]'))
    }

    function aB(a) {
        var b = [];
        for (let c of a) {
            a = !0;
            for (let d = 0; d < b.length; d++) {
                let e = b[d];
                if (e.contains(c)) {
                    a = !1;
                    break
                }
                if (c.contains(e)) {
                    a = !1;
                    b[d] = c;
                    break
                }
            }
            a && b.push(c)
        }
        return b
    };

    function eB(a) {
        return a.google_ad_modifications = a.google_ad_modifications || {}
    }

    function fB(a, b) {
        a = eB(a);
        a.processed_sra_frame_pingbacks = a.processed_sra_frame_pingbacks || {};
        var c = !a.processed_sra_frame_pingbacks[b];
        a.processed_sra_frame_pingbacks[b] = !0;
        return c
    };

    function gB(a) {
        return a.google_ad_client ? String(a.google_ad_client) : eB(a).head_tag_slot_vars ? .google_ad_client ? ? a.document.querySelector(".adsbygoogle[data-ad-client]") ? .getAttribute("data-ad-client") ? ? ""
    };
    var hB = Tg(Yp);
    var $p = Tg(bq);

    function iB(a, b) {
        return b(a) ? a : void 0
    }

    function jB(a, b, c, d, e) {
        c = c instanceof Ll ? c.error : c;
        var f = new eq,
            g = new dq;
        try {
            var h = ul(window);
            xf(g, 1, h)
        } catch (p) {}
        try {
            var k = $q();
            Ne(g, 2, k, gd)
        } catch (p) {}
        try {
            Kf(g, 3, window.document.URL)
        } catch (p) {}
        h = z(f, 2, g);
        k = new cq;
        b = F(k, 1, b);
        try {
            var l = x(c ? .name) ? c.name : "Unknown error";
            Kf(b, 2, l)
        } catch (p) {}
        try {
            var m = x(c ? .message) ? c.message : `Caught ${c}`;
            Kf(b, 3, m)
        } catch (p) {}
        try {
            var n = x(c ? .stack) ? c.stack : Error().stack;
            n && Ne(b, 4, n.split(/\n\s*/), Dd)
        } catch (p) {}
        l = A(h, 1, fq, b);
        if (e) {
            m = 0;
            switch (e.errSrc) {
                case "LCC":
                    m = 1;
                    break;
                case "PVC":
                    m = 2
            }
            n = Zp();
            b = iB(e.shv, x);
            n = Kf(n, 2, b);
            m = F(n, 6, m);
            n = og(hB());
            b = iB(e.es, vc());
            n = Ne(n, 1, b, gd);
            n = oe(n);
            m = z(m, 4, n);
            n = iB(e.client, x);
            m = Jf(m, 3, n);
            n = iB(e.slotname, x);
            m = Kf(m, 7, n);
            e = iB(e.tag_origin, x);
            e = Kf(m, 8, e);
            e = oe(e)
        } else e = qg(Zp());
        e = A(l, 6, gq, e);
        d = xf(e, 5, d ? ? 1);
        Rq(a, d)
    };

    function kB(a) {
        var b = (new lB).g();
        return a > 0 && b.Xm * a <= b.Jl
    }
    var lB = class {
        constructor() {
            this.g = mB
        }
    };

    function mB() {
        return {
            Xm: Xk() + (Xk() & 2 ** 21 - 1) * 2 ** 32,
            Jl: Number.MAX_SAFE_INTEGER
        }
    };
    var pB = class {
        constructor(a = !1) {
            var b = nB;
            this.F = oB;
            this.j = a;
            this.B = b;
            this.g = null;
            this.qa = this.Da
        }
        l(a) {
            this.g = a
        }
        A() {}
        Yb(a, b, c) {
            try {
                var d = b()
            } catch (e) {
                b = this.j;
                try {
                    b = this.qa(a, Ml(e), void 0, c)
                } catch (f) {
                    this.Da(217, f)
                }
                if (b) window.console ? .error ? .(e);
                else throw e;
            }
            return d
        }
        Zb(a, b, c, d) {
            return (...e) => this.Yb(a, () => b.apply(c, e), d)
        }
        sa(a, b, c) {
            b.catch(d => {
                d = d ? d : "unknown rejection";
                this.Da(a, d instanceof Error ? d : Error(d), void 0, c)
            })
        }
        Da(a, b, c, d) {
            try {
                let f = c === void 0 ? 1 / this.B : c === 0 ? 0 : 1 / c;
                if (kB(f)) {
                    var e = this.F;
                    c = {};
                    if (this.g) try {
                        this.g(c)
                    } catch (g) {}
                    if (d) try {
                        d(c)
                    } catch (g) {}
                    jB(e, a, b, f, c)
                }
            } catch (f) {}
            return this.j
        }
    };
    var qB = class extends Error {
        constructor(a = "") {
            super();
            this.name = "TagError";
            this.message = a ? "adsbygoogle.push() error: " + a : "";
            Error.captureStackTrace ? Error.captureStackTrace(this, qB) : this.stack = Error().stack || ""
        }
    };
    let oB, rB, sB, tB, nB;
    const uB = new bm(t);
    (function(a, b, c = !0) {
        ({
            qn: nB,
            lm: sB
        } = vB());
        rB = a || new jr;
        ir(rB, sB);
        oB = b || new cr(aq(), 1E3);
        tB = new pB(c);
        t.document.readyState === "complete" ? t.google_measure_js_timing || am(uB) : uB.g && Yj(t, "load", () => {
            t.google_measure_js_timing || am(uB)
        })
    })();

    function wB(a, b, c) {
        return tB.Yb(a, b, c)
    }

    function xB(a, b) {
        return tB.Zb(a, b)
    }

    function yB(a, b, c) {
        tB.sa(a, b, c)
    }

    function zB(a, b, c = .01) {
        var d = $q();
        !b.eid && d.length && (b.eid = d.toString());
        Hm(rB, a, b, !0, c)
    }

    function AB(a, b, c = nB, d) {
        return tB.Da(a, b, c, d, void 0)
    }

    function vB() {
        if (oc(t.google_srt)) {
            var a = t.google_srt;
            var b = t.google_srt === 0 ? 1 : .01
        } else a = Math.random(), b = .01;
        return {
            qn: b,
            lm: a
        }
    };

    function ar(a, b, c = 0) {
        a.j.size > 0 || BB(a);
        c = Math.min(Math.max(0, c), 9);
        var d = a.j.get(c);
        d ? d.push(b) : a.j.set(c, [b])
    }

    function CB(a, b, c, d) {
        Yj(b, c, d);
        xt(a, () => Zj(b, c, d))
    }

    function DB(a, b) {
        a.state !== 1 && (a.state = 1, a.j.size > 0 && EB(a, b))
    }

    function BB(a) {
        a.win.document.visibilityState ? CB(a, a.win.document, "visibilitychange", b => {
            a.win.document.visibilityState === "hidden" && DB(a, b);
            a.win.document.visibilityState === "visible" && (a.state = 0)
        }) : "onpagehide" in a.win ? (CB(a, a.win, "pagehide", b => {
            DB(a, b)
        }), CB(a, a.win, "pageshow", () => {
            a.state = 0
        })) : CB(a, a.win, "beforeunload", b => {
            DB(a, b)
        })
    }

    function EB(a, b) {
        for (let c = 9; c >= 0; c--) a.j.get(c) ? .forEach(d => {
            d(b)
        })
    }
    var FB = class extends O {
        constructor(a) {
            super();
            this.win = a;
            this.state = 0;
            this.j = new Map
        }
    };
    async function GB(a, b) {
        var c = 10;
        return c <= 0 ? Promise.reject(Error(`wfc bad input ${c} 200`)) : b() ? Promise.resolve() : new Promise((d, e) => {
            var f = a.setInterval(() => {
                --c ? b() && (a.clearInterval(f), d()) : (a.clearInterval(f), e(Error(`wfc timed out ${c}`)))
            }, 200)
        })
    };

    function HB() {
        return dr(IB)
    }

    function JB(a) {
        var b = a.state.pc;
        return b !== null && b !== 0 ? b : a.state.pc = ul(a.win)
    }

    function KB(a) {
        var b = a.state.wpc;
        return b !== null && b !== "" ? b : a.state.wpc = gB(a.win)
    }

    function LB(a, b) {
        var c = new Wp;
        var d = JB(a);
        c = xf(c, 1, d);
        d = KB(a);
        c = Kf(c, 2, d);
        c = Vp(c, a.state.sd);
        return xf(c, 7, Math.round(b || a.win.performance.now()))
    }

    function MB(a, b, c) {
        b(a.F.Xb.hc.Qe).wa(c)
    }

    function NB(a, b, c) {
        b(a.F.Xb.hc.Qe).Td(c)
    }
    async function OB(a) {
        try {
            return await GB(a.win, () => !(!JB(a) || !KB(a))), !0
        } catch (b) {
            return !1
        }
    }

    function PB(a) {
        var b = HB();
        if (b.g) {
            var c = b.l;
            a(c);
            b.state.cc = Zd(c)
        }
    }
    async function QB(a, b, c) {
        if (a.g && c.length && !a.state.lgdp.includes(Number(b))) {
            a.state.lgdp.push(Number(b));
            var d = a.win.performance.now();
            if (await OB(a)) {
                var e = a.F;
                a = LB(a, d);
                d = new uo;
                b = F(d, 1, b);
                c = Ne(b, 2, c, gd);
                c = A(a, 9, Xp, c);
                Sq(e, c)
            }
        }
    }
    async function RB(a, b) {
        if (await OB(a)) {
            var c = LB(a);
            b = A(c, 5, Xp, b);
            a.g && !a.state.le.includes(2) && (a.state.le.push(2), Sq(a.F, b))
        }
    }
    async function SB(a, b, c) {
        if (await OB(a)) {
            var d = a.F;
            a = Vp(LB(a, c), 1);
            b = A(a, 6, Xp, b);
            Sq(d, b)
        }
    }
    async function TB(a, b, c) {
        await OB(a) && MB(a, d => b(d.qk), c)
    }
    async function UB(a, b, c) {
        await OB(a) && NB(a, d => b(d.qk), c)
    }
    async function VB(a, b) {
        if (await OB(a)) {
            var c = a.F;
            a = Vp(LB(a), 1);
            b = A(a, 13, Xp, b);
            Sq(c, b)
        }
    }
    async function WB(a, b) {
        if (a.g && await OB(a)) {
            var c = a.F;
            a = LB(a);
            b = A(a, 11, Xp, b);
            Sq(c, b)
        }
    }
    async function XB(a, b) {
        if (await OB(a)) {
            var c = a.F;
            a = Vp(LB(a), 1);
            b = A(a, 16, Xp, b);
            Sq(c, b)
        }
    }
    async function YB(a, b) {
        if (await OB(a)) {
            var c = a.F;
            a = Vp(LB(a), 1);
            b = A(a, 19, Xp, b);
            Sq(c, b)
        }
    }
    async function ZB(a) {
        var b = HB(),
            c = V(Ox);
        if (c > 0 && Uk() < 1 / c && await OB(b)) {
            var d = new to;
            d = F(d, 1, a);
            a = b.F;
            b = LB(b);
            b = A(b, 23, Xp, d);
            Sq(a, Vp(b, c))
        }
    }
    var IB = class {
        constructor(a, b) {
            this.win = tr() || window;
            this.j = b ? ? new FB(this.win);
            this.F = a ? ? new cr(aq(), 100, 100, !0, this.j);
            this.state = KA(HA(), 33, () => {
                var c = V(Gv);
                return {
                    sd: c,
                    ssp: c > 0 && Uk() < 1 / c,
                    pc: null,
                    wpc: null,
                    cu: null,
                    le: [],
                    lgdp: [],
                    psi: null,
                    tar: 0,
                    cc: null
                }
            })
        }
        get g() {
            return this.state.ssp
        }
        get Pa() {
            return this.state.cu
        }
        set Pa(a) {
            this.state.cu = a
        }
        get l() {
            return wB(1227, () => rg(zo, $d(this.state.cc || []))) || new zo
        }
        async B() {
            var a = new Up;
            var b = tf(a, 3, !0);
            var c = this.win.performance.now();
            await OB(this) && (a = this.F,
                c = Vp(LB(this, c), 1), b = A(c, 20, Xp, b), Sq(a, b))
        }
        A(a) {
            ar(this.j, () => {
                if (U(Dv) && this.g && !this.state.le.includes(4)) {
                    this.state.le.push(4);
                    var b = this.F;
                    var c = Vp(LB(this), 1);
                    var d = a();
                    c = A(c, 20, Xp, d);
                    Sq(b, c)
                }
            }, 9)
        }
    };

    function $B(a) {
        return eB(a) ? .head_tag_slot_vars ? .google_ad_host ? ? a.document ? .querySelector('meta[name="google-adsense-platform-account"]') ? .getAttribute("content") ? ? null
    };
    var aC = class {
        constructor() {
            this.j = this.l = 1;
            this.g = new Map;
            this.isDrawerVisible = !1
        }
        takeNextPageEventIndex() {
            return this.l++
        }
        takeNextAnnotationEntryId() {
            return this.j++
        }
        getTermUsageCount(a) {
            return this.g.get(a) ? ? 0
        }
        incrementTermUsageCount(a) {
            var b = this.g.get(a) ? ? 0;
            this.g.set(a, b + 1)
        }
    };

    function bC(a) {
        a.google_reactive_ads_global_state ? (a.google_reactive_ads_global_state.sideRailProcessedFixedElements == null && (a.google_reactive_ads_global_state.sideRailProcessedFixedElements = new Set), a.google_reactive_ads_global_state.sideRailAvailableSpace == null && (a.google_reactive_ads_global_state.sideRailAvailableSpace = new Map), a.google_reactive_ads_global_state.sideRailPlasParam == null && (a.google_reactive_ads_global_state.sideRailPlasParam = new Map), a.google_reactive_ads_global_state.sideRailMutationCallbacks ==
            null && (a.google_reactive_ads_global_state.sideRailMutationCallbacks = []), a.google_reactive_ads_global_state.adIntentsPageState == null && (a.google_reactive_ads_global_state.adIntentsPageState = new aC)) : a.google_reactive_ads_global_state = new cC;
        return a.google_reactive_ads_global_state
    }
    var cC = class {
            constructor() {
                this.wasPlaTagProcessed = !1;
                this.wasReactiveAdConfigReceived = {};
                this.adCount = {};
                this.wasReactiveAdVisible = {};
                this.stateForType = {};
                this.reactiveTypeEnabledInAsfe = {};
                this.wasReactiveTagRequestSent = !1;
                this.reactiveTypeDisabledByPublisher = {};
                this.tagSpecificState = {};
                this.messageValidationEnabled = !1;
                this.floatingAdsStacking = new dC;
                this.sideRailProcessedFixedElements = new Set;
                this.sideRailAvailableSpace = new Map;
                this.sideRailPlasParam = new Map;
                this.sideRailMutationCallbacks = [];
                this.g =
                    null;
                this.clickTriggeredInterstitialMayBeDisplayed = !1;
                this.adIntentsPageState = new aC
            }
        },
        dC = class {
            constructor() {
                this.maxZIndexRestrictions = {};
                this.nextRestrictionId = 0;
                this.maxZIndexListeners = []
            }
        };
    var eC = class {
            constructor(a) {
                this.performance = a
            }
            pa() {
                return this.performance.now()
            }
        },
        fC = class {
            pa() {
                return Date.now()
            }
        };

    function gC(a) {
        return a ? nc(b => {
            try {
                if (b instanceof a) return !0;
                let c = b ? .ownerDocument ? .defaultView ? .[a.name];
                return qc(c) && b instanceof c
            } catch {
                return !1
            }
        }) : nc(() => !1)
    }
    gC(Node);
    var hC = gC(globalThis.Element),
        iC = gC(globalThis.HTMLElement);
    gC(globalThis.SVGElement);

    function jC() {
        return nc(a => iC(a) && a.tagName.toLowerCase() === "a")
    };

    function kC({
        xi: a,
        fh: b,
        Yh: c,
        yi: d,
        gh: e,
        Zh: f
    }) {
        var g = [];
        for (let n = 0; n < f; n++)
            for (let p = 0; p < c; p++) {
                var h = p,
                    k = c - 1,
                    l = n,
                    m = f - 1;
                g.push({
                    x: a + (k === 0 ? 0 : h / k) * (b - a),
                    y: d + (m === 0 ? 0 : l / m) * (e - d)
                })
            }
        return g
    }

    function lC(a, b) {
        a.hasOwnProperty("_goog_efp_called_") || (a._goog_efp_called_ = a.elementFromPoint(b.x, b.y));
        return a.elementFromPoint(b.x, b.y)
    };

    function mC(a, b, c) {
        var d = kC({
            xi: b.left,
            fh: b.right,
            Yh: 10,
            yi: b.top,
            gh: b.bottom,
            Zh: 10
        });
        b = new Set;
        for (let e of d)(d = nC(a, e, c)) && b.add(d);
        return b
    }

    function oC(a, b, c = !1) {
        for (let d of b)
            if (b = pC(a, d, c)) return b;
        return null
    }

    function qC(a, b, c = !1) {
        return oC(a, b, c) != null
    }

    function rC(a, b, c) {
        if (Lj(b, "position") !== "fixed") return null;
        var d = b.getAttribute("class") === "GoogleActiveViewInnerContainer" || Tj(b).width <= 1 && Tj(b).height <= 1 || a.g.he && !a.g.he(b) ? !0 : !1;
        a.g.qj && a.g.qj(b, c, d);
        return d ? null : b
    }

    function nC(a, b, c) {
        var d = lC(a.K.document, b);
        if (d) {
            var e;
            if (!(e = rC(a, d, b))) {
                if (c) a: {
                    for (d = sC(d); d && d !== a.K.document.body; d = sC(d))
                        if (c = rC(a, d, b)) {
                            a = c;
                            break a
                        }
                    a = null
                }
                else a: {
                    c = a.K.document;
                    for (d = d.offsetParent; d && d !== c.body; d = d.offsetParent)
                        if (e = rC(a, d, b)) {
                            a = e;
                            break a
                        }
                    a = null
                }
                e = a
            }
            a = e || null
        } else a = null;
        return a
    }

    function pC(a, b, c = !1) {
        b = nC(a, b);
        return !b || b.hasAttribute("google-allow-overlap") || c && (c = b.getBoundingClientRect(), c.width >= a.K.innerWidth && c.height >= a.K.innerHeight) ? null : b
    }
    var tC = class {
        constructor(a, b = {}) {
            this.K = a;
            this.g = b
        }
    };

    function sC(a) {
        return iC(a) ? a.offsetParent : a.parentElement
    };

    function uC({
        K: a,
        Sm: b,
        Km: c,
        ul: d,
        Fp: e,
        Gp: f,
        F: g,
        rm: h
    }) {
        var k = 0;
        try {
            k |= js(a, f);
            let n = Math.min(a.screen.width || 0, a.screen.height || 0);
            k |= n ? n < 320 ? 8192 : 0 : 2048;
            k |= a.navigator && vC(a.navigator.userAgent) ? 1048576 : 0;
            if (b) {
                f = k;
                let p = a.innerHeight;
                var l = Qk(a) * p >= b;
                var m = f | (l ? 0 : 1024)
            } else m = k | (a.innerHeight >= a.innerWidth ? 0 : 8);
            k = m;
            k |= ms(a, c, !0, e)
        } catch {
            k |= 32
        }
        switch (d) {
            case 2:
                wC(a, g, h) && (k |= 16777216);
                break;
            case 1:
                xC(a, g, h) && (k |= 16777216)
        }
        return k
    }

    function vC(a) {
        return /Android 2/.test(a) || /iPhone OS [34]_/.test(a) || /Windows Phone (?:OS )?[67]/.test(a) || /MSIE.*Windows NT/.test(a) || /Windows NT.*Trident/.test(a)
    }

    function wC(a, b = null, c = !1) {
        var d = kC({
            xi: 0,
            fh: a.innerWidth,
            Yh: 3,
            yi: 0,
            gh: Math.min(Math.round(a.innerWidth / 320 * 50), yC) + 15,
            Zh: 3
        });
        return zC(a, d, b, c)
    }

    function xC(a, b = null, c = !1) {
        var d = a.innerWidth,
            e = a.innerHeight,
            f = Math.min(Math.round(a.innerWidth / 320 * 50), yC) + 15,
            g = kC({
                xi: 0,
                fh: d,
                Yh: 3,
                yi: e - f,
                gh: e,
                Zh: 3
            });
        f > 25 && g.push({
            x: d - 25,
            y: e - 25
        });
        return zC(a, g, b, c)
    }

    function zC(a, b, c, d) {
        return qC(AC(a, c, e => e.getAttribute("google-anchor-overlappable") !== "true"), b, d)
    }

    function AC(a, b = null, c) {
        return new tC(a, {
            qj: BC(a, b),
            he: c
        })
    }

    function BC(a, b = null) {
        if (b) return (c, d, e) => {
            Hm(b, "ach_evt", {
                tn: c.tagName,
                id: c.getAttribute("id") ? ? "",
                cls: c.getAttribute("class") ? ? "",
                ign: String(e),
                pw: a.innerWidth,
                ph: a.innerHeight,
                x: d.x,
                y: d.y
            }, !0, 1)
        }
    }
    const yC = 90 * 1.38;
    var CC = class {
        constructor(a, b, c) {
            this.position = a;
            this.Le = b;
            this.g = c
        }
    };

    function DC(a, b) {
        this.start = a < b ? a : b;
        this.end = a < b ? b : a
    };

    function EC(a, b, c, d) {
        var e = ls(a);
        e = new CC(b.Rd.Rj(b.Fc), b.Le + 2 * b.Fc, Math.min(e, b.Lf) - b.Rd.uf() + 2 * b.Fc);
        e = e.position.hj(a, e.Le, e.g);
        var f = ks(a),
            g = ls(a);
        c = FC(a, new zj(si(e.top, g - 1), si(e.right, f - 1), si(e.bottom, g - 1), si(e.left, f - 1)), c, d);
        f = GC(c);
        g = e.top;
        d = [];
        for (let h = 0; h < f.length; h++) f[h].start > g && d.push(new DC(g, f[h].start)), g = f[h].end;
        g < e.bottom && d.push(new DC(g, e.bottom));
        a = ls(a);
        e = [];
        for (f = d.length - 1; f >= 0; f--) e.push(new DC(a - d[f].end, a - d[f].start));
        a: {
            for (let h of e) {
                b: {
                    a = h.start + b.Fc;
                    if (a > b.Rd.uf() +
                        b.Rh) {
                        a = null;
                        break b
                    }
                    e = Math.min(h.end - b.Fc, b.Lf) - a;a = e < b.Uh ? null : {
                        position: b.Rd.Bk(a),
                        te: e
                    }
                }
                if (a) {
                    b = a;
                    break a
                }
            }
            b = null
        }
        return {
            Bg: b,
            np: c
        }
    }

    function FC(a, b, c, d) {
        var e = mC(new tC(a), b, d);
        c.forEach(f => void e.delete(f));
        return e
    }

    function GC(a) {
        return [...a].map(HC).sort((b, c) => b.start - c.start)
    }

    function HC(a) {
        a = a.getBoundingClientRect();
        return new DC(a.top, a.bottom)
    };

    function IC({
        ta: a,
        jb: b
    }) {
        return new JC(a, b)
    }
    var JC = class {
        constructor(a, b) {
            this.ta = a;
            this.jb = b
        }
        Rj(a) {
            return new JC(this.ta - a, this.jb - a)
        }
        hj(a, b, c) {
            a = ls(a) - this.ta - c;
            return new zj(a, this.jb + b, a + c, this.jb)
        }
        Si(a) {
            a.bottom = `${this.ta}px`;
            a.left = `${this.jb}px`;
            a.right = ""
        }
        uj() {
            return 0
        }
        uf() {
            return this.ta
        }
        Bk(a) {
            return new JC(a, this.jb)
        }
    };

    function KC({
        ta: a,
        wb: b
    }) {
        return new LC(a, b)
    }
    var LC = class {
        constructor(a, b) {
            this.ta = a;
            this.wb = b
        }
        Rj(a) {
            return new LC(this.ta - a, this.wb - a)
        }
        hj(a, b, c) {
            var d = ks(a);
            a = ls(a) - this.ta - c;
            d = d - this.wb - b;
            return new zj(a, d + b, a + c, d)
        }
        Si(a) {
            a.bottom = `${this.ta}px`;
            a.right = `${this.wb}px`;
            a.left = ""
        }
        uj() {
            return 1
        }
        uf() {
            return this.ta
        }
        Bk(a) {
            return new LC(a, this.wb)
        }
    };

    function MC(a, b) {
        var c;
        a: {
            for (c = a.document.body; c; c = c.parentElement)
                if (c.classList.contains("google-anno-skip")) {
                    c = !1;
                    break a
                }
            c = b.ga >= 400
        }
        if (c)
            if ((c = NC(a, b)) != null) b = c;
            else a: {
                c = b.ba;
                var d = OC(a, b);a = 16;
                for (let e of d) {
                    d = e.start;
                    let f = e.end;
                    if (d > a) {
                        if (d - a - 16 >= 200) {
                            b = PC(b, d, a);
                            break a
                        }
                        a = f + 16
                    } else f >= a && (a = f + 16)
                }
                b = c - a - 16 >= 200 ? PC(b, c, a) : null
            }
        else b = null;
        return b
    }

    function NC(a, b) {
        var c = b.ka === b.X,
            d = QC(a, b, c);
        if (!d) return null;
        d = d.position.uf();
        a = RC(a, d, b, function(f) {
            f = f.getBoundingClientRect();
            return c ? b.ba - f.right : f.left
        });
        if (!a || a - 16 < 200) return null;
        var e = b.ba;
        return {
            jb: c ? e - a : 16,
            wb: c ? 16 : e - a,
            ta: d
        }
    }

    function SC(a, b) {
        var c = ks(a),
            d = ls(a);
        return mC(new tC(a, {
            he: e => e.id !== "google-anno-sa"
        }), new zj(d - b.ta - 50, c - b.wb, d - b.ta, b.jb), !0).size > 0
    }

    function QC(a, b, c) {
        b = Math.floor(b.ga * .3);
        if (b < 66) return null;
        c = c ? KC({
            ta: 16,
            wb: 16
        }) : IC({
            ta: 16,
            jb: 16
        });
        var d = a.document.getElementById("google-anno-sa");
        return EC(a, {
            Rd: c,
            Rh: b - 66,
            Le: 200,
            Uh: 50,
            Lf: b,
            Fc: 16
        }, d ? [a.document.body, d] : [a.document.body], !0).Bg
    }

    function RC(a, b, c, d) {
        a = c.ka ? TC(a, b, c) : UC(a, b, c);
        b = c.ba;
        var e = c.ka ? b : b * .35;
        a.forEach(f => {
            e = Math.min(e, d(f))
        });
        return e < 16 ? null : e - 16
    }

    function TC(a, b, c) {
        var d = c.ga;
        return mC(new tC(a, {
            he: e => e.id !== "google-anno-sa"
        }), new zj(d - b - 50, c.ba - 16, d - b, 16), !0)
    }

    function UC(a, b, c) {
        var d = c.ga,
            e = c.ba;
        c = c.X;
        return mC(new tC(a, {
            he: f => f.id !== "google-anno-sa"
        }), new zj(d - b - 50, (c ? e * .35 : e) - 16, d - b, (c ? 16 : e * .65) + 16), !0)
    }

    function PC(a, b, c) {
        var d = a.X;
        return {
            jb: d ? VC(a, b, c) : c,
            wb: d ? c : VC(a, b, c),
            ta: 16
        }
    }

    function VC(a, b, c) {
        var d = a.ba;
        return a.ka ? d - b + 16 : Math.max(d - c - d * .35, d - b + 16)
    }

    function OC(a, b) {
        var c = b.X,
            d = b.ba;
        return [...(b.ka ? TC(a, 16, b) : UC(a, 16, b))].map(e => new DC(c ? d - e.getBoundingClientRect().right : e.getBoundingClientRect().left, c ? d - e.getBoundingClientRect().left : e.getBoundingClientRect().right)).sort((e, f) => e.start - f.start)
    };

    function WC(a) {
        return a.M.gf || a.M.kg && E(a.T, 6) === 2 ? .4 : a.M.Wh
    }

    function XC(a, b, c, d, e) {
        var f = Bz(a, "span");
        f.id = "gda";
        f.appendChild(Kz(a, D(b.T, 18), e));
        Dz(f);
        YC(b, 1064, f, g => {
            d ? .();
            pj(c);
            g.preventDefault();
            g.stopImmediatePropagation();
            return !1
        });
        return f
    }

    function ZC(a, b, c, d, e, f, g) {
        var h = Bz(a, "span");
        J(h, {
            position: "absolute",
            top: "2.5px",
            bottom: "2.5px",
            left: (b.X(), "50px"),
            right: b.X() ? "24px" : "12px",
            display: "flex",
            "flex-direction": "row",
            color: f,
            cursor: "pointer",
            transition: "width 5s"
        });
        b.ka || J(h, {
            "justify-content": ""
        });
        var k = Iz(a, f),
            l = Bz(a, "span");
        J(l, {
            display: "inline-block",
            cursor: "inherit",
            "margin-left": b.X() ? "6px" : "4px",
            "margin-right": b.X() ? "4px" : "6px",
            "margin-top": "12px",
            "min-width": "initial"
        });
        h.appendChild(l);
        l.appendChild(k);
        c.classList ? .add("google-anno-sa-qtx",
            "google-anno-skip");
        c.tabIndex = 0;
        c.role = "link";
        c.ariaLive = "polite";
        c.ariaLabel = $C(d.g, b);
        J(c, {
            height: "40px",
            "align-items": "center",
            "line-height": "44px",
            "font-weight": "400",
            "font-style": "normal",
            "text-overflow": "ellipsis",
            "white-space": "nowrap",
            overflow: "hidden",
            "-webkit-tap-highlight-color": "transparent",
            color: f
        });
        b.M.Tb && g ? h.classList.add("google-anno-oc") : Dz(h);
        YC(b, 999, h, m => {
            m.preventDefault();
            if (!aD(e, b)) return !1;
            if ((d.A ? ? 0) + 800 <= b.pa(29)) {
                m = d.g;
                let q = b.D.get(m) || "";
                var n = bD(a, b, m);
                var p = vp(tp(m),
                    d.j);
                p = wf(p, 3, d.l);
                p = F(p, 9, 1);
                n = wp(p, n);
                n = b.g.qd(n);
                b.sa(1401, cD(e, a, b, n, m, q, 2, b.j.get(m) ? ? "", b.l.get(m) ? ? ""))
            }
            return !1
        });
        h.appendChild(c);
        return h
    }

    function dD(a, b, c, d, e, f) {
        var g = Bz(a, "div");
        g.id = "google-anno-sa";
        g.dir = b.X() ? "rtl" : "ltr";
        g.tabIndex = 0;
        g.setAttribute("google-side-rail-overlap", "true");
        g.setAttribute("google-anchor-overlappable", "true");
        var h = Gz(a, WC(b), {
            Xi: b.M.Vg,
            Yi: b.M.Wg,
            Zi: b.M.Xg
        });
        if (h) a: {
            if (WC(b)) {
                var k = a.document.querySelectorAll("p"),
                    l = [];
                for (var m = 0; m < Math.min(k.length, 2); m++) l.push(k[m]);
                k = xz(h);
                m = [k[0], k[1], k[2]];
                if (k[3] < 1) {
                    m = Az(a.document.body, b.M) || [255, 255, 255];
                    let p = k[3];
                    m = [Math.round(p * k[0] + (1 - p) * m[0]), Math.round(p *
                        k[1] + (1 - p) * m[1]), Math.round(p * k[2] + (1 - p) * m[2])]
                }
                for (n of l)
                    if ((l = yz(n)) && m && vz(l, m) >= 3) {
                        var n = a.getComputedStyle(n).color;
                        break a
                    }
            }
            n = null
        }
        else n = null;
        h = n ? h : null;
        n = n ? ? "#1A73E8";
        l = "#FFFFFF";
        h && (l = Az(a.document.body, b.M), l = `linear-gradient(${h}, ${h}), ${l?`rgb(${l[0]}, ${l[1]}, ${l[2]})`:"#FFFFFF"}`);
        J(g, {
            background: l,
            "border-style": "solid",
            bottom: W(d.ta),
            "border-radius": "16px",
            height: W(50),
            position: "fixed",
            "text-align": "center",
            border: "0px",
            left: W(d.jb),
            right: W(d.wb),
            "box-shadow": "0px 1px 2px rgba(0, 0, 0, 0.3), 0px 1px 3px 1px rgba(0, 0, 0, 0.15)",
            "z-index": "1000"
        });
        J(g, {
            fill: "white"
        });
        J(g, {
            color: n,
            cursor: "auto",
            "font-family": "Roboto",
            "font-size": "16px",
            "font-weight": "400",
            "font-style": "normal",
            overflow: "hidden",
            "text-align": "start",
            "text-orientation": "mixed",
            visibility: "visible",
            "writing-mode": "initial"
        });
        d = Bz(a, "span");
        J(d, {
            cursor: "inherit"
        });
        g.appendChild(ZC(a, b, d, c, f, n, eD(b, c.g)));
        g.appendChild(XC(a, b, g, e, n));
        return g
    }

    function fD(a, b, c) {
        var d = b.getElementsByClassName("google-anno-sa-qtx")[0];
        iC(d) && (d.innerText = a.g, d.ariaLabel = $C(a.g, c), b = b.getElementsByTagName("span")[0], c.M.Tb && eD(c, a.g) ? (b.classList.add("google-anno-oc"), b.removeAttribute("data-google-vignette"), b.removeAttribute("data-google-interstitial")) : (b.classList.remove("google-anno-oc"), Dz(b)));
        c = c.g;
        b = c.xg;
        d = new So;
        var e = a.j;
        d = we(d, 2, e == null ? e : zd(e, void 0));
        a = Kf(d, 4, a.g);
        return b.call(c, a)
    }

    function gD(a, b, c, d, e) {
        if (SC(b, d)) return null;
        a.A = c.pa(28);
        d = dD(b, c, a, d, () => {
            a.B = !0;
            var f = c.g,
                g = f.vg;
            var h = new Qo;
            h = If(h, 3, a.j);
            h = Kf(h, 2, a.g);
            g.call(f, h)
        }, e);
        e = fD(a, d, c);
        b.document.body.appendChild(d);
        return e
    }

    function hD(a, b, c, d, e, f, g, h) {
        if (!(a.B || a.g === e && a.j === d && a.C === f)) {
            if (a.l !== null) {
                var k = a.l,
                    l = c.g,
                    m = l.wg,
                    n = new Ro;
                k = xf(n, 1, k);
                m.call(l, k)
            }
            a.g = e;
            a.j = d;
            a.C = f;
            C(c.T, 17) || (d = b.document.getElementById("google-anno-sa"), a.l = d ? fD(a, d, c) : gD(a, b, c, g, h))
        }
    }

    function iD(a, b, c, d) {
        if (!a.B) {
            var e = b.document.getElementById("google-anno-sa");
            e && jD(d, b, () => {
                J(e, {
                    transition: "all 200ms ease-in-out",
                    bottom: W(c.ta),
                    left: W(c.jb),
                    right: W(c.wb)
                })
            })
        }
    }
    var kD = class {
        constructor() {
            this.g = "";
            this.j = null;
            this.C = "";
            this.l = null;
            this.B = !1;
            this.A = null
        }
    };

    function $C(a, b) {
        return D(b.T, 19).replace("TERM", a)
    };

    function lD(a, b, c = null) {
        a.l >= a.B.length && (a.l = 0, a.C++);
        a.C >= 3 || (c ? ? a.g.isDrawerVisible() ? a.g.Yc(() => void lD(a, b, !1)) : (c = a.B[a.l++], a.A = !1, hD(a.D, a.win, a.config, c.annotationId, c.searchTerm, c.g, a.j, a.g), a.config.uc(898, a.win, () => {
            lD(a, b)
        }, a.Ai)))
    }
    var mD = class {
        constructor(a, b, c, d, e) {
            var f = new kD;
            this.win = a;
            this.config = b;
            this.D = f;
            this.j = d;
            this.g = e;
            this.B = [];
            this.A = !0;
            this.C = this.l = 0;
            this.Ai = c.Ai
        }
    };
    class nD {
        constructor(a, b, c) {
            this.annotationId = a;
            this.searchTerm = b;
            this.g = c
        }
    };

    function oD(a) {
        return a.maximumAnnotationsPerPage > 0 && a.g.B >= a.maximumAnnotationsPerPage
    }
    var qD = class {
        constructor(a, b, c, d, e) {
            this.B = b;
            this.annotationsPerWindow = c;
            this.maximumAnnotationsPerPage = d;
            this.l = e;
            this.j = 0;
            this.g = new pD(a)
        }
    };

    function rD(a, b) {
        b -= a.A;
        for (let c of a.g.keys()) {
            let d = a.g.get(c),
                e = 0;
            for (; e < d.length && d[e] < b;) e++;
            a.j -= e;
            e > 0 && a.g.set(c, d.slice(e))
        }
    }
    class pD {
        constructor(a) {
            this.A = a;
            this.g = new Map;
            this.l = new Map;
            this.j = 0
        }
        get B() {
            return this.j
        }
    };

    function sD(a) {
        return a.M.gf || a.M.eh || a.M.kg && E(a.T, 6) === 2
    }

    function tD(a, b, c, d, e, f, g, h, k) {
        var l = Bz(a, "div");
        l.classList.add("google-anno-skip", "google-anno-sc");
        !k && b.M.Tb && eD(b, c) && l.classList.add("google-anno-oc");
        d = a.getComputedStyle(d).fontSize || "16px";
        if (h = sD(b) && !h) {
            var m = c.indexOf(" "),
                n = (k = m > 0) ? c.substring(0, m) : c;
            m = k ? c.substring(m + 1) : "";
            let p = Bz(a, "span");
            J(p, {
                "white-space": "nowrap",
                display: "inline-block",
                "padding-left": b.M.kb ? b.X() ? "0" : "6px" : "",
                "padding-right": b.M.kb ? b.X() ? "6px" : "0" : ""
            });
            p.appendChild(uD(a, d, b, f, h));
            p.appendChild(vD(a, b, n, !k));
            b.M.kb ||
                l.appendChild(a.document.createTextNode(" "));
            l.appendChild(p);
            m && l.appendChild(vD(a, b, m, !0))
        } else l.appendChild(uD(a, d, b, f, h)), k = l.appendChild, n = Bz(a, "span"), n.appendChild(a.document.createTextNode(c)), J(n, {
            position: "relative",
            left: b.X() ? "" : "3px",
            right: b.X() ? "3px" : "",
            "padding-left": b.X() ? "6px" : "",
            "padding-right": b.X() ? "" : "6px"
        }), k.call(l, n);
        if (h) {
            f = b.M.kb ? f : "inherit";
            g = "";
            if (b.M.ff || b.M.kb)
                if (d = a.document.querySelector("a")) g = a.getComputedStyle(d).color;
            b.M.ff && g && (f = g);
            J(l, {
                display: "inline",
                color: f,
                "font-family": "inherit",
                "font-weight": "inherit",
                "font-size": "inherit",
                "font-style": "inherit",
                background: "transparent",
                border: "none",
                "padding-left": "0",
                "padding-right": "0",
                "margin-top": "0",
                "margin-bottom": "0",
                "margin-inline-start": b.M.kb ? "0px" : "6px",
                "margin-inline-end": "0",
                cursor: "pointer"
            });
            b.M.kb && J(l, {
                "background-image": `linear-gradient(${e}, ${e})`,
                "border-radius": "20px",
                "padding-top": W(2),
                "padding-bottom": W(2),
                "padding-left": "",
                "padding-right": "",
                "box-shadow": `${b.X()?"-3px":"3px"} 0 0 0 ${e}`
            })
        } else J(l, {
            display: "inline-block",
            "border-radius": "20px",
            "padding-left": b.X() ? "7px" : "6px",
            "padding-right": b.X() ? "6px" : "7px",
            "padding-top": "3px",
            "padding-bottom": "3px",
            "border-width": "1px",
            "border-style": "solid",
            color: f,
            "font-family": "Roboto",
            "font-weight": "500",
            "font-size": d,
            "border-color": "#D7D7D7",
            background: e,
            cursor: "pointer",
            "margin-top": "-3px",
            height: "min-content"
        }), g && J(l, {
            margin: `${W(-3)} 0`,
            "padding-top": W(2),
            "padding-bottom": W(2)
        });
        l.tabIndex = 0;
        l.role = "link";
        l.ariaLabel = c;
        return l
    }

    function uD(a, b, c, d, e) {
        b = Jz(a, b, d);
        e ? J(b, {
            "vertical-align": "middle"
        }) : J(b, {
            position: "relative",
            top: "3px"
        });
        a = Bz(a, "span");
        J(a, {
            display: e ? "inline" : "inline-block",
            "padding-left": c.X() ? "" : e ? "0" : "3px",
            "padding-right": c.X() ? e ? "0" : "3px" : "",
            "white-space": e ? "nowrap" : ""
        });
        a.appendChild(b);
        return a
    }

    function vD(a, b, c, d) {
        var e = Bz(a, "span");
        e.appendChild(a.document.createTextNode(c));
        J(e, {
            "margin-left": b.X() ? "" : "3px",
            "margin-right": b.X() ? "3px" : "",
            "text-decoration": b.M.kb ? "" : "underline dotted",
            "-webkit-text-decoration": b.M.kb ? "" : "underline dotted",
            "padding-left": d && b.X() ? "6px" : "",
            "padding-right": d && !b.X() ? "6px" : ""
        });
        return e
    }

    function wD(a, b, c, d) {
        c = xz(c);
        d = yz(d);
        var e;
        if (e = d !== null) {
            e = c[0];
            var f = c[1],
                g = c[2];
            c = c[3];
            c === 1 ? a = [e, f, g] : (a = Az(a.document.body, b.M) ? ? [255, 255, 255], a = [Math.round(c * e + (1 - c) * a[0]), Math.round(c * f + (1 - c) * a[1]), Math.round(c * g + (1 - c) * a[2])]);
            e = vz(d, a) >= 3
        }
        return e
    }

    function xD(a, b) {
        return Gz(a, b.M.kb, {
            Xi: b.M.Zg,
            Yi: b.M.ah,
            Zi: b.M.bh
        })
    };
    var yD = class {
        constructor() {
            this.g = []
        }
    };

    function zD(a, b) {
        return new AD(a, b)
    }

    function BD(a) {
        var b = CD(a);
        ab(a.floatingAdsStacking.maxZIndexListeners, c => c(b))
    }

    function CD(a) {
        a = Gk(a.floatingAdsStacking.maxZIndexRestrictions);
        return a.length ? Math.min.apply(null, a) : null
    }

    function DD(a, b) {
        kb(a.floatingAdsStacking.maxZIndexListeners, c => c === b)
    }
    var ED = class {
        constructor(a) {
            this.floatingAdsStacking = bC(a).floatingAdsStacking
        }
    };

    function FD(a) {
        if (a.g == null) {
            var b = a.controller,
                c = a.Tc;
            let d = b.floatingAdsStacking.nextRestrictionId++;
            b.floatingAdsStacking.maxZIndexRestrictions[d] = c;
            BD(b);
            a.g = d
        }
    }

    function GD(a) {
        if (a.g != null) {
            var b = a.controller;
            delete b.floatingAdsStacking.maxZIndexRestrictions[a.g];
            BD(b);
            a.g = null
        }
    }
    var AD = class {
        constructor(a, b) {
            this.controller = a;
            this.Tc = b;
            this.g = null
        }
    };

    function HD(a) {
        a = a.activeElement;
        var b = a ? .shadowRoot;
        return b ? HD(b) || a : a
    }

    function ID(a, b) {
        return JD(b, a.document.body).flatMap(c => KD(c))
    }

    function JD(a, b) {
        var c = a;
        for (a = []; c && c !== b;) {
            a.push(c);
            let e;
            var d;
            (d = c.parentElement) || (c = c.getRootNode(), d = ((e = c.mode && c.host ? c : null) == null ? void 0 : e.host) || null);
            c = d
        }
        return c !== b ? [] : a
    }

    function KD(a) {
        var b = a.parentElement;
        return b ? Array.from(b.children).filter(c => c !== a) : []
    };

    function LD(a) {
        a.state !== null && (a.state.Sl.forEach(b => {
            b.inert = !1
        }), a.state.ln ? .focus(), a.state = null)
    }

    function MD(a, b) {
        LD(a);
        var c = HD(a.win.document);
        b = ID(a.win, b).filter(d => !d.inert);
        b.forEach(d => {
            d.inert = !0
        });
        a.state = {
            ln: c,
            Sl: b
        }
    }
    var ND = class {
        constructor(a) {
            this.win = a;
            this.state = null
        }
    };

    function OD(a) {
        return new PD(a, new At(a, a.document.body), new At(a, a.document.documentElement), new At(a, a.document.documentElement))
    }

    function QD(a) {
        zt(a.l, "scroll-behavior", "auto");
        var b = RD(a.win);
        b.activePageScrollPreventers.add(a);
        b.previousWindowScroll === null && (b.previousWindowScroll = a.win.scrollY);
        zt(a.g, "position", "fixed");
        zt(a.g, "top", `${-b.previousWindowScroll}px`);
        zt(a.g, "width", "100%");
        zt(a.g, "overflow-x", "hidden");
        zt(a.g, "overflow-y", "hidden");
        b = getComputedStyle(a.win.document.documentElement);
        SD(b.overflowX) && zt(a.j, "overflow-x", "unset");
        SD(b.overflowY) && zt(a.j, "overflow-y", "unset")
    }

    function SD(a) {
        return a === "scroll" || a === "auto"
    }

    function TD(a) {
        yt(a.g);
        yt(a.j);
        var b = RD(a.win);
        b.activePageScrollPreventers.delete(a);
        b.activePageScrollPreventers.size === 0 && (a.win.scrollTo(0, b.previousWindowScroll || 0), b.previousWindowScroll = null);
        yt(a.l)
    }
    var PD = class {
        constructor(a, b, c, d) {
            this.win = a;
            this.g = b;
            this.j = c;
            this.l = d
        }
    };

    function RD(a) {
        return a.googPageScrollPreventerInfo = a.googPageScrollPreventerInfo || {
            previousWindowScroll: null,
            activePageScrollPreventers: new Set
        }
    }

    function UD(a) {
        return a.googPageScrollPreventerInfo && a.googPageScrollPreventerInfo.activePageScrollPreventers.size > 0 ? !0 : !1
    };

    function VD(a, b) {
        return WD(`#${a}`, b)
    }

    function XD(a, b) {
        return WD(`.${a}`, b)
    }

    function WD(a, b) {
        b = b.querySelector(a);
        if (!b) throw Error(`Element (${a}) does not exist`);
        return b
    };

    function YD(a, b) {
        var c = a.document.createElement("div");
        J(c, rz(a));
        a = c.attachShadow({
            mode: "open"
        });
        b && c.classList.add(b);
        return {
            wc: c,
            shadowRoot: a
        }
    };

    function ZD(a, b) {
        b = YD(a, b);
        a.document.body.appendChild(b.wc);
        return b
    }

    function $D(a, b) {
        var c = new Ct(b.V);
        Lt(b, !0, () => void c.g(!0));
        Lt(b, !1, () => {
            a.setTimeout(() => {
                b.V || c.g(!1)
            }, 700)
        });
        return Gt(c)
    };

    function aE(a, b, c, d) {
        a = a && a.rb;
        return wy("<style" + (a ? ' nonce="' + R($y(a)) + '"' : "") + ">.drawer-close-button {float: " + T(d ? "left" : "right") + '; border: none; background: none; cursor: pointer;}</style><button id="' + R(b) + '" class="drawer-close-button" aria-label="' + R(c) + '"><svg xmlns="http://www.w3.org/2000/svg" height="24" width="24" fill="#5f6368"><path d="M6.4 19 5 17.6 10.6 12 5 6.4 6.4 5 12 10.6 17.6 5 19 6.4 13.4 12 19 17.6 17.6 19 12 13.4Z"/></svg></button>')
    };

    function bE(a) {
        var b = {},
            c = a.tf,
            d = a.mi,
            e = a.pf,
            f = a.Gc,
            g = a.Ui,
            h = a.zIndex;
        a = a.yg;
        var k = b && b.rb;
        c = Sy(Vy(), "<style" + (k ? ' nonce="' + R($y(k)) + '"' : "") + ">#hd-drawer-container {position: fixed; left: 0; top: 0; width: 100vw; height: 100%; overflow: hidden; z-index: " + T(h) + "; pointer-events: none;}#hd-drawer-container.hd-revealed {pointer-events: auto;}#hd-modal-background {position: absolute; left: 0; bottom: 0; background-color: black; transition: opacity .5s ease-in-out; width: 100%; height: 100%; opacity: 0;}.hd-revealed > #hd-modal-background {opacity: 0.5;}#hd-drawer {position: absolute; top: 0; height: 100%; width: " +
            T(c) + "; background-color: white; display: flex; flex-direction: column; box-sizing: border-box; padding-bottom: ");
        d = d ? 20 : 0;
        Sy(Ty(Sy(c, T(d) + "px; transition: transform " + T(a) + "s ease-in-out;" + (e ? "left: 0; border-top-right-radius: " + T(d) + "px; border-bottom-right-radius: " + T(d) + "px; transform: translateX(-100%);" : "right: 0; border-top-left-radius: " + T(d) + "px; border-bottom-left-radius: " + T(d) + "px; transform: translateX(100%);") + "}.hd-revealed > #hd-drawer {transform: translateY(0);}#hd-control-bar {height: 24px;}.hd-control-button {border: none; background: none; cursor: pointer;}#hd-back-arrow-button {" +
            (e ? "float: right;" : "float: left;") + '}#hd-content-container {flex-grow: 1; overflow: auto;}#hd-content-container::-webkit-scrollbar * {background: transparent;}.hd-hidden {visibility: hidden;}</style><div id="hd-drawer-container" class="hd-hidden" aria-modal="true" role="dialog" tabindex="0"><div id="hd-modal-background"></div><div id="hd-drawer"><div id="hd-control-bar"><button id="hd-back-arrow-button" class="hd-control-button hd-hidden" aria-label="' + R(g) + '"><svg xmlns="http://www.w3.org/2000/svg" height="24" width="24" fill="' +
            R("#5f6368") + '"><path d="m12 20-8-8 8-8 1.425 1.4-5.6 5.6H20v2H7.825l5.6 5.6Z"/></svg></button>'), aE(b, "hd-close-button", f, e)), '</div><div id="hd-content-container"></div></div></div>');
        return c
    };

    function cE(a) {
        a = a.top;
        if (!a) return null;
        try {
            var b = a.history
        } catch (c) {
            b = null
        }
        b = b && qc(b.pushState) ? b : null;
        if (!b) return null;
        if (a.googNavStack) return a.googNavStack;
        b = new dE(a, b);
        b.init();
        return b ? a.googNavStack = b : null
    }

    function eE(a, b) {
        return b ? b.googNavStackId === a.j ? b : null : null
    }

    function fE(a, b) {
        for (let c = b.length - 1; c >= 0; --c) {
            let d = c === 0;
            a.K.requestAnimationFrame(() => void b[c].yn({
                isFinal: d
            }))
        }
    }

    function gE(a, b) {
        b = ob(a.stack, b, (c, d) => c - d.Aj.googNavStackStateId);
        if (b >= 0) return a.stack.splice(b, a.stack.length - b);
        b = -b - 1;
        return a.stack.splice(b, a.stack.length - b)
    }
    class dE extends O {
        constructor(a, b) {
            super();
            this.K = a;
            this.history = b;
            this.stack = [];
            this.j = Math.random() * 1E9 >>> 0;
            this.A = 0;
            this.l = c => {
                (c = eE(this, c.state)) ? fE(this, gE(this, c.googNavStackStateId + .5)): fE(this, this.stack.splice(0, this.stack.length))
            }
        }
        pushEvent() {
            var a = {
                    googNavStackId: this.j,
                    googNavStackStateId: this.A++
                },
                b = new Promise(c => {
                    this.stack.push({
                        yn: c,
                        Aj: a
                    })
                });
            this.history.pushState(a, "");
            return {
                navigatedBack: b,
                triggerNavigateBack: () => {
                    var c = gE(this, a.googNavStackStateId),
                        d;
                    if (d = c.length > 0) {
                        d = c[0].Aj;
                        let e = eE(this, this.history.state);
                        d = e && e.googNavStackId === d.googNavStackId && e.googNavStackStateId === d.googNavStackStateId
                    }
                    d && this.history.go(-c.length);
                    fE(this, c)
                }
            }
        }
        init() {
            this.K.addEventListener("popstate", this.l)
        }
        g() {
            this.K.removeEventListener("popstate", this.l);
            super.g()
        }
    };

    function hE(a) {
        return (a = cE(a)) ? new iE(a) : null
    }

    function jE(a) {
        if (!a.j) {
            var {
                navigatedBack: b,
                triggerNavigateBack: c
            } = a.A.pushEvent();
            a.j = c;
            b.then(() => {
                a.j && !a.B && (a.j = null, Qt(a.l))
            })
        }
    }
    var iE = class extends O {
        constructor(a) {
            super();
            this.A = a;
            this.l = new Rt;
            this.j = null
        }
    };

    function kE(a, b, c) {
        var d = new ND(a),
            e = zD(new ED(a), c.zIndex - 1);
        b = lE(a, b, c);
        d = new mE(a, b, d, OD(a), e);
        d.init();
        (c.mj || c.mj === void 0) && nE(d);
        c.ie && ((a = hE(a)) ? oE(d, a, c.Xh) : c.Xh ? .(Error("Unable to create closeNavigator")));
        return d
    }

    function nE(a) {
        a.C = b => {
            b.key === "Escape" && a.j.V && a.collapse()
        };
        a.win.document.body.addEventListener("keydown", a.C)
    }

    function oE(a, b, c) {
        Lt(a.j, !0, () => {
            try {
                jE(b)
            } catch (d) {
                c ? .(d)
            }
        });
        Lt(a.j, !1, () => {
            try {
                b.j && (b.j(), b.j = null)
            } catch (d) {
                c ? .(d)
            }
        });
        Ot(b.l).listen(() => void a.collapse());
        wt(a, b)
    }

    function pE(a) {
        if (a.B) throw Error("Accessing domItems after disposal");
        return a.D
    }

    function qE(a) {
        a.win.setTimeout(() => {
            a.j.V && pE(a).yb.focus()
        }, 500)
    }

    function rE(a) {
        var {
            Vh: b,
            yl: c
        } = pE(a);
        b.addEventListener("click", () => void a.collapse());
        c.addEventListener("click", () => void a.collapse())
    }

    function sE(a) {
        Lt(a.l, !1, () => {
            pE(a).yb.classList.add("hd-hidden")
        })
    }
    var mE = class extends O {
        constructor(a, b, c, d, e) {
            super();
            this.win = a;
            this.D = b;
            this.A = c;
            this.j = new Ct(!1);
            this.l = $D(a, this.j);
            Lt(this.l, !0, () => {
                QD(d);
                FD(e)
            });
            Lt(this.l, !1, () => {
                TD(d);
                GD(e)
            })
        }
        show({
            jj: a = !1
        } = {}) {
            if (this.B) throw Error("Cannot show drawer after disposal");
            pE(this).yb.classList.remove("hd-hidden");
            ut(this.win);
            pE(this).yb.classList.add("hd-revealed");
            this.j.g(!0);
            MD(this.A, pE(this).xc.wc);
            qE(this);
            a && Lt(this.l, !1, () => {
                this.dispose()
            })
        }
        collapse() {
            pE(this).yb.classList.remove("hd-revealed");
            this.j.g(!1);
            LD(this.A)
        }
        isVisible() {
            return this.l
        }
        init() {
            rE(this);
            sE(this)
        }
        g() {
            this.C && this.win.document.body.removeEventListener("keydown", this.C);
            var a = this.D.xc.wc,
                b = a.parentNode;
            b && b.removeChild(a);
            LD(this.A);
            super.g()
        }
    };

    function lE(a, b, c) {
        var d = ZD(a, c.Sg),
            e = d.shadowRoot;
        e.appendChild(yj(new hj(a.document), bE({
            tf: c.tf,
            mi: c.mi ? ? !0,
            pf: c.pf || !1,
            Gc: c.Gc,
            Ui: c.Ui || "",
            zIndex: c.zIndex,
            yg: .5
        }).Fb()));
        var f = VD("hd-drawer-container", e);
        c.Ug ? .j(g => {
            f.setAttribute("aria-label", g)
        });
        c = VD("hd-content-container", e);
        c.appendChild(b);
        ut(a);
        return {
            yb: f,
            Vh: VD("hd-modal-background", e),
            Ig: c,
            yl: VD("hd-close-button", e),
            qp: VD("hd-back-arrow-button", e),
            xc: d
        }
    };

    function tE(a) {
        var b = {},
            c = a.en,
            d = a.jm,
            e = a.zIndex,
            f = a.yg,
            g = a.cf,
            h = a.X;
        a = a.Gc;
        var k = b && b.rb;
        return Sy(Ty(Ty(Sy(Ty(Ty(Sy(Vy(), "<style" + (k ? ' nonce="' + R($y(k)) + '"' : "") + ">#ved-drawer-container {position:  fixed; left: 0; top: 0; width: 100vw; height: 100%; overflow: hidden; z-index: " + T(e) + "; pointer-events: none;}#ved-drawer-container.ved-revealed {pointer-events: auto;}#ved-modal-background {position: absolute; left: 0; bottom: 0; background-color: black; transition: opacity .5s ease-in-out; width: 100%; height: 100%; opacity: 0;}.ved-revealed > #ved-modal-background {opacity: 0.5;}#ved-ui-revealer {position: absolute; left: 0; bottom: 0; width: 100%; height: " +
                T(d) + "%; transition: transform " + T(f) + "s ease-in-out; transform: translateY(100%);}#ved-ui-revealer.ved-no-animation {transition-property: none;}.ved-revealed > #ved-ui-revealer {transform: translateY(0);}#ved-scroller-container {position: absolute; left: 0; bottom: 0; width: 100%; height: 100%; clip-path: inset(0 0 -50px 0 round " + T(20) + "px);}#ved-scroller {position: relative; width: 100%; height: 100%; overflow-y: scroll; -ms-overflow-style: none; scrollbar-width: none; overflow-y: scroll; overscroll-behavior: none; scroll-snap-type: y mandatory;}#ved-scroller.ved-scrolling-paused {overflow: hidden;}#ved-scroller.ved-no-snap {scroll-snap-type: none;}#ved-scroller::-webkit-scrollbar {display: none;}#ved-scrolled-stack {width: 100%; height: 100%; overflow: visible;}#ved-scrolled-stack.ved-with-background {background-color: white;}.ved-snap-point-top {scroll-snap-align: start;}.ved-snap-point-bottom {scroll-snap-align: end;}#ved-fully-closed-anchor {height: " +
                T(c / d * 100) + "%;}.ved-with-background #ved-fully-closed-anchor {background-color: white;}#ved-partially-extended-anchor {height: " + T((d - c) / d * 100) + "%;}.ved-with-background #ved-partially-extended-anchor {background-color: white;}#ved-moving-handle-holder {scroll-snap-stop: always;}.ved-with-background #ved-moving-handle-holder {background-color: white;}#ved-fixed-handle-holder {position: absolute; left: 0; top: 0; width: 100%;}#ved-visible-scrolled-items {display: flex; flex-direction: column; min-height: " +
                T(c / d * 100) + "%;}#ved-content-background {width: 100%; flex-grow: 1; padding-top: 1px; margin-top: -1px; background-color: white;}#ved-content-sizer {overflow: hidden; width: 100%; height: 100%;}#ved-content-container {width: 100%;}#ved-over-scroll-block {display: flex; flex-direction: column; position: absolute; bottom: 0; left: 0; width: 100%; height: " + T(c / d * 100) + "%; pointer-events: none;}#ved-over-scroll-handle-spacer {height: " + T(80) + "px;}#ved-over-scroll-background {flex-grow: 1; background-color: white;}.ved-handle {align-items: flex-end; border-radius: " +
                T(20) + "px " + T(20) + "px 0 0; background: white; display: flex; height: " + T(30) + 'px; justify-content: center; cursor: grab;}.ved-handle-icon {background: #dadce0; width: 50px; border-radius: 2px; height: 4px; margin-bottom: 8px;}.ved-hidden {visibility: hidden;}#ved-moving-close-button, #ved-fixed-close-button {margin-top: -29px;}</style><div id="ved-drawer-container" class="ved-hidden" aria-modal="true" role="dialog" tabindex="0"><div id="ved-modal-background"></div><div id="ved-ui-revealer"><div id="ved-over-scroll-block" class="ved-hidden"><div id=\'ved-over-scroll-handle-spacer\'></div><div id=\'ved-over-scroll-background\'></div></div><div id="ved-scroller-container"><div id="ved-scroller"><div id="ved-scrolled-stack"><div id="ved-fully-closed-anchor" class="ved-snap-point-top"></div><div id="ved-partially-extended-anchor" class="ved-snap-point-top"></div><div id="ved-visible-scrolled-items"><div id="ved-moving-handle-holder" class="ved-snap-point-top">'),
            uE("ved-moving-handle")), g ? aE(b, "ved-moving-close-button", a, h) : ""), '</div><div id="ved-content-background"><div id="ved-content-sizer" class="ved-snap-point-bottom"><div id="ved-content-container"></div></div></div></div></div></div></div><div id="ved-fixed-handle-holder" class="ved-hidden">'), uE("ved-fixed-handle")), g ? aE(b, "ved-fixed-close-button", a, h) : ""), "</div></div></div>")
    }

    function uE(a) {
        return wy('<div class="ved-handle" id="' + R(a) + '"><div class="ved-handle-icon"></div></div>')
    };

    function vE(a) {
        return eu(a.g).map(b => b ? wE(a, b) : 0)
    }

    function wE(a, b) {
        switch (a.direction) {
            case 0:
                return xE(-b.Dk);
            case 1:
                return xE(-b.Ck);
            default:
                throw Error(`Unhandled direction: ${a.direction}`);
        }
    }

    function yE(a) {
        return gu(a.g).map(b => wE(a, b))
    }
    var zE = class {
        constructor(a) {
            this.g = a;
            this.direction = 0
        }
    };

    function xE(a) {
        return a === 0 ? 0 : a
    };

    function AE(a) {
        if (a.B) throw Error("Accessing domItems after disposal");
        return a.D
    }

    function BE(a) {
        a.win.setTimeout(() => {
            a.j.V && AE(a).yb.focus()
        }, 500)
    }

    function CE(a) {
        AE(a).yb.classList.remove("ved-hidden");
        ut(a.win);
        var {
            Ra: b,
            tc: c
        } = AE(a);
        c.getBoundingClientRect().top <= b.getBoundingClientRect().top || DE(a);
        AE(a).yb.classList.add("ved-revealed");
        a.j.g(!0);
        MD(a.A, AE(a).xc.wc);
        BE(a)
    }

    function EE(a, b) {
        var c = new Ct(b());
        Ot(a.J).listen(() => void c.g(b()));
        return Gt(c)
    }

    function FE(a) {
        var {
            Ra: b,
            Nf: c
        } = AE(a);
        return EE(a, () => c.getBoundingClientRect().top <= b.getBoundingClientRect().top)
    }

    function GE(a) {
        var {
            Ra: b,
            Nf: c
        } = AE(a);
        return EE(a, () => c.getBoundingClientRect().top <= b.getBoundingClientRect().top - 1)
    }

    function HE(a) {
        var {
            Ra: b
        } = AE(a);
        return EE(a, () => b.scrollTop === b.scrollHeight - b.clientHeight)
    }

    function IE(a) {
        return Ht(FE(a), HE(a))
    }

    function JE(a) {
        var {
            Ra: b,
            tc: c
        } = AE(a);
        return EE(a, () => c.getBoundingClientRect().top < b.getBoundingClientRect().top - 1)
    }

    function DE(a) {
        AE(a).tc.classList.add("ved-snap-point-top");
        var b = KE(a, AE(a).tc);
        AE(a).Ra.scrollTop = b;
        LE(a)
    }

    function ME(a) {
        Jt(FE(a), !0, () => {
            var {
                rj: b,
                Ee: c
            } = AE(a);
            b.classList.remove("ved-hidden");
            c.classList.add("ved-with-background")
        });
        Jt(FE(a), !1, () => {
            var {
                rj: b,
                Ee: c
            } = AE(a);
            b.classList.add("ved-hidden");
            c.classList.remove("ved-with-background")
        })
    }

    function NE(a) {
        var b = ku(a.win, AE(a).Ig);
        nu(b).j(() => void OE(a));
        wt(a, b)
    }

    function PE(a) {
        Jt(QE(a), !0, () => {
            AE(a).Xj.classList.remove("ved-hidden")
        });
        Jt(QE(a), !1, () => {
            AE(a).Xj.classList.add("ved-hidden")
        })
    }

    function RE(a) {
        var b = () => void Qt(a.G),
            {
                Vh: c,
                tc: d,
                im: e,
                Tm: f,
                fm: g
            } = AE(a);
        c.addEventListener("click", b);
        d.addEventListener("click", b);
        e.addEventListener("click", b);
        f && f.addEventListener("click", b);
        g && g.addEventListener("click", b);
        Lt(SE(a), !0, b)
    }

    function TE(a) {
        Lt(a.isDrawerVisible(), !1, () => {
            DE(a);
            AE(a).yb.classList.add("ved-hidden")
        })
    }

    function LE(a) {
        Kt(a.l, !1, () => void Qt(a.J))
    }

    function OE(a) {
        if (!a.l.V) {
            var {
                fj: b,
                Ig: c
            } = AE(a), d = c.getBoundingClientRect().height;
            d = Math.max(UE(a), d);
            a.l.g(!0);
            var e = VE(a);
            b.style.setProperty("height", `${d}px`);
            e();
            a.win.requestAnimationFrame(() => {
                a.win.requestAnimationFrame(() => {
                    a.l.g(!1)
                })
            })
        }
    }

    function QE(a) {
        var {
            Ra: b,
            tc: c
        } = AE(a);
        return EE(a, () => c.getBoundingClientRect().top <= b.getBoundingClientRect().top)
    }

    function SE(a) {
        return Ft(a.C.map(Qu), WE(a))
    }

    function WE(a) {
        return EE(a, () => AE(a).Ra.scrollTop === 0)
    }

    function KE(a, b) {
        ({
            Ee: a
        } = AE(a));
        a = a.getBoundingClientRect().top;
        return b.getBoundingClientRect().top - a
    }

    function XE(a, b) {
        a.C.g(!0);
        var {
            Ee: c,
            Ra: d
        } = AE(a);
        d.scrollTop = 0;
        d.classList.add("ved-scrolling-paused");
        c.style.setProperty("margin-top", `-${b}px`);
        return () => void YE(a, b)
    }

    function YE(a, b) {
        var {
            Ee: c,
            Ra: d
        } = AE(a);
        c.style.removeProperty("margin-top");
        d.classList.remove("ved-scrolling-paused");
        AE(a).Ra.scrollTop = b;
        LE(a);
        a.C.g(!1)
    }

    function VE(a) {
        var b = AE(a).Ra.scrollTop;
        XE(a, b);
        return () => void YE(a, b)
    }

    function UE(a) {
        var {
            Ra: b,
            Nf: c,
            fj: d,
            tc: e
        } = AE(a);
        a = b.getBoundingClientRect();
        var f = c.getBoundingClientRect(),
            g = d.getBoundingClientRect(),
            h = e.getBoundingClientRect();
        g = g.top - f.top;
        return Math.max(a.height - h.height - g, Math.min(a.height, a.bottom - f.top) - g)
    }
    var ZE = class extends O {
        constructor(a, b, c, d) {
            super();
            this.win = a;
            this.D = b;
            this.P = c;
            this.A = d;
            this.G = new Rt;
            this.J = new Rt;
            this.j = new Ct(!1);
            this.C = new Ct(!1);
            this.l = new Ct(!1)
        }
        isDrawerVisible() {
            return $D(this.win, this.j)
        }
        init() {
            DE(this);
            ME(this);
            NE(this);
            PE(this);
            RE(this);
            TE(this);
            AE(this).Ra.addEventListener("scroll", () => void LE(this))
        }
        g() {
            var a = this.D.xc.wc,
                b = a.parentNode;
            b && b.removeChild(a);
            LD(this.A);
            super.g()
        }
    };

    function $E(a, b, c) {
        var d = ZD(a, c.Sg),
            e = d.shadowRoot;
        e.appendChild(yj(new hj(a.document), tE({
            en: c.ck * 100,
            jm: c.sj * 100,
            zIndex: c.zIndex,
            yg: .5,
            cf: c.cf ? ? !1,
            X: c.X || !1,
            Gc: c.Gc || ""
        }).Fb()));
        var f = VD("ved-drawer-container", e);
        c.Ug ? .j(h => {
            f.setAttribute("aria-label", h)
        });
        var g = VD("ved-content-container", e);
        g.appendChild(b);
        ut(a);
        return {
            yb: f,
            Vh: VD("ved-modal-background", e),
            yk: VD("ved-ui-revealer", e),
            Ra: VD("ved-scroller", e),
            Ee: VD("ved-scrolled-stack", e),
            im: VD("ved-fully-closed-anchor", e),
            tc: VD("ved-partially-extended-anchor",
                e),
            fj: VD("ved-content-sizer", e),
            Ig: g,
            Tm: c.cf ? VD("ved-moving-close-button", e) : void 0,
            zp: VD("ved-moving-handle", e),
            Nf: VD("ved-moving-handle-holder", e),
            fm: c.cf ? VD("ved-fixed-close-button", e) : void 0,
            gm: VD("ved-fixed-handle", e),
            rj: VD("ved-fixed-handle-holder", e),
            Xj: VD("ved-over-scroll-block", e),
            xc: d
        }
    };

    function aF(a, b, c) {
        var d = zD(new ED(a), c.zIndex - 1);
        b = $E(a, b, c);
        var e = new ND(a);
        var f = b.gm;
        f = new hu(new Zt(a, f), new Wt(f));
        var g = f.g;
        g.A.addEventListener("mousedown", g.O);
        g.B.addEventListener("mouseup", g.C);
        g.B.addEventListener("mousemove", g.D, {
            passive: !1
        });
        g = f.j;
        g.j.addEventListener("touchstart", g.D);
        g.j.addEventListener("touchend", g.A);
        g.j.addEventListener("touchmove", g.C, {
            passive: !1
        });
        b = new ZE(a, b, new zE(f), e);
        b.init();
        d = new bF(a, b, OD(a), d);
        wt(d, b);
        d.init();
        c.ie && ((a = hE(a)) ? cF(d, a, c.Xh) : c.Xh ? .(Error("Unable to create closeNavigator")));
        return d
    }

    function cF(a, b, c) {
        Lt(a.j.j, !0, () => {
            try {
                jE(b)
            } catch (d) {
                c ? .(d)
            }
        });
        Lt(a.j.j, !1, () => {
            try {
                b.j && (b.j(), b.j = null)
            } catch (d) {
                c ? .(d)
            }
        });
        Ot(b.l).listen(() => void a.collapse());
        wt(a, b)
    }

    function dF(a) {
        Lt(Ft(IE(a.j), JE(a.j)), !0, () => {
            AE(a.j).tc.classList.remove("ved-snap-point-top")
        });
        Jt(GE(a.j), !0, () => {
            AE(a.j).Ra.classList.add("ved-no-snap")
        });
        Jt(GE(a.j), !1, () => {
            AE(a.j).Ra.classList.remove("ved-no-snap")
        });
        Lt(GE(a.j), !1, () => {
            var b = a.j;
            var c = AE(b).Nf;
            c = XE(b, KE(b, c));
            b.win.setTimeout(c, 100)
        })
    }

    function eF(a) {
        var b = a.j.P;
        vE(b).listen(c => {
            c = -c;
            if (c > 0) {
                let {
                    yk: d
                } = AE(a.j);
                d.classList.add("ved-no-animation");
                d.style.setProperty("transform", `translateY(${c}px)`)
            } else({
                yk: c
            } = AE(a.j)), c.classList.remove("ved-no-animation"), c.style.removeProperty("transform")
        });
        yE(b).listen(c => {
            -c > 30 && a.collapse()
        })
    }
    var bF = class extends O {
        constructor(a, b, c, d) {
            super();
            this.win = a;
            this.j = b;
            Lt(b.isDrawerVisible(), !0, () => {
                QD(c);
                FD(d)
            });
            Lt(b.isDrawerVisible(), !1, () => {
                TD(c);
                GD(d)
            })
        }
        show({
            jj: a = !1
        } = {}) {
            if (this.B) throw Error("Cannot show drawer after disposal");
            CE(this.j);
            a && Lt(this.j.isDrawerVisible(), !1, () => {
                this.dispose()
            })
        }
        collapse() {
            var a = this.j;
            AE(a).yb.classList.remove("ved-revealed");
            a.j.g(!1);
            LD(a.A)
        }
        isVisible() {
            return this.j.isDrawerVisible()
        }
        init() {
            Ot(this.j.G).listen(() => {
                this.collapse()
            });
            dF(this);
            eF(this);
            ut(this.win)
        }
    };

    function fF(a) {
        a.config.uc(1065, a.win, () => {
            if (!a.g) {
                var b = Ep(new Fp, a.j);
                var c = new Cp;
                b = A(b, 2, Gp, c);
                a.config.g.ye(b)
            }
        }, 1E4)
    }
    class gF {
        constructor(a, b, c) {
            this.win = a;
            this.config = b;
            this.j = c;
            this.g = !1
        }
        dismiss() {
            this.g = !0
        }
        cancel(a) {
            this.win.clearTimeout(a)
        }
    }

    function aD(a, b) {
        b = b.pa(14);
        if (b < a.j + 1500 && a.j !== 0) return !1;
        a.j = b;
        return !0
    }

    function bD(a, b, c) {
        var d = b.ka ? a.innerWidth : Math.min(a.document.body.clientWidth, 670);
        a = Hz(b.ka, a);
        var e = new rp;
        d = vf(e, 1, d);
        d = vf(d, 2, a);
        b.Jc.fk ? .(d, b.A.get(c));
        return d
    }

    function cD(a, b, c, d, e, f, g, h, k, l = !1) {
        a.l();
        return new Promise(m => {
            var n = Kt(a.g, !1, () => void m(hF(a, b, c, d, e, f, g, h, k, l)));
            a.l = () => {
                n();
                m(null)
            }
        })
    }

    function hF(a, b, c, d, e, f, g, h, k, l) {
        var m = ja(Promise, "withResolvers").call(Promise);
        m.promise.then(() => {
            var q = c.g,
                u = q.ye;
            var w = Ep(new Fp, d);
            var B = new Dp;
            w = A(w, 4, Gp, B);
            u.call(q, w)
        });
        var n = c.ka ? b.innerWidth : Math.min(b.document.body.clientWidth, 670);
        f = c.Jc.Dg({
            win: b,
            searchTerm: e,
            rsToken: f,
            M: c.M,
            ka: c.ka,
            X: c.X(),
            T: c.T,
            rd: n,
            Ic: Hz(c.ka, b),
            Pe: c.Pe.bind(c),
            uc: c.uc.bind(c),
            oi: c.oi.bind(c),
            sa: c.sa.bind(c),
            Yc: q => void a.Yc(q),
            format: g,
            kk: l,
            hf: h,
            jf: k,
            content: c.A.get(e),
            Vc: m.resolve
        });
        e = c.ka ? aF(b, f, {
            ck: .95,
            sj: .95,
            zIndex: 2147483647,
            ie: !0,
            Sg: "adpub-drawer-root",
            Ug: new Ct(oA(c.T, e))
        }) : iF(b, c, e, n, f);
        Lt(e.isVisible(), !1, () => {
            var q = a.B;
            for (let u of q.g) u();
            q.g.length = 0;
            a.g.g(!1);
            bC(b).adIntentsPageState.isDrawerVisible = !1
        });
        e.show({
            jj: !0
        });
        a.g.g(!0);
        bC(b).adIntentsPageState.isDrawerVisible = !0;
        var p = new gF(b, c, d);
        fF(p);
        a.Yc(() => {
            var q = c.g,
                u = q.ye;
            var w = Ep(new Fp, d);
            var B = new Bp;
            w = A(w, 3, Gp, B);
            u.call(q, w);
            p.dismiss()
        });
        return e
    }

    function iF(a, b, c, d, e) {
        return kE(a, e, {
            tf: `${d}px`,
            pf: b.X(),
            Gc: D(b.T, 14),
            zIndex: 2147483647,
            ie: !0,
            mj: !0,
            Sg: "adpub-drawer-root",
            Ug: new Ct(oA(b.T, c))
        })
    }
    var jF = class {
        constructor() {
            this.g = new Ct(!1);
            this.B = new yD;
            this.l = () => {};
            this.j = 0
        }
        isDrawerVisible() {
            return this.g.V
        }
        Yc(a) {
            this.B.g.push(a)
        }
    };
    async function kF(a, b, c) {
        var d = [...a.document.body.getElementsByClassName("adsbygoogle")].filter(e => Rj(e).y < a.innerHeight * c.M.Te);
        d = Promise.all(d.map(e => lF(e, c)));
        c.M.Se === 0 ? await d : await Promise.race([d, mF(a, b, c)])
    }

    function lF(a, b) {
        return a.getAttribute("data-ad-status") ? Promise.resolve() : b.sa(1065, new Promise(c => {
            (new MutationObserver((d, e) => {
                a.getAttribute("data-ad-status") && (e.disconnect(), c())
            })).observe(a, {
                attributeFilter: ["data-ad-status"]
            })
        }))
    }

    function mF(a, b, c) {
        return c.sa(1065, new Promise(d => {
            var e = c.uc(1065, a, () => void d(), c.M.Se);
            b.push(async () => void a.clearTimeout(e))
        }))
    };
    const nF = ["BTN", "BUTTON", "LINK"],
        pF = oF("banner cc cookie dialog gdpr modal notice notification pop-up popup privacy prompt slidedown-container sticky stky".split(" ")),
        qF = oF("accept acknowledge allow close consent deny dismiss ok opt-in opt-out reject".split(" "));

    function oF(a) {
        return new RegExp(`(?:^|[_-\\s])${a.join("|(?:^|[_-\\s])")}`, "i")
    }

    function rF(a, b) {
        if (a.classList ? .contains("google-anno-skip")) return !1;
        switch (a.tagName ? .toUpperCase ? .()) {
            case "IFRAME":
            case "A":
            case "AUDIO":
            case "BUTTON":
            case "CANVAS":
            case "CITE":
            case "CODE":
            case "EMBED":
            case "FOOTER":
            case "FORM":
            case "IMG":
            case "KBD":
            case "LABEL":
            case "MENU":
            case "OBJECT":
            case "PRE":
            case "SAMP":
            case "SCRIPT":
            case "SELECT":
            case "STYLE":
            case "SUB":
            case "SUPER":
            case "SVG":
            case "TEXTAREA":
            case "TIME":
            case "VAR":
            case "VIDEO":
            case null:
            case void 0:
                return !1;
            case "BODY":
                return !0
        }
        return !(sF(a).includes("CRUMB") &&
            a.offsetHeight <= 50) && !tF(a, b) && !tG(a) && !sF(a).includes("MENU") && !(a.tabIndex >= 0) && b.getComputedStyle(a).transform === "none" && !a.classList ? .contains("adsbygoogle")
    }

    function tF(a, b) {
        return a.role ? .toUpperCase ? .() === "BUTTON" || a.tagName ? .toUpperCase ? .() === "INPUT" && a.getAttribute("type") ? .toUpperCase ? .() === "BUTTON" || nF.some(c => sF(a).includes(c)) || b.getComputedStyle(a).cursor === "pointer" || a.childNodes.length === 1 && jC()(a.firstElementChild)
    }

    function uG(a, b, c) {
        var d = a.getBoundingClientRect();
        d = c.document.elementsFromPoint(d.x + d.width / 2, d.y + d.height / 2);
        for (let e of d)
            if (a.contains(e)) break;
            else if (vG(e, b, c)) return !0;
        return !1
    }

    function wG(a, b, c) {
        var d = a.getClientRects();
        if (!d.length) return !1;
        var e = !1;
        for (let f of d) {
            d = c.document.elementsFromPoint(f.x + f.width / 2, f.y + f.height / 2);
            let g = !1;
            for (let h of d)
                if (a.contains(h)) {
                    g = !0;
                    break
                } else if (vG(h, b, c)) {
                e = !0;
                g = !1;
                break
            }
            if (g) return !1
        }
        return e
    }

    function vG(a, b, c) {
        return !(a.closest(".adsbygoogle") || a.closest("#google-anno-sa") || xG(a, b, c))
    }

    function xG(a, b, c) {
        return tG(a) || c.getComputedStyle(a).position === "fixed" ? !0 : !!a.parentElement && a.parentElement.tagName !== "BODY" && xG(a.parentElement, b, c)
    }

    function tG(a) {
        var b = a.getAttribute("id") ? ? "";
        return b.match ? .(pF) || a.className ? .match ? .(pF) || a.ariaLabel ? .match ? .(pF) || a.role ? .toUpperCase ? .() === "DIALOG" || (a.tagName === "A" || a.tagName === "BUTTON") && (b.match ? .(qF) || a.className ? .match ? .(qF) || a.ariaLabel ? .match ? .(qF)) ? !0 : !1
    }

    function yG(a) {
        var b = a.textContent;
        if (!b) return !1;
        switch (a.tagName ? .toUpperCase ? .()) {
            case "H1":
            case "H2":
            case "H3":
            case "H4":
            case "H5":
            case "H6":
            case "HEADER":
            case "HGROUP":
            case "TH":
            case "THEAD":
                return !0;
            case "LI":
            case "OL":
            case "TD":
            case "TR":
            case "UL":
                return !1
        }
        a: {
            for (a = 0; a < b.length; a++) {
                let c = b.charAt(a);
                if ((a === 0 || b.charAt(a - 1) === " ") && c.toLowerCase() === c) {
                    b = !1;
                    break a
                }
            }
            b = !0
        }
        return b
    }

    function sF(a) {
        return (a.id ? .toUpperCase ? .() ? ? "") + "," + (a.className ? .toUpperCase ? .() ? ? "")
    };

    function zG(a, b, c, d) {
        b = b.getBoundingClientRect();
        a = jp(ip(hp(new af, a), 3), c);
        a = vf(a, 6, Math.round(b.x));
        b = vf(a, 7, Math.round(b.y));
        return kp(b, d)
    }

    function AG(a, b, c) {
        return kp(jp(ip(hp(new af, a), 4), b), c)
    }

    function BG(a, b, c) {
        return kp(jp(ip(hp(new af, a), 5), b), c)
    }

    function CG(a) {
        a = xz(a);
        var b = new fp;
        b = vf(b, 1, a[0]);
        b = vf(b, 2, a[1]);
        b = vf(b, 3, a[2]);
        return Oe(b, 4, Wc(a[3]), 0)
    };
    const DG = /[\s!'",:;\\(\\)\\?\\.\u00bf\u00a1\u30a0\uff1d\u037e\u061f\u3002\uff1f\uff1b\uff1a\u2014\u2014\uff5e\u300a\u300b\u3008\u3009\uff08\uff09\u300c\u300d\u3001\u00b7\u2026\u2025\uff01\uff0c\u00b7\u2019\u060c\u061b\u060d\u06d4\u0648]/;

    function EG(a, b) {
        switch (b) {
            case 1:
                return !0;
            default:
                return a === "" || DG.test(a)
        }
    };

    function FG(a, b) {
        var c = new GG(b);
        for (let d of a) D(d, 5) && mf(d, 3).forEach(e => {
            HG(c, e, fy(d))
        });
        IG(c);
        return new JG(c)
    }

    function KG(a, b) {
        b = a.match(b);
        a = new Map;
        for (let c of b)
            if (b = c.g, a.has(b)) {
                let d = a.get(b);
                c.length > d.length && a.set(b, c)
            } else a.set(b, c);
        return [...a.values()]
    }
    var JG = class {
        constructor(a) {
            this.g = a
        }
        isEmpty() {
            return this.g.isEmpty()
        }
        match(a) {
            return this.g.match(a)
        }
    };

    function HG(a, b, c) {
        var d = a.j.has(c) ? a.j.get(c) : a.B++;
        a.j.set(c, d);
        a.A.set(d, c);
        c = 0;
        for (let e = 0; e < b.length; e++) {
            let f = b.charCodeAt(e);
            a.g[c].contains(f) || (a.g.push(new LG), a.g[a.size].A = c, a.g[a.size].D = f, a.g[c].l.set(f, a.size), a.size++);
            c = a.g[c].l.get(f)
        }
        a.g[c].B = !0;
        a.g[c].C = d;
        a.g[c].O = a.l.length;
        a.l.push(b.length)
    }

    function IG(a) {
        var b = [];
        for (b.push(0); b.length > 0;) {
            let f = b.shift();
            var c = a,
                d = c.g[f];
            if (f === 0) d.g = 0, d.j = 0;
            else if (d.A === 0) d.g = 0, d.j = d.B ? f : c.g[c.g[f].g].j;
            else {
                d = c.g[c.g[f].A].g;
                for (var e = c.g[f].D;;) {
                    if (c.g[d].contains(e)) {
                        c.g[f].g = c.g[d].l.get(e);
                        break
                    }
                    if (d === 0) {
                        c.g[f].g = 0;
                        break
                    }
                    d = c.g[d].g
                }
                c.g[f].j = c.g[f].B ? f : c.g[c.g[f].g].j
            }
            for (let g of a.g[f].Gb) b.push(g)
        }
    }
    class GG {
        constructor(a) {
            this.C = a;
            this.size = 1;
            this.g = [new LG];
            this.l = [];
            this.j = new Map;
            this.A = new Map;
            this.B = 0
        }
        isEmpty() {
            return this.B === 0
        }
        match(a) {
            var b = 0,
                c = [];
            for (let g = 0; g < a.length; g++) {
                for (;;) {
                    var d = a.charCodeAt(g),
                        e = this.g[b];
                    if (e.contains(d)) {
                        b = e.l.get(d);
                        break
                    }
                    if (b === 0) break;
                    b = e.g
                }
                let h = b;
                for (;;) {
                    h = this.g[h].j;
                    if (h === 0) break;
                    let k = g + 1 - this.l[this.g[h].O],
                        l = g;
                    d = a;
                    e = l;
                    var f = this.C;
                    EG(d.charAt(k - 1), f) && EG(d.charAt(e + 1), f) && c.push(new MG(k, l, this.A.get(this.g[h].C)));
                    h = this.g[h].g
                }
            }
            return c
        }
    }
    class LG {
        constructor() {
            this.l = new Map;
            this.P = !1;
            this.Ba = this.J = this.G = this.la = this.W = this.Z = -1
        }
        contains(a) {
            return this.l.has(a)
        }
        set A(a) {
            this.Z = a
        }
        get A() {
            return this.Z
        }
        set D(a) {
            this.W = a
        }
        get D() {
            return this.W
        }
        set B(a) {
            this.P = a
        }
        get B() {
            return this.P
        }
        set C(a) {
            this.J = a
        }
        get C() {
            return this.J
        }
        set g(a) {
            this.la = a
        }
        get g() {
            return this.la
        }
        set j(a) {
            this.G = a
        }
        get j() {
            return this.G
        }
        set O(a) {
            this.Ba = a
        }
        get O() {
            return this.Ba
        }
        get Gb() {
            return this.l.values()
        }
    }
    var MG = class {
        constructor(a, b, c) {
            this.g = a;
            this.j = b;
            this.searchTerm = c
        }
        get length() {
            return this.j - this.g
        }
    };
    const NG = "A B EM I LI S SPAN STRONG U".split(" ");
    async function OG(a, b, c, d, e, f, g) {
        var h = FG(hy(b.T), b.B);
        h.isEmpty() || await PG(a, a.document.body, b, h, new Set, c, d, e, new qD(0, 0, 0, 100, 2 * a.innerHeight), new QG(a.innerHeight * .6), f, g)
    }
    async function PG(a, b, c, d, e, f, g, h, k, l, m, n) {
        f.g.pa(9) >= f.j && await RG(f, 10);
        if (b.nodeType === Node.TEXT_NODE) KG(d, b.textContent ? ? "").forEach(p => void e.add(p.searchTerm));
        else if (iC(b))
            if (SG(b, a)) {
                for (let p of b.childNodes) await PG(a, p, c, d, e, f, g, h, k, l, m, n);
                TG(a, b, e, l) && UG(a, e, c, g, h, b, k, l, n)
            } else b.classList ? .contains("adsbygoogle") && b.dataset.adStatus === "filled" && (l.j = VG(a, b))
    }

    function SG(a, b) {
        return rF(a, b) && a.tagName !== "TABLE" && b.getComputedStyle(a).display !== "none"
    }

    function TG(a, b, c, d) {
        if (c = c.size && ["block", "table-cell"].includes(a.getComputedStyle(b).display)) c = el(a.getComputedStyle(b).fontSize), c = !(c !== null && c > 22) && !(c !== null && c < 8);
        c && (a = VG(a, b), c = (d.g === void 0 || a - d.g > d.l) && (d.j === void 0 || a - d.j > 639));
        if (d = c && !yG(b)) {
            for (b = b.lastChild; b ? .nodeType !== Node.TEXT_NODE;)
                if (iC(b) && NG.includes(b.tagName)) b = b.lastChild;
                else break;
            d = b ? .nodeType === Node.TEXT_NODE && !!b ? .textContent && b.textContent.trim().length > 3
        }
        return !!d
    }

    function UG(a, b, c, d, e, f, g, h, k) {
        b.size && uu(a, ["Roboto:500"]);
        var l = "#0B57D0",
            m = "#FFFFFF";
        sD(c) && (l = (m = (l = xD(a, c)) && wD(a, c, l, f)) ? l : "#FFFFFF", m = m ? "inherit" : "#1A73E8");
        var n = [...b];
        for (let G = 0; G < n.length; ++G) {
            let K = n[G];
            if (oD(g) || G === 1) break;
            b.delete(K);
            var p = g,
                q = K,
                u = f.getBoundingClientRect().bottom;
            q = p.g.l.get(q);
            if (!(q === void 0 || u - q > p.l)) {
                b.delete(K);
                continue
            }
            p = zG(c.g.lc(), f, K, eD(c, K));
            WG(d, p);
            e.incrementTermUsageCount(K);
            var w = g;
            q = K;
            var B = f.getBoundingClientRect().bottom;
            u = w.g;
            w = w.j;
            u.j++;
            let H = u.g.get(q) ? ? [];
            H.push(w);
            u.g.set(q, H);
            w = u.l.get(q) ? ? 0;
            u.l.set(q, Math.max(w, B));
            if (C(c.T, 17)) continue;
            u = tD(a, c, K, f, l, m, !0, !1, !1);
            q = XG(u, c, kf(p), a);
            c.M.Tb && eD(c, K) || Dz(u);
            YG(u, c, K, kf(p), q, k, a);
            sD(c) && c.M.kb > 0 && f.appendChild(a.document.createTextNode(" "));
            f.appendChild(u);
            (sD(c) ? wG(u, c.M, a) : uG(u, c.M, a)) ? u.remove(): h.g = VG(a, u)
        }
    }
    async function ZG(a, b, c, d, e, f, g, h, k) {
        d.size && uu(a, ["Roboto:500"]);
        var l = new jF;
        d = [...d];
        qc(g.getTermUsageCount) && d.sort((m, n) => g.getTermUsageCount(m) - g.getTermUsageCount(n));
        for (let m = 0; m < d.length && !(m >= c.Jm); ++m) {
            let n = d[m],
                p = AG(e.g.lc(), n, eD(e, n));
            WG(f, p);
            let q = tD(a, e, n, h, "#FFFFFF", "#1A73E8", !1, !0, k === 4),
                u = $G(q, e, kf(p));
            e.M.Tb && eD(e, n) || Dz(q);
            YC(e, 999, q, w => {
                try {
                    if (!aD(l, e)) return !1;
                    let K = b ? .document ? .body ? .tagName === "BODY" ? b : a,
                        H = bD(K, e, n);
                    var B = vp(tp(n), kf(p));
                    var G = wf(B, 8, u.A);
                    let L = wp(F(G, 9, 4),
                            H),
                        S = e.g.bg(L);
                    cD(l, K, e, S, n, e.C.get(n) || "", 4, e.j.get(n) ? ? "", e.l.get(n) ? ? "", e.M.Vf);
                    return !1
                } finally {
                    w.preventDefault(), w.stopImmediatePropagation()
                }
            });
            h.appendChild(q);
            if (h.scrollHeight > h.clientHeight) {
                h.removeChild(q);
                break
            }
            g.incrementTermUsageCount(n)
        }
    }
    var aH = class {
        constructor() {
            this.B = this.l = null
        }
        get A() {
            return this.l
        }
        j(a, b) {
            if (!this.l) {
                var c = a.Hg,
                    d = new Lo;
                b = If(d, 1, b);
                this.l = c.call(a, b)
            }
        }
        g(a) {
            if (this.l && !this.B) {
                var b = a.Gg;
                var c = new Ko;
                c = xf(c, 1, this.l);
                this.B = b.call(a, c)
            }
        }
    };

    function XG(a, b, c, d) {
        var e = new aH;
        bH(b, 1065, f => {
            for (let g of f) g.isIntersecting ? e.A === null && (sD(b) ? wG(a, b.M, d) : uG(a, b.M, d)) ? a.remove() : e.j(b.g, c) : e.g(b.g)
        }).observe(a);
        return e
    }

    function YG(a, b, c, d, e, f, g) {
        YC(b, 999, a, h => {
            try {
                if (!aD(f, b)) return !1;
                let m = bD(g, b, c);
                var k = vp(tp(c), d);
                var l = wf(k, 7, e.A);
                let n = wp(F(l, 9, 3), m),
                    p = b.g.qd(n);
                b.sa(1401, cD(f, g, b, p, c, b.O.get(c) ? ? "", 3, b.j.get(c) ? ? "", b.l.get(c) ? ? ""));
                return !1
            } finally {
                h.preventDefault(), h.stopImmediatePropagation()
            }
        })
    }
    class QG {
        constructor(a) {
            this.l = a;
            this.j = this.g = void 0
        }
    }

    function VG(a, b) {
        return b.getBoundingClientRect().bottom + a.scrollY
    }
    class cH {
        constructor() {
            this.B = this.l = null
        }
        get A() {
            return this.l
        }
        j(a, b) {
            if (!this.l) {
                var c = a.jg,
                    d = new Po;
                b = If(d, 1, b);
                this.l = c.call(a, b)
            }
        }
        g(a) {
            if (this.l && !this.B) {
                var b = a.ig;
                var c = new Oo;
                c = xf(c, 1, this.l);
                this.B = b.call(a, c)
            }
        }
    }

    function $G(a, b, c) {
        var d = new cH;
        bH(b, 1065, e => {
            for (let f of e) f.isIntersecting ? d.j(b.g, c) : d.g(b.g)
        }).observe(a);
        return d
    };
    async function dH(a, b, c, d, e, f, g, h) {
        a = tD(a, b, c, d, f, g, !0, !1, !1);
        b.M.ef ? (a.style.position = "absolute", a.style.visibility = "hidden", d.appendChild(a), e = a.getBoundingClientRect().width, d.removeChild(a), d = h >= e ? 1 : 0) : (d.appendChild(a), h = d.getBoundingClientRect().height, d.removeChild(a), d = h === e ? 1 : 0);
        return d
    }
    async function eH(a, b, c, d, e, f) {
        var g = c.textContent || "",
            h = KG(d, g);
        d = c.getBoundingClientRect();
        if (g.length === 0 || h.length === 0) return null;
        if (b.M.ef) {
            var k = a.document.createRange();
            k.selectNodeContents(c);
            k = k.getClientRects();
            if (k.length === 0) k = 0;
            else {
                k = k[k.length - 1];
                g = c.getBoundingClientRect();
                var l = a.getComputedStyle(c);
                if (b.X()) {
                    var m = Number(l.paddingLeft.replace("px", "")) || 0;
                    l = Number(l.borderLeftWidth.replace("px", "")) || 0;
                    k = k.left - (g.left + m + l)
                } else m = Number(l.paddingRight.replace("px", "")) || 0, l = Number(l.borderRightWidth.replace("px",
                    "")) || 0, k = g.right - m - l - k.right
            }
        }
        g = -1;
        l = "";
        for (let n of h)
            if (h = n.searchTerm, m = await dH(a, b, h, c, d.height, e, f, k), m > g && (g = m, l = h), g === 1) break;
        return g < 0 ? null : {
            Yf: (g + Math.max(0, 1 - Math.max(d.top + a.scrollY, 0) / (a.innerHeight * 5))) / 2,
            Fg: [l]
        }
    }
    async function fH(a, b, c, d) {
        var e = FG(hy(b.T), b.B);
        if (!e.isEmpty()) {
            var f = Array.from(a.document.body.getElementsByTagName("p")),
                g = xD(a, b),
                h = new gH(a.innerHeight),
                k = [],
                l = !1,
                m = async () => {
                    if (!l) {
                        l = !0;
                        var p = 0;
                        b.M.df && (p = b.pa(12));
                        try {
                            for (; k.length > 0;) {
                                var q = [...k];
                                k.length = 0;
                                let u = [];
                                for (let w of q) {
                                    q = "#0B57D0";
                                    let B = "#FFFFFF";
                                    sD(b) && g && wD(a, b, g, w) ? (q = g, B = "inherit") : sD(b) && (q = "#FFFFFF", B = "#1A73E8");
                                    let G = await eH(a, b, w, e, q, B);
                                    G && u.push({
                                        element: w,
                                        Yf: G.Yf,
                                        Fg: G.Fg,
                                        vl: q,
                                        wl: B
                                    })
                                }
                                if (u.length > 0) {
                                    u.sort((w, B) =>
                                        B.Yf - w.Yf);
                                    for (let w of u)
                                        if (hH(h, w.element.getBoundingClientRect().bottom + a.scrollY))
                                            for (let B of w.Fg) iH(a, B, b, c, w.element, d, h, w.vl, w.wl)
                                }
                            }
                        } finally {
                            l = !1, b.M.df && (p = jH(c, b.pa(13) - p), p.j() && lp(p.j()).length > 0 && b.g.Hf(p)), k.length > 0 && m()
                        }
                    }
                },
                n = bH(b, 898, p => {
                    var q = !1;
                    for (let u of p) u.isIntersecting && u.target instanceof HTMLParagraphElement && (n.unobserve(u.target), k.push(u.target), q = !0);
                    q && m()
                }, {
                    root: null,
                    rootMargin: "0px 0px 300% 0px",
                    threshold: 0
                });
            for (let p of f) n.observe(p)
        }
    }

    function iH(a, b, c, d, e, f, g, h, k) {
        var l = zG(c.g.lc(), e, b, eD(c, b));
        WG(d, l);
        C(c.T, 17) || (d = tD(a, c, b, e, h, k, !0, !1, !1), h = XG(d, c, kf(l), a), c.M.Tb && eD(c, b) || Dz(d), YG(d, c, b, kf(l), h, f, a), sD(c) && c.M.kb > 0 && e.appendChild(a.document.createTextNode(" ")), e.appendChild(d), a = d.getBoundingClientRect().bottom + window.scrollY, g.g.push(a))
    }

    function hH(a, b) {
        for (let c of a.g)
            if (Math.abs(b - c) < a.j) return !1;
        return !0
    }
    class gH {
        constructor(a) {
            this.j = a;
            this.g = []
        }
    };

    function kH(a) {
        var b = new Rt,
            c = bu(a, 2500, () => void Qt(b));
        return new lH(a, () => void mH(a, () => void c()), Ot(b))
    }

    function nH(a) {
        a.l || (oH(a), pH(a), a.l = !0);
        return a.A
    }

    function oH(a) {
        var b = new MutationObserver(() => {
            a.j()
        });
        b.observe(a.win.document.documentElement, {
            childList: !0,
            subtree: !0,
            attributes: !0,
            attributeFilter: ["class", "style"]
        });
        xt(a, () => void b.disconnect())
    }

    function pH(a) {
        a.win.addEventListener("resize", a.j);
        xt(a, () => void a.win.removeEventListener("resize", a.j))
    }
    var lH = class extends O {
        constructor(a, b, c) {
            super();
            this.win = a;
            this.j = b;
            this.A = c;
            this.l = !1
        }
    };

    function mH(a, b) {
        b();
        a.setTimeout(b, 1500)
    };
    const qH = ["block", "inline", "inline-block", "list-item", "table-cell"];
    async function rH(a, b, c, d, e, f, g) {
        e.g.pa(5) >= e.j && await RG(e, 6);
        var h = new jF;
        d.Ml || sH(a, b, c, d, f, hy(c.T), h);
        d.Nl || (c.M.Yg && C(c.T, 5) ? await c.sa(898, fH(a, c, f, h)) : await c.sa(898, OG(a, c, e, f, g, b, h)));
        d.Ol || await tH(a, c, d, e, f, g, h)
    }
    async function tH(a, b, c, d, e, f, g) {
        var h = hy(b.T);
        var k = new GG(b.B);
        for (let l of h) D(l, 6) !== "" && (h = fy(l), HG(k, h, h));
        IG(k);
        k = new JG(k);
        k.isEmpty() || await b.sa(898, uH(a, b, d, e, f, k, new qD(c.wordWindowSize, c.sameSearchTermPerWindow, c.annotationsPerWindow, c.maximumAnnotationsPerPage, 0), g))
    }
    async function uH(a, b, c, d, e, f, g, h) {
        for (var k = a.document.body; k;) {
            c.g.pa(7) >= c.j && await RG(c, 8);
            if (k.nodeType === Node.TEXT_NODE && k.textContent !== "" && k.parentElement) {
                let xc = k.parentElement;
                a: {
                    var l = a,
                        m = b,
                        n = xc,
                        p = k.textContent,
                        q = d,
                        u = e,
                        w = f,
                        B = g,
                        G = h;
                    let Wa = [];b: {
                        var K = p;
                        switch (m.B) {
                            case 1:
                                var H = K;
                                let yc = Array(H.length),
                                    fc = 0;
                                for (let zc = 0; zc < H.length; zc++) DG.test(H[zc]) || fc++, yc[zc] = fc;
                                var L = yc;
                                break b;
                            default:
                                var S = K;
                                let $c = Array(S.length),
                                    rd = 0,
                                    Gb = 0;
                                for (; Gb < S.length;) {
                                    for (;
                                        /\s/.test(S[Gb]);) $c[Gb] = rd, Gb++;
                                    let zc = !1;
                                    for (; Gb < S.length && !/\s/.test(S[Gb]);) zc = !0, $c[Gb] = rd, Gb++;
                                    zc && (rd++, $c[Gb - 1] = rd)
                                }
                                L = $c
                        }
                    }
                    let Vb = L,
                        Ug = p.includes("\u00bb") ? [] : KG(w, p),
                        Ie = -1;
                    for (let yc of Ug) {
                        let fc = yc.g,
                            $c = yc.j;
                        if (fc < Ie) continue;
                        var da = B,
                            Ea = yc.searchTerm;
                        rD(da.g, da.j + Vb[fc]);
                        var ka = da;
                        if (!((ka.g.g.get(Ea) ? .length ? ? 0) < ka.B && da.g.B < da.annotationsPerWindow)) continue;
                        let rd = l.getComputedStyle(n),
                            Gb = rd.fontSize.match(/\d+/);
                        if (!(Gb && Number(Gb[0]) >= 12 && Number(Gb[0]) <= 22 && hb(qH, rd.display))) {
                            B.j += Vb[Vb.length - 1];
                            var Da = [];
                            break a
                        }
                        let zc =
                            Ie + 1;
                        zc < fc && Wa.push(l.document.createTextNode(p.substring(zc, fc)));
                        let zf = p.substring(fc, $c + 1);
                        var Nc = p,
                            ad = fc,
                            Oc = $c + 1;
                        let Ui = Nc.substring(Math.max(ad - 30, 0), ad) + "~~" + Nc.substring(Oc, Math.min(Oc + 30, Nc.length));
                        var ee = l,
                            ya = m.g.lc(),
                            Pc = n,
                            Vg = zf,
                            Wg = Ui,
                            Xg = yc.searchTerm,
                            Yg = Vb[fc],
                            Zg = eD(m, yc.searchTerm);
                        let $g = Pc.getBoundingClientRect();
                        var ah = ip(hp(new af, ya), 2);
                        var bh = Kf(ah, 2, Vg);
                        var ch = Kf(bh, 3, Wg);
                        var dh = jp(ch, Xg);
                        var eh = vf(dh, 5, Yg);
                        var fh = vf(eh, 6, Math.round($g.x));
                        var gh = vf(fh, 7, Math.round($g.y));
                        let sd =
                            ee.getComputedStyle(Pc);
                        var Vi = new gp;
                        var Wi = Kf(Vi, 1, sd.fontFamily);
                        var Xi = CG(sd.color);
                        var Yi = z(Wi, 7, Xi);
                        var Zi = CG(sd.backgroundColor);
                        var $i = z(Yi, 8, Zi);
                        let hh = sd.fontSize.match(/^(\d+(\.\d+)?)px$/);
                        var Af = vf($i, 4, hh ? Math.round(Number(hh[1])) : 0);
                        let Bf = Math.round(Number(sd.fontWeight));
                        isNaN(Bf) || Bf === 400 || vf(Af, 5, Bf);
                        sd.textDecorationLine !== "none" && Kf(Af, 6, sd.textDecorationLine);
                        var aj = z(gh, 8, Af);
                        let Cf = [],
                            fe = Pc;
                        for (; fe && Cf.length < 20;) {
                            var ih = Cf,
                                bj = ih.push,
                                Df = fe,
                                cj = new ep;
                            let jh = Kf(cj, 1, Df.tagName);
                            Df.className !== "" && Ne(jh, 2, Df.className.split(" "), Dd);
                            bj.call(ih, jh);
                            if (fe.tagName === "BODY") break;
                            fe = fe.parentElement
                        }
                        var dj = Cf.reverse();
                        var ej = Xe(aj, 9, dj);
                        let kh = kp(ej, Zg);
                        WG(q, kh);
                        u.incrementTermUsageCount(zf);
                        Wa.push(vH(l, m, kf(kh), yc.searchTerm, zf, n, G));
                        var Ef = B.g,
                            lh = yc.searchTerm,
                            fj = B.j + Vb[fc];
                        Ef.j++;
                        let mh = Ef.g.get(lh) ? ? [];
                        mh.push(fj);
                        Ef.g.set(lh, mh);
                        Ie = $c;
                        if (oD(B)) break
                    }
                    let Ff = Ie + 1;Ff !== 0 && Ff < p.length && Wa.push(l.document.createTextNode(p.substring(Ff)));B.j += Vb[Vb.length - 1];Da = Wa
                }
                let bd = Da;
                if (bd.length && !C(b.T, 17)) {
                    for (let Wa of bd) xc.insertBefore(Wa, k), wH(Wa, b.M);
                    xc.removeChild(k);
                    for (let Wa of xc.children) Wa.classList ? .contains("google-anno") && Wa.firstElementChild && uG(Wa.firstElementChild, b.M, a) && Wa.replaceWith(a.document.createTextNode(Wa.textContent ? .trimStart() ? ? ""));
                    for (k = bd[bd.length - 1]; k.lastChild;) k = k.lastChild;
                    if (oD(g)) break
                }
            }
            a: {
                var nh = a,
                    Ac = k,
                    oh = g,
                    gj = b.B;
                if (Ac.firstChild && iC(Ac) && !Ac.classList ? .contains("google-anno-skip") && (Ac.offsetHeight || nh.getComputedStyle(Ac).display ===
                        "contents")) {
                    if (rF(Ac, nh)) {
                        k = Ac.firstChild;
                        break a
                    }
                    if (Ac.textContent ? .length) {
                        b: {
                            var Gf = Ac.textContent;
                            switch (gj) {
                                case 1:
                                    var ph = Gf;
                                    let bd = 0;
                                    for (let Vb = ph.length - 1; Vb >= 0; Vb--) DG.test(ph[Vb]) || bd++;
                                    var Hf = bd;
                                    break b;
                                default:
                                    let Wa = Gf.trim();
                                    Hf = Wa === "" ? 0 : Wa.split(/\s+/).length
                            }
                        }
                        rD(oh.g, oh.j + Hf)
                    }
                }
                let xc = Ac;
                for (;;) {
                    if (xc.nextSibling) {
                        k = xc.nextSibling;
                        break a
                    }
                    if (!xc.parentNode) {
                        k = null;
                        break a
                    }
                    xc = xc.parentNode
                }
                k = void 0
            }
        }
    }

    function xH(a, b) {
        return MC(a, {
            X: b.X(),
            ka: b.ka,
            ba: ks(a),
            ga: ls(a)
        })
    }

    function sH(a, b, c, d, e, f, g) {
        function h() {
            return l ? ? (l = c.oi(898, a, () => {
                if (!k) {
                    var n = c.pa(12),
                        p = xH(a, c);
                    p && (a.clearInterval(l), k = !0, yH(a, b, c, d, e, n, f, p, g))
                }
            }, d.Uk ? ? 3E3))
        }
        if (f.filter(n => D(n, 7).length).length) {
            var k = !1,
                l = void 0,
                m = zH(c, a, () => {
                    if (!(a.scrollY <= (d.Vk ? ? 300) || k)) {
                        var n = c.pa(12),
                            p = xH(a, c);
                        p ? (k = !0, a.removeEventListener("scroll", m), yH(a, b, c, d, e, n, f, p, g)) : l = h()
                    }
                });
            c.uc(898, a, () => {
                if (!k) {
                    var n = c.pa(12),
                        p = xH(a, c);
                    p ? (k = !0, yH(a, b, c, d, e, n, f, p, g)) : l = h()
                }
            }, d.Tk ? ? 15E3)
        }
    }

    function yH(a, b, c, d, e, f, g, h, k) {
        var l = new mD(a, c, d, h, k);
        g.filter(m => D(m, 7).length).forEach(m => {
            var n = c.g.lc();
            var p = fy(m),
                q = eD(c, fy(m));
            n = kp(jp(ip(hp(new af, n), 1), p), q);
            WG(e, n);
            n = kf(n);
            p = fy(m);
            m = fy(m);
            l.B.push(new nD(n, p, m));
            l.A && lD(l, b)
        });
        a = kH(a);
        nH(a).listen(() => {
            if (!l.g.isDrawerVisible() && SC(l.win, l.j)) {
                var m = MC(l.win, {
                    X: l.config.X(),
                    ka: l.config.ka,
                    ba: ks(l.win),
                    ga: ls(l.win)
                });
                m && (l.j = m, iD(l.D, l.win, m, l.config))
            }
        });
        c.g.Hf(jH(e, c.pa(13) - f))
    }

    function wH(a, b) {
        if (hC(a)) {
            if (a.tagName === "A") {
                var c = yz(a.parentElement),
                    d = yz(a);
                var e = Az(a, b);
                if (e = c && d && e ? vz(d, e) < Math.min(vz(c, e), 2.5) ? c : null : c) {
                    c = e[0];
                    d = e[1];
                    e = e[2];
                    c = Number(c);
                    d = Number(d);
                    e = Number(e);
                    if (c != (c & 255) || d != (d & 255) || e != (e & 255)) throw Error('"(' + c + "," + d + "," + e + '") is not a valid RGB color');
                    d = c << 16 | d << 8 | e;
                    J(a, {
                        color: c < 16 ? "#" + (16777216 | d).toString(16).slice(1) : "#" + d.toString(16)
                    })
                }
            }
            for (c = 0; c < a.childElementCount; c++) wH(a.children[c], b)
        }
    }
    class AH {
        constructor() {
            this.B = this.l = null
        }
        get A() {
            return this.l
        }
        j(a, b) {
            if (!this.l) {
                var c = a.Ph,
                    d = new Ap;
                b = If(d, 2, b);
                this.l = c.call(a, b)
            }
        }
        g(a) {
            if (this.l && !this.B) {
                var b = a.Oh;
                var c = new zp;
                c = xf(c, 1, this.l);
                this.B = b.call(a, c)
            }
        }
    }

    function vH(a, b, c, d, e, f, g) {
        e = BH(a, e, f);
        e.className = "google-anno";
        b.M.Tb && eD(b, d) ? e.classList.add("google-anno-oc") : Dz(e);
        var h = CH(b, c, e, a);
        YC(b, 999, e, k => {
            try {
                if (!aD(g, b)) return !1;
                let n = bD(a, b, d);
                var l = vp(tp(d), c);
                var m = wf(l, 2, h.A);
                let p = wp(F(m, 9, 2), n),
                    q = b.g.qd(p);
                b.sa(1401, cD(g, a, b, q, d, b.G.get(d) || "", 1, b.j.get(d) ? ? "", b.l.get(d) ? ? ""));
                return !1
            } finally {
                k.preventDefault(), k.stopImmediatePropagation()
            }
        });
        return e
    }

    function BH(a, b, c) {
        var d = Bz(a, "span");
        d.className = "google-anno-t";
        J(d, {
            "text-decoration": "underline"
        });
        J(d, {
            "text-decoration-style": "dotted"
        });
        J(d, {
            "-webkit-text-decoration-line": "underline",
            "-webkit-text-decoration-style": "dotted"
        });
        J(d, {
            color: "inherit",
            "font-family": "inherit",
            "font-size": "inherit",
            "font-style": "inherit",
            "font-weight": "inherit"
        });
        d.appendChild(a.document.createTextNode(b));
        b = Bz(a, "a");
        J(b, {
            color: "revert-layer",
            cursor: "pointer",
            fill: "currentColor",
            "font-family": "inherit",
            "font-size": "inherit",
            "font-style": "inherit",
            "font-weight": "inherit",
            "line-height": "inherit",
            "text-decoration": "none"
        });
        Hi(b, "#");
        var e = b.appendChild;
        c = a.getComputedStyle(c).fontSize;
        c = Lz(a, "100 -1000 840 840", `calc(${c} - 2px)`, c, "M168-144q-29.7 0-50.85-21.15Q96-186.3 96-216v-528q0-29.7 21.15-50.85Q138.3-816 168-816h624q29.7 0 50.85 21.15Q864-773.7 864-744v528q0 29.7-21.15 50.85Q821.7-144 792-144H168Zm0-72h624v-528H168v528Zm72-96h480v-72H240v72Zm0-144h168v-216H240v216Zm240 0h240v-72H480v72Zm0-144h240v-72H480v72ZM168-216v-528 528Z");
        J(c, {
            color: "inherit",
            cursor: "inherit",
            fill: "currentcolor"
        });
        e.call(b, c);
        b.appendChild(a.document.createTextNode("\u00a0"));
        b.appendChild(d);
        return b
    }

    function CH(a, b, c, d) {
        var e = new AH;
        bH(a, 1065, f => {
            for (let g of f) g.isIntersecting ? c.classList ? .contains("google-anno") && e.A === null && c.firstElementChild && uG(c.firstElementChild, a.M, d) ? c.replaceWith(d.document.createTextNode(c.textContent ? .trimStart() ? ? "")) : e.j(a.g, b) : e.g(a.g)
        }).observe(c);
        return e
    };

    function WG(a, b) {
        a.entries.push(ne(b))
    }

    function jH(a, b) {
        var c = a.g;
        a.g = a.entries.length;
        var d = new yp,
            e = new mp;
        a = Xe(e, 2, a.entries.slice(c));
        d = z(d, 1, a);
        b !== 0 && xf(d, 2, Math.round(b));
        return d
    }

    function DH(a, b) {
        var c = new Uo;
        a = Kf(c, 2, a.language);
        return Kf(a, 3, b)
    }

    function EH(a) {
        var b = hy(a),
            c = 0,
            d = 0,
            e = 0,
            f = 0,
            g = 0,
            h = 0;
        a = 0;
        for (var k of b) c += FH(D(k, 6) !== "") + FH(D(k, 7) !== "") + FH(D(k, 5) !== "") + FH(D(k, 12) !== "") + FH(D(k, 9) !== ""), d += FH(D(k, 6) !== "") + FH(D(k, 7) !== "") + FH(D(k, 5) !== "") + FH(D(k, 12) !== "") + FH(D(k, 9) !== ""), e += FH(D(k, 6) !== ""), f += FH(D(k, 7) !== ""), g += FH(D(k, 5) !== ""), h += FH(D(k, 12) !== ""), a += FH(D(k, 9) !== "");
        k = new np;
        b = uf(k, 1, b.length);
        c = uf(b, 2, c);
        d = we(c, 3, d == null ? d : id(d));
        e = we(d, 4, e == null ? e : id(e));
        f = we(e, 5, f == null ? f : id(f));
        g = uf(f, 6, g);
        h = uf(g, 7, h);
        return uf(h, 8, a)
    }

    function GH(a, b, c, d, e, f, g, h) {
        var k = new pp;
        var l = new To;
        c = Kf(l, 1, c);
        d = Kf(c, 2, d);
        b = tf(d, 3, b);
        b = tf(b, 5, !1);
        k = z(k, 1, b);
        e = DH(a, e);
        e = z(k, 2, e);
        g = xf(e, 3, Math.round(g));
        e = EH(f);
        g = z(g, 6, e);
        for (let m of nf(f, 8)) Ye(g, 7, ed, HH(m), fd);
        h.length ? (a = new dp, a = Xe(a, 1, h), A(g, 5, op, a)) : (a.g = a.entries.length, h = new mp, a = $e(h, a.entries), A(g, 4, op, a));
        return g
    }
    var IH = class {
        constructor() {
            this.entries = [];
            this.language = null;
            this.g = 0
        }
    };

    function FH(a) {
        return a ? 1 : 0
    }

    function HH(a) {
        switch (a) {
            case 1:
                return 2;
            case 3:
                return 3;
            case 2:
                return 1;
            case 4:
                return 4;
            case 5:
                return 5;
            case 0:
                return 0;
            default:
                return 0
        }
    };

    function JH(a) {
        if (a != null) return KH(a)
    }

    function LH(a) {
        return a == null ? null : KH(a)
    }

    function KH(a) {
        return Dc(a) ? Number(a) : String(a)
    };

    function MH(a, b, c) {
        NH(a);
        b = OH(b);
        for (let [d, e] of b) b = d, PH(a, e, b, c), QH(a, b)
    }

    function RH(a, b, c) {
        a.j.forEach(d => {
            SH(d, { ...a.g,
                outcome: b,
                sc: !1,
                Nc: c
            })
        })
    }

    function TH(a, b, c, d) {
        a.j.forEach(e => {
            e.si(b, { ...a.g,
                outcome: c,
                sc: !1,
                Nc: d
            })
        })
    }

    function UH(a, b, c, d) {
        a.j.forEach(e => {
            VH(e, { ...a.g,
                outcome: b,
                sc: c,
                Nc: d
            })
        })
    }

    function WH(a, b, c, d, e) {
        a.j.forEach(f => {
            f.zg(b, { ...a.g,
                outcome: c,
                sc: d,
                Nc: e
            })
        })
    }

    function NH(a) {
        a.B || (a.B = !0, a.j.forEach(b => {
            XH(b, a.g)
        }))
    }

    function PH(a, b, c, d) {
        a.j.forEach(e => {
            e.Ag(b, { ...a.g,
                format: c,
                sc: d
            })
        })
    }

    function QH(a, b) {
        a.A.has(b) || (a.A.add(b), a.j.forEach(c => {
            YH(c, { ...a.g,
                Mb: a.Mb,
                format: b
            })
        }))
    }

    function ZH(a) {
        a.C || (a.C = !0, a.j.forEach(b => {
            $H(b, a.g)
        }))
    }

    function aI(a, b) {
        a.j.forEach(c => {
            c.ui(b, { ...a.g,
                format: 4,
                sc: !1
            })
        })
    }

    function bI(a, b) {
        a.j.forEach(c => {
            cI(c, { ...a.g,
                reason: dI(b)
            })
        })
    }
    var kI = class {
        constructor(a, b, c, d) {
            this.D = this.l = 1;
            this.C = this.B = !1;
            this.g = {
                language: a.has(b) ? b : "other",
                Oa: Za() ? 2 : Ua() ? 4 : Va() ? 7 : 10
            };
            a: switch (d) {
                case 1:
                    a = 1;
                    break a;
                case 2:
                    a = 2;
                    break a;
                default:
                    a = 0
            }
            this.Mb = a;
            this.A = new Set;
            this.j = [...c]
        }
        lc() {
            return this.D++
        }
        Ue(a) {
            a: switch (Se(a, op)) {
                case 4:
                    var b = 1;
                    break a;
                case 5:
                    b = 2;
                    break a;
                default:
                    b = 0
            }
            var c = eI(a),
                d = hf(a, 3),
                e = c.length > 0;UH(this, b, !1, e);WH(this, d, b, !1, e);a.g() && c.length > 0 && MH(this, c, !1);
            if (Ae(a, dp, 5, op)) {
                a = of (a, dp, 5, op);
                for (let f of Ve(a, Zo, 1, De())) bI(this,
                    f)
            }
            this.l++
        }
        Hf(a) {
            var b = a.g() ? 1 : 0,
                c = eI(a),
                d = hf(a, 2),
                e = c.length > 0;
            UH(this, b, !0, e);
            WH(this, d, b, !0, e);
            a.g() && c.length > 0 && MH(this, c, !0);
            this.l++
        }
        ti(a) {
            var b = eI(a),
                c = a.g() ? 1 : 2,
                d = hf(a, 5),
                e = b.length > 0;
            RH(this, c, e);
            TH(this, d, c, e);
            if (a.g() && b.length > 0) {
                ZH(this);
                a = OH(b);
                for (let [, f] of a) aI(this, f)
            }
            this.l++
        }
        Ph() {
            this.j.forEach(a => {
                fI(a, { ...this.g,
                    format: 2
                })
            });
            return this.l++
        }
        Oh() {
            this.j.forEach(a => {
                gI(a, { ...this.g,
                    format: 2
                })
            });
            return this.l++
        }
        xg() {
            this.j.forEach(a => {
                fI(a, { ...this.g,
                    format: 1
                })
            });
            return this.l++
        }
        wg() {
            this.j.forEach(a => {
                gI(a, { ...this.g,
                    format: 1
                })
            });
            this.l++
        }
        Hg() {
            this.j.forEach(a => {
                fI(a, { ...this.g,
                    format: 3
                })
            });
            return this.l++
        }
        Gg() {
            this.j.forEach(a => {
                gI(a, { ...this.g,
                    format: 3
                })
            });
            return this.l++
        }
        jg() {
            this.j.forEach(a => {
                fI(a, { ...this.g,
                    format: 4
                })
            });
            return this.l++
        }
        ig() {
            this.j.forEach(a => {
                gI(a, { ...this.g,
                    format: 4
                })
            });
            return this.l++
        }
        ji() {
            this.j.forEach(a => {
                fI(a, { ...this.g,
                    format: 5
                })
            });
            return this.l++
        }
        ii() {
            this.j.forEach(a => {
                gI(a, { ...this.g,
                    format: 5
                })
            });
            return this.l++
        }
        qd(a) {
            var b = 0;
            bf(a, 2) != null ? b = 2 : bf(a, 3) != null ? b =
                1 : bf(a, 7) != null && (b = 3);
            this.j.forEach(c => {
                c.click({ ...this.g,
                    format: b
                })
            });
            return this.l++
        }
        bg() {
            this.j.forEach(a => {
                hI(a, { ...this.g,
                    format: 4
                })
            });
            return this.l++
        }
        ye(a) {
            var b = 0;
            Ae(a, Cp, 2, Gp) ? b = 1 : Ae(a, Bp, 3, Gp) && (b = 2);
            this.j.forEach(c => {
                iI(c, { ...this.g,
                    type: b
                })
            });
            this.l++
        }
        vg() {
            this.j.forEach(a => {
                jI(a, this.g)
            });
            this.l++
        }
    };

    function eI(a) {
        return a.g() ? [...lp(a.j())] : []
    }

    function dI(a) {
        switch (Se(a, $o)) {
            case 1:
                return 1;
            case 9:
                return 4;
            case 13:
                return 7;
            default:
                return 0
        }
    }

    function OH(a) {
        var b = new Map;
        for (let c of a) a = lI(c), b.set(a, (b.get(a) ? ? 0) + 1);
        return b
    }

    function lI(a) {
        switch (E(a, 1)) {
            case 1:
                return 1;
            case 2:
                return 2;
            case 3:
                return 3;
            case 4:
                return 4;
            case 5:
                return 5;
            default:
                return 0
        }
    };

    function mI(a, b) {
        var c = new Jp;
        var d = a.adIntentsPageState.takeNextPageEventIndex();
        c = xf(c, 1, d);
        b = xf(c, 2, Math.round(a.j.pa(b) - a.B));
        b = z(b, 10, a.A);
        b = sf(b, 15, a.C ? !0 : void 0);
        return F(b, 18, a.Mb)
    }
    var nI = class {
        constructor(a, b, c, d, e, f, g, h, k, l) {
            this.j = b;
            this.B = c;
            this.A = d;
            this.C = f;
            this.Mb = k;
            this.adIntentsPageState = l;
            this.l = [...g];
            this.g = h.length ? new kI(e, a, h, k) : null
        }
        lc() {
            return this.adIntentsPageState.takeNextAnnotationEntryId()
        }
        Ue(a) {
            this.g ? .Ue(a);
            var b = this.handle,
                c = mI(this, 11);
            a = A(c, 3, Kp, a);
            b.call(this, a)
        }
        Hf(a) {
            this.g ? .Hf(a);
            var b = this.handle,
                c = mI(this, 11);
            a = A(c, 14, Kp, a);
            b.call(this, a)
        }
        ti(a) {
            this.g ? .ti(a);
            var b = this.handle,
                c = mI(this, 11);
            a = A(c, 22, Kp, a);
            b.call(this, a)
        }
        Ph(a) {
            this.g ? .Ph(a);
            var b =
                this.handle,
                c = mI(this, 15);
            a = A(c, 4, Kp, a);
            return b.call(this, a)
        }
        Oh(a) {
            this.g ? .Oh(a);
            var b = this.handle,
                c = mI(this, 16);
            a = A(c, 5, Kp, a);
            return b.call(this, a)
        }
        xg(a) {
            this.g ? .xg(a);
            var b = this.handle,
                c = mI(this, 17);
            a = A(c, 6, Kp, a);
            return b.call(this, a)
        }
        wg(a) {
            this.g ? .wg(a);
            var b = this.handle,
                c = mI(this, 18);
            a = A(c, 7, Kp, a);
            b.call(this, a)
        }
        Hg(a) {
            this.g ? .Hg(a);
            var b = this.handle,
                c = mI(this, 19);
            a = A(c, 16, Kp, a);
            return b.call(this, a)
        }
        Gg(a) {
            this.g ? .Gg(a);
            var b = this.handle,
                c = mI(this, 20);
            a = A(c, 17, Kp, a);
            return b.call(this, a)
        }
        jg(a) {
            this.g ? .jg(a);
            var b = this.handle,
                c = mI(this, 21);
            a = A(c, 20, Kp, a);
            return b.call(this, a)
        }
        ig(a) {
            this.g ? .ig(a);
            var b = this.handle,
                c = mI(this, 22);
            a = A(c, 21, Kp, a);
            return b.call(this, a)
        }
        ji(a) {
            this.g ? .ji(a);
            var b = this.handle,
                c = mI(this, 23);
            a = A(c, 23, Kp, a);
            return b.call(this, a)
        }
        ii(a) {
            this.g ? .ii(a);
            var b = this.handle,
                c = mI(this, 24);
            a = A(c, 24, Kp, a);
            return b.call(this, a)
        }
        qd(a) {
            this.g ? .qd(a);
            var b = this.handle,
                c = mI(this, 14);
            a = A(c, 8, Kp, a);
            return b.call(this, a)
        }
        bg(a) {
            this.g ? .bg(a);
            var b = this.handle,
                c = mI(this, 14);
            a = A(c, 8, Kp, a);
            return b.call(this,
                a)
        }
        ye(a) {
            this.g ? .ye(a);
            var b = this.handle,
                c = mI(this, 25);
            a = A(c, 9, Kp, a);
            b.call(this, a)
        }
        vg(a) {
            this.g ? .vg(a);
            var b = this.handle,
                c = mI(this, 27);
            a = A(c, 12, Kp, a);
            b.call(this, a)
        }
        handle(a) {
            for (let b of this.l) b(a);
            return KH(hf(a, 1))
        }
    };

    function oI(a) {
        this.g = a || {
            cookie: ""
        }
    }

    function pI() {
        var a = qI;
        if (!t.navigator.cookieEnabled) return !1;
        if (!a.isEmpty()) return !0;
        a.set("TESTCOOKIESENABLED", "1", {
            Kf: 60
        });
        if (a.get("TESTCOOKIESENABLED") !== "1") return !1;
        rI(a, "TESTCOOKIESENABLED");
        return !0
    }
    r = oI.prototype;
    r.set = function(a, b, c) {
        var d = !1;
        if (typeof c === "object") {
            var e = c.sameSite;
            d = c.secure || !1;
            var f = c.domain || void 0;
            var g = c.path || void 0;
            var h = c.Kf
        }
        if (/[;=\s]/.test(a)) throw Error('Invalid cookie name "' + a + '"');
        if (/[;\r\n]/.test(b)) throw Error('Invalid cookie value "' + b + '"');
        h === void 0 && (h = -1);
        this.g.cookie = a + "=" + b + (f ? ";domain=" + f : "") + (g ? ";path=" + g : "") + (h < 0 ? "" : h == 0 ? ";expires=" + (new Date(1970, 1, 1)).toUTCString() : ";expires=" + (new Date(Date.now() + h * 1E3)).toUTCString()) + (d ? ";secure" : "") + (e != null ? ";samesite=" +
            e : "")
    };
    r.get = function(a, b) {
        var c = a + "=",
            d = (this.g.cookie || "").split(";");
        for (let e = 0, f; e < d.length; e++) {
            f = Ka(d[e]);
            if (f.lastIndexOf(c, 0) == 0) return f.slice(c.length);
            if (f == a) return ""
        }
        return b
    };

    function rI(a, b, c, d) {
        a.get(b);
        a.set(b, "", {
            Kf: 0,
            path: c,
            domain: d
        })
    }
    r.isEmpty = function() {
        return !this.g.cookie
    };
    r.Mc = function() {
        return this.g.cookie ? (this.g.cookie || "").split(";").length : 0
    };
    r.clear = function() {
        var a = (this.g.cookie || "").split(";"),
            b = [],
            c = [];
        for (let f = 0; f < a.length; f++) {
            var d = Ka(a[f]);
            var e = d.indexOf("=");
            e == -1 ? (b.push(""), c.push(d)) : (b.push(d.substring(0, e)), c.push(d.substring(e + 1)))
        }
        for (a = b.length - 1; a >= 0; a--) rI(this, b[a])
    };
    var qI = new oI(typeof document == "undefined" ? null : document);

    function sI(a, b = window) {
        if (a.ha()) try {
            return b.localStorage
        } catch {}
        return null
    }

    function tI(a) {
        return a.origin !== "null"
    }
    let uI;

    function vI(a) {
        return uI ? uI : tI(a) ? uI = wI(a) : uI = !1
    }

    function wI(a) {
        if (!a.navigator.cookieEnabled) return !1;
        var b = new oI(a.document);
        if (!b.isEmpty()) return !0;
        b.set("TESTCOOKIESENABLED", "1", {
            Kf: 60,
            sameSite: a.isSecureContext ? "none" : void 0,
            secure: a.isSecureContext || void 0
        });
        if (b.get("TESTCOOKIESENABLED") !== "1") return !1;
        rI(b, "TESTCOOKIESENABLED");
        return !0
    }

    function xI(a, b) {
        b = tI(b) ? b.document.cookie : null;
        return b === null ? null : (new oI({
            cookie: b
        })).get(a) || ""
    }

    function yI(a, b, c, d) {
        tI(d) && (d.isSecureContext && (c = { ...c,
            sameSite: "none",
            secure: !0
        }), (new oI(d.document)).set(a, b, c))
    }

    function zI(a, b, c) {
        tI(b) && rI(new oI(b.document), a, "/", c)
    };
    const AI = {
        gfpCookie: null,
        parsedGfpCookie: {
            id: null,
            creationTimeSeconds: null
        }
    };
    var BI = class {
        constructor(a) {
            this.win = a;
            this.Ua = void 0
        }
    };

    function CI(a) {
        var b = a.split(":");
        a = b.find(c => c.indexOf("ID") === 0) || null;
        b = b.find(c => c.indexOf("T=") === 0) ? .substring(2) || null;
        return {
            id: a,
            creationTimeSeconds: b
        }
    }

    function DI(a, b) {
        a = a.get("__gads", b);
        if (!a) return AI;
        b = CI(a);
        return {
            gfpCookie: a,
            parsedGfpCookie: b
        }
    };

    function EI(a, b) {
        if (!a) return null;
        a = new BI(a);
        b ? a.Ua ? b = a.Ua.get("__gads", b) : (a = a.win, b = b.ha() ? xI("__gads", a) : null) : b = null;
        return b ? Uu(b + "t2Z7mVic") % 20 : null
    };

    function FI(a) {
        return (a = a.match(/^[a-z]{2,3}/i)) ? a[0].toLowerCase() : ""
    };

    function YC(a, b, c, d) {
        c.addEventListener("click", GI(a, b, d))
    }

    function eD(a, b) {
        return a.A.has(b)
    }

    function jD(a, b, c) {
        b.requestAnimationFrame(GI(a, 898, c))
    }

    function bH(a, b, c, d) {
        return new IntersectionObserver(GI(a, b, c), d || {
            threshold: .98
        })
    }

    function zH(a, b, c) {
        a = GI(a, 898, c);
        b.addEventListener("scroll", a, {
            passive: !0
        });
        return a
    }

    function GI(a, b, c) {
        return a.ob.Zb(b, c, void 0, d => {
            d.es = a.M.Jd.join(",")
        })
    }
    var II = class {
        constructor(a, b, c, d, e, f, g) {
            this.ka = a;
            this.T = b;
            this.ob = c;
            this.g = d;
            this.P = e;
            this.M = f;
            this.Jc = g;
            this.G = new Map;
            this.D = new Map;
            this.O = new Map;
            this.C = new Map;
            this.J = new Map;
            this.j = new Map;
            this.l = new Map;
            this.A = new Map;
            this.B = hb(HI, D(b, 7)) ? 1 : 0;
            for (let h of hy(this.T)) Nf(h, 6) && this.G.set(fy(h), D(h, 6)), Nf(h, 7) && this.D.set(fy(h), D(h, 7)), Nf(h, 5) && this.O.set(fy(h), D(h, 5)), Nf(h, 12) && this.C.set(fy(h), D(h, 12)), Nf(h, 9) && this.J.set(fy(h), D(h, 9)), mf(h, 4).length && this.j.set(fy(h), mf(h, 4).join("~")), mf(h,
                2).length && this.l.set(fy(h), mf(h, 2).join("~")), ye(h, Eh, 10) ? this.A.set(fy(h), Te(h, Eh, 10)) : ye(h, Ch, 14) && this.A.set(fy(h), qg((new Eh).setContent(Te(h, Ch, 14))))
        }
        Pe(a, b, c) {
            a = GI(this, a, c);
            b.addEventListener("message", a);
            return a
        }
        uc(a, b, c, d) {
            return b.setTimeout(GI(this, a, c), d)
        }
        oi(a, b, c, d) {
            return b.setInterval(GI(this, a, c), d)
        }
        sa(a, b) {
            this.ob.sa(a, b, c => {
                c.es = this.M.Jd.join(",")
            });
            return b
        }
        pa(a) {
            return this.P.pa(a)
        }
        X() {
            return E(this.T, 12) === 2
        }
    };
    const HI = ["ja", "zh_CN", "zh_TW"];

    function JI(a, b, c, d) {
        var e = Bz(a, "div");
        e.classList.add("google-anno-skip", "goog-rentry");
        var f = KI(a, c);
        e.appendChild(f);
        J(e, {
            display: "flex",
            "flex-direction": "row",
            "justify-content": "flex-start",
            "padding-inline": W(16),
            "align-items": "center",
            "margin-bottom": W(0),
            "box-sizing": "border-box",
            height: W(58),
            width: "100%",
            "min-width": "0",
            color: "#3c4043",
            "font-family": "Google Sans, Roboto, Arial, sans-serif",
            "font-weight": "400",
            "font-size": W(18),
            "font-style": "normal",
            background: "#fff",
            cursor: "pointer"
        });
        a.getComputedStyle(d);
        e.appendChild(LI(a, b));
        e.tabIndex = 0;
        e.role = "link";
        e.ariaLabel = c;
        e.addEventListener("mouseenter", () => {
            J(f, {
                "text-decoration": "underline",
                "-webkit-text-decoration-line": "underline"
            })
        });
        e.addEventListener("mouseleave", () => {
            J(f, {
                "text-decoration": "none",
                "-webkit-text-decoration-line": "none"
            })
        });
        return e
    }

    function LI(a, b) {
        var c = Lz(a, "0 0 24 24", "24px", "24px", "M7.59009 18.59L9.00009 20L17.0001 12L9.00009 4L7.59009 5.41L14.1701 12");
        J(c, {
            fill: "#9aa0a6",
            color: "#9aa0a6",
            cursor: "inherit"
        });
        a = Bz(a, "span");
        J(a, {
            "margin-inline-start": "auto",
            "margin-inline-end": W(10),
            "font-weight": "bold",
            "align-items": "center",
            "justify-content": "center",
            "font-size": W(16)
        });
        b.X() && J(a, {
            transform: "scaleX(-1)"
        });
        a.appendChild(c);
        a.ariaHidden = "true";
        a.tabIndex = -1;
        return a
    }

    function KI(a, b) {
        var c = Bz(a, "span");
        c.appendChild(a.document.createTextNode(b));
        c.title = b;
        J(c, {
            "font-size": W(18),
            "padding-bottom": W(14),
            "padding-inline-start": W(5),
            "padding-inline-end": W(10),
            "padding-top": W(14),
            color: "#3c4043",
            width: "auto",
            "white-space": "nowrap",
            overflow: "hidden",
            "text-overflow": "ellipsis",
            "flex-shrink": "1",
            "min-width": "0"
        });
        return c
    };

    function MI(a) {
        a = Bz(a, "div");
        a.className = "goog-rentries";
        J(a, {
            display: "flex",
            "flex-direction": "row",
            width: "100%",
            "align-self": "stretch",
            "justify-content": "flex-start",
            "align-items": "center",
            "flex-shrink": "1",
            "flex-wrap": "wrap",
            "padding-bottom": W(5),
            margin: W(5),
            gap: W(2),
            "background-color": "#f8f9fa",
            "border-radius": W(4),
            border: "1px solid #dadce0",
            "box-sizing": "border-box"
        });
        return a
    }

    function NI(a, b, c) {
        var d = Bz(a, "span");
        d.innerText = b;
        d.ariaLabel = c;
        d.tabIndex = 0;
        d.role = "heading";
        d.ariaLevel = "2";
        J(d, {
            "font-weight": "700",
            "border-radius": W(2),
            "font-size": W(18),
            "padding-inline-start": W(16),
            "margin-bottom": W(0),
            "padding-bottom": W(14),
            "padding-top": W(14),
            color: "#4a4a4a"
        });
        a = Bz(a, "div");
        a.appendChild(d);
        J(a, {
            cursor: "inherit",
            direction: "inherit",
            "text-orientation": "inherit",
            visibility: "inherit",
            "writing-mode": "inherit",
            "font-size": W(18),
            "padding-inline-start": W(5),
            color: "#4a4a4a",
            "font-family": "Google Sans, Roboto, Arial, sans-serif",
            height: W(48),
            display: "flex",
            "flex-direction": "row",
            "justify-content": "flex-start",
            "align-items": "center"
        });
        return a
    }

    function OI(a, b) {
        var c = b.clientHeight;
        c === 0 && (a = a.getComputedStyle(b), a = Number(a.maxHeight.replace("px", "")), isNaN(a) || (c = a));
        c = Math.max(Math.floor((c - 48 - 10) / 58), 0);
        return c === 0 ? 0 : Math.min(8, c)
    }
    async function PI(a, b, c, d, e, f, g, h = 4) {
        var k = OI(a, g);
        if (!(k < 2 || c.size < 2)) {
            uu(a, ["Google Sans:400", "Google Sans:700"]);
            c = [...c];
            qc(f.getTermUsageCount) && c.sort((n, p) => f.getTermUsageCount(n) - f.getTermUsageCount(p));
            var l = MI(a),
                m = NI(a, D(d.T, 2), D(d.T, 4));
            l.appendChild(m);
            m = new jF;
            for (let n = 0; n < c.length; n++) {
                let p = c[n];
                if (n >= k) break;
                let q = h === 4 ? QI(a, b, g, d, e, m, p) : RI(a, b, g, d, e, m, p);
                l.appendChild(q);
                f.incrementTermUsageCount(p)
            }
            g.appendChild(l);
            l.appendChild(SI(a))
        }
    }

    function RI(a, b, c, d, e, f, g) {
        var h = BG(d.g.lc(), g, eD(d, g));
        WG(e, h);
        c = JI(a, d, g, c);
        var k = TI(c, d, kf(h));
        Dz(c);
        YC(d, 999, c, l => {
            try {
                if (!aD(f, d)) return !1;
                let p = b ? .document ? .body ? .tagName === "BODY" ? b : a,
                    q = bD(p, d, g);
                var m = vp(tp(g), kf(h));
                var n = wf(m, 11, k.Nh);
                let u = wp(F(n, 9, 5), q),
                    w = d.g.qd(u);
                cD(f, p, d, w, g, d.J.get(g) || "", 5, d.j.get(g) ? ? "", d.l.get(g) ? ? "", !1);
                return !1
            } finally {
                l.preventDefault(), l.stopImmediatePropagation()
            }
        });
        return c
    }

    function QI(a, b, c, d, e, f, g) {
        var h = AG(d.g.lc(), g, eD(d, g));
        WG(e, h);
        c = JI(a, d, g, c);
        var k = UI(c, d, kf(h));
        Dz(c);
        YC(d, 999, c, l => {
            try {
                if (!aD(f, d)) return !1;
                let p = b ? .document ? .body ? .tagName === "BODY" ? b : a,
                    q = bD(p, d, g);
                var m = vp(tp(g), kf(h));
                var n = wf(m, 8, k.Nh);
                let u = wp(F(n, 9, 4), q),
                    w = d.g.bg(u);
                cD(f, p, d, w, g, d.C.get(g) || "", 4, d.j.get(g) ? ? "", d.l.get(g) ? ? "", d.M.Vf);
                return !1
            } finally {
                l.preventDefault(), l.stopImmediatePropagation()
            }
        });
        return c
    }
    class VI {
        constructor() {
            this.B = this.l = null
        }
        get Nh() {
            return this.l
        }
        j(a, b) {
            if (!this.l) {
                var c = a.jg,
                    d = new Po;
                b = If(d, 1, b);
                this.l = c.call(a, b)
            }
        }
        g(a) {
            if (this.l && !this.B) {
                var b = a.ig;
                var c = new Oo;
                c = xf(c, 1, this.l);
                this.B = b.call(a, c)
            }
        }
    }
    class WI {
        constructor() {
            this.B = this.l = null
        }
        get Nh() {
            return this.l
        }
        j(a, b) {
            if (!this.l) {
                var c = a.ji,
                    d = new No;
                b = If(d, 1, b);
                this.l = c.call(a, b)
            }
        }
        g(a) {
            if (this.l && !this.B) {
                var b = a.ii;
                var c = new Mo;
                c = xf(c, 1, this.l);
                this.B = b.call(a, c)
            }
        }
    }

    function SI(a) {
        a = Bz(a, "div");
        J(a, {
            "align-self": "stretch",
            width: "100%",
            "background-color": "#dadce0",
            margin: "0",
            padding: "0"
        });
        return a
    }

    function UI(a, b, c) {
        var d = new VI;
        bH(b, 1065, e => {
            for (let f of e) f.isIntersecting ? d.j(b.g, c) : d.g(b.g)
        }).observe(a);
        return d
    }

    function TI(a, b, c) {
        var d = new WI;
        bH(b, 1065, e => {
            for (let f of e) f.isIntersecting ? d.j(b.g, c) : d.g(b.g)
        }).observe(a);
        return d
    };
    const XI = new Map([
        [1, 1],
        [2, 2]
    ]);
    async function YI(a, b, c, d, e, f, g, h, k) {
        var l = tB,
            m = EI(a, k) ? ? Math.floor(Uk() * 20);
        k = g.pa(0);
        var n = !!a && ks(a) < 488,
            p = c.T,
            q = FI(D(p, 7)),
            u = a ? bC(a).adIntentsPageState : new aC,
            w = new xp;
        m = vf(w, 2, m);
        m = Ye(m, 3, kd, c.M.Jd, xd, void 0, void 0, !0);
        e = new nI(q, g, k, m, d.Oj ? ? new Set, C(p, 17), e, f, c.Mb, u);
        f = new II(n, p, l, e, g, c.M, c.Jc);
        l = new IH;
        l.language = q;
        b = await ZI(a, b, f, d, h, l, u);
        e.Ue(GH(l, n, c.Pa, a ? .location ? .hostname || "", c.sb, p, g.pa(11) - k, b))
    }
    async function $I(a, b, c, d, e, f, g, h, k, l, m, n = 4) {
        var p = tB,
            q = FI(D(c.T, 7)),
            u = g.pa(0),
            w = b ? bC(b).adIntentsPageState : new aC,
            B = EI(b, h) ? ? Math.floor(Uk() * 20);
        h = c.T;
        var G = new xp;
        B = vf(G, 2, B);
        B = Ye(B, 3, kd, c.M.Jd, xd, void 0, void 0, !0);
        e = new nI(q, g, u, B, d.Oj ? ? new Set, C(h, 17), e, f, c.Mb, w);
        f = !!b && ks(b) < 488;
        h = new II(f, c.T, p, e, g, c.M, c.Jc);
        p = new IH;
        p.language = q;
        q = [];
        a ? .document ? .body && aJ(a.document.body) || q.push(Yo());
        m || q.length || (bJ(l, a) ? await h.sa(898, ZG(a, b, d, k, h, p, w, l, n)) : await h.sa(898, PI(a, b, k, h, p, w, l, n)));
        d = g.pa(11) -
            u;
        n === 4 ? (n = e.ti, a = a !== b, k = c.Pa, l = b ? .location ? .hostname || "", b = c.sb, c = c.T, g = new Ip, m = new To, k = Kf(m, 1, k), k = Kf(k, 2, l), f = tf(k, 3, f), f = tf(f, 5, a), f = z(g, 1, f), b = DH(p, b), b = z(f, 3, b), b = xf(b, 5, Math.round(d)), c = EH(c), c = z(b, 2, c), q.length ? (p = new dp, p = Xe(p, 1, q), A(c, 6, Hp, p)) : (q = new mp, p = $e(q, p.entries), A(c, 4, Hp, p)), n.call(e, c)) : e.Ue(GH(p, f, c.Pa, b ? .location ? .hostname || "", c.sb, c.T, d, q))
    }

    function bJ(a, b) {
        var c = a.clientHeight;
        c === 0 && (a = b.getComputedStyle(a), a = Number(a.maxHeight.replace("px", "")), isNaN(a) || (c = a));
        return c < 184
    }
    async function ZI(a, b, c, d, e, f, g) {
        if (!a) return [ap()];
        var h = a.document.body;
        if (!h || !aJ(h)) return [Yo()];
        e.g.pa(3) >= e.j && await RG(e, 4);
        h = [];
        (ks(a) < 250 || ls(a) < 300) && h.push(Yo());
        if (nf(c.T, 1).length) {
            let k = nf(c.T, 1).map(l => XI.get(l) ? ? 0);
            h.push(cp(new Zo, Vo(k)))
        }
        Tk() && h.push(bp());
        h.length || (c.M.Te > 0 && await kF(a, b, c), await rH(a, b, c, d, e, f, g));
        return h
    }

    function aJ(a) {
        try {
            (new ResizeObserver(() => {})).disconnect(), (new IntersectionObserver(() => {})).disconnect(), (new MutationObserver(() => {})).disconnect()
        } catch {
            return !1
        }
        return a.classList && a.classList.contains !== void 0 && a.attachShadow !== void 0
    };
    async function RG(a, b) {
        await new Promise(c => void a.win.setTimeout(c, 0));
        a.j = a.g.pa(b) + a.l
    }
    var cJ = class {
        constructor(a, b) {
            var c = V(Bx);
            this.win = a;
            this.g = b;
            this.l = c;
            this.j = b.pa(2) + c
        }
    };
    async function dJ(a, b, c, d, e, f, g) {
        var h = a.performance ? .now ? new eC(a.performance) : new fC,
            k = new cJ(a, h);
        if (!x(e)) throw Error(`Invalid config string ${e}`);
        e = ly(e);
        var l = Te(e, iy, 1),
            m = c.google_ad_client;
        if (!x(m)) throw new qB(`Invalid property code ${m}`);
        D(e, 5) && m !== D(e, 5) || (c = eJ(c), m = fJ(a, m, c), a = HB(), l = gJ(l), g = {
            T: BA(b) || Te(e, iy, 1),
            Pa: c,
            sb: g,
            Mb: 1,
            M: zA(l),
            Jc: m
        }, await hJ(b, d, a, g, { ...EA(),
            Ml: U(Mw),
            Ol: U(Ow),
            Nl: U(Nw),
            wordWindowSize: V(Ax),
            sameSearchTermPerWindow: V(Jx),
            annotationsPerWindow: V(Hx),
            maximumAnnotationsPerPage: V(Ix),
            Ai: V(Kx),
            Uk: V(yx),
            Tk: V(xx),
            Vk: V(zx)
        }, h, k, f))
    }
    async function iJ(a, b, c, d, e, f, g, h = !1) {
        var k = a.performance ? .now ? new eC(a.performance) : new fC,
            l = c.google_ad_client;
        if (!x(l)) throw new qB(`Invalid property code ${l}`);
        l === D(d, 2) && (c = eJ(c), l = fJ(a, l, c, Te(d, iy, 1)), d = AA(b, d, c, f, gJ(Te(d, iy, 1)), l), f = d.T, l = new Set(hy(f).filter(m => D(m, 12)).map(m => fy(m))), c = HB(), !h && bJ(g, a) && jJ(a, g, f), await $I(a, b, d, DA(), kJ(c, k, f), [new lJ(c, f)], k, e, l, g, h))
    }
    async function mJ(a, b, c, d, e, f, g) {
        var h = a.performance ? .now ? new eC(a.performance) : new fC,
            k = Te(f, iy, 1);
        c = fJ(a, c, d);
        d = CA(b, f, d, e, gJ(k), c);
        e = HB();
        f = new Set(hy(k).filter(l => D(l, 9)).map(l => fy(l)));
        await $I(a, b, d, DA(), kJ(e, h, k), [new lJ(e, k)], h, null, f, g, !1, 5)
    }

    function jJ(a, b, c) {
        uu(a, ["Google Sans Text:500"]);
        var d = a.document.createElement("div");
        J(d, rz(a));
        d.className = "goog-rtopics";
        d.innerText = D(c, 2);
        d.ariaLabel = D(c, 4);
        d.tabIndex = 0;
        J(d, {
            cursor: "inherit",
            direction: "inherit",
            "text-orientation": "inherit",
            visibility: "inherit",
            "writing-mode": "inherit",
            "font-family": "Google Sans Text",
            "font-size": "16px",
            "font-weight": "500",
            "line-height": "24px",
            "letter-spacing": "0%",
            color: "#5F6368",
            "text-align": "center",
            "border-radius": "5px",
            "padding-left": "5px",
            "padding-right": "5px",
            "padding-top": "2px",
            "padding-bottom": "2px",
            background: "#FFFFFF"
        });
        b.appendChild(d)
    }

    function kJ(a, b, c) {
        return [d => {
            tB.sa(1214, SB(a, d, b.pa(26)), e => {
                e.es = gJ(c)
            })
        }]
    }

    function gJ(a) {
        a = [42, ...$q(), ...(a ? .g() ? ? [])].filter(b => b > 0);
        return [...(new Set(a))].sort((b, c) => b - c)
    }

    function fJ(a, b, c) {
        var d = new hA(b, $B(a), nJ(a), c);
        return U(bx) ? new uA(b, $B(a), nJ(a), c, d) : d
    }
    async function hJ(a, b, c, d, e, f, g, h) {
        if (a) {
            let k = bC(a);
            if (k.wasReactiveAdConfigReceived[42]) return;
            k.wasReactiveAdConfigReceived[42] = !0
        }
        await YI(a, b, d, e, kJ(c, f, d.T), [new lJ(c, d.T)], f, g, h)
    }

    function XH(a, b) {
        oJ(a, c => c.Wk, {
            da: 1,
            ...b
        })
    }

    function $H(a, b) {
        oJ(a, c => c.Gn, {
            da: 1,
            ...b
        })
    }

    function YH(a, b) {
        oJ(a, c => c.hm, {
            da: 1,
            ...b
        })
    }

    function VH(a, b) {
        oJ(a, c => c.Xk, {
            da: 1,
            ...b
        })
    }

    function SH(a, b) {
        oJ(a, c => c.Hn, {
            da: 1,
            ...b
        })
    }

    function cI(a, b) {
        oJ(a, c => c.Yk, {
            da: 1,
            ...b
        })
    }

    function fI(a, b) {
        oJ(a, c => c.al, {
            da: 1,
            ...b
        })
    }

    function gI(a, b) {
        oJ(a, c => c.Zk, {
            da: 1,
            ...b
        })
    }

    function hI(a, b) {
        oJ(a, c => c.In, {
            da: 1,
            ...b
        })
    }

    function iI(a, b) {
        oJ(a, c => c.mn, {
            da: 1,
            ...b
        })
    }

    function jI(a, b) {
        oJ(a, c => c.Sk, {
            da: 1,
            ...b
        })
    }

    function oJ(a, b, c) {
        a.ea && a.ob.sa(1214, TB(a.ea, b, c), d => {
            d.es = gJ(a.g)
        })
    }

    function pJ(a, b, c) {
        a.ea && a.ob.sa(1214, UB(a.ea, b, c), d => {
            d.es = gJ(a.g)
        })
    }
    class lJ {
        constructor(a, b) {
            var c = tB;
            this.ea = a;
            this.ob = c;
            this.g = b
        }
        zg(a, b) {
            pJ(this, c => c.zg, {
                Zc: a != null && Dc(a) ? Number(a) : 0,
                ...b
            })
        }
        si(a, b) {
            pJ(this, c => c.si, {
                Zc: a != null && Dc(a) ? Number(a) : 0,
                ...b
            })
        }
        Ag(a, b) {
            oJ(this, c => c.Ag, {
                da: a,
                ...b
            })
        }
        ui(a, b) {
            oJ(this, c => c.ui, {
                da: a,
                ...b
            })
        }
        click(a) {
            oJ(this, b => b.xl, {
                da: 1,
                ...a
            })
        }
    }

    function eJ(a) {
        a = a.google_page_url;
        return x(a) ? a : ""
    }

    function nJ(a) {
        return Yk(a, {
            Ja: () => {}
        })
    };
    var qJ = class extends O {
        constructor({
            pubWin: a,
            K: b,
            gi: c,
            Pa: d,
            sb: e
        }) {
            super();
            this.j = [];
            this.pubWin = a;
            this.K = b;
            this.gi = c;
            this.Pa = d;
            this.sb = e
        }
        g() {
            for (let a of this.j) a();
            this.j.length = 0;
            super.g()
        }
    };
    var rJ = {
            Lc: "ama_success",
            ac: .1,
            qc: !0,
            Pc: !0
        },
        sJ = {
            Lc: "ama_failure",
            ac: .1,
            qc: !0,
            Pc: !0
        },
        tJ = {
            Lc: "ama_coverage",
            ac: .1,
            qc: !0,
            Pc: !0
        },
        uJ = {
            Lc: "ama_opt",
            ac: .1,
            qc: !0,
            Pc: !1
        },
        vJ = {
            Lc: "ama_auto_rs",
            ac: 1,
            qc: !0,
            Pc: !1
        },
        wJ = {
            Lc: "ama_reltops",
            ac: 1,
            qc: !0,
            Pc: !1
        },
        xJ = {
            Lc: "ama_constraints",
            ac: 0,
            qc: !0,
            Pc: !0
        };

    function yJ(a, b, c) {
        b = {
            sts: b
        };
        c && (b.excp_n = c.name, b.excp_m = c.message && c.message.substring(0, 512), b.excp_s = c.stack && Ol(c.stack, "") || "");
        zJ(a.ea, wJ, { ...b,
            evt: "place",
            vh: ls(a.win),
            eid: JH(a.g.j() ? .g()) || 0,
            hl: y(a.g, AJ, 5) ? .g() || ""
        })
    }
    var BJ = class {
        constructor(a, b, c) {
            this.win = a;
            this.ea = b;
            this.g = c
        }
    };
    var CJ = class extends I {
        setProperty(a) {
            return Jf(this, 1, a)
        }
        getValue() {
            return qf(this, 2)
        }
    };
    var DJ = class extends I {};
    var EJ = class extends I {
        ya() {
            return y(this, Su, 1)
        }
        j() {
            return rf(this, 2)
        }
    };
    var FJ = class extends I {};
    var GJ = class extends I {
        ya() {
            return y(this, Su, 1)
        }
        j() {
            return rf(this, 2)
        }
    };
    var HJ = class extends I {};
    var IJ = class extends I {
        g() {
            return Ve(this, HJ, 1, De())
        }
    };

    function JJ(a) {
        if (a.nodeType != 1) var b = !1;
        else if (b = a.tagName == "INS") a: {
            b = ["adsbygoogle-placeholder"];
            var c = a.className ? a.className.split(/\s+/) : [];a = {};
            for (let d = 0; d < c.length; ++d) a[c[d]] = !0;
            for (c = 0; c < b.length; ++c)
                if (!a[b[c]]) {
                    b = !1;
                    break a
                }
            b = !0
        }
        return b
    }

    function KJ(a) {
        return zs(a.querySelectorAll("ins.adsbygoogle-ablated-ad-slot"))
    };

    function LJ(a, b) {
        a = xj(new hj(a), "DIV");
        var c = a.style;
        c.width = "100%";
        c.height = "auto";
        c.clear = b ? "both" : "none";
        return a
    }

    function MJ(a, b, c) {
        switch (c) {
            case 0:
                b.parentNode && b.parentNode.insertBefore(a, b);
                break;
            case 3:
                if (c = b.parentNode) {
                    let d = b.nextSibling;
                    if (d && d.parentNode != c)
                        for (; d && d.nodeType == 8;) d = d.nextSibling;
                    c.insertBefore(a, d)
                }
                break;
            case 1:
                b.insertBefore(a, b.firstChild);
                break;
            case 2:
                b.appendChild(a)
        }
        JJ(b) && (b.setAttribute("data-init-display", b.style.display), b.style.display = "block")
    }

    function NJ(a) {
        if (a && a.parentNode) {
            let b = a.parentNode;
            b.removeChild(a);
            JJ(b) && (b.style.display = b.getAttribute("data-init-display") || "none")
        }
    };
    var PJ = (a, b, c, d = 0) => {
            var e = OJ(b, c, d);
            if (e.init) {
                for (c = b = e.init; c = e.vf(c);) b = c;
                e = {
                    anchor: b,
                    position: e.Pf
                }
            } else e = {
                anchor: b,
                position: c
            };
            a["google-ama-order-assurance"] = d;
            MJ(a, e.anchor, e.position)
        },
        QJ = (a, b, c, d = 0) => {
            U(ow) ? PJ(a, b, c, d) : MJ(a, b, c)
        };

    function OJ(a, b, c) {
        var d = f => {
                f = RJ(f);
                return f == null ? !1 : c < f
            },
            e = f => {
                f = RJ(f);
                return f == null ? !1 : c > f
            };
        switch (b) {
            case 0:
                return {
                    init: SJ(a.previousSibling, d),
                    vf: f => SJ(f.previousSibling, d),
                    Pf: 0
                };
            case 2:
                return {
                    init: SJ(a.lastChild, d),
                    vf: f => SJ(f.previousSibling, d),
                    Pf: 0
                };
            case 3:
                return {
                    init: SJ(a.nextSibling, e),
                    vf: f => SJ(f.nextSibling, e),
                    Pf: 3
                };
            case 1:
                return {
                    init: SJ(a.firstChild, e),
                    vf: f => SJ(f.nextSibling, e),
                    Pf: 3
                }
        }
        throw Error("Un-handled RelativePosition: " + b);
    }

    function RJ(a) {
        return a.hasOwnProperty("google-ama-order-assurance") ? a["google-ama-order-assurance"] : null
    }

    function SJ(a, b) {
        return a && b(a) ? a : null
    };

    function TJ(a, b) {
        do {
            let c = al(a, b);
            if (c && c.position === "fixed") return !1
        } while (a = a.parentElement);
        return !0
    }

    function UJ(a, b, c) {
        var d;
        return a.style && !!a.style[c] && el(a.style[c]) || (d = al(a, b)) && !!d[c] && el(d[c]) || null
    }

    function VJ(a, b) {
        try {
            let c = b.document.documentElement.getBoundingClientRect(),
                d = a.getBoundingClientRect();
            return {
                x: d.left - c.left,
                y: d.top - c.top
            }
        } catch (c) {
            return null
        }
    }

    function WJ(a, b) {
        return (a = VJ(a, b)) ? a.y : 0
    }

    function XJ(a, b) {
        a = WJ(a, b);
        b = ls(b);
        return a < b - 100
    }

    function YJ(a, b) {
        var c = UJ(b, a, "height");
        if (c) return c;
        var d = b.style.height;
        b.style.height = "inherit";
        c = UJ(b, a, "height");
        b.style.height = d;
        if (c) return c;
        c = Infinity;
        do(d = b.style && el(b.style.height)) && (c = Math.min(c, d)), (d = UJ(b, a, "maxHeight")) && (c = Math.min(c, d)); while (b.parentElement && (b = b.parentElement) && b.tagName !== "HTML");
        return c
    };

    function ZJ(a, b) {
        var c;
        return a.style && a.style.zIndex || (c = al(a, b)) && c.zIndex || null
    };

    function $J(a, b) {
        for (let c = 0; c < b.length; c++) {
            let d = b[c],
                e = Ri(d.property);
            a[e] = d.value
        }
    }

    function aK(a, b, c, d, e, f) {
        a = bK(a, e);
        a.Hb.setAttribute("data-ad-format", d ? d : "auto");
        cK(a, b, c, f);
        return a
    }

    function dK(a, b, c = null) {
        a = bK(a, {});
        cK(a, b, null, c);
        return a
    }

    function cK(a, b, c, d) {
        var e = [];
        if (d = d && d.bj) a.td.className = d.join(" ");
        a = a.Hb;
        a.className = "adsbygoogle";
        a.setAttribute("data-ad-client", b);
        c && a.setAttribute("data-ad-slot", c);
        e.length && a.setAttribute("data-ad-channel", e.join("+"))
    }

    function bK(a, b) {
        var c = LJ(a, b.clearBoth || !1),
            d = c.style;
        d.textAlign = "center";
        b.Of && $J(d, b.Of);
        a = xj(new hj(a), "INS");
        d = a.style;
        d.display = "block";
        d.margin = "auto";
        d.backgroundColor = "transparent";
        b.Ci && (d.marginTop = b.Ci);
        b.Cg && (d.marginBottom = b.Cg);
        b.Wd && $J(d, b.Wd);
        c.appendChild(a);
        return {
            td: c,
            Hb: a
        }
    }

    function eK(a, b, c, d = null) {
        b.dataset.adsbygoogleStatus = "reserved";
        b.className += " adsbygoogle-noablate";
        var e = {
            element: b
        };
        c = c && c.oe();
        if (d) c = d.LmpfC ? ? c, e.ofxVI = {
            recYb: d
        };
        else if (b.hasAttribute("data-pub-vars")) {
            try {
                c = JSON.parse(b.getAttribute("data-pub-vars"))
            } catch (f) {
                return
            }
            b.removeAttribute("data-pub-vars")
        }
        c && (e.params = c);
        (a.adsbygoogle = a.adsbygoogle || []).push(e)
    }

    function fK(a) {
        var b = a.fqjyf;
        if (b != null)
            for (let e of KJ(a.document)) {
                var c = a,
                    d = WJ(e, c);
                c = ls(c);
                if (d < c) continue;
                if (d = gK(e, b)) e.removeAttribute("height"), e.style.removeProperty("height"), e.removeAttribute("width"), e.style.removeProperty("width"), eK(a, e, null, d)
            }
    }

    function gK(a, b) {
        return (a = a.getAttribute("google_element_uid")) ? b && b[a] || null : null
    };
    var iK = (a, b, c) => {
        if (!b || !c) return !1;
        var d = b.parentElement,
            e = c.parentElement;
        if (!d || !e || d != e) return !1;
        d = 0;
        for (b = b.nextSibling; d < 10 && b;) {
            if (b == c) return !0;
            if (hK(a, b)) break;
            b = b.nextSibling;
            d++
        }
        return !1
    };
    const hK = (a, b) => {
        if (b.nodeType == 3) return b.nodeType == 3 ? (b = b.data, a = b.indexOf("&") != -1 ? Oi(b, a.document) : b, a = /\S/.test(a)) : a = !1, a;
        if (b.nodeType == 1) {
            var c = a.getComputedStyle(b);
            if (c.opacity == "0" || c.display == "none" || c.visibility == "hidden") return !1;
            if ((c = b.tagName) && $s.contains(c.toUpperCase())) return !0;
            b = b.childNodes;
            for (c = 0; c < b.length; c++)
                if (hK(a, b[c])) return !0
        }
        return !1
    };
    var jK = a => {
        if (a >= 460) return a = Math.min(a, 1200), Math.ceil(a < 800 ? a / 4 : 200);
        a = Math.min(a, 600);
        return a <= 420 ? Math.ceil(a / 1.2) : Math.ceil(a / 1.91) + 130
    };
    var kK = class {
        constructor() {
            this.g = {
                clearBoth: !0
            }
        }
        j(a, b, c, d) {
            return aK(d.document, a, null, null, this.g, b)
        }
        l(a) {
            return jK(Math.min(a.screen.width || 0, a.screen.height || 0))
        }
    };
    var lK = class extends I {};
    var mK = class extends I {};
    var nK = class extends I {
        j() {
            return qf(this, 2)
        }
        g() {
            return qf(this, 5)
        }
        B() {
            return Ve(this, mK, 3, De())
        }
        A() {
            return ff(this, 4)
        }
        C() {
            return Ce(this, 6)
        }
        O() {
            return ye(this, lK, 7)
        }
    };
    var oK = class extends I {};
    var pK = class extends I {
        B() {
            return C(this, 12)
        }
        j() {
            return cf(this, 13)
        }
        g() {
            return ef(this, 23)
        }
    };
    var qK = class extends I {};

    function rK(a) {
        return Ce(a, 1, te)
    }
    var sK = class extends I {
        g() {
            return rf(this, 3)
        }
        j() {
            return pf(this, 6)
        }
    };
    var tK = class extends I {};
    var uK = class extends I {};
    var vK = class extends I {};
    var wK = class extends I {};
    var xK = class extends I {
            getName() {
                return qf(this, 4)
            }
        },
        yK = [1, 2, 3];
    var zK = class extends I {
        g() {
            return y(this, sK, 10)
        }
    };

    function AK(a) {
        return pf(a, 1)
    }
    var BK = class extends I {
        g() {
            return pf(this, 2)
        }
        j() {
            return ef(this, 2)
        }
        B() {
            return pf(this, 3)
        }
    };
    var CK = class extends I {
        g() {
            return cf(this, 1, te)
        }
    };
    var DK = class extends I {
        g() {
            return hf(this, 1)
        }
    };
    var AJ = class extends I {
        g() {
            return D(this, 1)
        }
        j() {
            return D(this, 2)
        }
    };
    var EK = class extends I {
        B() {
            return C(this, 1)
        }
        A() {
            return C(this, 3)
        }
        C() {
            return C(this, 7)
        }
        g() {
            return C(this, 4)
        }
        j() {
            return C(this, 5)
        }
    };
    var FK = class extends I {
        j() {
            return y(this, DK, 6)
        }
        B() {
            return C(this, 14)
        }
        g() {
            return y(this, EK, 12)
        }
    };
    var GK = class extends I {};
    var HK = class extends I {};
    var IK = class extends I {},
        JK = qh(IK);
    var KK = class extends I {
        g() {
            return hf(this, 1)
        }
    };
    var LK = class extends I {};
    var NK = class extends I {
            g() {
                return of(this, LK, 2, MK)
            }
        },
        MK = [1, 2];
    var OK = class extends I {
        g() {
            return y(this, NK, 3)
        }
    };
    var PK = class extends I {};
    var QK = class extends I {
        g() {
            return Ve(this, PK, 1, De())
        }
    };
    var RK = class extends I {
        g() {
            return mf(this, 1)
        }
        j() {
            return y(this, OK, 3)
        }
    };
    var SK = class extends I {};
    var TK = class extends I {};

    function UK(a) {
        return Ve(a, GJ, 1, De())
    }

    function VK(a) {
        return y(a, FK, 28)
    }
    var WK = qh(class extends I {
        g() {
            return y(this, pK, 15)
        }
    });

    function XK(a) {
        var b = [];
        ys(a.getElementsByTagName("p"), function(c) {
            YK(c) >= 100 && b.push(c)
        });
        return b
    }

    function YK(a) {
        if (a.nodeType == 3) return a.length;
        if (a.nodeType != 1 || a.tagName == "SCRIPT") return 0;
        var b = 0;
        ys(a.childNodes, function(c) {
            b += YK(c)
        });
        return b
    }

    function ZK(a) {
        return a.length == 0 || isNaN(a[0]) ? a : "\\" + (30 + parseInt(a[0], 10)) + " " + a.substring(1)
    }

    function $K(a, b) {
        if (a.g == null) return b;
        switch (a.g) {
            case 1:
                return b.slice(1);
            case 2:
                return b.slice(0, b.length - 1);
            case 3:
                return b.slice(1, b.length - 1);
            case 0:
                return b;
            default:
                throw Error("Unknown ignore mode: " + a.g);
        }
    }

    function aL(a, b) {
        var c = [];
        try {
            c = b.querySelectorAll(a.B)
        } catch (d) {}
        if (!c.length) return [];
        b = mb(c);
        b = $K(a, b);
        typeof a.j === "number" && (c = a.j, c < 0 && (c += b.length), b = c >= 0 && c < b.length ? [b[c]] : []);
        if (typeof a.l === "number") {
            c = [];
            for (let d = 0; d < b.length; d++) {
                let e = XK(b[d]),
                    f = a.l;
                f < 0 && (f += e.length);
                f >= 0 && f < e.length && c.push(e[f])
            }
            b = c
        }
        return b
    }
    var bL = class {
        constructor(a, b, c, d) {
            this.B = a;
            this.j = b;
            this.l = c;
            this.g = d
        }
        toString() {
            return JSON.stringify({
                nativeQuery: this.B,
                occurrenceIndex: this.j,
                paragraphIndex: this.l,
                ignoreMode: this.g
            })
        }
    };
    var cL = class {
        constructor() {
            this.g = fi `https://pagead2.googlesyndication.com/pagead/js/err_rep.js`
        }
        Da(a, b, c = .01, d = "jserror") {
            if (Math.random() > c) return !1;
            b.error && b.meta && b.id || (b = new Ll(b, {
                context: a,
                id: d
            }));
            t.google_js_errors = t.google_js_errors || [];
            t.google_js_errors.push(b);
            t.error_rep_loaded || (Zk(t.document, this.g), t.error_rep_loaded = !0);
            return !1
        }
        Yb(a, b) {
            try {
                return b()
            } catch (c) {
                if (!this.Da(a, c, .01, "jserror")) throw c;
            }
        }
        Zb(a, b, c) {
            return (...d) => this.Yb(a, () => b.apply(c, d))
        }
        sa(a, b) {
            b.catch(c => {
                c = c ? c : "unknown rejection";
                this.Da(a, c instanceof Error ? c : Error(c), void 0)
            })
        }
    };

    function dL(a, b) {
        b = b.google_js_reporting_queue = b.google_js_reporting_queue || [];
        b.length < 2048 && b.push(a)
    }

    function eL(a, b, c, d, e = !1) {
        var f = d || window,
            g = typeof queueMicrotask !== "undefined";
        return function(...h) {
            e && g && queueMicrotask(() => {
                f.google_rum_task_id_counter = f.google_rum_task_id_counter || 1;
                f.google_rum_task_id_counter += 1
            });
            var k = Vl(),
                l = 3;
            try {
                var m = b.apply(this, h)
            } catch (n) {
                l = 13;
                if (!c) throw n;
                c(a, n)
            } finally {
                f.google_measure_js_timing && k && dL({
                    label: a.toString(),
                    value: k,
                    duration: (Vl() || 0) - k,
                    type: l,
                    ...(e && g && {
                        taskId: f.google_rum_task_id_counter = f.google_rum_task_id_counter || 1
                    })
                }, f)
            }
            return m
        }
    }

    function fL(a, b) {
        return eL(754, a, (c, d) => {
            (new cL).Da(c, d)
        }, b, !0)
    };

    function gL(a, b, c) {
        return eL(a, b, void 0, c, !0).apply()
    }

    function hL(a, b) {
        return fL(a, b).apply()
    }

    function iL(a) {
        if (!a) return null;
        var b = qf(a, 7);
        if (qf(a, 1) || a.getId() || mf(a, 4).length > 0) {
            var c = a.getId(),
                d = qf(a, 1),
                e = mf(a, 4);
            b = ff(a, 2, te);
            var f = ff(a, 5, te);
            a = jL(rf(a, 6));
            let g = "";
            d && (g += d);
            c && (g += "#" + ZK(c));
            if (e)
                for (c = 0; c < e.length; c++) g += "." + ZK(e[c]);
            b = (e = g) ? new bL(e, b, f, a) : null
        } else b = b ? new bL(b, ff(a, 2, te), ff(a, 5, te), jL(rf(a, 6))) : null;
        return b
    }
    const kL = {
        1: 1,
        2: 2,
        3: 3,
        0: 0
    };

    function jL(a) {
        return a == null ? a : kL[a]
    }

    function lL(a) {
        var b = [];
        for (let c = 0; c < a.length; c++) {
            let d = qf(a[c], 1),
                e = a[c].getValue();
            d && e != null && b.push({
                property: d,
                value: e
            })
        }
        return b
    }

    function mL(a, b) {
        var c = {};
        a && (c.Ci = qf(a, 1), c.Cg = qf(a, 2), c.clearBoth = !!pf(a, 3));
        b && (c.Of = lL(Ve(b, CJ, 3, De()).map(d => Sd(d))), c.Wd = lL(Ve(b, CJ, 4, De()).map(d => Sd(d))));
        return c
    }
    const nL = {
            1: 0,
            2: 1,
            3: 2,
            4: 3
        },
        oL = {
            0: 1,
            1: 2,
            2: 3,
            3: 4
        };
    var pL = class {
        constructor(a) {
            this.g = a
        }
        j(a, b, c, d) {
            return aK(d.document, a, null, null, this.g, b)
        }
        l() {
            return null
        }
    };
    var qL = class {
        constructor(a) {
            this.j = a
        }
        g(a) {
            a = Math.floor(a.j);
            var b = jK(a);
            return new dv(["ap_container"], {
                google_reactive_ad_format: 27,
                google_responsive_auto_format: 16,
                google_max_num_ads: 1,
                google_ad_type: this.j,
                google_ad_format: a + "x" + b,
                google_ad_width: a,
                google_ad_height: b
            })
        }
    };
    var rL = class {
        constructor(a, b) {
            this.B = a;
            this.l = b
        }
        g() {
            return this.B
        }
        j() {
            return this.l
        }
    };
    var sL = class {
        constructor(a) {
            this.g = a
        }
        j(a, b, c, d) {
            var e = Ve(this.g, DJ, 9, De()).length > 0 ? Ve(this.g, DJ, 9, De())[0] : null,
                f = mL(Te(this.g, FJ, 3), e);
            if (!e) return null;
            if (e = qf(e, 1)) {
                d = d.document;
                var g = c.tagName;
                c = xj(new hj(d), g);
                c.style.clear = f.clearBoth ? "both" : "none";
                g == "A" && (c.style.display = "block");
                c.style.padding = "0px";
                c.style.margin = "0px";
                f.Of && $J(c.style, f.Of);
                d = xj(new hj(d), "INS");
                f.Wd && $J(d.style, f.Wd);
                c.appendChild(d);
                f = {
                    td: c,
                    Hb: d
                };
                f.Hb.setAttribute("data-ad-type", "text");
                f.Hb.setAttribute("data-native-settings-key",
                    e);
                cK(f, a, null, b);
                a = f
            } else a = null;
            return a
        }
        l() {
            var a = Ve(this.g, DJ, 9, De()).length > 0 ? Ve(this.g, DJ, 9, De())[0] : null;
            if (!a) return null;
            a = Ve(a, CJ, 3, De());
            for (let b = 0; b < a.length; b++) {
                let c = a[b];
                if (qf(c, 1) == "height" && parseInt(c.getValue(), 10) > 0) return parseInt(c.getValue(), 10)
            }
            return null
        }
    };
    var tL = class {
        constructor(a) {
            this.g = a
        }
        j(a, b, c, d) {
            if (!this.g) return null;
            var e = this.g.google_ad_format || null,
                f = this.g.google_ad_slot || null;
            if (c = c.style) {
                var g = [];
                for (let h = 0; h < c.length; h++) {
                    let k = c.item(h);
                    k !== "width" && k !== "height" && g.push({
                        property: k,
                        value: c.getPropertyValue(k)
                    })
                }
                c = {
                    Wd: g
                }
            } else c = {};
            a = aK(d.document, a, f, e, c, b);
            a.Hb.setAttribute("data-pub-vars", JSON.stringify(this.g));
            return a
        }
        l() {
            return this.g ? parseInt(this.g.google_ad_height, 10) || null : null
        }
        oe() {
            return this.g
        }
    };
    var uL = class {
        constructor(a) {
            this.j = a
        }
        g() {
            return new dv([], {
                google_ad_type: this.j,
                google_reactive_ad_format: 26,
                google_ad_format: "fluid"
            })
        }
    };
    var vL = class {
        constructor(a, b) {
            this.B = a;
            this.l = b
        }
        j() {
            return this.l
        }
        g(a) {
            a = aL(this.B, a.document);
            return a.length > 0 ? a[0] : null
        }
    };

    function wL(a, b, c) {
        var d = [];
        for (let p = 0; p < a.length; p++) {
            a: {
                var e = a[p];
                var f = p,
                    g = b,
                    h = c,
                    k = e.ya();
                if (!k) {
                    e = null;
                    break a
                }
                var l = iL(k);
                if (!l) {
                    e = null;
                    break a
                }
                var m = e.j();m = nL[m];
                var n = m === void 0 ? null : m;
                if (n === null) {
                    e = null;
                    break a
                }
                m = (m = y(e, FJ, 3)) ? pf(m, 3) : null;l = new vL(l, n);n = nf(e, 10).slice(0);ff(k, 5) != null && n.push(1);k = ff(e, 12, te);
                let q = ye(e, bv, 4) ? y(e, bv, 4) : null;fd(ue(e, 8)) == 1 ? (h = h && h.ll || null, e = new xL(l, new pL(mL(y(e, FJ, 3), null)), h, m, 0, n, q, g, f, k, e)) : e = fd(ue(e, 8)) == 2 ? new xL(l, new sL(e), h && h.ym || new uL("text"),
                    m, 1, n, q, g, f, k, e) : null
            }
            e !== null && d.push(e)
        }
        return d
    }

    function yL(a) {
        return a.B
    }

    function zL(a) {
        return a.Ba
    }

    function AL(a) {
        return a.C instanceof tL ? a.C.oe() : null
    }

    function BL(a, b, c) {
        As(a.P, b) || a.P.set(b, []);
        a.P.get(b).push(c)
    }

    function CL(a) {
        return LJ(a.g.document, a.G || !1)
    }

    function DL(a) {
        return a.C.l(a.g)
    }

    function EL(a, b = null, c = null) {
        return new xL(a.O, b || a.C, c || a.W, a.G, a.Fd, a.Ed, a.ag, a.g, a.la, a.D, a.l, a.A, a.Z)
    }
    var xL = class {
        constructor(a, b, c, d, e, f, g, h, k, l = null, m = null, n = null, p = null) {
            this.O = a;
            this.C = b;
            this.W = c;
            this.G = d;
            this.Fd = e;
            this.Ed = f;
            this.ag = g ? g : new bv;
            this.g = h;
            this.la = k;
            this.D = l;
            this.l = m;
            (a = !m) || ((a = !m.ya()) || (m = m.ya(), a = ff(m, 5) == null), a = !!a);
            this.Ba = !a;
            this.A = n;
            this.Z = p;
            this.J = [];
            this.B = !1;
            this.P = new Es
        }
        ua() {
            return this.g
        }
        j() {
            return this.O.j()
        }
    };

    function FL(a, b, c, d, e, f) {
        var g = av();
        return new xL(new rL(c, e), new kK, new qL(a), !0, 2, [], g, d, null, null, null, b, f)
    }

    function GL(a, b, c, d, e) {
        var f = av();
        return new xL(new rL(b, d), new pL({
            clearBoth: !0
        }), null, !0, 2, [], f, c, null, null, null, a, e)
    };
    var HL = class {
        constructor(a, b, c) {
            this.articleStructure = a;
            this.element = b;
            this.win = c
        }
        ua() {
            return this.win
        }
        A(a) {
            return FL(a, this.articleStructure, this.element, this.win, 3, null)
        }
        j() {
            return GL(this.articleStructure, this.element, this.win, 3, null)
        }
    };
    const IL = {
        TABLE: {
            fe: new Eu([1, 2])
        },
        THEAD: {
            fe: new Eu([0, 3, 1, 2])
        },
        TBODY: {
            fe: new Eu([0, 3, 1, 2])
        },
        TR: {
            fe: new Eu([0, 3, 1, 2])
        },
        TD: {
            fe: new Eu([0, 3])
        }
    };

    function JL(a, b, c, d) {
        var e = c.childNodes;
        c = c.querySelectorAll(b);
        b = [];
        for (let f of c) c = $a(e, f), c < 0 || b.push(new KL(a, [f], c, f, 3, tj(f).trim(), d));
        return b
    }

    function LL(a, b, c) {
        var d = [],
            e = [],
            f = b.childNodes,
            g = f.length,
            h = 0,
            k = "";
        for (let n = 0; n < g; n++) {
            var l = f[n];
            if (l.nodeType != 1 && l.nodeType != 3) continue;
            a: {
                if (l.nodeType != 1) {
                    var m = null;
                    break a
                }
                if (l.tagName == "BR") {
                    m = l;
                    break a
                }
                m = c.getComputedStyle(l).getPropertyValue("display");m = m == "inline" || m == "inline-block" ? null : l
            }
            if (m) {
                d.length && k && e.push(new KL(a, d, n - 1, m, 0, k, c));
                d = [];
                h = n + 1;
                k = "";
                continue
            }
            d.push(l);
            l = tj(l).trim();
            k += l && k ? " " + l : l
        }
        d.length && k && e.push(new KL(a, d, h, b, 2, k, c));
        return e
    }

    function ML(a, b) {
        return a.g - b.g
    }
    var KL = class {
        constructor(a, b, c, d, e, f, g) {
            this.B = a;
            this.Ze = b.slice(0);
            this.g = c;
            this.mg = d;
            this.ng = e;
            this.C = f;
            this.l = g
        }
        ua() {
            return this.l
        }
        A(a) {
            return FL(a, this.B, this.mg, this.l, this.ng, this.g)
        }
        j() {
            return GL(this.B, this.mg, this.l, this.ng, this.g)
        }
    };

    function NL(a) {
        return lb(a.C ? LL(a.g, a.l, a.j) : [], a.A ? JL(a.g, a.A, a.l, a.j) : []).filter(b => {
            var c = b.mg.tagName;
            c ? (c = IL[c.toUpperCase()], b = c != null && c.fe.contains(b.ng)) : b = !1;
            return !b
        })
    }
    var OL = class {
        constructor(a, b, c) {
            this.l = a;
            this.A = b.Xe;
            this.C = b.pj;
            this.g = b.articleStructure;
            this.j = c;
            this.B = b.Qi
        }
    };

    function PL(a, b) {
        if (!b) return !1;
        var c = sa(b),
            d = a.g.get(c);
        if (d != null) return d;
        if (b.nodeType == 1 && (b.tagName == "UL" || b.tagName == "OL") && a.j.getComputedStyle(b).getPropertyValue("list-style-type") != "none") return a.g.set(c, !0), !0;
        b = PL(a, b.parentNode);
        a.g.set(c, b);
        return b
    }

    function QL(a, b) {
        return fb(b.Ze, c => PL(a, c))
    }
    var RL = class {
        constructor(a) {
            this.g = new Es;
            this.j = a
        }
    };
    var SL = class {
        constructor(a, b) {
            this.B = a;
            this.g = [];
            this.j = [];
            this.l = b
        }
    };
    var UL = (a, {
            Dj: b = !1,
            ri: c = !1,
            Pj: d = c ? 2 : 3,
            ni: e = null
        } = {}) => {
            a = NL(a);
            return TL(a, {
                Dj: b,
                ri: c,
                Pj: d,
                ni: e
            })
        },
        TL = (a, {
            Dj: b = !1,
            ri: c = !1,
            Pj: d = c ? 2 : 3,
            ni: e = null
        } = {}) => {
            if (d < 2) throw Error("minGroupSize should be at least 2, found " + d);
            var f = a.slice(0);
            f.sort(ML);
            a = [];
            b = new SL(b, e);
            for (let h of f) {
                e = {
                    Qf: h,
                    Cf: h.C.length < 51 ? !1 : b.l != null ? !QL(b.l, h) : !0
                };
                if (b.B || e.Cf) {
                    a: {
                        var g = b;f = e.Qf;
                        if (!g.g.length) {
                            f = !0;
                            break a
                        }
                        g = g.g[g.g.length - 1].Qf;f = iK(g.ua(), g.Ze[g.Ze.length - 1], f.Ze[0])
                    }
                    f ? (b.g.push(e), e.Cf && b.j.push(e.Qf)) : (b.g = [e],
                        b.j = e.Cf ? [e.Qf] : [])
                }
                if (b.j.length >= d) {
                    a: {
                        e = b;f = c ? 0 : 1;
                        if (f < 0 || f >= e.j.length) {
                            e = null;
                            break a
                        }
                        for (f = e.j[f]; e.g.length && !e.g[0].Cf;) e.g.shift();e.g.shift();e.j.shift();e = f
                    }
                    e && a.push(e)
                }
            }
            return a
        };
    var WL = (a, b, c = !1) => {
            a = VL(a, b);
            var d = new RL(b);
            return yu(a, e => UL(e, {
                ri: c,
                ni: d
            }))
        },
        XL = (a, b) => {
            a = VL(a, b);
            var c = new RL(b);
            return yu(a, d => {
                if (d.B) {
                    var e = d.g;
                    var f = d.j;
                    d = d.l.querySelectorAll(d.B);
                    var g = [];
                    for (var h of d) g.push(new HL(e, h, f));
                    e = g
                } else e = [];
                d = e.slice(0);
                if (d.length) {
                    e = [];
                    f = d[0];
                    for (g = 1; g < d.length; g++) {
                        let m = d[g];
                        h = f;
                        b: {
                            if (h.element.hasAttributes())
                                for (l of h.element.attributes)
                                    if (l.name.toLowerCase() === "style" && l.value.toLowerCase().includes("background-image")) {
                                        var k = !0;
                                        break b
                                    }
                            k = h.element.tagName;
                            k = k === "IMG" || k === "SVG"
                        }(k || h.element.textContent.length > 1) && !PL(c, f.element) && iK(m.ua(), f.element, m.element) && e.push(f);
                        f = m
                    }
                    var l = e
                } else l = [];
                return l
            })
        },
        VL = (a, b) => {
            var c = new Es;
            a.forEach(d => {
                var e = iL(Te(d, Su, 1));
                if (e) {
                    var f = e.toString();
                    As(c, f) || c.set(f, {
                        articleStructure: d,
                        el: e,
                        Xe: null,
                        pj: !1,
                        Qi: null
                    });
                    e = c.get(f);
                    (f = (f = y(d, Su, 2)) ? qf(f, 7) : null) ? e.Xe = e.Xe ? e.Xe + "," + f : f: e.pj = !0;
                    d = y(d, Su, 4);
                    e.Qi = d ? qf(d, 7) : null
                }
            });
            return Ds(c).map(d => {
                var e = aL(d.el, b.document);
                return e.length ? new OL(e[0], d, b) : null
            }).filter(d =>
                d != null)
        };
    var YL = a => a ? .google_ad_slot ? Fu(new Tu(1, {
            Pk: a.google_ad_slot
        })) : Hu(Error("Missing dimension when creating placement id")),
        $L = a => {
            switch (a.Fd) {
                case 0:
                case 1:
                    var b = a.l;
                    b == null ? a = null : (a = b.ya(), a == null ? a = null : (b = b.j(), a = b == null ? null : new Tu(0, {
                        Ri: [a],
                        jk: b
                    })));
                    return a != null ? Fu(a) : Hu(Error("Missing dimension when creating placement id"));
                case 2:
                    return a = ZL(a), a != null ? Fu(a) : Hu(Error("Missing dimension when creating placement id"));
                default:
                    return Hu(Error("Invalid type: " + a.Fd))
            }
        };
    const ZL = a => {
        if (a == null || a.A == null) return null;
        var b = y(a.A, Su, 1),
            c = y(a.A, Su, 2);
        if (b == null || c == null) return null;
        var d = a.Z;
        if (d == null) return null;
        a = a.j();
        return a == null ? null : new Tu(0, {
            Ri: [b, c],
            xm: d,
            jk: oL[a]
        })
    };

    function aM(a) {
        var b = AL(a.va);
        return (b ? YL(b) : $L(a.va)).map(c => Xu(c))
    }

    function bM(a) {
        a.g = a.g || aM(a);
        return a.g
    }

    function cM(a, b) {
        if (a.va.B) throw Error("AMA:AP:AP");
        QJ(b, a.ya(), a.va.j());
        a = a.va;
        a.B = !0;
        b != null && a.J.push(b)
    }
    const dM = class {
        constructor(a, b, c) {
            this.va = a;
            this.j = b;
            this.Fa = c;
            this.g = null
        }
        ya() {
            return this.j
        }
        fill(a, b) {
            var c = this.va;
            (a = c.C.j(a, b, this.j, c.g)) && cM(this, a.td);
            return a
        }
    };

    function eM(a, b) {
        return hL(() => {
            var c = [],
                d = [];
            try {
                var e = [];
                for (var f = 0; f < a.length; f++) {
                    var g = a[f],
                        h = g.O.g(g.g);
                    h && e.push({
                        ek: g,
                        anchorElement: h
                    })
                }
                for (g = 0; g < e.length; g++) {
                    f = d;
                    var k = f.push; {
                        var l = e[g];
                        let u = l.anchorElement,
                            w = l.ek;
                        var m = w.G;
                        let B = w.g.document.createElement("div");
                        B.className = "google-auto-placed";
                        let G = B.style;
                        G.textAlign = "center";
                        G.width = "100%";
                        G.height = "0px";
                        G.clear = m ? "both" : "none";
                        h = B;
                        try {
                            QJ(h, u, w.j());
                            var n = h
                        } catch (K) {
                            throw NJ(h), K;
                        }
                    }
                    k.call(f, n)
                }
                let p = ts(b),
                    q = us(b);
                for (k = 0; k < d.length; k++) {
                    let u =
                        d[k].getBoundingClientRect(),
                        w = e[k];
                    c.push(new dM(w.ek, w.anchorElement, new pu(u.left + q, u.top + p, u.right - u.left)))
                }
            } finally {
                for (e = 0; e < d.length; e++) NJ(d[e])
            }
            return c
        }, b)
    };
    const fM = {
            1: "0.5vp",
            2: "300px"
        },
        gM = [1E3, 930, 880, 830, 780, 730, 680, 630, 580, 530, 480, 430, 380, 350, 330, 310, 290, 270, 250, 230, 220, 210, 200, 190, 180, 170, 160, 150, 140, 130, 125, 120, 115, 110, 105, 100, 95, 90, 85, 80, 78, 76, 74, 72, 70, 68, 66, 64, 62, 61, 60, 59, 58, 57, 56, 55, 54, 53, 52, 51, 50],
        hM = {
            1: 700,
            2: 1200
        },
        iM = {
            [1]: {
                vk: "3vp",
                wi: "1vp",
                uk: "0.3vp"
            },
            [2]: {
                vk: "900px",
                wi: "300px",
                uk: "90px"
            }
        };

    function jM(a) {
        return gM.reduce((b, c) => {
            var d = Math.abs(b - a),
                e = Math.abs(c - a);
            return e === d ? c < b ? c : b : e < d ? c : b
        }, 530)
    }

    function kM(a, b, c) {
        var d = lM(a),
            e = ls(a) || hM[d];
        if (U(Wv)) {
            var f = V(Yv),
                g = V(Zv);
            let h = V(Xv);
            if (f && g && h) return b = b ? ? .5, b = b < .5 ? g + (1 - 2 * b) * (f - g) : h + (2 - 2 * b) * (g - h), U(vw) && (b = jM(b)), a = new sK, a = wf(a, 4, 8), b = we(a, 5, Wc(b)), mM(b, nM(d, e))
        }
        f = void 0;
        c && (f = (c = (c = oM(Ve(c, nK, 2, De()), d)) ? y(c, lK, 7) : void 0) ? pM(c, e) : void 0);
        c = f;
        f = lM(a);
        a = ls(a) || hM[f];
        g = qM(iM[f].wi, a);
        a = g === null ? nM(f, a) : new rM(g, g, sM(g, 8), 8, .3, c);
        c = qM(iM[d].vk, e);
        f = qM(iM[d].wi, e);
        d = qM(iM[d].uk, e);
        e = a.l;
        c && d && f && b !== void 0 && (e = b <= .5 ? f + (1 - 2 * b) * (c - f) : d + (2 - 2 * b) *
            (f - d));
        d = new rM(e, e, sM(e, a.j), a.j, a.C, a.g);
        return tM(d, null, b ? ? null)
    }

    function mM(a, b) {
        var c = JH(cf(a, 4, te)),
            d = Ce(a, 5, te);
        return c == null || d == null ? b : tM(new rM(d, 0, [], c, 1), a, null)
    }

    function uM(a, b) {
        var c = lM(a),
            d = ls(a) || hM[c];
        if (U(aw)) return kM(a, .5);
        if (!b) return nM(c, d);
        if (a = oM(Ve(b, nK, 2, De()), c))
            if (a = vM(a, d)) return a;
        return nM(c, d)
    }

    function wM(a) {
        var b = lM(a);
        a = ls(a) || hM[b];
        return nM(b, a)
    }

    function tM(a, b, c) {
        b = xM(b, c);
        return b == null ? a : new rM(a.l, a.A, a.B, a.j, b, a.g)
    }

    function yM(a, b) {
        var c = {
            ve: a.l,
            Uc: a.A
        };
        for (let d of a.B) d.adCount <= b && (c = d.Ie);
        return c
    }

    function xM(a, b) {
        var c = V(gw);
        if (c <= 0) return null;
        if (U(bw)) return c;
        if (!U(cw) || !a && !b) return null;
        if (a && a.g() === 2) a = String(cf(a, 4, te)) === "8" && Ce(a, 5, te) === 530;
        else {
            if (!b) return null;
            a = b === .5
        }
        return a ? c : null
    }

    function zM(a, b, c) {
        var d = pf(b, 2);
        b = y(b, nK, 1);
        var e = lM(c);
        var f = ls(c) || hM[e];
        c = qM(b ? .j(), f) ? ? a.l;
        e = qM(b ? .g(), f) ? ? a.A;
        d = d ? [] : AM(b ? .B(), f) ? ? a.B;
        var g = b ? .A() ? ? a.j,
            h = b ? .C() ? ? a.C;
        a = (b ? .O() ? pM(y(b, lK, 7), f) : null) ? ? a.g;
        return new rM(c, e, d, g, h, a)
    }

    function BM(a, b) {
        var c = lM(b),
            d = new oK,
            e = new nK,
            f = !1,
            g = V(fw);
        g >= 0 && (uf(e, 4, g), f = !0);
        g = null;
        c === 1 ? (c = V(kw), c >= 0 && (g = c + "vp")) : (c = V(jw), c >= 0 && (g = c + "px"));
        c = V(iw);
        c >= 0 && (g = c + "px");
        g !== null && (Jf(e, 2, g), f = !0);
        c = U(mw) ? "0px" : null;
        c !== null && (Jf(e, 5, c), f = !0);
        if (U(nw)) sf(d, 2, !0), f = !0;
        else if (c !== null || g !== null) {
            let m = [];
            for (let n of a.B) {
                var h = m,
                    k = h.push;
                var l = new mK;
                l = uf(l, 1, n.adCount);
                l = Jf(l, 3, c ? ? n.Ie.Uc + "px");
                l = Jf(l, 2, g ? ? n.Ie.ve + "px");
                k.call(h, l)
            }
            Xe(e, 3, m)
        }
        return f ? (z(d, 1, e), zM(a, d, b)) : a
    }
    var rM = class {
        constructor(a, b, c, d, e, f) {
            this.l = a;
            this.A = b;
            this.B = c.sort((g, h) => g.adCount - h.adCount);
            this.j = d;
            this.C = e;
            this.g = f
        }
    };

    function oM(a, b) {
        for (let c of a)
            if (fd(ue(c, 1)) == b) return c;
        return null
    }

    function AM(a, b) {
        if (a === void 0) return null;
        var c = [];
        for (let d of a) {
            a = ff(d, 1, te);
            let e = qM(qf(d, 2), b),
                f = qM(qf(d, 3), b);
            if (typeof a !== "number" || e === null) return null;
            c.push({
                adCount: a,
                Ie: {
                    ve: e,
                    Uc: f
                }
            })
        }
        return c
    }

    function vM(a, b) {
        var c = qM(a.j(), b),
            d = qM(a.g(), b);
        if (c === null) return null;
        var e = ff(a, 4, te);
        if (e == null) return null;
        var f = a.B();
        f = AM(f, b);
        if (f === null) return null;
        var g = y(a, lK, 7);
        b = g ? pM(g, b) : void 0;
        return new rM(c, d, f, e, Ce(a, 6, te), b)
    }

    function nM(a, b) {
        a = qM(fM[a], b);
        return U(aw) ? new rM(a === null ? Infinity : a, null, [], 8, .3) : new rM(a === null ? Infinity : a, null, [], 3, null)
    }

    function qM(a, b) {
        if (!a) return null;
        var c = parseFloat(a);
        return isNaN(c) ? null : a.endsWith("px") ? c : a.endsWith("vp") ? c * b : null
    }

    function lM(a) {
        a = ks(a) >= 900;
        return Nk() && !a ? 1 : 2
    }

    function sM(a, b) {
        if (b < 4) return [];
        var c = Math.ceil(b / 2);
        return [{
            adCount: c,
            Ie: {
                ve: a * 2,
                Uc: a * 2
            }
        }, {
            adCount: c + Math.ceil((b - c) / 2),
            Ie: {
                ve: a * 3,
                Uc: a * 3
            }
        }]
    }

    function pM(a, b) {
        var c = qM(qf(a, 2), b) || 0,
            d = ff(a, 3, te) || 1;
        a = qM(qf(a, 1), b) || 0;
        return {
            Qj: c,
            Kj: d,
            Zd: a
        }
    };

    function CM(a, b, c) {
        return Gr({
            top: a.g.top - (c + 1),
            right: a.g.right + (c + 1),
            bottom: a.g.bottom + (c + 1),
            left: a.g.left - (c + 1)
        }, b.g)
    }

    function DM(a) {
        if (!a.length) return null;
        var b = Hr(a.map(c => c.g));
        a = a.reduce((c, d) => c + d.j, 0);
        return new EM(b, a)
    }
    var EM = class {
        constructor(a, b) {
            this.g = a;
            this.j = b
        }
    };
    var FM = xB(453, UA),
        GM = xB(454, function(a, b) {
            var c = VA(b, ".google-auto-placed"),
                d = WA(b),
                e = XA(b),
                f = YA(b),
                g = ZA(b),
                h = $A(b),
                k = VA(b, "div.googlepublisherpluginad");
            b = VA(b, "html > ins.adsbygoogle");
            return aB([...(a.Bf === !0 ? c : []), ...(a.Bd === !0 ? d : []), ...(a.vm === !0 ? e : []), ...(a.zh === !0 ? f : []), ...(a.Ah === !0 ? g : []), ...(a.sm === !0 ? h : []), ...(a.um === !0 ? k : []), ...(a.wm === !0 ? b : [])])
        });

    function HM(a, b, c, d = !1) {
        d = IM(a, d);
        b = JM(d, b, c);
        return new KM(a, d, b)
    }

    function LM(a) {
        return (a.bottom - a.top) * (a.right - a.left) > 1
    }

    function MM(a) {
        return a.g.map(b => b.box)
    }

    function NM(a) {
        return a.g.reduce((b, c) => b + c.box.bottom - c.box.top, 0)
    }
    var KM = class {
        constructor(a, b, c) {
            this.l = a;
            this.g = b.slice(0);
            this.B = c.slice(0);
            this.j = null
        }
    };

    function IM(a, b = !1) {
        b = FM({
            Bd: !1,
            Wl: b
        }, a);
        var c = us(a),
            d = ts(a);
        return b.map(e => {
            var f = e.getBoundingClientRect();
            return (e = cB(e)) || LM(f) ? {
                box: {
                    top: f.top + d,
                    right: f.right + c,
                    bottom: f.bottom + d,
                    left: f.left + c
                },
                lp: e ? 1 : 0
            } : null
        }).filter(ni(e => e === null))
    }

    function JM(a, b, c) {
        return b != void 0 && a.length <= (c != void 0 ? c : 8) ? OM(a, b) : db(a, d => new EM(d.box, 1))
    }

    function OM(a, b) {
        a = db(a, d => new EM(d.box, 1));
        for (var c = []; a.length > 0;) {
            let d = a.pop(),
                e = !0;
            for (; e;) {
                e = !1;
                for (let f = 0; f < a.length; f++)
                    if (CM(d, a[f], b)) {
                        d = DM([d, a[f]]);
                        Array.prototype.splice.call(a, f, 1);
                        e = !0;
                        break
                    }
            }
            c.push(d)
        }
        return c
    };

    function PM(a, b, c) {
        var d = ou(c, b);
        return !fb(a, e => Gr(e, d))
    }

    function QM(a, b, c, d, e) {
        e = e.Fa;
        var f = ou(e, b),
            g = ou(e, c),
            h = ou(e, d);
        return !fb(a, k => Gr(k, g) || Gr(k, f) && !Gr(k, h))
    }

    function RM(a, b, c, d) {
        var e = MM(a);
        if (PM(e, b, d.Fa)) return !0;
        if (!QM(e, b, c.Qj, c.Zd, d)) return !1;
        var f = new EM(ou(d.Fa, 0), 1);
        a = cb(a.B, g => CM(g, f, c.Zd));
        b = eb(a, (g, h) => g + h.j);
        return a.length === 0 || b > c.Kj ? !1 : !0
    };
    var SM = (a, b) => {
        var c = [],
            d = a;
        for (a = () => {
                c.push({
                    anchor: d.anchor,
                    position: d.position
                });
                return d.anchor == b.anchor && d.position == b.position
            }; d;) {
            switch (d.position) {
                case 1:
                    if (a()) return c;
                    d.position = 2;
                case 2:
                    if (a()) return c;
                    if (d.anchor.firstChild) {
                        d = {
                            anchor: d.anchor.firstChild,
                            position: 1
                        };
                        continue
                    } else d.position = 3;
                case 3:
                    if (a()) return c;
                    d.position = 4;
                case 4:
                    if (a()) return c
            }
            for (; d && !d.anchor.nextSibling && d.anchor.parentNode != d.anchor.ownerDocument.body;) {
                d = {
                    anchor: d.anchor.parentNode,
                    position: 3
                };
                if (a()) return c;
                d.position = 4;
                if (a()) return c
            }
            d && d.anchor.nextSibling ? d = {
                anchor: d.anchor.nextSibling,
                position: 1
            } : d = null
        }
        return c
    };

    function TM(a, b) {
        var c = new Pu,
            d = new Fs;
        b.forEach(e => {
            if ( of (e, vK, 1, yK)) {
                e = of (e, vK, 1, yK);
                if (y(e, EJ, 1) && y(e, EJ, 1).ya() && y(e, EJ, 2) && y(e, EJ, 2).ya()) {
                    let g = UM(a, y(e, EJ, 1).ya()),
                        h = UM(a, y(e, EJ, 2).ya());
                    if (g && h)
                        for (var f of SM({
                                anchor: g,
                                position: y(e, EJ, 1).j()
                            }, {
                                anchor: h,
                                position: y(e, EJ, 2).j()
                            })) c.set(sa(f.anchor), f.position)
                }
                y(e, EJ, 3) && y(e, EJ, 3).ya() && (f = UM(a, y(e, EJ, 3).ya())) && c.set(sa(f), y(e, EJ, 3).j())
            } else of(e, wK, 2, yK) ? VM(a, of (e, wK, 2, yK), c) : of (e, uK, 3, yK) && WM(a, of (e, uK, 3, yK), d)
        });
        return new XM(c, d)
    }
    var XM = class {
        constructor(a, b) {
            this.j = a;
            this.g = b
        }
    };
    const VM = (a, b, c) => {
            y(b, EJ, 2) ? (b = y(b, EJ, 2), (a = UM(a, b.ya())) && c.set(sa(a), b.j())) : y(b, Su, 1) && (a = YM(a, y(b, Su, 1))) && a.forEach(d => {
                d = sa(d);
                c.set(d, 1);
                c.set(d, 4);
                c.set(d, 2);
                c.set(d, 3)
            })
        },
        WM = (a, b, c) => {
            y(b, Su, 1) && (a = YM(a, y(b, Su, 1))) && a.forEach(d => {
                c.add(sa(d))
            })
        },
        UM = (a, b) => (a = YM(a, b)) && a.length > 0 ? a[0] : null,
        YM = (a, b) => (b = iL(b)) ? aL(b, a) : null;
    var ZM = class {
        constructor() {
            var a = Math.random;
            this.g = Math.floor(a() * 2 ** 52);
            this.j = 0
        }
    };

    function $M(a, b, c) {
        switch (c) {
            case 2:
            case 3:
                break;
            case 1:
            case 4:
                b = b.parentElement;
                break;
            default:
                throw Error("Unknown RelativePosition: " + c);
        }
        for (c = []; b;) {
            if (aN(b)) return !0;
            if (a.g.has(b)) break;
            c.push(b);
            b = b.parentElement
        }
        c.forEach(d => a.g.add(d));
        return !1
    }

    function bN(a) {
        a = cN(a);
        return a.has("all") || a.has("after")
    }

    function dN(a) {
        a = cN(a);
        return a.has("all") || a.has("before")
    }

    function cN(a) {
        return (a = a && a.getAttribute("data-no-auto-ads")) ? new Set(a.split("|")) : new Set
    }

    function aN(a) {
        var b = cN(a);
        return a && (a.tagName === "AUTO-ADS-EXCLUSION-AREA" || b.has("inside") || b.has("all"))
    }
    var eN = class {
        constructor() {
            this.g = new Set;
            this.j = new ZM
        }
    };

    function fN(a) {
        return function(b) {
            return eM(b, a)
        }
    }

    function gN(a) {
        var b = ls(a);
        return b ? Aa(hN, b + ts(a)) : ki
    }

    function iN(a, b, c) {
        if (a < 0) throw Error("ama::ead:nd");
        if (a === Infinity) return ki;
        var d = MM(c || HM(b));
        return e => PM(d, a, e.Fa)
    }

    function jN(a, b, c, d) {
        if (a < 0 || b.Qj < 0 || b.Kj < 0 || b.Zd < 0) throw Error("ama::ead:nd");
        return a === Infinity ? ki : e => RM(d || HM(c, b.Zd), a, b, e)
    }

    function kN(a) {
        if (!a.length) return ki;
        var b = new Eu(a);
        return c => b.contains(c.Fd)
    }

    function lN(a) {
        return function(b) {
            for (let c of b.Ed)
                if (a.indexOf(c) > -1) return !1;
            return !0
        }
    }

    function mN(a) {
        return a.length ? function(b) {
            var c = b.Ed;
            return a.some(d => c.indexOf(d) > -1)
        } : li
    }

    function nN(a, b) {
        if (a <= 0) return li;
        var c = ps(b).scrollHeight - a;
        return function(d) {
            return d.Fa.g <= c
        }
    }

    function oN(a) {
        var b = {};
        a && a.forEach(c => {
            b[c] = !0
        });
        return function(c) {
            return !b[rf(c.ag, 2) || 0]
        }
    }

    function pN(a) {
        return a.length ? b => a.includes(rf(b.ag, 1) || 0) : li
    }

    function qN(a, b) {
        var c = TM(a, b);
        return function(d) {
            var e = d.ya();
            d = d.va.j();
            d = oL[d];
            var f = c.j,
                g = sa(e);
            f = f.g.get(g);
            if (!(f = f ? f.contains(d) : !1)) a: {
                if (c.g.contains(sa(e))) switch (d) {
                    case 2:
                    case 3:
                        f = !0;
                        break a;
                    default:
                        f = !1;
                        break a
                }
                for (e = e.parentElement; e;) {
                    if (c.g.contains(sa(e))) {
                        f = !0;
                        break a
                    }
                    e = e.parentElement
                }
                f = !1
            }
            return !f
        }
    }

    function rN() {
        var a = new eN;
        return function(b) {
            var c = b.ya();
            b = b.va.j();
            var d = oL[b];
            a: switch (d) {
                case 1:
                    b = bN(c.previousElementSibling) || dN(c);
                    break a;
                case 4:
                    b = bN(c) || dN(c.nextElementSibling);
                    break a;
                case 2:
                    b = dN(c.firstElementChild);
                    break a;
                case 3:
                    b = bN(c.lastElementChild);
                    break a;
                default:
                    throw Error("Unknown RelativePosition: " + d);
            }
            c = $M(a, c, d);
            d = a.j;
            zB("ama_exclusion_zone", {
                typ: b ? c ? "siuex" : "siex" : c ? "suex" : "noex",
                cor: d.g,
                num: d.j++,
                dvc: Sk()
            }, .1);
            return !(b || c)
        }
    }
    const hN = (a, b) => b.Fa.g >= a,
        sN = (a, b, c) => {
            c = c.Fa.j;
            return a <= c && c <= b
        };

    function tN(a, b, c, d, e) {
        var f = uN(vN(a, b), a);
        if (f.length === 0) {
            var g = !!y(b, IJ, 6) ? .g() ? .length;
            f = VK(b) ? .g() ? .j() && g ? uN(wN(a, b), a) : f
        }
        if (f.length === 0) return yJ(d, "pfno"), [];
        b = f;
        a = e.vd ? xN(a, b, c) : {
            qb: b,
            Ub: null
        };
        var {
            qb: h,
            Ub: k
        } = a;
        f = h;
        return f.length === 0 && k ? (yJ(d, k), []) : [f[e.Fi ? 0 : e.Ei ? Math.floor(f.length / 4) : Math.floor(f.length / 2)]]
    }

    function xN(a, b, c) {
        c = c ? Ve(c, xK, 5, De()) : [];
        var d = qN(a.document, c),
            e = rN();
        b = b.filter(f => d(f));
        if (b.length === 0) return {
            qb: [],
            Ub: "pfaz"
        };
        b = b.filter(f => e(f));
        return b.length === 0 ? {
            qb: [],
            Ub: "pfet"
        } : {
            qb: b,
            Ub: null
        }
    }

    function yN(a, b) {
        return a.Fa.g - b.Fa.g
    }

    function vN(a, b) {
        var c = y(b, IJ, 6);
        if (!c) return [];
        b = VK(b) ? .g();
        return (b ? .g() ? XL(c.g(), a) : WL(c.g(), a, !!b ? .B())).map(d => d.j())
    }

    function wN(a, b) {
        b = UK(b) || [];
        return wL(b, a, {}).filter(c => !c.Ed.includes(6))
    }

    function uN(a, b) {
        a = eM(a, b);
        var c = gN(b);
        a = a.filter(d => c(d));
        return a.sort(yN)
    };

    function zN(a) {
        var b = CL(a.j.va),
            c = a.C.Bb(a.A, () => AN(a));
        b.appendChild(c);
        a.B && (b.className = a.B);
        return {
            Rl: b,
            Dl: c
        }
    }

    function AN(a) {
        a.g && a.g.parentNode && a.g.parentNode.removeChild(a.g);
        a.g = null;
        a.l.g(null)
    }
    var BN = class {
        constructor(a, b, c, d) {
            this.A = a;
            this.j = b;
            this.C = c;
            this.B = d || null;
            this.g = null;
            this.l = new Ct(null)
        }
        init() {
            var a = zN(this);
            this.g = a.Rl;
            cM(this.j, this.g);
            this.l.g(a.Dl)
        }
    };
    async function CN(a) {
        await new Promise(b => {
            setTimeout(() => {
                try {
                    DN(a)
                } catch (c) {
                    yJ(a.Qa, "pfere", c)
                }
                b()
            })
        })
    }

    function DN(a) {
        if (!EN({
                ja: a.ja,
                Qa: a.Qa
            })) {
            var b = a.g.g();
            b = tN(a.win, a.config, a.ja, a.Qa, {
                Fi: !!b ? .A(),
                vd: !0,
                Vm: !!b ? .g(),
                Ei: !!b ? .C()
            });
            var c = FN(b.slice(0, 1), a.win),
                d = Object.keys(c),
                e = Object.values(c).map(({
                    Wn: g
                }) => g);
            if (!y(a.config, BK, 25) ? .j() && d.length !== 0) {
                var f = async () => {
                    e.forEach(g => {
                        AN(g)
                    })
                };
                gL(1661, () => {
                    var g = new qJ({
                        pubWin: a.win,
                        K: a.win.top,
                        gi: a.webPropertyCode,
                        Pa: a.win.location.href,
                        sb: a.win.location.href
                    });
                    xt(g, f);
                    mJ(g.pubWin, g.K, g.gi, g.Pa, g.sb, a.j, c[d[0]].vn)
                }, a.win)
            }
        }
    }
    var GN = class {
        constructor(a, b, c, d, e) {
            this.win = a;
            this.config = c;
            this.webPropertyCode = d;
            this.ja = e;
            this.g = VK(this.config);
            this.j = y(this.config, TK, 37);
            this.Qa = new BJ(a, b, this.g)
        }
    };

    function EN({
        ja: a,
        Qa: b
    }) {
        return (a ? nf(a, 2) : []).length === 0 ? (yJ(b, "pfeu"), !0) : !1
    }

    function FN(a, b) {
        var c = {};
        for (let e = 0; e < a.length; e++) {
            var d = a[e];
            let f = "reltops-container-" + e.toString(),
                g = b.document.createElement("div");
            g.setAttribute("id", f);
            J(g, rz(b));
            J(g, {
                "max-height": "1000px"
            });
            d = new BN(b, d, {
                Bb: () => g
            }, "reltops-widget");
            d.init();
            c[f] = {
                Wn: d,
                vn: g
            }
        }
        return c
    };
    var HN = class extends I {},
        IN = qh(HN);

    function JN(a) {
        try {
            let b = a.localStorage.getItem("google_ama_settings");
            return b ? IN(b) : null
        } catch (b) {
            return null
        }
    }

    function KN(a, b) {
        if (a.Tg !== void 0) {
            var c = JN(b);
            c || (c = new HN);
            a.Tg !== void 0 && sf(c, 2, a.Tg);
            a = Date.now() + 864E5;
            Number.isFinite(a) && wf(c, 1, Math.round(a));
            c = pg(c);
            try {
                b.localStorage.setItem("google_ama_settings", c)
            } catch (d) {}
        } else {
            if (c = a = JN(b)) c = hf(a, 1), c = BigInt(c) < Date.now();
            if (c) try {
                b.localStorage.removeItem("google_ama_settings")
            } catch (d) {}
        }
    };

    function LN(a, b) {
        zJ(a.ea, vJ, { ...b,
            evt: "place",
            vh: ls(a.win),
            eid: JH(a.g.j() ? .g()) || 0,
            hl: y(a.g, AJ, 5) ? .g() || ""
        })
    }

    function MN(a, b, c) {
        b = {
            sts: b
        };
        c && (b.excp_n = c.name, b.excp_m = c.message && c.message.substring(0, 512), b.excp_s = c.stack && Ol(c.stack, "") || "");
        LN(a, b)
    }
    var NN = class {
        constructor(a, b, c) {
            this.win = a;
            this.ea = b;
            this.g = c
        }
    };
    var ON = class {
        constructor(a) {
            this.g = a
        }
        Bb(a) {
            var b = a.document.createElement("div");
            J(b, rz(a));
            J(b, {
                width: "100%",
                "max-width": "1000px",
                margin: "auto"
            });
            b.appendChild(this.g);
            var c = a.document.createElement("div");
            J(c, rz(a));
            J(c, {
                width: "100%",
                "text-align": "center",
                display: "block",
                padding: "5px 5px 2px",
                "box-sizing": "border-box",
                "background-color": "#FFF"
            });
            c.appendChild(b);
            return c
        }
    };

    function PN(a, b, c, d, e) {
        var f = QN(RN(a, b), a);
        if (f.length === 0) {
            var g = !!y(b, IJ, 6) ? .g() ? .length;
            f = VK(b) ? .g() ? .j() && g ? QN(SN(a, b), a) : f
        }
        if (f.length === 0) return MN(d, "pfno"), [];
        b = f;
        a = e.vd ? TN(a, b, c) : {
            qb: b,
            Ub: null
        };
        var {
            qb: h,
            Ub: k
        } = a;
        f = h;
        return f.length === 0 && k ? (MN(d, k), []) : [f[e.Fi ? 0 : e.Ei ? Math.floor(f.length / 4) : Math.floor(f.length / 2)]]
    }

    function TN(a, b, c) {
        c = c ? Ve(c, xK, 5, De()) : [];
        var d = qN(a.document, c),
            e = rN();
        b = b.filter(f => d(f));
        if (b.length === 0) return {
            qb: [],
            Ub: "pfaz"
        };
        b = b.filter(f => e(f));
        return b.length === 0 ? {
            qb: [],
            Ub: "pfet"
        } : {
            qb: b,
            Ub: null
        }
    }

    function UN(a, b) {
        return a.Fa.g - b.Fa.g
    }

    function RN(a, b) {
        var c = y(b, IJ, 6);
        if (!c) return [];
        b = VK(b) ? .g();
        return (b ? .g() ? XL(c.g(), a) : WL(c.g(), a, !!b ? .B())).map(d => d.j())
    }

    function SN(a, b) {
        b = UK(b) || [];
        return wL(b, a, {}).filter(c => !c.Ed.includes(6))
    }

    function QN(a, b) {
        a = eM(a, b);
        var c = gN(b);
        a = a.filter(d => c(d));
        return a.sort(UN)
    };
    var VN = class {
        constructor(a) {
            this.L = a.L;
            this.nc = a.nc;
            this.kd = a.kd;
            this.host = a.location.host;
            this.origin = a.location.origin;
            this.language = a.language;
            this.Qh = a.Qh;
            this.jh = a.jh;
            this.ze = a.ze;
            this.rk = !!a.rk;
            this.alwaysSetAdSafeHigh = !!a.alwaysSetAdSafeHigh
        }
        postMessage(a, b) {
            a ? .postMessage(b, "https://www.gstatic.com")
        }
        init() {
            this.L.setAttribute("id", "prose-iframe");
            this.L.setAttribute("width", "100%");
            this.L.setAttribute("height", "100%");
            this.L.style.cssText = "box-sizing:border-box;border:unset;";
            var a = this.L;
            var b = fi `https://www.gstatic.com/prose/protected/${this.ze||"558153351"}/iframe.html?cx=${this.nc}&host=${this.host}&hl=${this.language}&lrh=${this.Qh}&client=${this.kd}&origin=${this.origin}`;
            b = this.rk ? gi(b, {
                soo: 1
            }) : b;
            Ii(a, b)
        }
    };

    function WN(a, b) {
        return Sk() === 2 ? aF(a.win, b, {
            ck: .95,
            sj: .95,
            zIndex: 2147483645,
            ie: !0
        }) : kE(a.win, b, {
            tf: "min(65vw, 768px)",
            Gc: "",
            pf: !1,
            zIndex: 2147483645,
            ie: !0,
            mi: !1
        })
    }

    function XN(a) {
        ((d, e) => {
            d[e] = d[e] || function() {
                (d[e].q = d[e].q || []).push(arguments)
            };
            d[e].t = (new Date).getTime()
        })(a.win, "_googCsa");
        var b = a.af.map(d => ({
                container: d,
                relatedSearches: 5
            })),
            c = {
                pubId: a.kd,
                styleId: "5134551505",
                hl: a.language,
                fexp: a.A.join(","),
                channel: "AutoRsVariant",
                resultsPageBaseUrl: "http://google.com",
                resultsPageQueryParam: "q",
                relatedSearchTargeting: "content",
                relatedSearchResultClickedCallback: a.P.bind(a),
                relatedSearchUseResultCallback: !0,
                cx: a.nc
            };
        a.G && (c.adLoadedCallback = a.J.bind(a));
        a.win._googCsa("relatedsearch", c, b)
    }

    function YN(a) {
        a.win.addEventListener("message", b => {
            b.origin === "https://www.gstatic.com" && b.data.action === "resize" && (a.j.style.height = `${Math.ceil(b.data.height)+1}px`)
        })
    }
    var ZN = class extends O {
        constructor(a) {
            super();
            this.win = a.win;
            this.af = a.af;
            this.Qa = a.Qa;
            this.di = a.di ? ? (() => {});
            this.language = a.Ij ? .g() || "en";
            this.G = U(tw);
            this.kd = a.webPropertyCode.replace("ca", "partner");
            this.C = new hj(this.win.document);
            this.j = xj(this.C, "IFRAME");
            this.nc = a.Ek.g ? a.Ek.nc : "9d449ff4a772956c6";
            this.A = $q().concat(a.experimentId ? a.experimentId : []);
            var b = a.Ij ? .j() || "Search results from ${website}";
            this.l = new VN({
                L: this.j,
                nc: this.nc,
                kd: this.kd,
                location: this.win.location,
                language: this.language,
                Qh: b,
                jh: this.A,
                ze: a.ze,
                alwaysSetAdSafeHigh: a.alwaysSetAdSafeHigh
            });
            this.D = WN(this, this.j);
            wt(this, this.D)
        }
        init() {
            this.af.length !== 0 && (this.G || gL(1075, () => {
                this.l.init()
            }, this.win), gL(1076, () => {
                var a = xj(this.C, "SCRIPT");
                Ki(a, fi `https://www.google.com/adsense/search/async-ads.js`);
                this.win.document.head.appendChild(a)
            }, this.win), XN(this), LN(this.Qa, {
                sts: "ok"
            }), YN(this))
        }
        J(a, b) {
            b ? gL(1075, () => {
                this.l.init()
            }, this.win) : (this.di(), MN(this.Qa, "pfns"))
        }
        P(a, b) {
            var c = this.l,
                d = c.L.contentWindow;
            a = {
                action: "search",
                searchTerm: a,
                rsToken: b
            };
            a.experimentId = c.jh;
            c.alwaysSetAdSafeHigh && (a.alwaysSetAdSafeHigh = "1");
            c.postMessage(d, a);
            this.D.show()
        }
    };
    var $N = class {
        constructor(a, b) {
            this.g = a;
            this.nc = b
        }
    };
    async function aO(a) {
        await new Promise(b => {
            setTimeout(() => {
                try {
                    bO(a)
                } catch (c) {
                    MN(a.Qa, "pfere", c)
                }
                b()
            })
        })
    }

    function bO(a) {
        if ((!a.vd || !cO(a.config, a.ja, a.Qa)) && dO(y(a.g, AJ, 5), a.Qa)) {
            var b = a.g.g();
            b = PN(a.win, a.config, a.ja, a.Qa, {
                Fi: !!b ? .A(),
                vd: a.vd,
                Vm: !!b ? .g(),
                Ei: !!b ? .C()
            });
            b = eO(b, a.win);
            var c = Object.keys(b),
                d = Object.values(b),
                e = JH(a.g.j() ? .g()),
                f = fO(a.g),
                g = String(D(a.g, 13));
            b = y(a.config, BK, 25) ? .g() || !1;
            var h = a.g ? .B() || !1;
            if (!b) {
                var k = () => {
                    d.forEach(l => {
                        AN(l)
                    })
                };
                gL(1074, () => {
                    var l = {
                        win: a.win,
                        af: c,
                        webPropertyCode: a.webPropertyCode,
                        Ij: y(a.g, AJ, 5),
                        Qa: a.Qa,
                        experimentId: e,
                        Ek: f,
                        ze: g,
                        di: k,
                        alwaysSetAdSafeHigh: h
                    };
                    (new ZN(l)).init()
                }, a.win)
            }
        }
    }
    var gO = class {
        constructor(a, b, c, d, e) {
            this.win = a;
            this.config = c;
            this.webPropertyCode = d;
            this.ja = e;
            this.vd = !0;
            this.g = VK(this.config);
            this.Qa = new NN(a, b, this.g)
        }
    };

    function cO(a, b, c) {
        a = JH(VK(a) ? .j() ? .g());
        var d = pz(yw);
        return d && a && d.includes(a.toString()) ? !1 : (b ? nf(b, 2) : []).length === 0 ? (MN(c, "pfeu"), !0) : !1
    }

    function dO(a, b) {
        var c = pz(xw);
        a = a ? .g() || "";
        return c && c.length !== 0 && !c.includes(a.toString()) ? (MN(b, "pflna"), !1) : !0
    }

    function eO(a, b) {
        var c = {};
        for (let e = 0; e < a.length; e++) {
            var d = a[e];
            let f = "autors-container-" + e.toString(),
                g = b.document.createElement("div");
            g.setAttribute("id", f);
            d = new BN(b, d, new ON(g), "autors-widget");
            d.init();
            c[f] = d
        }
        return c
    }

    function fO(a) {
        var b = C(a, 11) || !1;
        a = D(a, 8) || "";
        return new $N(b, a)
    };
    var hO = (a, b) => {
        var c = [];
        y(a, IK, 18) && c.push(2);
        b.ja && c.push(0);
        if (b = VK(a)) b = VK(a), b = E(b, 1) == 1;
        b && (y(a, TK, 37) ? c.push(3) : c.push(1));
        y(a, SK, 38) && c.push(4);
        return c
    };
    var iO = a => a.googlefc = a.googlefc || {},
        jO = a => {
            a = a.googlefc = a.googlefc || {};
            return a.__fcusi = a.__fcusi || {}
        },
        kO = a => {
            a = a.googlefc = a.googlefc || {};
            if (!a.getFloatingToolbarTranslatedMessages) return null;
            if (a = a.getFloatingToolbarTranslatedMessages()) {
                var b = new GK;
                b = Jf(b, 1, a.defaultFloatingToolbarToggleExpansionText);
                b = Jf(b, 2, a.defaultFloatingToolbarTogglePrivacySettings);
                a = Jf(b, 3, a.defaultFloatingToolbarDismissPrivacySettings);
                a = oe(a)
            } else a = null;
            return a
        };

    function lO(a, b) {
        b = b.filter(c => y(c, bv, 4) ? .g() === 5 && fd(ue(c, 8)) === 1);
        b = wL(b, a);
        a = eM(b, a);
        a.sort((c, d) => d.Fa.g - c.Fa.g);
        return a[0] || null
    };

    function mO(a) {
        var b = {},
            c = a.Xl,
            d = a.Al,
            e = a.ql,
            f = a.Cn,
            g = a.rl;
        a = a.pl;
        b = b && b.rb;
        return wy('<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Google+Symbols:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200"' + (b ? ' nonce="' + R($y(b)) + '"' : "") + '/><link href="https://fonts.googleapis.com/css?family=Google+Sans+Text:400,500,700" rel="stylesheet"' + (b ? ' nonce="' + R($y(b)) + '"' : "") + "><style" + (b ? ' nonce="' + R($y(b)) + '"' : "") + ">.ft-styless-button {border: none; background: none; user-select: none; cursor: pointer; border-radius: " +
            T(16) + "px;}.ft-container {position: fixed;}.ft-menu {position: absolute; bottom: 0; display: flex; flex-direction: column; justify-content: center; align-items: center; box-shadow: 0 4px 8px 3px rgba(60, 64, 67, 0.15), 0 1px 3px rgba(60, 64, 67, 0.3); min-height: " + T(e) + "px;}.ft-menu:not(.ft-multiple-buttons *) {transition: padding 0.25s 0.25s, margin 0.25s 0.25s, border-radius 0.25s 0.25s, background-color 0s 0.5s; padding: 0; margin: " + T(a) + "px; border-radius: " + T(16) + "px; background-color: rgba(255, 255, 255, 0);}.ft-multiple-buttons .ft-menu {transition: margin 0.25s, padding 0.25s, border-radius 0.25s 0.25s, background-color 0s; padding: " +
            T(a) + "px; margin: 0; border-radius: " + T(16 + a) + "px; background-color: rgba(255, 255, 255, 1);}.ft-left-pos .ft-menu {left: 0;}.ft-right-pos .ft-menu {right: 0;}.ft-container.ft-hidden {transition: opacity 0.25s, visibility 0.5s 0s; opacity: 0; visibility: hidden;}.ft-container:not(.ft-hidden) {transition: opacity 0.25s, bottom 0.5s ease; opacity: 1;}.google-symbols {font-size: 26px; color: #3c4043;}.ft-button-holder {display: flex; flex-direction: column; justify-content: center; align-items: center; padding: 0;}.ft-flip-vertically {transform: scaleY(-1);}.ft-expand-toggle {width: " +
            T(e) + "px; height: " + T(e) + "px;}.ft-collapsed .ft-expand-icon {transition: transform 0.25s; transform: rotate(180deg);}.ft-expand-icon:not(.ft-collapsed *) {transition: transform 0.25s; transform: rotate(0deg);}.ft-button {position: relative; height: " + T(e) + "px; margin-bottom: " + T(g) + "px; transform: margin 0.25s 0.25s;}.ft-button.ft-last-button {margin-bottom: 0;}.ft-button > button {position: relative; height: " + T(e) + "px; width: " + T(e) + "px; margin: 0; padding: 0; border: none;}.ft-button > button > * {position: relative;}.ft-button .ft-highlighter {position: absolute; left: 50%; top: 50%; transform: translate(-50%, -50%); height: " +
            T(e - 6) + "px; width: " + T(e - 6) + "px; border-radius: " + T(e / 2) + "px; background-color: #d2e3fc; opacity: 0; transition: opacity 0.25s;}.ft-button.ft-highlighted .ft-highlighter {opacity: 1;}.ft-button-corner-info {display: none;}.ft-button.ft-show-corner-info .ft-button-corner-info {position: absolute; left: -5px; top: 4px; background: #b3261e; border: 1.5px solid #ffffff; box-shadow: 0 1px 2px rgba(60, 64, 67, 0.3), 0 1px 3px 1px rgba(60, 64, 67, 0.15); border-radius: 100px; color: ffffff; font-family: 'Google Sans Text'; font-style: normal; font-weight: 700; font-size: 11px; line-height: 14px; min-width: 16px; height: 16px; display: flex; flex-direction: row; justify-content: center; align-items: center;}.ft-separator {display: block; width: 100%; height: " +
            T(f) + "px;}.ft-separator > span {display: block; width: 28px; margin: 0 auto 10px auto; height: 0; border-bottom: 1px solid #dadce0;}.ft-expand-toggle-container {height: " + T(e) + "px;}.ft-hidden {transition: opacity 0.25s, visibility 0.5s 0s; opacity: 0; visibility: hidden;}:not(.ft-hidden) {transition: opacity 0.25s; opacity: 1;}.ft-collapsed .ft-collapsible, .ft-collapsible.ft-collapsed, .ft-expand-toggle-container.ft-collapsed {transition: opacity 0.25s, margin 0.25s 0.25s, height 0.25s 0.25s, overflow 0.25s 0s, visibility 1s 0s; height: 0; opacity: 0; overflow: hidden; visibility: hidden; margin: 0;}.ft-collapsible:not(.ft-collapsed *):not(.ft-collapsed), .ft-expand-toggle-container:not(.ft-collapsed) {transition: margin 0.25s, height 0.25s, opacity 0.25s 0.25s; opacity: 1;}.ft-symbol-font-load-test {position: fixed; left: -1000px; top: -1000px; font-size: 26px; visibility: hidden;}.ft-reg-bubble {position: absolute; bottom: 0; padding: 10px 10px 0 10px; background: #fff; box-shadow: 0 4px 8px 3px rgba(60, 64, 67, 0.15), 0 1px 3px rgba(60, 64, 67, 0.3); border-radius: " +
            T(16) + "px; max-width: calc(90vw - " + T(e * 2) + "px); width: 300px; height: 200px;}.ft-left-pos .ft-reg-bubble {left: " + T(e + 10 + a) + "px;}.ft-right-pos .ft-reg-bubble {right: " + T(e + 10 + a) + "px;}.ft-collapsed .ft-reg-bubble, .ft-reg-bubble.ft-collapsed {transition: width 0.25s ease-in 0.25s, height 0.25s ease-in 0.25s, opacity 0.05s linear 0.45s, overflow 0s 0.25s, visibility 0s 0.5s; width: 0; overflow: hidden; opacity: 0; visibility: hidden;}.ft-collapsed .ft-reg-bubble, .ft-reg-bubble.ft-no-messages {height: 0 !important;}.ft-reg-bubble:not(.ft-collapsed *):not(.ft-collapsed) {transition: width 0.25s ease-out, height 0.25s ease-out, opacity 0.05s linear;}.ft-reg-bubble-content {display: flex; flex-direction: row; max-width: calc(90vw - " +
            T(e * 2) + 'px); width: 300px;}.ft-collapsed .ft-reg-bubble-content {transition: opacity 0.25s; opacity: 0;}.ft-reg-bubble-content:not(.ft-collapsed *) {transition: opacity 0.25s 0.25s; opacity: 1;}.ft-reg-message-holder {flex-grow: 1; display: flex; flex-direction: column; height: auto;}.ft-reg-controls {flex-grow: 0; padding-left: 5px;}.ft-reg-bubble-close-icon {font-size: 16px;}.ft-reg-message {font-family: \'Google Sans Text\'; font-style: normal; font-weight: 400; font-size: 12px; line-height: 14px; padding-bottom: 5px; margin-bottom: 5px; border-bottom: 1px solid #dadce0;}.ft-reg-message-custom h1 {display: flex; align-items: center; gap: 5px; font-weight: 500; font-size: 14px; line-height: 14px; margin: 0 0 10px 0; padding: 0;}.ft-reg-message-custom p {margin: 10px 0 0 0; padding: 0;}.ft-reg-message-custom a, .ft-reg-message-custom a:link, .ft-reg-message-custom a:visited, .ft-reg-message-custom a:hover, .ft-reg-message-custom a:active {color: #0b57d0; text-decoration: none;}.ft-reg-message:last-of-type {border-bottom: none;}.ft-reg-message-button {border: none; background: none; font-family: \'Google Sans Text\'; color: #0b57d0; font-weight: 500; font-size: 14px; line-height: 22px; cursor: pointer; margin: 0; padding: 0; text-align: start;}.ft-display-none {display: none;}</style><toolbar id="ft-floating-toolbar" class="ft-container ft-hidden"><div class="ft-menu"><div class="ft-button-holder"></div><div class="ft-separator ft-collapsible ft-collapsed"><span></span></div><div class="ft-bottom-button-holder"></div><div class="ft-expand-toggle-container"><button class="ft-expand-toggle ft-styless-button" aria-controls="ft-floating-toolbar" aria-label="' +
            R(c) + '"><span class="google-symbols ft-expand-icon" aria-hidden="true">expand_more</span></button></div></div><div id="ft-reg-bubble" class="ft-reg-bubble ft-collapsed ft-no-messages"><div class="ft-reg-bubble-content"><div class="ft-reg-message-holder"></div><div class="ft-reg-controls"><button class="ft-reg-bubble-close ft-styless-button" aria-controls="ft-reg-bubble" aria-label="' + R(d) + '"><span class="google-symbols ft-reg-bubble-close-icon" aria-hidden="true">close</span></button></div></div></div></toolbar><span inert class="ft-symbol-font-load-test"><span class="ft-symbol-reference google-symbols" aria-hidden="true">keyboard_double_arrow_right</span><span class="ft-text-reference" aria-hidden="true">keyboard_double_arrow_right</span></span>')
    }

    function nO(a) {
        var b = a.googleIconName,
            c = a.backgroundColorCss,
            d = a.iconColorCss;
        return wy('<div class="ft-button ft-collapsible ft-collapsed ft-last-button"><button class="ft-styless-button" aria-label="' + R(a.ariaLabel) + '" style="background-color: ' + R(T(c)) + '"><span class="ft-highlighter"></span><span class="google-symbols" style="color: ' + R(T(d)) + '" aria-hidden="true">' + uy(b) + '</span></button><span class="ft-button-corner-info"></span></div>')
    };
    const oO = ["Google Symbols:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200", "Google Sans Text:400,500,700"];

    function pO(a, b) {
        a = new qO(a, b, rO(a, b));
        a.init();
        return a
    }

    function sO() {
        ({
            ae: a
        } = {
            ae: 2
        });
        var a;
        return a > 1 ? 50 : 120
    }

    function tO(a, b, c) {
        uO(a) === 0 && b.classList.remove("ft-collapsed");
        vO(b, c);
        ut(a.win);
        b.classList.remove("ft-collapsed");
        wO(a);
        return () => void xO(a, b, c)
    }

    function yO(a) {
        zO(a.j.xa.ue).length === 0 ? (a.A.V ? .wn(), a.A.g(null), a.j.xa.yj.g(!1), a.j.xa.Gh.g(!1), a.j.xa.Ch.g(!1)) : (a.j.xa.yj.g(!0), AO(a))
    }

    function BO(a, {
        Qk: b = 0,
        mp: c = 0
    }) {
        b = Math.max(zO(a.j.od).length + b, 0);
        c = Math.max(zO(a.j.Ec).length + c, 0);
        var d = b + c,
            e = d * 50;
        b > 0 && c > 0 && (e += 11);
        e += Math.max(0, d - 1) * 10;
        d >= a.l.ae && (e += 60);
        d > 1 && (e += 10);
        return e
    }

    function uO(a) {
        var b = a.j.Ec;
        return zO(a.j.od).length + zO(b).length
    }

    function wO(a) {
        var b = a.j.Ec,
            c = a.j.separator;
        zO(a.j.od).length > 0 && zO(b).length > 0 ? c.classList.remove("ft-collapsed") : c.classList.add("ft-collapsed");
        uO(a) >= a.l.ae ? a.j.Ej.g(!0) : a.j.Ej.g(!1);
        uO(a) > 1 ? a.j.zj.g(!0) : a.j.zj.g(!1);
        uO(a) > 0 ? a.j.isVisible.g(!0) : a.j.isVisible.g(!1);
        CO(a);
        DO(a)
    }

    function xO(a, b, c) {
        b.classList.contains("ft-removing") || (b.classList.add("ft-removing"), b.classList.add("ft-collapsed"), wO(a), a.win.setTimeout(() => {
            c.removeChild(b)
        }, 750))
    }

    function CO(a) {
        var b = zO(a.j.od).concat(zO(a.j.Ec));
        b.forEach(c => {
            c.classList.remove("ft-last-button")
        });
        uO(a) >= a.l.ae || b[b.length - 1] ? .classList.add("ft-last-button")
    }

    function DO(a) {
        var b = zO(a.j.od).concat(zO(a.j.Ec)).filter(c => !c.classList.contains("ft-reg-button"));
        a.G.g(b.length > 0)
    }

    function EO(a) {
        ys(a.j.xa.ue.children, b => {
            var c = a.j.xa.Ae;
            xO(a, b, a.j.xa.ue);
            var d = c.get(b);
            c.delete(b);
            d ? .isDismissed.g(!0)
        });
        yO(a)
    }

    function AO(a) {
        if (!a.A.V) {
            var b = FO(a.win, {
                googleIconName: "verified_user",
                ariaLabel: D(a.l.Th, 2),
                orderingIndex: 0,
                onClick: () => {
                    a.j.xa.Gh.g(!a.j.xa.isVisible.V);
                    for (let [, c] of a.j.xa.Ae) c.Kh = !0;
                    a.j.xa.Ch.g(!1)
                },
                backgroundColorCss: "#fff"
            });
            b.We.classList.add("ft-reg-button");
            tO(a, b.We, a.j.Ec);
            Mt(b.Dm, a.j.xa.isVisible);
            a.A.g({
                up: b,
                wn: () => void xO(a, b.We, a.j.Ec)
            })
        }
    }

    function GO(a) {
        var b = a.j.xa.Ch,
            c = b.g;
        a: {
            for ([, d] of a.j.xa.Ae)
                if (a = d, a.showUnlessUserInControl && !a.Kh) {
                    var d = !0;
                    break a
                }
            d = !1
        }
        c.call(b, d)
    }

    function HO(a) {
        a.j.xa.zl.listen(() => {
            EO(a)
        })
    }
    var qO = class extends O {
        constructor(a, b, c) {
            super();
            this.win = a;
            this.l = b;
            this.j = c;
            this.A = new Ct(null);
            this.G = new Ct(!1)
        }
        addButton(a) {
            a = FO(this.win, a);
            return tO(this, a.We, this.j.od)
        }
        addRegulatoryMessage(a) {
            var b = this.j.xa.ue,
                c = IO(this.win, a);
            vO(c.Sh, b);
            this.j.xa.Ae.set(c.Sh, c);
            yO(this);
            return {
                showUnlessUserInControl: () => {
                    c.showUnlessUserInControl = !0;
                    GO(this)
                },
                hideUnlessUserInControl: () => {
                    c.showUnlessUserInControl = !1;
                    GO(this)
                },
                showAndGiveUserControl: () => void this.showAndGiveUserControl(c),
                isDismissed: Nt(c.isDismissed),
                removeCallback: () => {
                    var d = c.Sh,
                        e = this.j.xa.ue;
                    d.parentNode === e && e.removeChild(d);
                    this.j.xa.Ae.delete(d);
                    yO(this)
                }
            }
        }
        J() {
            return Gt(this.A.map(a => a != null))
        }
        D() {
            return Gt(this.G)
        }
        C() {
            return [this.j.container]
        }
        g() {
            var a = this.j.xc.wc;
            a.parentNode ? .removeChild(a);
            super.g()
        }
        showAndGiveUserControl(a) {
            a.Kh = !0;
            this.j.xa.Gh.g(!0);
            GO(this)
        }
        init() {
            uu(this.win, oO);
            Mt(this.j.Yn, this.l.Tc);
            this.win.document.body.appendChild(this.j.xc.wc);
            HO(this)
        }
    };

    function rO(a, b) {
        var c = YD(a),
            d = c.shadowRoot;
        d.appendChild(yj(new hj(a.document), mO({
            Xl: D(b.Th, 1),
            Al: D(b.Th, 3),
            ql: 50,
            Cn: 11,
            rl: 10,
            pl: 5
        }).Fb()));
        var e = XD("ft-container", d),
            f = XD("ft-expand-toggle", d),
            g = XD("ft-expand-toggle-container", d),
            h = new Ct(null);
        h.j(p => {
            e.style.zIndex = String(p ? ? 2147483647)
        });
        var k = new Ct(!0);
        Jt(k, !0, () => {
            e.classList.remove("ft-collapsed");
            f.setAttribute("aria-expanded", "true")
        });
        Jt(k, !1, () => {
            e.classList.add("ft-collapsed");
            f.setAttribute("aria-expanded", "false")
        });
        f.addEventListener("click",
            () => {
                k.g(!k.V)
            });
        var l = new Ct(!1);
        Jt(l, !0, () => {
            g.classList.remove("ft-collapsed");
            e.classList.add("ft-toolbar-collapsible")
        });
        Jt(l, !1, () => {
            g.classList.add("ft-collapsed");
            e.classList.remove("ft-toolbar-collapsible");
            k.g(!0)
        });
        var m = new Ct(!1);
        Jt(m, !0, () => {
            e.classList.add("ft-multiple-buttons")
        });
        Jt(m, !1, () => {
            e.classList.remove("ft-multiple-buttons")
        });
        b.position.j(p => {
            if (p) {
                p.Si(e.style);
                p = p.uj();
                switch (p) {
                    case 0:
                        e.classList.add("ft-left-pos");
                        e.classList.remove("ft-right-pos");
                        break;
                    case 1:
                        e.classList.add("ft-right-pos");
                        e.classList.remove("ft-left-pos");
                        break;
                    default:
                        throw Error(`Unknown HorizontalAnchoring: ${p}`);
                }
                ut(a)
            }
        });
        var n = new Ct(!1);
        b = Ft(JO(a, d), n, b.position.map(p => p !== null));
        Jt(b, !0, () => {
            e.classList.remove("ft-hidden")
        });
        Jt(b, !1, () => {
            e.classList.add("ft-hidden")
        });
        b = KO(a, XD("ft-reg-bubble", d));
        return {
            container: e,
            od: XD("ft-button-holder", d),
            Ec: XD("ft-bottom-button-holder", d),
            separator: XD("ft-separator", d),
            xc: c,
            Yn: h,
            Dh: k,
            Ej: l,
            zj: m,
            isVisible: n,
            xa: b
        }
    }

    function KO(a, b) {
        var c = new Ct(!1),
            d = new Ct(!1),
            e = Ht(c, d);
        Jt(e, !0, () => {
            b.classList.remove("ft-collapsed")
        });
        Jt(e, !1, () => {
            b.classList.add("ft-collapsed")
        });
        var f = new Ct(!1);
        Jt(f, !0, () => {
            b.classList.remove("ft-no-messages")
        });
        Jt(f, !1, () => {
            b.classList.add("ft-no-messages")
        });
        var g = XD("ft-reg-bubble-close", b),
            h = new Rt;
        g.addEventListener("click", () => {
            Qt(h)
        });
        var k = XD("ft-reg-message-holder", b);
        nu(ku(a, k)).j(() => {
            b.style.height = `${k.offsetHeight}px`
        });
        return {
            ue: k,
            Gh: c,
            Ch: d,
            isVisible: e,
            yj: f,
            Ae: new Map,
            zl: Ot(h)
        }
    }

    function FO(a, b) {
        var c = yj(new hj(a.document), nO({
            googleIconName: b.googleIconName,
            ariaLabel: b.ariaLabel,
            backgroundColorCss: b.backgroundColorCss || "#e2eaf6",
            iconColorCss: b.iconColorCss || "#3c4043"
        }).Fb());
        b.buttonExtension ? .styleSheet && c.appendChild(b.buttonExtension.styleSheet);
        if (b.cornerNumber !== void 0) {
            let d = si(Math.round(b.cornerNumber), 99);
            XD("ft-button-corner-info", c).appendChild(a.document.createTextNode(String(d)));
            c.classList.add("ft-show-corner-info")
        }
        c.orderingIndex = b.orderingIndex;
        b.onClick &&
            WD("BUTTON", c).addEventListener("click", b.onClick);
        a = new Ct(!1);
        Jt(a, !0, () => {
            c.classList.add("ft-highlighted")
        });
        Jt(a, !1, () => {
            c.classList.remove("ft-highlighted")
        });
        return {
            We: c,
            Dm: a
        }
    }

    function IO(a, b) {
        a: {
            var c = b.regulatoryMessage;
            var d = c.kind;
            if (d) switch (d) {
                case "standard":
                    c = LO(a, c);
                    break a;
                case "custom":
                    a = new hj(a.document);
                    d = wy('<div class="ft-reg-message ft-reg-message-custom"></div>');
                    a = yj(a, d.Fb());
                    a.appendChild(c.content);
                    c = a;
                    break a;
                default:
                    throw Error(`Unknown regulatory message kind: ${d}`);
            } else c = LO(a, c)
        }
        c.orderingIndex = b.orderingIndex;
        return {
            Sh: c,
            showUnlessUserInControl: !1,
            Kh: !1,
            isDismissed: new Ct(!1)
        }
    }

    function LO(a, b) {
        a = new hj(a.document);
        var c = wy('<div class="ft-reg-message"><button class="ft-reg-message-button"></button><div class="ft-reg-message-info"></div></div>');
        a = yj(a, c.Fb());
        c = XD("ft-reg-message-button", a);
        b.actionButton ? (c.appendChild(b.actionButton.buttonText), c.addEventListener("click", b.actionButton.onClick)) : c.classList.add("ft-display-none");
        c = XD("ft-reg-message-info", a);
        b.informationText ? c.appendChild(b.informationText) : c.classList.add("ft-display-none");
        return a
    }

    function vO(a, b) {
        a: {
            var c = Array.from(b.children);
            for (let d = 0; d < c.length; ++d)
                if (c[d].orderingIndex >= a.orderingIndex) {
                    c = d;
                    break a
                }
            c = c.length
        }
        b.insertBefore(a, b.childNodes[c] || null)
    }

    function zO(a) {
        return Array.from(a.children).filter(b => !b.classList.contains("ft-removing"))
    }

    function JO(a, b) {
        var c = new Ct(!1),
            d = XD("ft-symbol-font-load-test", b);
        b = XD("ft-symbol-reference", d);
        var e = XD("ft-text-reference", d),
            f = ku(a, b);
        Kt(nu(f).map(g => g.width > 0 && g.width < e.offsetWidth / 2), !0, () => {
            c.g(!0);
            d.parentNode ? .removeChild(d);
            f.dispose()
        });
        return c
    };

    function MO(a) {
        return a.g[a.g.length - 1]
    }
    var OO = class {
        constructor() {
            this.l = NO;
            this.g = [];
            this.j = new Set
        }
        add(a) {
            if (this.j.has(a)) return !1;
            var b = ob(this.g, a, this.l);
            this.g.splice(b >= 0 ? b : -b - 1, 0, a);
            this.j.add(a);
            return !0
        }
        first() {
            return this.g[0]
        }
        has(a) {
            return this.j.has(a)
        }
        delete(a) {
            kb(this.g, b => b === a);
            return this.j.delete(a)
        }
        clear() {
            this.j.clear();
            return this.g.splice(0, this.g.length)
        }
        size() {
            return this.g.length
        }
    };

    function PO(a) {
        for (var b = a.te.V, c; a.l.Gl() > b && (c = a.j.first());) {
            var d = a,
                e = c;
            QO(d, e);
            d.g.add(e)
        }
        for (;
            (d = MO(a.g)) && a.l.pm() <= b;) RO(a, d);
        for (;
            (d = MO(a.g)) && (c = a.j.first()) && d.priority > c.priority;) b = a, e = c, QO(b, e), b.g.add(e), RO(a, d)
    }

    function RO(a, b) {
        a.g.delete(b);
        a.j.add(b) && (b.Di = a.l.addButton(b.buttonSpec));
        b.isInToolbar.g(!0)
    }

    function QO(a, b) {
        b.Di && b.Di();
        b.Di = void 0;
        a.j.delete(b);
        b.isInToolbar.g(!1)
    }
    var SO = class {
        constructor(a, b) {
            this.te = a;
            this.l = b;
            this.g = new OO;
            this.j = new OO;
            this.B = 0;
            this.te.listen(() => void PO(this))
        }
        addButton(a) {
            var b = {
                buttonSpec: a.buttonSpec,
                priority: a.priority,
                Ki: this.B++,
                isInToolbar: new Ct(!1)
            };
            this.g.add(b);
            PO(this);
            return {
                isInToolbar: Nt(Gt(b.isInToolbar)),
                removeCallback: () => {
                    QO(this, b);
                    this.g.delete(b);
                    PO(this)
                }
            }
        }
    };

    function NO(a, b) {
        return a.priority === b.priority ? b.Ki - a.Ki : a.priority - b.priority
    };

    function TO(a) {
        if (!UD(a.win)) {
            if (a.l.V) {
                let b = ts(a.win);
                if (b > a.j + 100 || b < a.j - 100) a.l.g(!1), a.j = ns(a.win)
            }
            a.A && a.win.clearTimeout(a.A);
            a.A = a.win.setTimeout(() => void UO(a), 200)
        }
    }

    function UO(a) {
        if (!UD(a.win)) {
            var b = ns(a.win);
            a.j && a.j > b && (a.j = b);
            b = ts(a.win);
            b >= a.j - 100 && (a.j = Math.max(a.j, b), a.l.g(!0))
        }
    }
    var VO = class extends O {
        constructor(a) {
            super();
            this.win = a;
            this.l = new Ct(!1);
            this.j = 0;
            this.A = null;
            this.C = () => void TO(this)
        }
        init() {
            this.win.addEventListener("scroll", this.C);
            this.j = ns(this.win);
            UO(this)
        }
        g() {
            this.win.removeEventListener("scroll", this.C);
            this.l.g(!1);
            super.g()
        }
    };

    function WO(a, b) {
        var c = a.l.addRegulatoryMessage(b);
        c.showAndGiveUserControl();
        return {
            removeCallback: () => void c.removeCallback(),
            isDismissed: c.isDismissed
        }
    }

    function XO(a, b) {
        var c = new Ct(!1),
            d = new Ct(!1),
            e = Kt(YO(a), !0, () => {
                ZO(a, b, c, d)
            });
        return {
            removeCallback: () => {
                c.g(!0);
                e()
            },
            isDismissed: Nt(Gt(d))
        }
    }

    function YO(a) {
        if (!a.j) {
            var b = new VO(a.win);
            b.init();
            a.j = Gt(b.l);
            wt(a, b)
        }
        return a.j
    }

    function ZO(a, b, c, d) {
        var e = a.l.addRegulatoryMessage(b);
        $O(a, e, c);
        Kt(c, !0, () => {
            e.removeCallback()
        });
        Mt(d, Bt(e.isDismissed))
    }

    function $O(a, b, c) {
        a = YO(a);
        var d = Jt(a, !0, () => void b.showUnlessUserInControl()),
            e = Jt(a, !1, () => void b.hideUnlessUserInControl());
        Jt(Bt(b.isDismissed), !0, () => {
            d();
            e()
        });
        Kt(c, !0, () => {
            d();
            e()
        })
    }
    var aP = class extends O {
        constructor(a, b) {
            super();
            this.win = a;
            this.l = b;
            this.j = null
        }
        addRegulatoryMessage(a) {
            return a.displayImmediately ? WO(this, a.messageSpec) : XO(this, a.messageSpec)
        }
    };

    function bP(a, b) {
        a.googFloatingToolbarManager || (a.googFloatingToolbarManager = new cP(a, b));
        return a.googFloatingToolbarManager
    }

    function dP(a) {
        a.j || (a.j = eP(a.win, a.l, a.Tc), wt(a, a.j.wd), wt(a, a.j.ik), fP(a), gP(a, a.j.wd));
        return a.j
    }

    function hP(a) {
        a.Tc.V === null && a.j ? .position.g(iP(a))
    }

    function jP(a) {
        a.win.requestAnimationFrame(() => void hP(a))
    }

    function iP(a) {
        var b = [];
        a.j ? .wd ? .D().A() ? (b.push(() => kP(a)), b.push(() => lP(a))) : (b.push(() => lP(a)), b.push(() => kP(a)));
        a.j ? .wd ? .J() ? .A() && b.push(() => {
            var c = ls(a.win);
            return {
                position: IC({
                    ta: Math.floor(c / 3),
                    jb: 10
                }),
                te: 0
            }
        });
        for (let c of b)
            if (b = c()) return b;
        return null
    }

    function fP(a) {
        a.win.googFloatingToolbarManagerAsyncPositionUpdate ? jP(a) : hP(a)
    }

    function gP(a, b) {
        var c = kH(a.win);
        nH(c).listen(() => void fP(a));
        wt(a, c);
        b.J().listen(() => void fP(a));
        b.D().listen(() => void fP(a));
        a.Tc.listen(() => void fP(a))
    }

    function kP(a) {
        var b = a.win,
            c = ls(a.win);
        return EC(b, {
            Rd: KC({
                ta: 50,
                wb: 10
            }),
            Rh: Math.floor(c / 3),
            Le: 60,
            Uh: sO(),
            Lf: Math.floor(c / 2),
            Fc: 20
        }, [...(a.j ? .wd.C() ? ? []), a.win.document.body]).Bg
    }

    function lP(a) {
        var b = a.win,
            c = ls(a.win);
        return EC(b, {
            Rd: IC({
                ta: 50,
                jb: 10
            }),
            Rh: Math.floor(c / 3),
            Le: 60,
            Uh: sO(),
            Lf: Math.floor(c / 2),
            Fc: 40
        }, [...(a.j ? .wd.C() ? ? []), a.win.document.body]).Bg
    }
    class cP extends O {
        constructor(a, b) {
            super();
            this.win = a;
            this.l = b;
            this.j = null;
            this.Tc = mP(this.win, this)
        }
        addButton(a) {
            return dP(this).Wm.addButton(a)
        }
        addRegulatoryMessage(a) {
            return dP(this).ik.addRegulatoryMessage(a)
        }
    }

    function eP(a, b, c) {
        var d = new Ct(null),
            e = pO(a, {
                ae: 2,
                position: d.map(f => f ? .position ? ? null),
                Th: b,
                Tc: c
            });
        b = new SO(d.map(f => f ? .te || 0), {
            addButton: f => e.addButton(f),
            Gl: () => BO(e, {}),
            pm: () => BO(e, {
                Qk: 1
            })
        });
        a = new aP(a, {
            addRegulatoryMessage: f => e.addRegulatoryMessage(f)
        });
        return {
            wd: e,
            position: d,
            Wm: b,
            ik: a
        }
    }

    function mP(a, b) {
        var c = new ED(a),
            d = new Ct(null),
            e = f => void d.g(f);
        xt(b, () => {
            DD(c, e)
        });
        c.floatingAdsStacking.maxZIndexListeners.push(e);
        e(CD(c));
        return d
    };
    const nP = ["Google Symbols:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200", "Google Sans Text:400,500"];

    function oP(a, b, c, d) {
        a = new pP(a, b, c, d);
        if (a.l) {
            uu(a.win, nP);
            var e = a.win;
            b = a.message;
            c = YD(e);
            var f = c.shadowRoot;
            d = f.appendChild;
            e = new hj(e.document);
            var g = (g = {}, g.rb);
            g = wy('<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Google+Symbols:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200"' + (g ? ' nonce="' + R($y(g)) + '"' : "") + '/><link href="https://fonts.googleapis.com/css?family=Google+Sans+Text:400,500" rel="stylesheet"' + (g ? ' nonce="' + R($y(g)) + '"' : "") + "><style" + (g ? ' nonce="' + R($y(g)) +
                '"' : "") + '>.ipr-container {font-family: \'Google Sans Text\'; font-style: normal; font-weight: 400; font-size: 12px; line-height: 14px; color: #000; border-top: 2px solid rgb(236, 237, 237); border-bottom: 2px solid rgb(236, 237, 237); background-color: #fff; padding: 5px; margin: 5px 0; text-align: center;}.ipr-button {border: none; background: none; font-family: \'Google Sans Text\'; color: #0b57d0; font-weight: 500; font-size: 14px; line-height: 22px; cursor: pointer; margin: 0; padding: 0;}.ipr-display-none {display: none;}</style><div class="ipr-container"><button class="ipr-button"></button><div class="ipr-info"></div></div>');
            d.call(f, yj(e, g.Fb()));
            d = XD("ipr-container", f);
            f = XD("ipr-button", d);
            b.actionButton ? (f.appendChild(b.actionButton.buttonText), f.addEventListener("click", b.actionButton.onClick)) : f.classList.add("ipr-display-none");
            d = XD("ipr-info", d);
            b.informationText ? d.appendChild(b.informationText) : d.classList.add("ipr-display-none");
            a.j = c.wc;
            cM(a.l, a.j);
            qP(a)
        } else rP(a);
        return a
    }

    function qP(a) {
        var b = new xu(a.win);
        b.init(2E3);
        wt(a, b);
        vu(b, () => {
            sP(a);
            rP(a);
            b.dispose()
        })
    }

    function rP(a) {
        var b = bP(a.win, a.A).addRegulatoryMessage({
            messageSpec: {
                regulatoryMessage: a.message,
                orderingIndex: 0
            }
        });
        xt(a, () => void b.removeCallback())
    }

    function sP(a) {
        a.j && (a.j.parentNode ? .removeChild(a.j), a.j = null)
    }
    var pP = class extends O {
        constructor(a, b, c, d) {
            super();
            this.win = a;
            this.l = b;
            this.message = c;
            this.A = d;
            this.j = null
        }
        g() {
            sP(this);
            super.g()
        }
    };
    var uP = (a, b, c, d) => tP(a, b, c, d);

    function tP(a, b, c, d) {
        var e = oP(a, lO(a, d), {
            kind: "standard",
            actionButton: {
                buttonText: a.document.createTextNode(b),
                onClick: c
            }
        }, vP(a));
        return () => e.dispose()
    }

    function vP(a) {
        if (a = kO(a)) return a;
        AB(1234, Error("No messages"));
        return qg(new GK)
    };

    function wP(a, b) {
        b && (a.g = uP(a.j, b.localizedDnsText, () => xP(a, b), a.B))
    }

    function yP(a) {
        var b = iO(a.j);
        b.callbackQueue = b.callbackQueue || [];
        jO(a.j).overrideDnsLink = !0;
        b.callbackQueue.push({
            INITIAL_US_STATES_DATA_READY: c => wP(a, c)
        })
    }

    function xP(a, b) {
        FD(a.l);
        b.openConfirmationDialog(c => {
            c && a.g && (a.g(), a.g = null);
            GD(a.l)
        })
    }
    var zP = class {
        constructor(a, b, c) {
            this.j = a;
            this.l = zD(b, 2147483643);
            this.B = c;
            this.g = null
        }
    };

    function AP(a) {
        BP(a.l, b => {
            var c = a.j,
                d = b.revocationText,
                e = b.attestationText,
                f = b.showRevocationMessage;
            b = lO(c, a.B);
            d = {
                kind: "standard",
                actionButton: {
                    buttonText: c.document.createTextNode(d),
                    onClick: f
                },
                informationText: c.document.createTextNode(e)
            };
            e = kO(c);
            e || (AB(1233, Error("No messages")), e = qg(new GK));
            oP(c, b, d, e)
        }, () => {
            GD(a.g);
            CP(a)
        })
    }

    function DP(a) {
        FD(a.g);
        AP(a)
    }

    function CP(a) {
        a.j.__tcfapi ? a.j.__tcfapi("addEventListener", 2, (b, c) => {
            c && b.eventStatus == "cmpuishown" ? FD(a.g) : GD(a.g)
        }) : AB(1250, Error("No TCF API function"))
    }
    var EP = class {
        constructor(a, b, c, d) {
            this.j = a;
            this.g = zD(b, 2147483643);
            this.B = c;
            this.l = d
        }
    };
    var FP = a => {
            if (!a || fd(ue(a, 1)) == null) return !1;
            a = E(a, 1);
            switch (a) {
                case 1:
                    return !0;
                case 2:
                    return !1;
                default:
                    throw Error("Unhandled AutoConsentUiStatus: " + a);
            }
        },
        GP = a => {
            if (!a || fd(ue(a, 3)) == null) return !1;
            a = E(a, 3);
            switch (a) {
                case 1:
                    return !0;
                case 2:
                    return !1;
                default:
                    throw Error("Unhandled AutoCcpaUiStatus: " + a);
            }
        },
        HP = a => a ? C(a, 5) === !0 : !1;

    function IP(a) {
        if (a.j.adsbygoogle_ama_fc_has_run !== !0) {
            var b = FP(a.g),
                c = GP(a.g),
                d = !1;
            b && (DP(new EP(a.j, a.A, a.B || Ve(a.g, GJ, 4, De()), a.l)), d = !0);
            c && (yP(new zP(a.j, a.A, a.B || Ve(a.g, GJ, 4, De()))), d = !0);
            PB(e => {
                e = tf(e, 9, !0);
                e = tf(e, 10, b);
                tf(e, 11, c)
            });
            HP(a.g) && (d = !0);
            d && (a.l.start(!0), a.j.adsbygoogle_ama_fc_has_run = !0)
        }
    }
    var JP = class {
        constructor(a, b, c, d, e) {
            this.j = a;
            this.l = b;
            this.g = c;
            this.A = d;
            this.B = e || null
        }
    };

    function KP(a, b, c, d, e, f) {
        try {
            let g = a.g,
                h = $k("SCRIPT", g);
            h.async = !0;
            Ki(h, b);
            g.head.appendChild(h);
            h.addEventListener("load", () => {
                e();
                d && g.head.removeChild(h)
            });
            h.addEventListener("error", () => {
                c > 0 ? KP(a, b, c - 1, d, e, f) : (d && g.head.removeChild(h), f())
            })
        } catch (g) {
            f()
        }
    }

    function LP(a, b, c = () => {}, d = () => {}) {
        KP(Ti(a), b, 0, !1, c, d)
    };

    function MP(a = null) {
        a = a || t;
        return a.googlefc || (a.googlefc = {})
    };
    Di(Er).map(a => Number(a));
    Di(Fr).map(a => Number(a));
    const NP = t.URL;

    function OP(a) {
        var b = c => encodeURIComponent(c).replace(/[!()~']|(%20)/g, d => ({
            "!": "%21",
            "(": "%28",
            ")": "%29",
            "%20": "+",
            "'": "%27",
            "~": "%7E"
        })[d]);
        return Array.from(a, c => b(c[0]) + "=" + b(c[1])).join("&")
    };

    function PP(a) {
        var b = (new NP(a.location.href)).searchParams;
        a = b.get("fcconsent");
        b = b.get("fc");
        return b === "alwaysshow" ? b : a === "alwaysshow" ? a : null
    }

    function QP(a) {
        var b = "ab gdpr consent gdpr_transparency ccpa monetization usnat usfl".split(" ");
        return (a = (new NP(a.location.href)).searchParams.get("fctype")) && b.indexOf(a) !== -1 ? a : null
    }

    function RP(a) {
        return (a = (new NP(a.location.href)).searchParams.get("hl")) ? a : null
    }

    function SP(a) {
        var b = new NP(a),
            c = {
                search: "",
                hash: ""
            };
        a = {};
        b && (a.protocol = b.protocol, a.username = b.username, a.password = b.password, a.hostname = b.hostname, a.port = b.port, a.pathname = b.pathname, a.search = b.search, a.hash = b.hash);
        Object.assign(a, c);
        if (a.port && a.port[0] === ":") throw Error("port should not start with ':'");
        a.hash && a.hash[0] != "#" && (a.hash = "#" + a.hash);
        c.search ? c.search[0] != "?" && (a.search = "?" + c.search) : c.searchParams && (a.search = "?" + OP(c.searchParams), a.searchParams = void 0);
        b = "";
        a.protocol && (b += a.protocol +
            "//");
        c = a.username;
        var d = a.password;
        b = b + (c && d ? c + ":" + d + "@" : c ? c + "@" : d ? ":" + d + "@" : "") + (a.hostname || "");
        a.port && (b += ":" + a.port);
        b += a.pathname || "";
        b += a.search || "";
        b += a.hash || "";
        a = (new NP(b)).toString();
        a.charAt(a.length - 1) === "/" && (a = a.substring(0, a.length - 1));
        return a.toString().length <= 1E3 ? a : null
    };

    function TP(a, b) {
        var c = a.document,
            d = () => {
                if (!a.frames[b])
                    if (c.body) {
                        let e = $k("IFRAME", c);
                        e.style.display = "none";
                        e.style.width = "0px";
                        e.style.height = "0px";
                        e.style.border = "none";
                        e.style.zIndex = "-1000";
                        e.style.left = "-1000px";
                        e.style.top = "-1000px";
                        e.name = b;
                        c.body.appendChild(e)
                    } else a.setTimeout(d, 5)
            };
        d()
    };
    var UP = qh(class extends I {});

    function VP(a) {
        if (a.j) return a.j;
        a.P && a.P(a.l) ? a.j = a.l : a.j = ll(a.l, a.W);
        return a.j ? ? null
    }

    function WP(a) {
        a.A || (a.A = b => {
            try {
                var c = a.J ? a.J(b) : void 0;
                if (c) {
                    var d = c.ei,
                        e = a.G.get(d);
                    e && (e.hn || a.G.delete(d), e.Ld ? .(e.Kl, c.payload))
                }
            } catch (f) {}
        }, Yj(a.l, "message", a.A))
    }

    function XP(a, b, c) {
        if (VP(a))
            if (a.j === a.l)(b = a.D.get(b)) && b(a.j, c);
            else {
                var d = a.C.get(b);
                if (d && d.se) {
                    WP(a);
                    var e = ++a.Z;
                    a.G.set(e, {
                        Ld: d.Ld,
                        Kl: d.If(c),
                        hn: b === "addEventListener"
                    });
                    a.j.postMessage(d.se(c, e), "*")
                }
            }
    }
    var YP = class extends O {
        constructor(a, b, c, d) {
            super();
            this.W = b;
            this.P = c;
            this.J = d;
            this.D = new Map;
            this.Z = 0;
            this.C = new Map;
            this.G = new Map;
            this.A = void 0;
            this.l = a
        }
        g() {
            delete this.j;
            this.D.clear();
            this.C.clear();
            this.G.clear();
            this.A && (Zj(this.l, "message", this.A), delete this.A);
            delete this.l;
            delete this.J;
            super.g()
        }
    };
    const ZP = (a, b) => {
            var c = {
                cb: d => {
                    d = UP(d);
                    b.Jb({
                        ce: d
                    })
                }
            };
            b.spsp && (c.spsp = b.spsp);
            a = a.googlefc || (a.googlefc = {});
            a.__fci = a.__fci || [];
            a.__fci.push(b.command, c)
        },
        $P = {
            If: a => a.Jb,
            se: (a, b) => ({
                __fciCall: {
                    callId: b,
                    command: a.command,
                    spsp: a.spsp || void 0
                }
            }),
            Ld: (a, b) => {
                a({
                    ce: b
                })
            }
        };

    function aQ(a) {
        a = UP(a.data.__fciReturn);
        return {
            payload: a,
            ei: KH(hf(a, 1))
        }
    }

    function bQ(a, b = !1) {
        if (b) return !1;
        a.l || (a.j = !!VP(a.caller), a.l = !0);
        return a.j
    }

    function cQ(a) {
        return new Promise(b => {
            bQ(a) && XP(a.caller, "getDataWithCallback", {
                command: "loaded",
                Jb: c => {
                    b(c.ce)
                }
            })
        })
    }

    function dQ(a, b) {
        bQ(a) && XP(a.caller, "getDataWithCallback", {
            command: "prov",
            spsp: pg(b),
            Jb: () => {}
        })
    }
    var eQ = class extends O {
        constructor(a) {
            super();
            this.j = this.l = !1;
            this.caller = new YP(a, "googlefcPresent", void 0, aQ);
            this.caller.D.set("getDataWithCallback", ZP);
            this.caller.C.set("getDataWithCallback", $P)
        }
        g() {
            this.caller.dispose();
            super.g()
        }
    };
    var fQ = class extends I {};

    function gQ(a) {
        a.addtlConsent === void 0 || x(a.addtlConsent) || (a.addtlConsent = void 0);
        a.gdprApplies === void 0 || pc(a.gdprApplies) || (a.gdprApplies = void 0);
        return a.tcString !== void 0 && !x(a.tcString) || a.listenerId !== void 0 && !oc(a.listenerId) ? 2 : a.cmpStatus && a.cmpStatus !== "error" ? 0 : 3
    }

    function hQ(a) {
        if (a.gdprApplies === !1) return !0;
        a.internalErrorState === void 0 && (a.internalErrorState = gQ(a));
        return a.cmpStatus === "error" || a.internalErrorState !== 0 ? a.internalBlockOnErrors ? (zl({
            e: String(a.internalErrorState)
        }, "tcfe"), !1) : !0 : a.cmpStatus !== "loaded" || a.eventStatus !== "tcloaded" && a.eventStatus !== "useractioncomplete" ? !1 : !0
    }

    function iQ(a, b = {}) {
        return hQ(a) ? a.gdprApplies === !1 ? !0 : a.tcString === "tcunavailable" ? !b.idpcApplies : (b.idpcApplies || a.gdprApplies !== void 0 || b.wp) && (b.idpcApplies || x(a.tcString) && a.tcString.length) ? jQ(a, "1") : !0 : !1
    }

    function jQ(a, b) {
        a: {
            if (a.publisher && a.publisher.restrictions) {
                var c = a.publisher.restrictions[b];
                if (c !== void 0) {
                    c = c["755"];
                    break a
                }
            }
            c = void 0
        }
        if (c === 0) return !1;a = a.purpose && a.vendor ? (c = kQ(a.vendor.consents, "755")) && b === "1" && a.purposeOneTreatment && a.publisherCC === "CH" ? !0 : c && kQ(a.purpose.consents, b) : !0;
        return a
    }

    function kQ(a, b) {
        return !(!a || !a[b])
    }

    function lQ(a) {
        var b = ["3", "4"];
        return a.gdprApplies === !1 ? !0 : b.every(c => jQ(a, c))
    }

    function mQ(a) {
        if (a.j) return a.j;
        a.j = ll(a.l, "__tcfapiLocator");
        return a.j
    }

    function nQ(a) {
        return typeof a.l.__tcfapi === "function" || mQ(a) != null
    }

    function oQ(a, b, c, d) {
        c || (c = () => {});
        var e = a.l;
        typeof e.__tcfapi === "function" ? (a = e.__tcfapi, a(b, 2, c, d)) : mQ(a) ? (pQ(a), e = ++a.D, a.C[e] = c, a.j && a.j.postMessage({
            __tcfapiCall: {
                command: b,
                version: 2,
                callId: e,
                parameter: d
            }
        }, "*")) : c({}, !1)
    }

    function qQ(a, b) {
        var c = {
                internalErrorState: 0,
                internalBlockOnErrors: a.nd
            },
            d = pi(() => {
                b(c)
            }),
            e = 0;
        a.timeoutMs !== -1 && (e = setTimeout(() => {
            e = 0;
            c.tcString = "tcunavailable";
            c.internalErrorState = 1;
            d()
        }, a.timeoutMs));
        oQ(a, "addEventListener", f => {
            f && (c = f, c.internalErrorState = gQ(c), c.internalBlockOnErrors = a.nd, hQ(c) ? (c.internalErrorState !== 0 && (c.tcString = "tcunavailable"), oQ(a, "removeEventListener", null, c.listenerId), (f = e) && clearTimeout(f), d()) : (c.cmpStatus === "error" || c.internalErrorState !== 0) && (f = e) && clearTimeout(f))
        })
    }

    function pQ(a) {
        if (!a.A) {
            var b = c => {
                try {
                    var d = (x(c.data) ? JSON.parse(c.data) : c.data).__tcfapiReturn;
                    a.C[d.callId](d.returnValue, d.success)
                } catch (e) {}
            };
            a.A = b;
            Yj(a.l, "message", b)
        }
    }
    var rQ = class extends O {
        constructor(a, b = {}) {
            super();
            this.j = null;
            this.C = {};
            this.D = 0;
            this.A = null;
            this.l = a;
            this.timeoutMs = b.timeoutMs ? ? 500;
            this.nd = b.nd ? ? !1
        }
        g() {
            this.C = {};
            this.A && (Zj(this.l, "message", this.A), delete this.A);
            delete this.C;
            delete this.l;
            delete this.j;
            super.g()
        }
        addEventListener(a) {
            var b = {
                    internalBlockOnErrors: this.nd
                },
                c = pi(() => {
                    a(b)
                }),
                d = 0;
            this.timeoutMs !== -1 && (d = setTimeout(() => {
                b.tcString = "tcunavailable";
                b.internalErrorState = 1;
                c()
            }, this.timeoutMs));
            var e = (f, g) => {
                clearTimeout(d);
                f ? (b = f, b.internalErrorState =
                    gQ(b), b.internalBlockOnErrors = this.nd, g && b.internalErrorState === 0 || (b.tcString = "tcunavailable", g || (b.internalErrorState = 3))) : (b.tcString = "tcunavailable", b.internalErrorState = 3);
                a(b)
            };
            try {
                oQ(this, "addEventListener", e)
            } catch (f) {
                b.tcString = "tcunavailable", b.internalErrorState = 3, d && (clearTimeout(d), d = 0), c()
            }
        }
        removeEventListener(a) {
            a && a.listenerId && oQ(this, "removeEventListener", null, a.listenerId)
        }
    };

    function BP(a, b, c) {
        var d = MP(a.win);
        d.callbackQueue = d.callbackQueue || [];
        d.callbackQueue.push({
            CONSENT_DATA_READY: () => {
                var e = MP(a.win),
                    f = new rQ(a.win);
                nQ(f) && qQ(f, g => {
                    g.cmpId === 300 && g.tcString && g.tcString !== "tcunavailable" && g.gdprApplies && b({
                        revocationText: (0, e.getDefaultConsentRevocationText)(),
                        closeText: (0, e.getDefaultConsentRevocationCloseText)(),
                        attestationText: (0, e.getDefaultConsentRevocationAttestationText)(),
                        showRevocationMessage: () => {
                            (0, e.showRevocationMessage)()
                        }
                    })
                });
                c()
            }
        })
    }

    function sQ(a, b = !1, c) {
        c || (c = new fQ);
        wf(c, 2, Math.round(performance.now()));
        var d = {};
        try {
            let f = PP(a.win),
                g = QP(a.win);
            d.fc = f;
            d.fctype = g;
            let h = RP(a.win);
            h && (d.hl = h)
        } catch (f) {}
        try {
            var e = SP(a.win.location.href)
        } catch (f) {}
        b && e && (d.href = e);
        b = tQ(a.g, d);
        LP(a.win, b, () => {}, () => {});
        c && dQ(new eQ(a.win), c)
    }
    var uQ = class {
        constructor(a, b) {
            this.win = a;
            this.g = b;
            this.ea = null
        }
        start(a = !1, b) {
            if (this.win === this.win.top) try {
                TP(this.win, "googlefcPresent"), sQ(this, a, b)
            } catch (c) {}
        }
    };

    function tQ(a, b) {
        a = fi `https://fundingchoicesmessages.google.com/i/${a}`;
        return gi(a, { ...b,
            ers: 2
        })
    };

    function vQ(a, b, c) {
        return (a = a.g()) && pf(a, 11) ? c.map(d => d.j()) : c.map(d => d.A(b))
    };
    var wQ = class {
        constructor() {
            this.map = new Map
        }
        clear() {
            this.map.clear()
        }
        delete(a, b) {
            var c = this.map.get(a);
            return c ? (b = c.delete(b), c.size === 0 && this.map.delete(a), b) : !1
        }
        get(a) {
            return [...(this.map.get(a) ? ? [])]
        }
        keys() {
            return this.map.keys()
        }
        add(a, b) {
            var c = this.map.get(a);
            c || this.map.set(a, c = new Set);
            c.add(b)
        }
        get size() {
            var a = 0;
            for (let b of this.map.values()) a += b.size;
            return a
        }
        values() {
            var a = this.map;
            return function() {
                return function*() {
                    for (let b of a.values()) yield* b
                }()
            }()
        }[Symbol.iterator]() {
            var a = this.map;
            return function() {
                return function*() {
                    for (let [b, c] of a) {
                        let d = b,
                            e = c;
                        for (let f of e) yield [d, f]
                    }
                }()
            }()
        }
    };

    function xQ(a) {
        return [a[0],
            [...a[1]]
        ]
    };
    const yQ = new Set([7, 1]);
    var zQ = class {
        constructor() {
            this.l = new wQ;
            this.B = []
        }
        g(a, b) {
            yQ.has(b) || Ou(Lu(bM(a), c => void this.l.add(c, b)), c => void this.B.push(c))
        }
        j(a, b) {
            for (let c of a) this.g(c, b)
        }
    };

    function AQ(a) {
        return new dv(["pedestal_container"], {
            google_reactive_ad_format: 30,
            google_ad_width: Math.floor(a),
            google_ad_format: "autorelaxed",
            google_full_width_responsive: !0,
            google_enable_content_recommendations: !0,
            google_content_recommendation_ui_type: "pedestal"
        })
    }
    var BQ = class {
        g(a) {
            return AQ(Math.floor(a.j))
        }
    };
    var CQ = class extends I {};

    function DQ(a, b) {
        var c = b.adClient;
        if (!x(c) || !c) return !1;
        a.pg = c;
        a.j = !!b.adTest;
        c = b.pubVars;
        ra(c) && (a.I = c);
        if (Array.isArray(b.fillMessage) && b.fillMessage.length > 0) {
            a.B = {};
            for (let d of b.fillMessage) a.B[d.key] = d.value
        }
        a.Dc = b.adWidth;
        a.Cc = b.adHeight;
        oc(a.Dc) && a.Dc > 0 && oc(a.Cc) && a.Cc > 0 || zB("rctnosize", b);
        return !0
    }
    var EQ = class {
        constructor() {
            this.B = this.I = this.j = this.pg = null;
            this.Cc = this.Dc = 0
        }
        A() {
            return !0
        }
    };

    function FQ(a) {
        try {
            a.setItem("__storage_test__", "__storage_test__");
            let b = a.getItem("__storage_test__");
            a.removeItem("__storage_test__");
            return b === "__storage_test__"
        } catch (b) {
            return !1
        }
    }

    function GQ(a, b = []) {
        var c = Date.now();
        return cb(b, d => c - d < a * 1E3)
    }

    function HQ(a, b, c) {
        try {
            let d = a.getItem(c);
            if (!d) return [];
            let e;
            try {
                e = JSON.parse(d)
            } catch (f) {}
            if (!Array.isArray(e) || fb(e, f => !Number.isInteger(f))) return a.removeItem(c), [];
            e = GQ(b, e);
            e.length || a ? .removeItem(c);
            return e
        } catch (d) {
            return null
        }
    }

    function IQ(a, b, c) {
        return b <= 0 || a == null || !FQ(a) ? null : HQ(a, b, c)
    };

    function JQ(a, b, c) {
        var d = 0;
        try {
            var e = d |= js(a);
            let h = ks(a),
                k = a.innerWidth;
            var f = h && k ? h / k : 0;
            d = e | (f ? f > 1.05 ? 262144 : f < .95 ? 524288 : 0 : 131072);
            d |= ms(a);
            d |= a.innerHeight >= a.innerWidth ? 0 : 8;
            d |= a.navigator && /Android 2/.test(a.navigator.userAgent) ? 1048576 : 0;
            var g;
            if (g = b) g = IQ(c, 3600, "__lsv__") ? .length !== 0;
            g && (d |= 134217728)
        } catch (h) {
            d |= 32
        }
        return d
    };
    var KQ = class extends EQ {
        constructor() {
            super(...arguments);
            this.l = !1;
            this.g = null
        }
        A(a) {
            this.l = !!a.enableAma;
            if (a = a.amaConfig) try {
                var b = WK(a)
            } catch (c) {
                b = null
            } else b = null;
            this.g = b;
            return !0
        }
    };
    var LQ = {};

    function MQ(a, b, c) {
        var d = NQ(a, c, b);
        if (!d) return !0;
        for (var e = c.D.j; d.Pd && d.Pd.length;) {
            let f = d.Pd.shift(),
                g = DL(f.va);
            if (g && !(typeof d.md === "number" && g <= d.md)) c.C ? .g(f, 18);
            else if (OQ(c, f, {
                    Jf: d.md
                })) {
                if (d.Oe.g.length + 1 >= e) return c.C ? .j(d.Pd, 19), !0;
                d = NQ(a, c, b);
                if (!d) return !0
            }
        }
        return c.l
    }
    const NQ = (a, b, c) => {
        var d = b.D.j,
            e = b.D.C,
            f = b.ua(),
            g = b.D;
        f = HM(f, g.g ? g.g.Zd : void 0, d, !0);
        if (f.g.length >= d) return b.C ? .j(PQ(b, f, {
            types: a
        }, c), 19), null;
        e ? (d = f.j || (f.j = ps(f.l).scrollHeight || null), e = !d || d < 0 ? -1 : d * e - NM(f)) : e = void 0;
        g = (d = e == null || e >= 50) ? PQ(b, f, {
            types: a
        }, c) : null;
        d || b.C ? .j(PQ(b, f, {
            types: a
        }, c), 18);
        return {
            Oe: f,
            md: e,
            Pd: g
        }
    };
    LQ[2] = Aa(function(a, b) {
        a = PQ(b, HM(b.ua()), {
            types: a,
            Bc: wM(b.ua())
        }, 2);
        if (a.length == 0) return !0;
        for (let c = 0; c < a.length; c++)
            if (OQ(b, a[c])) return !0;
        return b.l ? (b.B.push(11), !0) : !1
    }, [0]);
    LQ[5] = Aa(MQ, [0], 5);
    LQ[10] = Aa(function(a, b) {
        a = [];
        var c = b.Me;
        c.includes(3) && a.push(2);
        c.includes(1) && a.push(0);
        c.includes(2) && a.push(1);
        return MQ(a, 10, b)
    }, 10);
    LQ[3] = function(a) {
        if (!a.l) return !1;
        var b = PQ(a, HM(a.ua()), {
            types: [0],
            Bc: wM(a.ua())
        }, 3);
        if (b.length == 0) return !0;
        for (let c = b.length - 1; c >= 0; c--)
            if (OQ(a, b[c])) return !0;
        a.B.push(11);
        return !0
    };
    const RQ = a => {
            var b = a.ua().document.body.getBoundingClientRect().width;
            QQ(a, AQ(b))
        },
        TQ = (a, b) => {
            var c = {
                types: [0],
                Bc: new rM(0, null, [], 3, null),
                xn: [5]
            };
            c = PQ(a, HM(a.ua()), c, 8);
            SQ(a, c.reverse(), b)
        },
        SQ = (a, b, c) => {
            for (let d of b)
                if (b = c.g(d.Fa), OQ(a, d, {
                        qg: b
                    })) return !0;
            return !1
        };
    LQ[8] = function(a) {
        var b = a.ua().document;
        if (b.readyState != "complete") return b.addEventListener("readystatechange", () => LQ[8](a), {
            once: !0
        }), !0;
        if (!a.l) return !1;
        if (!a.Ef()) return !0;
        b = {
            types: [0],
            Bc: new rM(0, null, [], 3, null),
            ki: [2, 4, 5]
        };
        b = PQ(a, HM(a.ua()), b, 8);
        var c = new BQ;
        if (SQ(a, b, c)) return !0;
        if (a.A.nj) switch (a.A.dk || 0) {
            case 1:
                TQ(a, c);
                break;
            default:
                RQ(a)
        }
        return !0
    };
    LQ[6] = Aa(MQ, [2], 6);
    LQ[7] = Aa(MQ, [1], 7);
    LQ[9] = function(a) {
        var b = NQ([0, 2], a, 9);
        if (!b || !b.Pd) return a.B.push(17), a.l;
        for (var c of b.Pd) {
            a: {
                var d = a.A.oh || null;
                if (d == null) {
                    var e = null;
                    break a
                }
                e = new UQ;d = new VQ(d, a.ua());e = EL(c.va, e, d);e = new dM(e, c.ya(), c.Fa)
            }
            if (!e) continue;d = DL(e.va);
            if (d === null) continue;
            if (typeof b.md === "number" && d > b.md) continue;
            if (!OQ(a, e, {
                    Jf: b.md,
                    Eg: !0
                })) continue;a = e.va.J;c = c.va;a = a.length > 0 ? a[0] : null;c.B = !0;a != null && c.J.push(a);
            return !0
        }
        a.B.push(17);
        return a.l
    };
    var UQ = class {
        j(a, b, c, d) {
            return dK(d.document, a, b)
        }
        l(a) {
            return ls(a) || 0
        }
    };
    var WQ = class {
        constructor(a, b, c) {
            this.j = a;
            this.g = b;
            this.Oe = c
        }
        pb(a) {
            return this.g ? jN(this.j, this.g, a, this.Oe) : iN(this.j, a, this.Oe)
        }
        ib() {
            return this.g ? 16 : 9
        }
    };
    var XQ = class {
        constructor(a) {
            this.rg = a
        }
        pb(a) {
            return qN(a.document, this.rg)
        }
        ib() {
            return 11
        }
    };
    var YQ = class {
        constructor(a) {
            this.Uc = a
        }
        pb(a) {
            return nN(this.Uc, a)
        }
        ib() {
            return 13
        }
    };
    var ZQ = class {
        pb(a) {
            return gN(a)
        }
        ib() {
            return 12
        }
    };
    var $Q = class {
        constructor(a) {
            this.je = a
        }
        pb() {
            return lN(this.je)
        }
        ib() {
            return 2
        }
    };
    var aR = class {
        constructor(a) {
            this.g = a
        }
        pb() {
            return oN(this.g)
        }
        ib() {
            return 3
        }
    };
    var bR = class {
        pb() {
            return rN()
        }
        ib() {
            return 17
        }
    };
    var cR = class {
        constructor(a) {
            this.g = a
        }
        pb() {
            return kN(this.g)
        }
        ib() {
            return 1
        }
    };
    var dR = class {
        pb() {
            return ni(yL)
        }
        ib() {
            return 7
        }
    };
    var eR = class {
        constructor(a) {
            this.ki = a
        }
        pb() {
            return mN(this.ki)
        }
        ib() {
            return 6
        }
    };
    var fR = class {
        constructor(a) {
            this.g = a
        }
        pb() {
            return pN(this.g)
        }
        ib() {
            return 5
        }
    };
    var gR = class {
        constructor(a, b) {
            this.minWidth = a;
            this.maxWidth = b
        }
        pb() {
            return Aa(sN, this.minWidth, this.maxWidth)
        }
        ib() {
            return 10
        }
    };
    var hR = class {
        constructor(a) {
            this.B = a.j.slice(0);
            this.j = a.g.slice(0);
            this.l = a.l;
            this.A = a.B;
            this.g = a.A
        }
    };

    function iR(a) {
        var b = new jR;
        b.A = a;
        b.j.push(new cR(a));
        return b
    }

    function kR(a, b) {
        a.j.push(new eR(b));
        return a
    }

    function lR(a, b) {
        a.j.push(new $Q(b));
        return a
    }

    function mR(a, b) {
        a.j.push(new fR(b));
        return a
    }

    function nR(a, b) {
        a.j.push(new aR(b));
        return a
    }

    function oR(a) {
        a.j.push(new dR);
        return a
    }

    function pR(a) {
        a.g.push(new ZQ);
        return a
    }

    function qR(a, b = 0, c, d) {
        a.g.push(new WQ(b, c, d));
        return a
    }

    function rR(a, b = 0, c = Infinity) {
        a.g.push(new gR(b, c));
        return a
    }

    function sR(a) {
        a.g.push(new bR);
        return a
    }

    function tR(a, b = 0) {
        a.g.push(new YQ(b));
        return a
    }

    function uR(a, b) {
        a.l = b;
        return a
    }
    var jR = class {
        constructor() {
            this.l = 0;
            this.B = !1;
            this.j = [].slice(0);
            this.g = [].slice(0)
        }
        build() {
            return new hR(this)
        }
    };
    var VQ = class {
        constructor(a, b) {
            this.j = a;
            this.l = b
        }
        g() {
            var a = this.j,
                b = this.l,
                c = a.I || {};
            c.google_ad_client = a.pg;
            c.google_ad_height = ls(b) || 0;
            c.google_ad_width = ks(b) || 0;
            c.google_reactive_ad_format = 9;
            b = new CQ;
            b = sf(b, 1, a.l);
            a.g && z(b, 2, a.g);
            c.google_rasc = pg(b);
            a.j && (c.google_adtest = "on");
            return new dv(["fsi_container"], c)
        }
    };
    var vR = Xu(new Tu(0, {})),
        wR = Xu(new Tu(1, {})),
        xR = a => a === vR || a === wR;

    function yR(a, b, c) {
        As(a.g, b) || a.g.set(b, []);
        a.g.get(b).push(c)
    }
    var zR = class {
        constructor() {
            this.g = new Es
        }
    };

    function AR(a, b) {
        a.C.wpc = b;
        return a
    }

    function BR(a, b) {
        for (let c = 0; c < a.B.length; c++)
            if (a.B[c] == b) return a;
        a.B.push(b);
        return a
    }

    function CR(a, b) {
        for (let c = 0; c < b.length; c++) BR(a, b[c]);
        return a
    }

    function DR(a, b) {
        a.l = a.l ? a.l : b;
        return a
    }
    var ER = class {
        constructor(a) {
            this.C = {};
            this.C.c = a;
            this.B = [];
            this.l = null;
            this.A = [];
            this.D = 0
        }
        getData(a) {
            var b = Ei(this.C);
            this.D > 0 && (b.t = this.D);
            b.err = this.B.join();
            b.warn = this.A.join();
            this.l && (b.excp_n = this.l.name, b.excp_m = this.l.message && this.l.message.substring(0, 512), b.excp_s = this.l.stack && Ol(this.l.stack, ""));
            b.w = 0 < a.innerWidth ? a.innerWidth : null;
            b.h = 0 < a.innerHeight ? a.innerHeight : null;
            return b
        }
    };

    function FR(a, b) {
        b && (a.g.apv = qf(b, 4), ye(b, CK, 23) && (a.g.sat = "" + y(b, CK, 23).g()));
        return a
    }

    function GR(a, b) {
        a.g.afm = b.join(",");
        return a
    }
    var HR = class extends ER {
        constructor(a) {
            super(a);
            this.g = {}
        }
        getData(a) {
            try {
                this.g.su = a.location.hostname
            } catch (b) {
                this.g.su = "_ex"
            }
            a = super.getData(a);
            Gi(a, this.g);
            return a
        }
    };

    function IR(a) {
        return a == null ? null : Number.isInteger(a) ? a.toString() : a.toFixed(3)
    };

    function JR(a, b, c, d = 30) {
        c.length <= d ? a[b] = KR(c) : (a[b] = KR(c.slice(0, d)), a[b + "_c"] = c.length.toString())
    }

    function KR(a) {
        var b = a.length > 0 && typeof a[0] === "string";
        a = a.map(c => c ? .toString() ? ? "null");
        b && (a = a.map(c => ja(c, "replaceAll").call(c, "~", "")));
        return a.join("~")
    }

    function LR(a) {
        return a == null ? "null" : typeof a === "string" ? a : typeof a === "boolean" ? a ? "1" : "0" : Number.isInteger(a) ? a.toString() : a.toFixed(3)
    };

    function MR(a, b) {
        a.j.op = LR(b)
    }

    function NR(a, b, c) {
        JR(a.j, "fap", b);
        a.j.fad = LR(c)
    }

    function OR(a, b, c) {
        JR(a.j, "fmp", b);
        a.j.fmd = LR(c)
    }

    function PR(a, b, c) {
        JR(a.j, "vap", b);
        a.j.vad = LR(c)
    }

    function QR(a, b, c) {
        JR(a.j, "vmp", b);
        a.j.vmd = LR(c)
    }

    function RR(a, b, c) {
        JR(a.j, "pap", b);
        a.j.pad = LR(c)
    }

    function SR(a, b, c) {
        JR(a.j, "pmp", b);
        a.j.pmd = LR(c)
    }

    function TR(a, b) {
        JR(a.j, "psq", b)
    }
    var UR = class extends HR {
        constructor(a) {
            super(0);
            Object.assign(this, a);
            this.j = {};
            this.errors = []
        }
        getData(a) {
            a = super.getData(a);
            Object.assign(a, this.j);
            this.errors.length > 0 && (a.e = KR(this.errors));
            return a
        }
    };

    function VR(a, b, c) {
        var d = b.va;
        As(a.g, d) || a.g.set(d, new WR(Ku(bM(b)) ? ? ""));
        c(a.g.get(d))
    }

    function YR(a, b) {
        VR(a, b, c => {
            c.g = !0
        })
    }

    function ZR(a, b) {
        VR(a, b, c => {
            c.j = !0
        })
    }

    function $R(a, b) {
        VR(a, b, c => {
            c.l = !0
        });
        a.P.push(b.va)
    }

    function aS(a, b, c) {
        VR(a, b, d => {
            d.Gd = c
        })
    }

    function bS(a, b, c) {
        var d = [],
            e = 0;
        for (let f of c.filter(b)) xR(f.Gd ? ? "") ? ++e : (b = a.j.get(f.Gd ? ? "", null), d.push(b));
        return {
            list: d.sort((f, g) => (f ? ? -1) - (g ? ? -1)),
            Hd: e
        }
    }

    function cS(a, b) {
        MR(b, a.j.Mc());
        var c = Ds(a.g).filter(f => (f.cd.startsWith(vR) ? 0 : 1) === 0),
            d = Ds(a.g).filter(f => (f.cd.startsWith(vR) ? 0 : 1) === 1),
            e = bS(a, f => f.g, c);
        NR(b, e.list, e.Hd);
        e = bS(a, f => f.g, d);
        OR(b, e.list, e.Hd);
        e = bS(a, f => f.j, c);
        PR(b, e.list, e.Hd);
        e = bS(a, f => f.j, d);
        QR(b, e.list, e.Hd);
        c = bS(a, f => f.l, c);
        RR(b, c.list, c.Hd);
        d = bS(a, f => f.l, d);
        SR(b, d.list, d.Hd);
        TR(b, a.P.map(f => a.g.get(f) ? .Gd).map(f => a.j.get(f) ? ? null))
    }

    function fo() {
        var a = dr(dS);
        if (!a.A) return Un();
        var b = co(bo(ao($n(Zn(Yn(Xn(Wn(Tn(Sn(new Vn, a.A ? ? []), a.J ? ? []), a.C), a.O), a.G), a.W), a.Z), a.D ? ? 0), Ds(a.g).map(c => {
            var d = new Rn;
            d = Kf(d, 1, c.cd);
            var e = a.j.get(c.Gd ? ? "", -1);
            d = xf(d, 2, e);
            d = tf(d, 3, c.g);
            return tf(d, 4, c.j)
        })), a.P.map(c => a.g.get(c) ? .Gd).map(c => a.j.get(c) ? ? -1));
        a.l != null && tf(b, 6, a.l);
        a.B != null && If(b, 13, a.B);
        return b
    }
    var dS = class {
        constructor() {
            this.B = this.J = this.A = null;
            this.G = this.O = !1;
            this.l = null;
            this.Z = this.C = this.W = !1;
            this.D = null;
            this.j = new Es;
            this.g = new Es;
            this.P = []
        }
    };
    class WR {
        constructor(a) {
            this.l = this.j = this.g = !1;
            this.Gd = null;
            this.cd = a
        }
    };
    var eS = class {
        constructor(a) {
            this.j = a;
            this.g = -1
        }
    };

    function fS(a) {
        for (var b = 0; a;)(!b || a.previousElementSibling || a.nextElementSibling) && b++, a = a.parentElement;
        return b
    };

    function gS(a, b) {
        var c = a.J.filter(d => Cs(d.bf).every(e => d.bf.get(e) === b.get(e)));
        return c.length === 0 ? (a.j.push(19), null) : c.reduce((d, e) => d.bf.Mc() > e.bf.Mc() ? d : e, c[0])
    }

    function hS(a, b) {
        b = bM(b);
        if (!Ju(b)) return a.j.push(18), null;
        b = b.getValue();
        if (As(a.l, b)) return a.l.get(b);
        var c = Vu(b);
        c = gS(a, c);
        a.l.set(b, c);
        return c
    }
    var iS = class {
        constructor(a) {
            this.g = a;
            this.l = new Es;
            this.J = (y(a, QK, 2) ? .g() || []).map(b => {
                var c = Vu(D(b, 1)),
                    d = KH(hf(b, 2));
                return {
                    bf: c,
                    gk: d,
                    cd: D(b, 1)
                }
            });
            this.j = []
        }
        G() {
            var a = dr(dS),
                b = this.B();
            a.A = b;
            b = this.C();
            a.J = b;
            b = this.A();
            b != null && (a.B = b);
            b = !!this.g.j() ? .g() ? .g();
            a.G = b;
            b = new Es;
            for (let c of y(this.g, QK, 2) ? .g() ? ? []) b.set(D(c, 1), KH(hf(c, 2)));
            a.j = b
        }
        D() {
            return [...this.j]
        }
        B() {
            return [...this.g.g()]
        }
        C() {
            return [...df(this.g, 4).map(KH)]
        }
        A() {
            return JH(y(this.g, KK, 5) ? .g()) ? ? null
        }
        O(a) {
            var b = hS(this, a);
            b ? .cd != null &&
                aS(dr(dS), a, b.cd)
        }
        P(a) {
            return a.length == 0 ? !0 : .75 <= (new Bu(a)).filter(b => {
                b = hS(this, b) ? .cd || "";
                return b != "" && !(b === vR || b === wR)
            }).g.length / a.length
        }
    };

    function jS(a, b) {
        return b.g.length == 0 ? b : b.sort((c, d) => (hS(a.g, c) ? .gk ? ? Number.MAX_VALUE) - (hS(a.g, d) ? .gk ? ? Number.MAX_VALUE))
    }

    function kS(a, b) {
        var c = b.Fa.g,
            d = Math,
            e = d.min,
            f = b.ya(),
            g = b.va.j();
        c += 200 * e.call(d, 20, g == 0 || g == 3 ? fS(f.parentElement) : fS(f));
        a = a.j;
        a.g < 0 && (a.g = ps(a.j).scrollHeight || 0);
        a = a.g - b.Fa.g;
        a = c + (a > 1E3 ? 0 : 2 * (1E3 - a));
        b.ya();
        return a
    }

    function lS(a, b) {
        return b.g.length == 0 ? b : b.sort((c, d) => kS(a, c) - kS(a, d))
    }

    function mS(a, b) {
        return b.sort((c, d) => {
            var e = c.va.D,
                f = d.va.D,
                g;
            e == null || f == null ? g = e == null && f == null ? kS(a, c) - kS(a, d) : e == null ? 1 : -1 : g = e - f;
            return g
        })
    }
    var nS = class {
        constructor(a, b = null) {
            this.j = new eS(a);
            this.g = b && new iS(b)
        }
    };

    function oS(a, b, c = 0, d) {
        var e = a.j;
        for (var f of b.B) e = Au(e, f.pb(a.l), pS(f.ib(), c));
        f = e = e.apply(fN(a.l));
        for (let g of b.j) f = Au(f, g.pb(a.l), Ru([qS(g.ib(), c), h => {
            d ? .g(h, g.ib())
        }]));
        switch (b.l) {
            case 1:
                f = lS(a.g, f);
                break;
            case 2:
                f = mS(a.g, f);
                break;
            case 3:
                let g = dr(dS);
                f = jS(a.g, f);
                e.forEach(h => {
                    YR(g, h);
                    a.g.g ? .O(h)
                });
                f.forEach(h => ZR(g, h))
        }
        b.A && (f = Du(f, Qi(a.l.location.href + a.l.localStorage.google_experiment_mod)));
        b.g ? .length === 1 && yR(a.B, b.g[0], {
            qb: e.g.length,
            zk: f.g.length
        });
        return Cu(f)
    }
    var rS = class {
        constructor(a, b, c = null) {
            this.j = new Bu(a);
            this.g = new nS(b, c);
            this.l = b;
            this.B = new zR
        }
    };
    const pS = (a, b) => c => BL(c, b, a),
        qS = (a, b) => c => BL(c.va, b, a);

    function sS(a, b, c, d) {
        a: {
            switch (b) {
                case 0:
                    a = tS(uS(c), a);
                    break a;
                case 3:
                    a = tS(c, a);
                    break a;
                case 2:
                    let e = c.lastChild;
                    a = tS(e ? e.nodeType == 1 ? e : uS(e) : null, a);
                    break a
            }
            a = !1
        }
        if (d = !a && !(!d && b == 2 && !vS(c))) b = b == 1 || b == 2 ? c : c.parentNode,
        d = !(b && !JJ(b) && b.offsetWidth <= 0);
        return d
    }

    function tS(a, b) {
        if (!a) return !1;
        a = al(a, b);
        if (!a) return !1;
        a = a.cssFloat || a.styleFloat;
        return a == "left" || a == "right"
    }

    function uS(a) {
        for (a = a.previousSibling; a && a.nodeType != 1;) a = a.previousSibling;
        return a ? a : null
    }

    function vS(a) {
        return !!a.nextSibling || !!a.parentNode && vS(a.parentNode)
    };
    var wS = {
        rectangle: 1,
        horizontal: 2,
        vertical: 4
    };

    function xS(a, b) {
        var c = ["width", "height"];
        for (let e = 0; e < c.length; e++) {
            let f = "google_ad_" + c[e];
            if (!b.hasOwnProperty(f)) {
                var d = el(a[c[e]]);
                d = d === null ? null : Math.round(d);
                d != null && (b[f] = d)
            }
        }
    }

    function yS(a, b) {
        return !((cl.test(b.google_ad_width) || bl.test(a.style.width)) && (cl.test(b.google_ad_height) || bl.test(a.style.height)))
    }

    function zS(a, b) {
        var c = a.google_reactive_ad_format === 40,
            d = a.google_reactive_ad_format === 16;
        return !!a.google_ad_resizable && (!a.google_reactive_ad_format || c) && !d && !!b.navigator && /iPhone|iPod|iPad|Android|BlackBerry/.test(b.navigator.userAgent) && b === b.top
    }

    function AS(a, b, c, d, e) {
        if (a !== a.top) return Lk(a) ? 3 : 16;
        if (!(ks(a) < 488)) return 4;
        if (!(a.innerHeight >= a.innerWidth)) return 5;
        var f = ks(a);
        if (!f || (f - c) / f > d) a = 6;
        else {
            if (c = e.google_full_width_responsive !== "true") a: {
                c = b.parentElement;
                for (b = ks(a); c; c = c.parentElement) {
                    d = al(c, a);
                    if (!d) continue;
                    if ((e = el(d.width)) && !(e >= b) && d.overflow !== "visible") {
                        c = !0;
                        break a
                    }
                }
                c = !1
            }
            a = c ? 7 : !0
        }
        return a
    }

    function BS(a, b, c, d) {
        var e = AS(b, c, a, V(Jv), d);
        e !== !0 ? a = e : d.google_full_width_responsive === "true" || TJ(c, b) ? (b = ks(b), a = b - a, a = b && a >= 0 ? !0 : b ? a < -10 ? 11 : a < 0 ? 14 : 12 : 10) : a = 9;
        return a
    }

    function CS(a, b, c) {
        a = a.style;
        b === "rtl" ? a.marginRight = c : a.marginLeft = c
    }

    function DS(a, b) {
        if (b.nodeType === 3) return /\S/.test(b.data);
        if (b.nodeType === 1) {
            if (/^(script|style)$/i.test(b.nodeName)) return !1;
            let c;
            try {
                c = al(b, a)
            } catch (d) {}
            return !c || c.display !== "none" && !(c.position === "absolute" && (c.visibility === "hidden" || c.visibility === "collapse"))
        }
        return !1
    }

    function ES(a, b, c) {
        a = VJ(b, a);
        return c === "rtl" ? -a.x : a.x
    }

    function FS(a, b) {
        b = b.parentElement;
        return b ? (a = al(b, a)) ? a.direction : "" : ""
    }

    function GS(a, b, c) {
        if (ES(a, b, c) !== 0) {
            CS(b, c, "0px");
            var d = ES(a, b, c);
            CS(b, c, `${-1*d}px`);
            a = ES(a, b, c);
            a !== 0 && a !== d && CS(b, c, `${d/(a-d)*d}px`)
        }
    }

    function HS(a, b) {
        var c = FS(a, b);
        if (c) {
            var d = b.style;
            d.border = d.borderStyle = d.outline = d.outlineStyle = d.transition = "none";
            d.borderSpacing = d.padding = "0";
            CS(b, c, "0px");
            d.width = `${ks(a)}px`;
            GS(a, b, c);
            d.zIndex = "30"
        }
    };
    const IS = !tb && !Va();

    function JS(a) {
        if (/-[a-z]/.test("adFormat")) return null;
        if (IS && a.dataset) {
            if (!(!Ra("Android") || Za() || Ua() || Ta() || Ra("Silk") || "adFormat" in a.dataset)) return null;
            a = a.dataset.adFormat;
            return a === void 0 ? null : a
        }
        return a.getAttribute("data-" + "adFormat".replace(/([A-Z])/g, "-$1").toLowerCase())
    };

    function KS(a, b, c) {
        if (!b) return null;
        var d = $k("INS");
        d.id = "google_pedestal_container";
        d.style.width = "100%";
        d.style.zIndex = "-1";
        if (c) {
            var e = a.getComputedStyle(c),
                f = "";
            if (e && e.position !== "static") {
                var g = c.parentNode.lastElementChild;
                for (f = e.position; g && g !== c;) {
                    if (a.getComputedStyle(g).display !== "none") {
                        f = a.getComputedStyle(g).position;
                        break
                    }
                    g = g.previousElementSibling
                }
            }
            if (c = f) d.style.position = c
        }
        b.appendChild(d);
        if (d) {
            var h = a.document;
            f = h.createElement("div");
            f.style.width = "100%";
            f.style.height = "2000px";
            c = ls(a);
            e = h.body.scrollHeight;
            a = a.innerHeight;
            g = h.body.getBoundingClientRect().bottom;
            d.appendChild(f);
            var k = f.getBoundingClientRect().top;
            h = h.body.getBoundingClientRect().top;
            d.removeChild(f);
            f = e;
            e <= a && c > 0 && g > 0 && (f = g - h);
            a = k - h >= .8 * f
        } else a = !1;
        return a ? d : (b.removeChild(d), null)
    }

    function LS(a) {
        var b = a.document.body,
            c = KS(a, b, null);
        if (c) return c;
        if (a.document.body) {
            c = Math.floor(a.document.body.getBoundingClientRect().width);
            for (var d = [{
                    element: a.document.body,
                    depth: 0,
                    height: 0
                }], e = -1, f = null; d.length > 0;) {
                let h = d.pop(),
                    k = h.element;
                var g = h.height;
                h.depth > 0 && g > e && (e = g, f = k);
                if (h.depth < 5)
                    for (g = 0; g < k.children.length; g++) {
                        let l = k.children[g],
                            m = l.getBoundingClientRect().width;
                        (m == null || c == null ? 0 : m >= c * .9 && m <= c * 1.01) && d.push({
                            element: l,
                            depth: h.depth + 1,
                            height: l.getBoundingClientRect().height
                        })
                    }
            }
            c =
                f
        } else c = null;
        return c ? KS(a, c.parentNode || b, c) : null
    }

    function MS(a) {
        var b = 0;
        try {
            b |= js(a), Nk() || (b |= 1048576), Math.floor(a.document.body.getBoundingClientRect().width) <= 1200 || (b |= 32768), NS(a) && (b |= 33554432)
        } catch (c) {
            b |= 32
        }
        return b
    }

    function NS(a) {
        a = a.document.getElementsByClassName("adsbygoogle");
        for (let b = 0; b < a.length; b++)
            if (JS(a[b]) === "autorelaxed") return !0;
        return !1
    };

    function OS(a) {
        var b = os(a, !0),
            c = ps(a).scrollWidth,
            d = ps(a).scrollHeight,
            e = "unknown";
        a && a.document && a.document.readyState && (e = a.document.readyState);
        var f = ts(a),
            g = [],
            h = [],
            k = [],
            l = [],
            m = [],
            n = [],
            p = [],
            q = 0,
            u = 0,
            w = Infinity,
            B = Infinity,
            G = null,
            K = UA({
                Bd: !1
            }, a);
        for (var H of K) {
            K = H.getBoundingClientRect();
            let da = b - (K.bottom + f);
            var L = void 0,
                S = void 0;
            if (H.className && H.className.indexOf("adsbygoogle-ablated-ad-slot") != -1) {
                L = H.getAttribute("google_element_uid");
                let Ea;
                if (S = a.fqjyf) {
                    if (L && S[L] && (Ea = S[L].LmpfC), !Ea) continue
                } else continue;
                L = (S = Ar(Ea)) ? S.height : 0;
                S = S ? S.width : 0
            } else if (L = K.bottom - K.top, S = K.right - K.left, L <= 1 || S <= 1) continue;
            g.push(L);
            k.push(S);
            l.push(L * S);
            cB(H) ? (u += 1, H.className && H.className.indexOf("pedestal_container") != -1 && (G = L)) : (w = Math.min(w, da), n.push(K), q += 1, h.push(L), m.push(L * S));
            B = Math.min(B, da);
            p.push(K)
        }
        w = w === Infinity ? null : w;
        B = B === Infinity ? null : B;
        f = PS(n);
        p = PS(p);
        h = QS(b, h);
        n = QS(b, g);
        m = QS(b * c, m);
        H = QS(b * c, l);
        return new RS(a, {
            Ql: e,
            ci: b,
            dn: c,
            cn: d,
            Im: q,
            fl: u,
            jl: SS(g),
            kl: SS(k),
            il: SS(l),
            Rm: f,
            Qm: p,
            Pm: w,
            Om: B,
            Qg: h,
            Pg: n,
            dl: m,
            bl: H,
            fn: G
        })
    }

    function TS(a, b, c, d) {
        var e = Nk() && !(ks(a.win) >= 900);
        d = cb(d, f => hb(a.j, f)).join(",");
        b = {
            wpc: b,
            su: c,
            eid: d,
            doc: a.g.Ql ? ? null,
            pg_h: US(a.g.ci),
            pg_w: US(a.g.dn),
            pg_hs: US(a.g.cn),
            c: US(a.g.Im),
            aa_c: US(a.g.fl),
            av_h: US(a.g.jl),
            av_w: US(a.g.kl),
            av_a: US(a.g.il),
            s: US(a.g.Rm),
            all_s: US(a.g.Qm),
            b: US(a.g.Pm),
            all_b: US(a.g.Om),
            d: US(a.g.Qg),
            all_d: US(a.g.Pg),
            ard: US(a.g.dl),
            all_ard: US(a.g.bl),
            pd_h: US(a.g.fn),
            dt: e ? "m" : "d"
        };
        c = {};
        for (let f of Object.keys(b)) b[f] !== null && (c[f] = b[f]);
        return c
    }
    var RS = class {
        constructor(a, b) {
            this.j = [];
            this.win = a;
            this.g = b
        }
    };

    function SS(a) {
        return ui.apply(null, cb(a, b => b > 0)) || null
    }

    function QS(a, b) {
        return a <= 0 ? null : ti.apply(null, b) / a
    }

    function PS(a) {
        var b = Infinity;
        for (let e = 0; e < a.length - 1; e++)
            for (let f = e + 1; f < a.length; f++) {
                var c = a[e],
                    d = a[f];
                c = Math.max(Math.max(0, c.left - d.right, d.left - c.right), Math.max(0, c.top - d.bottom, d.top - c.bottom));
                c > 0 && (b = Math.min(c, b))
            }
        return b !== Infinity ? b : null
    }

    function US(a) {
        return a == null ? null : Number.isInteger(a) ? a.toString() : a.toFixed(3)
    };

    function VS(a) {
        var b = FM({
            Bd: !1,
            Bf: !1
        }, a);
        a = (ls(a) || 0) - ts(a);
        var c = 0;
        for (let d = 0; d < b.length; d++) {
            let e = b[d].getBoundingClientRect();
            LM(e) && e.top <= a && (c += 1)
        }
        return c > 0
    }

    function WS(a) {
        var b = {},
            c = FM({
                Bd: !1,
                Bf: !1,
                zh: !1,
                Ah: !1
            }, a).map(d => d.getBoundingClientRect()).filter(LM);
        b.Li = c.length;
        c = GM({
            zh: !0
        }, a).map(d => d.getBoundingClientRect()).filter(LM);
        b.lj = c.length;
        c = GM({
            Ah: !0
        }, a).map(d => d.getBoundingClientRect()).filter(LM);
        b.Sj = c.length;
        c = GM({
            Bf: !0
        }, a).map(d => d.getBoundingClientRect()).filter(LM);
        b.Pi = c.length;
        c = (ls(a) || 0) - ts(a);
        c = FM({
            Bd: !1
        }, a).map(d => d.getBoundingClientRect()).filter(LM).filter(za(XS, null, c));
        b.Mi = c.length;
        a = OS(a);
        c = a.g.Qg != null ? a.g.Qg : null;
        c != null &&
            (b.Jj = c);
        a = a.g.Pg != null ? a.g.Pg : null;
        a != null && (b.Ni = a);
        return b
    }

    function OQ(a, b, {
        Jf: c,
        qg: d,
        Eg: e
    } = {}) {
        return gL(997, () => YS(a, b, {
            Jf: c,
            qg: d,
            Eg: e
        }), a.g)
    }

    function PQ(a, b, c, d) {
        var e = c.Bc ? c.Bc : a.D,
            f = yM(e, b.g.length);
        e = a.A.Oi ? e.g : void 0;
        var g = sR(tR(pR(rR(qR(oR(mR(nR(kR(lR(iR(c.types), a.Ba), c.ki || []), a.la), c.xn || [])), f.ve || void 0, e, b), c.minWidth, c.maxWidth)), f.Uc || void 0));
        a.Z && g.g.push(new XQ(a.Z));
        b = 1;
        a.Qc() && (b = 3);
        uR(g, b);
        a.A.sk && (g.B = !0);
        return gL(995, () => oS(a.j, g.build(), d, a.C || void 0), a.g)
    }

    function QQ(a, b) {
        var c = LS(a.g);
        if (c) {
            let d = cv(a.W, b),
                e = aK(a.g.document, a.G, null, null, {}, d);
            e && (QJ(e.td, c, 2, 256), gL(996, () => ZS(a, e, d), a.g))
        }
    }

    function $S(a) {
        return a.J ? a.J : a.J = a.g.google_ama_state
    }

    function YS(a, b, {
        Jf: c,
        qg: d,
        Eg: e
    } = {}) {
        var f = b.va;
        if (f.B) return !1;
        var g = b.ya(),
            h = f.j();
        if (!sS(a.g, h, g, a.l)) return !1;
        h = null;
        f.Ed ? .includes(6) ? (h = Math.round(g.getBoundingClientRect().height), h = new dv(null, {
            google_max_responsive_height: c == null ? h : Math.min(c, h),
            google_full_width_responsive: "false"
        })) : h = c == null ? null : new dv(null, {
            google_max_responsive_height: c
        });
        c = ev(rf(f.ag, 2) || 0);
        g = fv(f.D);
        var k = aT(a, f),
            l = bT(a),
            m = cv(a.W, f.W ? f.W.g(b.Fa) : null, h, d || null, c, g, k, l),
            n = b.fill(a.G, m);
        if (e && !cT(a, n, m) || !gL(996, () =>
                ZS(a, n, m), a.g)) return !1;
        Kl(9, [f.D, f.Fd]);
        a.Qc() && $R(dr(dS), b);
        return !0
    }

    function aT(a, b) {
        return Ku(Ou($L(b).map(gv), () => {
            a.B.push(18)
        }))
    }

    function bT(a) {
        if (!a.Qc()) return null;
        var b = a.j.g.g ? .C();
        if (b == null) return null;
        b = b.join("~");
        a = a.j.g.g ? .A() ? ? null;
        return hv({
            Hl: b,
            Yl: a
        })
    }

    function cT(a, b, c) {
        if (!b) return !1;
        var d = b.Hb,
            e = d.style.width;
        d.style.width = "100%";
        var f = d.offsetWidth;
        d.style.width = e;
        if (BS(f, a.g, b.Hb, c && c.oe() || {})) return HS(a.g, b.Hb), !0;
        NJ(b.td);
        return !1
    }

    function ZS(a, b, c) {
        if (!b) return !1;
        try {
            eK(a.g, b.Hb, c)
        } catch (d) {
            return NJ(b.td), a.B.push(6), !1
        }
        return !0
    }
    var dT = class {
        constructor(a, b, c, d, e = {}, f = [], g = !1) {
            this.j = a;
            this.G = b;
            this.g = c;
            this.D = d.Bc;
            this.Ba = d.je || [];
            this.W = d.am || null;
            this.la = d.Pl || [];
            this.Z = d.rg || [];
            this.A = e;
            this.l = !1;
            this.O = [];
            this.B = [];
            this.P = this.J = void 0;
            this.Me = f;
            this.C = g ? new zQ : null
        }
        ua() {
            return this.g
        }
        Qc() {
            if ((this.j.g.g ? .B().length ? ? 0) == 0) return !1;
            if (this.P === void 0) {
                let a = uR(pR(oR(iR([0, 1, 2]))), 1).build(),
                    b = gL(995, () => oS(this.j, a), this.g);
                this.P = this.j.g.g ? .P(b) || !1
            }
            return this.P
        }
        Hh() {
            return !!this.A.mk
        }
        Ef() {
            return !NS(this.g)
        }
        Gb() {
            return this.C
        }
    };
    const XS = (a, b) => b.top <= a;

    function eT(a, b, c, d, e, f = 0, g = 0) {
        this.kc = a;
        this.Sf = f;
        this.Rf = g;
        this.errors = b;
        this.gd = c;
        this.g = d;
        this.j = e
    };
    var fT = (a, {
        Ef: b = !1,
        Hh: c = !1,
        zn: d = !1,
        Qc: e = !1
    } = {}) => {
        var f = [];
        d && f.push(9);
        if (e) {
            a.includes(4) && !c && b && f.push(8);
            a.includes(1) && f.push(1);
            d = a.includes(3);
            e = a.includes(2);
            let g = a.includes(1);
            (d || e || g) && f.push(10)
        } else a.includes(3) && f.push(6), a.includes(4) && !c && b && f.push(8), a.includes(1) && f.push(1, 5), a.includes(2) && f.push(7);
        a.includes(4) && c && b && f.push(8);
        return f
    };

    function gT(a, b, c) {
        a = fT(a, {
            Ef: b.Ef(),
            Hh: b.Hh(),
            zn: !!b.A.oh,
            Qc: b.Qc()
        });
        return new hT(a, b, c)
    }

    function iT(a, b) {
        var c = LQ[b];
        return c ? gL(998, () => c(a.g), a.A) : (a.g.O.push(12), !0)
    }

    function jT(a, b) {
        return new Promise(c => {
            setTimeout(() => {
                c(iT(a, b))
            })
        })
    }

    function kT(a) {
        a.g.l = !0;
        return Promise.all(a.j.map(b => jT(a, b))).then(b => {
            b.includes(!1) && a.g.O.push(5);
            a.j.splice(0, a.j.length)
        })
    }
    var hT = class {
        constructor(a, b, c) {
            this.B = a.slice(0);
            this.j = a.slice(0);
            this.l = ib(this.j, 1);
            this.g = b;
            this.A = c
        }
    };
    var lT = class {
        constructor(a) {
            this.g = a;
            this.exception = void 0
        }
    };

    function mT(a) {
        return kT(a).then(() => {
            var b = a.g.j.j.filter(yL).g.length;
            var c = a.g.O.slice(0);
            var d = a.g;
            d = [...d.B, ...(d.j.g.g ? .D() || [])];
            b = new eT(b, c, d, a.g.j.j.g.length, a.g.j.B.g, a.g.j.j.filter(yL).filter(zL).g.length, a.g.j.j.filter(zL).g.length);
            return new lT(b)
        })
    };
    var nT = class {
        g() {
            return new dv([], {
                google_reactive_ad_format: 40,
                google_tag_origin: "qs"
            })
        }
    };
    var oT = class {
        g() {
            return new dv(["adsbygoogle-resurrected-ad-slot"], {})
        }
    };

    function pT(a) {
        return KJ(a.g.document).map(b => {
            var c = new rL(b, 3);
            b = gK(b, a.g.fqjyf ? ? {}) ? .LmpfC;
            return new xL(c, new tL(b), a.j, !1, 0, [], null, a.g, null)
        })
    }
    var qT = class {
        constructor(a) {
            var b = new oT;
            this.g = a;
            this.j = b || null
        }
    };
    const rT = {
        Ci: "10px",
        Cg: "10px"
    };

    function sT(a) {
        return zs(a.g.document.querySelectorAll("INS.adsbygoogle-placeholder")).map(b => new xL(new rL(b, 1), new pL(rT), a.j, !1, 0, [], null, a.g, null))
    }
    var tT = class {
        constructor(a, b) {
            this.g = a;
            this.j = b || null
        }
    };

    function uT(a, b) {
        var c = [];
        b.forEach((d, e) => {
            c.push(ja(e, "replaceAll").call(e, "~", "_") + "--" + d.map(f => Number(f)).join("_"))
        });
        JR(a.g, "cnstr", c, 80)
    }
    var vT = class extends ER {
        constructor() {
            super(-1);
            this.g = {}
        }
        getData(a) {
            a = super.getData(a);
            Object.assign(a, this.g);
            return a
        }
    };
    var wT = class extends Error {
        constructor(a, b, c) {
            super(a);
            this.g = b;
            this.field = c
        }
    };

    function xT(a, b, c) {
        return a == null ? new wT(b + "ShouldNotBeNull", 2, c) : a == 0 ? new wT(b + "ShouldNotBeZero", 3, c) : a < -1 ? new wT(b + "ShouldNotBeLessMinusOne", 4, c) : null
    }

    function yT(a, b, c) {
        var d = xT(c.ne, "gapsMeasurementWindow", 1) || xT(c.xd, "gapsPerMeasurementWindow", 2) || xT(c.Id, "maxGapsToReport", 3);
        return d != null ? Hu(d) : c.ug || c.xd != -1 || c.Id != -1 ? Fu(new zT(a, b, c)) : Hu(new wT("ShouldHaveLimits", 1, 0))
    }

    function AT(a) {
        return $S(a.l) && $S(a.l).placed || []
    }

    function BT(a) {
        return AT(a).map(b => su(qu(b.element, a.g)))
    }

    function CT(a) {
        return AT(a).map(b => b.index)
    }

    function DT(a, b) {
        var c = b.va;
        return !a.C && c.l && fd(ue(c.l, 8)) != null && rf(c.l, 8) == 1 ? [] : c.B ? (c.J || []).map(d => su(qu(d, a.g))) : [su(new ru(b.Fa.g, 0))]
    }

    function ET(a) {
        a.sort((e, f) => e.g - f.g);
        var b = [],
            c = 0;
        for (let e = 0; e < a.length; ++e) {
            var d = a[e];
            let f = d.g;
            d = d.g + d.j;
            f <= c ? c = Math.max(c, d) : (b.push(new ru(c, f - c)), c = d)
        }
        return b
    }

    function FT(a, b) {
        b = b.map(c => {
            var d = new wn;
            d = uf(d, 1, c.g);
            c = c.getHeight();
            return uf(d, 2, c)
        });
        return yn(xn(new zn, a), b)
    }

    function GT(a) {
        var b = Ve(a, wn, 2, De()).map(c => `G${gf(c,1)}~${c.getHeight()}`);
        return `W${gf(a,1)}${b.join("")}`
    }

    function HT(a, b) {
        var c = [],
            d = 0;
        for (let e of Cs(b)) {
            let f = b.get(e);
            f.sort((g, h) => h.getHeight() - g.getHeight());
            a.G || f.splice(a.A, f.length);
            !a.D && d + f.length > a.j && f.splice(a.j - d, f.length);
            c.push(FT(e, f));
            d += f.length;
            if (!a.D && d >= a.j) break
        }
        return c
    }

    function IT(a) {
        var b = Ve(a, zn, 5, De()).map(c => GT(c));
        return `M${gf(a,1)}H${gf(a,2)}C${gf(a,3)}B${Number(!!C(a,4))}${b.join("")}`
    }

    function JT(a) {
        var b = eM(Cu(a.l.j.j), a.g),
            c = BT(a),
            d = new Fs(CT(a));
        for (var e = 0; e < b.length; ++e) {
            if (d.contains(e)) continue;
            var f = DT(a, b[e]);
            c.push(...f)
        }
        c.push(new ru(0, 0));
        c.push(su(new ru(ps(a.g).scrollHeight, 0)));
        b = ET(c);
        c = new Es;
        for (d = 0; d < b.length; ++d) e = b[d], f = a.O ? 0 : Math.floor(e.g / a.B), As(c, f) || c.set(f, []), c.get(f).push(e);
        b = HT(a, c);
        c = new An;
        c = uf(c, 1, a.j);
        c = uf(c, 2, a.B);
        c = uf(c, 3, a.A);
        a = sf(c, 4, a.C);
        return Xe(a, 5, b)
    }

    function KT(a) {
        a = JT(a);
        return IT(a)
    }
    var zT = class {
        constructor(a, b, c) {
            this.O = c.ne == -1;
            this.B = c.ne;
            this.G = c.xd == -1;
            this.A = c.xd;
            this.D = c.Id == -1;
            this.j = c.Id;
            this.C = c.yh;
            this.l = b;
            this.g = a
        }
    };

    function zJ(a, b, c) {
        var d = b.ac;
        b.Pc && U(rw) && (d = 1, "r" in c && (c.r += "F"));
        d <= 0 || (!b.qc || "pvc" in c || (c.pvc = ul(a.g)), zB(b.Lc, c, d))
    }

    function LT(a, b, c) {
        c = c.getData(a.g);
        b.qc && (c.pvc = ul(a.g));
        0 <= b.ac && (c.r = b.ac, zJ(a, b, c))
    }
    var MT = class {
        constructor(a) {
            this.g = a
        }
    };
    const NT = {
        google_ad_channel: !0,
        google_ad_host: !0
    };

    function OT(a, b) {
        a.location.href && a.location.href.substring && (b.url = a.location.href.substring(0, 200));
        zB("ama", b, .01)
    }

    function PT(a) {
        var b = {};
        Fk(NT, (c, d) => {
            a.hasOwnProperty(d) && (b[d] = a[d])
        });
        return b
    };

    function QT(a) {
        var b = /[a-zA-Z0-9._~-]/,
            c = /%[89a-zA-Z]./;
        return a.replace(/(%[a-zA-Z0-9]{2})/g, d => {
            if (!d.match(c)) {
                let e = decodeURIComponent(d);
                if (e.match(b)) return e
            }
            return d.toUpperCase()
        })
    }

    function RT(a) {
        var b = "",
            c = /[/%?&=]/;
        for (let d = 0; d < a.length; ++d) {
            let e = a[d];
            b = e.match(c) ? b + e : b + encodeURIComponent(e)
        }
        return b
    };

    function ST(a, b) {
        a = nf(a, 2);
        if (!a) return !1;
        for (let c = 0; c < a.length; c++)
            if (a[c] == b) return !0;
        return !1
    }

    function TT(a, b) {
        a = RT(QT(a.location.pathname)).replace(/(^\/)|(\/$)/g, "");
        var c = Uu(a),
            d = UT(a);
        return b.find(e => {
            if (ye(e, tK, 7)) {
                var f = y(e, tK, 7);
                f = jd(ue(f, 1, void 0, te))
            } else f = jd(ue(e, 1, void 0, te));
            ye(e, tK, 7) ? (e = y(e, tK, 7), e = rf(e, 2)) : e = 2;
            if (!oc(f)) return !1;
            switch (e) {
                case 1:
                    return f == c;
                case 2:
                    return d[f] || !1
            }
            return !1
        }) || null
    }

    function UT(a) {
        for (var b = {};;) {
            b[Uu(a)] = !0;
            if (!a) return b;
            a = a.substring(0, a.lastIndexOf("/"))
        }
    };

    function VT(a, b) {
        try {
            b.removeItem("google_ama_config")
        } catch (c) {
            OT(a, {
                lserr: 1
            })
        }
    };
    var XT = (a, b, c, d, e, f = null, g = null) => {
            WT(a, new MT(a), b, c, d, e, f, g)
        },
        WT = (a, b, c, d, e, f, g = null, h = null) => {
            if (c)
                if (d) {
                    var k = hO(d, e);
                    try {
                        let l = new YT(a, b, c, d, e, k, f, g, h);
                        Nf(d, 35) && c !== qf(d, 35) ? YB(HB(), qg(wo(xo(new yo, qf(d, 35)), c))) : gL(990, () => ZT(l), a)
                    } catch (l) {
                        Jl() && Kl(15, [l]), LT(b, sJ, DR(BR(AR(GR(FR(new HR(0), d), k), c), 1), l)), RB(HB(), jo(new so, tn(1)))
                    }
                } else LT(b, sJ, BR(AR(new HR(0), c), 8)), RB(HB(), jo(new so, tn(8)));
            else LT(b, sJ, BR(new HR(0), 9)), RB(HB(), jo(new so, tn(9)))
        };

    function ZT(a) {
        a.J.forEach(b => {
            switch (b) {
                case 0:
                    gL(991, () => $T(a), a.g);
                    break;
                case 1:
                    gL(1073, () => {
                        aO(new gO(a.g, a.C, a.B, a.A, a.j.ja))
                    }, a.g);
                    break;
                case 3:
                    gL(1663, () => {
                        CN(new GN(a.g, a.C, a.B, a.A, a.j.ja))
                    }, a.g);
                    break;
                case 2:
                    aU(a);
                    break;
                case 4:
                    gL(1680, () => {
                        var c = y(a.B, SK, 38);
                        c && a.Ba.runVideoFeed({
                            win: a.g,
                            Un: oe(c),
                            webPropertyCode: a.A
                        })
                    }, a.g)
            }
        })
    }

    function $T(a) {
        var b = U(aw) ? void 0 : a.j.jn,
            c = null;
        c = U(aw) ? wM(a.g) : uM(a.g, b);
        if (a.j.ja && ye(a.j.ja, sK, 10)) {
            var d = rK(a.j.ja.g());
            d !== null && d !== void 0 && (c = kM(a.g, d, b));
            U(ww) && (b = a.j.ja.g(), b ? .g() === 2 && (c = mM(b, c)))
        }
        ye(a.B, oK, 26) && (c = zM(c, y(a.B, oK, 26), a.g));
        c = BM(c, a.g);
        b = a.j.ja ? nf(a.j.ja, 6) : [];
        d = a.j.ja ? Ve(a.j.ja, xK, 5, De()) : [];
        var e = a.j.ja ? nf(a.j.ja, 2) : [],
            f = gL(993, () => {
                var g = a.B,
                    h = UK(g),
                    k = a.j.ja && ST(a.j.ja, 1) ? "text_image" : "text",
                    l = new nT,
                    m = wL(h, a.g, {
                        ll: l,
                        ym: new uL(k)
                    });
                h.length != m.length && a.G.push(13);
                m = m.concat(sT(new tT(a.g,
                    l)));
                h = U(sw);
                l = y(g, RK, 24) ? .j() ? .g() ? .g() || !1;
                if (h || l) h = pT(new qT(a.g)), l = dr(dS), m = m.concat(h), l.W = !0, l.D = h.length, a.O === "n" && (a.O = y(g, RK, 24) ? .g() ? .length ? "o" : "p");
                h = U(ww) && a.j.ja.g() ? .g() === 2 && a.j.ja.g() ? .j();
                h = U(Vv) || h;
                a: {
                    if (l = y(g, IJ, 6))
                        for (n of l.g())
                            if (ye(n, Su, 4)) {
                                var n = !0;
                                break a
                            }
                    n = !1
                }
                h && n ? (n = m.concat, h = a.g, (l = y(g, IJ, 6)) ? (h = XL(l.g(), h), k = vQ(g, k, h)) : k = [], k = n.call(m, k)) : (n = m.concat, h = a.g, (l = y(g, IJ, 6)) ? (h = WL(l.g(), h), k = vQ(g, k, h)) : k = [], k = n.call(m, k));
                m = k;
                g = y(g, RK, 24);
                return new rS(m, a.g, g)
            }, a.g);
        a.l = new dT(f, a.A, a.g, {
            Bc: c,
            am: a.W,
            je: a.j.je,
            Pl: b,
            rg: d
        }, bU(a), e, U(rw));
        $S(a.l) ? .optimization ? .ablatingThisPageview && !a.l.Qc() && (fK(a.g), dr(dS).C = !0, a.O = "f");
        a.D = gT(e, a.l, a.g);
        gL(992, () => mT(a.D), a.g).then(gL(994, () => a.la.bind(a), a.g), a.Z.bind(a))
    }

    function aU(a) {
        var b = y(a.B, IK, 18);
        b && IP(new JP(a.g, new uQ(a.g, a.A), b, new ED(a.g), UK(a.B)))
    }

    function bU(a) {
        var b = U(uw);
        if (!a.B.g()) return {
            sk: b,
            nj: !1,
            mk: !1,
            gn: 0,
            dk: 0,
            Oi: cU(a),
            oh: a.P
        };
        var c = a.B.g();
        return {
            sk: b || C(c, 14),
            nj: C(c, 5),
            mk: C(c, 6),
            gn: jf(c, 8),
            dk: rf(c, 10),
            Oi: cU(a),
            oh: a.P
        }
    }

    function cU(a) {
        return U(lw) || U(ww) && a.j.ja ? .g() ? .g() === 2 ? !1 : a.j.ja && ye(a.j.ja, sK, 10) ? (rK(a.j.ja.g()) || 0) >= .5 : !0
    }

    function dU(a, b) {
        var c = new HR(b.kc);
        c.g.pp = b.Rf;
        c.g.ppp = b.Sf;
        c.g.ppos = b.placementPositionDiffs;
        c.g.eatf = b.de;
        c.g.eatfAbg = b.ee;
        c.g.reatf = b.yd;
        c.g.a = a.D.B.slice(0).join(",");
        c = GR(FR(c, a.B), a.J);
        var d = b.xb;
        d && (c.g.as_count = d.Li, c.g.d_count = d.lj, c.g.ng_count = d.Sj, c.g.am_count = d.Pi, c.g.atf_count = d.Mi, c.g.mdns = IR(d.Jj), c.g.alldns = IR(d.Ni));
        d = b.Od;
        d != null && (c.g.allp = d);
        if (d = b.sf) {
            var e = [];
            for (var f of Cs(d))
                if (d.get(f).length > 0) {
                    var g = d.get(f)[0];
                    e.push("(" + [f, g.qb, g.zk].join() + ")")
                }
            c.g.fd = e.join(",")
        }
        f =
            b.ci;
        f != null && (c.g.pgh = f);
        c.g.abl = b.xj;
        c.g.rr = a.O;
        a = CR(CR(AR(c, a.A), b.errors), a.G);
        c = b.gd;
        for (e = 0; e < c.length; e++) a: {
            f = a;d = c[e];
            for (g = 0; g < f.A.length; g++)
                if (f.A[g] == d) break a;f.A.push(d)
        }
        b.exception !== void 0 && BR(DR(a, b.exception), 1);
        return a
    }

    function eU(a, b) {
        var c = dU(a, b);
        LT(a.C, b.errors.length > 0 || a.G.length > 0 || b.exception !== void 0 ? sJ : rJ, c);
        if (y(a.B, RK, 24)) {
            a.l.j.g.g ? .G();
            b = $S(a.l);
            let d = dr(dS);
            d.l = !!b ? .optimization ? .ablationFromStorage;
            b ? .optimization ? .ablatingThisPageview && (d.O = !0);
            d.Z = !!b ? .optimization ? .availableAbg;
            b = dr(dS);
            c = new UR(c);
            b.A ? (c.j.sl = KR(b.A ? ? []), c.j.daaos = KR(b.J ? ? []), c.j.ab = LR(b.O), c.j.rr = LR(b.W), c.j.oab = LR(b.G), b.l != null && (c.j.sab = LR(b.l)), b.C && (c.j.fb = LR(b.C)), c.j.ls = LR(b.Z), MR(c, b.j.Mc()), b.D != null && (c.j.rp = LR(b.D)),
                b.B != null && (c.j.expl = LR(b.B)), cS(b, c)) : c.errors.push("irr");
            LT(a.C, uJ, c)
        }
        c = a.l ? .Gb();
        U(rw) && c != null && (c = new Map([...c.l.map.entries()].map(xQ)), b = new vT, uT(b, c), LT(a.C, xJ, b))
    }

    function fU(a, b) {
        if (U(ew) && a.l != null) {
            var c = yT(a.g, a.l, {
                ne: V(qw),
                xd: V(pw),
                Id: V(hw),
                yh: !0,
                ug: !1
            });
            if (Ju(c)) a = new Dn, c = JT(c.getValue()), a = A(a, 2, Cn, c), z(b, 16, a);
            else {
                var d = c.g;
                a = new Dn;
                c = a.setError;
                var e = new Bn;
                e = Lf(e, 2, d.field);
                d = Lf(e, 1, d.g);
                a = c.call(a, d);
                z(b, 16, a)
            }
        }
    }

    function gU(a, b) {
        var c = HB();
        if (c.g) {
            var d = new so,
                e = b.gd.filter(g => g !== null),
                f = a.G.concat(b.errors, b.exception ? [1] : []).filter(g => g !== null);
            oo(lo(ro(qo(po(no(mo(go(io(ko(ho(d, a.D.B.slice(0).map(g => {
                var h = new sn;
                return Lf(h, 1, g)
            })), e.map(g => {
                var h = new vn;
                return Lf(h, 1, g)
            })), f.map(g => tn(g))), y(a.B, CK, 23) ? .g()), b.kc), b.Od), b.yd), b.de), b.ee), a.J.map(g => g.toString())), Kn(Jn(In(Hn(Gn(Fn(En(new Ln, b.xb ? .Li), b.xb ? .lj), b.xb ? .Sj), b.xb ? .Pi), b.xb ? .Mi), b.xb ? .Jj), b.xb ? .Ni));
            if (b.sf)
                for (let g of Cs(b.sf)) {
                    e = new Qn;
                    for (let h of b.sf.get(g)) Pn(e, Nn(Mn(new On, h.qb), h.zk));
                    Le(d, 14, Qn).set(g.toString(), e)
                }
            y(a.B, RK, 24) && eo(d);
            fU(a, d);
            RB(c, d)
        }
    }

    function hU(a, b, c) {
        {
            var d = $S(a.l),
                e = b.g;
            let f = e.g,
                g = e.Rf,
                h = e.kc,
                k = e.Sf,
                l = e.errors.slice(),
                m = e.gd.slice(),
                n = b.exception,
                p = eB(a.g).had_ads_ablation ? ? !1;
            d ? (d.numAutoAdsPlaced ? h += d.numAutoAdsPlaced : a.D.l && m.push(13), d.exception !== void 0 && (n = d.exception), d.numPostPlacementsPlaced && (k += d.numPostPlacementsPlaced), c = {
                kc: h,
                Rf: g,
                Sf: k,
                Od: f,
                errors: e.errors.slice(),
                gd: m,
                exception: n,
                yd: c,
                de: !!d.eatf,
                ee: !!d.eatfAbg,
                xj: p
            }) : (m.push(12), a.D.l && m.push(13), c = {
                kc: h,
                Rf: g,
                Sf: k,
                Od: f,
                errors: l,
                gd: m,
                exception: n,
                yd: c,
                de: !1,
                ee: !1,
                xj: p
            })
        }
        c.xb = WS(a.l.g);
        if (b = b.g.j) c.sf = b;
        c.ci = ps(a.g).scrollHeight;
        if (Jl() || y(a.B, BK, 25) ? .B()) {
            a.l.ua();
            d = Cu(a.l.j.j);
            b = [];
            for (let f of d) {
                d = {};
                e = f.P;
                for (let g of Cs(e)) d[g] = e.get(g);
                d = {
                    anchorElement: f.O.g(f.g),
                    position: f.j(),
                    clearBoth: f.G,
                    locationType: f.Fd,
                    placed: f.B,
                    placementProto: f.l ? Zd(f.l) : null,
                    articleStructure: f.A ? Zd(f.A) : null,
                    rejectionReasons: d
                };
                b.push(d)
            }
            Kl(14, [{
                placementIdentifiers: b
            }, a.l.G, c.xb])
        }
        return c
    }

    function iU(a, b) {
        var c = a.l.g;
        c = c.googleSimulationState = c.googleSimulationState || {};
        c.amaConfigPlacementCount = b.Od;
        c.numAutoAdsPlaced = b.kc;
        c.hasAtfAd = b.yd;
        b.exception !== void 0 && (c.exception = b.exception);
        if (a.l != null)
            if (a = yT(a.g, a.l, {
                    ne: -1,
                    xd: -1,
                    Id: -1,
                    yh: !0,
                    ug: !0
                }), Ju(a)) c.placementPositionDiffs = KT(a.getValue()), b = JT(a.getValue()), a = new Dn, a = A(a, 2, Cn, b), c.placementPositionDiffsReport = pg(a);
            else {
                c.placementPositionDiffs = "E" + a.g.message;
                var d = a.g;
                a = new Dn;
                b = a.setError;
                var e = new Bn;
                e = Lf(e, 2, d.field);
                d =
                    Lf(e, 1, d.g);
                a = b.call(a, d);
                c.placementPositionDiffsReport = pg(a)
            }
    }

    function jU(a, b) {
        eU(a, {
            kc: 0,
            Od: void 0,
            errors: [],
            gd: [],
            exception: b,
            yd: void 0,
            de: void 0,
            ee: void 0,
            xb: void 0
        });
        gU(a, {
            kc: 0,
            Od: void 0,
            errors: [],
            gd: [],
            exception: b,
            yd: void 0,
            de: void 0,
            ee: void 0,
            xb: void 0
        })
    }
    var YT = class {
        constructor(a, b, c, d, e, f, g, h, k) {
            this.g = a;
            this.C = b;
            this.A = c;
            this.B = d;
            this.j = e;
            this.J = f;
            this.Ba = g;
            this.W = h || null;
            this.G = [];
            this.P = k;
            this.O = "n"
        }
        la(a) {
            try {
                let b = VS(this.l.g) || void 0;
                KN({
                    Tg: b
                }, this.g);
                let c = hU(this, a, VS(this.l.g));
                ye(this.B, BK, 25) && AK(y(this.B, BK, 25)) && iU(this, c);
                eU(this, c);
                gU(this, c);
                xB(753, () => {
                    if (U(dw) && this.l != null) {
                        var d = yT(this.g, this.l, {
                                ne: V(qw),
                                xd: V(pw),
                                Id: V(hw),
                                yh: !0,
                                ug: !1
                            }),
                            e = Ei(c);
                        Ju(d) ? (d = KT(d.getValue()), e.placementPositionDiffs = d) : e.placementPositionDiffs = "E" +
                            d.g.message;
                        e = dU(this, e);
                        LT(this.C, tJ, e)
                    }
                })()
            } catch (b) {
                jU(this, b)
            }
        }
        Z(a) {
            jU(this, a)
        }
    };
    var kU = class extends I {},
        lU = qh(kU);

    function mU(a) {
        try {
            var b = a.localStorage.getItem("google_auto_fc_cmp_setting") || null
        } catch (d) {
            b = null
        }
        var c = b;
        return c ? Iu(() => lU(c)) : Fu(null)
    };

    function nU(a, b) {
        return sf(a, 5, b)
    }

    function oU(a, b) {
        return sf(a, 12, b)
    }
    var pU = class extends I {
        B() {
            return Nf(this, 1)
        }
        j() {
            return Nf(this, 2)
        }
        g() {
            return C(this, 3)
        }
        ha() {
            return C(this, 5)
        }
    };
    var tU = ({
            Jb: a,
            win: b,
            Xa: c,
            zf: d = !1,
            Af: e = !1
        }) => {
            qU({
                win: b,
                Xa: c,
                zf: d,
                Af: e
            }) ? (b = (b = RA(HA())) ? rU(b) : void 0) ? a(Fu(b)) : sU().then(f => f.map(rU)).then(a) : a(Fu(nU(new pU, !0)))
        },
        vU = ({
            win: a,
            Xa: b,
            zf: c = !1,
            Af: d = !1
        }) => qU({
            win: a,
            Xa: b,
            zf: c,
            Af: d
        }) ? (b = RA(HA())) ? uU(a, rU(b)) : Hu(Error("tcunav")) : uU(a, nU(new pU, !0));

    function qU({
        win: a,
        Xa: b,
        zf: c,
        Af: d
    }) {
        if (!(d = !d && nQ(new rQ(a)))) {
            if (c = !c) {
                if (b) {
                    a = mU(a);
                    if (Ju(a))
                        if ((a = a.getValue()) && fd(ue(a, 1)) != null) b: switch (a = E(a, 1), a) {
                            case 1:
                                a = !0;
                                break b;
                            default:
                                throw Error("Unhandled AutoGdprFeatureStatus: " + a);
                        } else a = !1;
                        else AB(806, a.g), a = !1;
                    b = !a
                }
                c = b
            }
            d = c
        }
        return d ? !0 : !1
    }

    function sU() {
        return (new Promise(a => {
            var b = HA();
            a = {
                resolve: a
            };
            var c = MA(b, 25, []);
            c.push(a);
            NA(b, 25, c)
        })).then(wU)
    }

    function wU(a) {
        return a ? Fu(a) : Hu(Error("tcnull"))
    }

    function rU(a) {
        return nU(new pU, iQ(a))
    }

    function uU(a, b) {
        return (a = sI(b, a)) ? Fu(a) : Hu(Error("unav"))
    };
    var xU = class {
        constructor(a, b, c, d, e) {
            this.g = a;
            this.A = b;
            this.B = c;
            this.j = !1;
            this.l = d;
            this.C = e
        }
    };
    var yU = class extends I {
        getName() {
            return E(this, 1)
        }
        getVersion() {
            return D(this, 3)
        }
    };
    var zU = [0, Rg, -1, Og];
    var AU = class extends I {
        nm() {
            return E(this, 3)
        }
    };
    const BU = {
        "-": 0,
        Y: 2,
        N: 1
    };
    var CU = class extends I {
        getVersion() {
            return gf(this, 2)
        }
    };

    function DU(a) {
        return a.includes("~") ? a.split("~").slice(1) : []
    };

    function EU(a) {
        return Cb(a.length % 4 !== 0 ? a + "A" : a).map(b => b.toString(2).padStart(8, "0")).join("")
    }

    function FU(a) {
        if (!/^[0-1]+$/.test(a)) throw Error(`Invalid input [${a}] not a bit string.`);
        return parseInt(a, 2)
    }

    function GU(a) {
        if (!/^[0-1]+$/.test(a)) throw Error(`Invalid input [${a}] not a bit string.`);
        var b = [1, 2, 3, 5],
            c = 0;
        for (let d = 0; d < a.length - 1; d++) b.length <= d && b.push(b[d - 1] + b[d - 2]), c += parseInt(a[d], 2) * b[d];
        return c
    }

    function HU(a, b) {
        a = EU(a);
        return a.length < b ? a.padEnd(b, "0") : a
    };

    function IU(a) {
        var b = EU(a),
            c = FU(b.slice(0, 6));
        a = FU(b.slice(6, 12));
        var d = new CU;
        c = vf(d, 1, c);
        a = vf(c, 2, a);
        b = b.slice(12);
        c = FU(b.slice(0, 12));
        d = [];
        var e = b.slice(12).replace(/0+$/, "");
        for (let k = 0; k < c; k++) {
            if (e.length === 0) throw Error(`Found ${k} of ${c} sections [${d}] but reached end of input [${b}]`);
            var f = FU(e[0]) === 0;
            e = e.slice(1);
            var g = JU(e, b),
                h = d.length === 0 ? 0 : d[d.length - 1];
            h = GU(g) + h;
            e = e.slice(g.length);
            if (f) {
                d.push(h);
                continue
            }
            f = JU(e, b);
            g = GU(f);
            for (let l = 0; l <= g; l++) d.push(h + l);
            e = e.slice(f.length)
        }
        if (e.length >
            0) throw Error(`Found ${c} sections [${d}] but has remaining input [${e}], entire input [${b}]`);
        return Ne(a, 3, d, gd)
    }

    function JU(a, b) {
        var c = a.indexOf("11");
        if (c === -1) throw Error(`Expected section bitstring but not found in [${a}] part of [${b}]`);
        return a.slice(0, c + 2)
    };
    var KU = class extends I {
        g() {
            return E(this, 1)
        }
        j() {
            return E(this, 2)
        }
    };
    var LU = class extends I {};
    var MU = class extends I {
        getVersion() {
            return gf(this, 1)
        }
    };
    var NU = class extends I {};

    function OU(a) {
        var b = new PU;
        return z(b, 1, a)
    }
    var PU = class extends I {};
    const QU = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        RU = 6 + QU.reduce((a, b) => a + b);
    var SU = class extends I {};
    var TU = class extends I {
        getVersion() {
            return gf(this, 1)
        }
    };
    var UU = class extends I {};

    function VU(a) {
        var b = new WU;
        return z(b, 1, a)
    }
    var WU = class extends I {};
    const XU = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        YU = 6 + XU.reduce((a, b) => a + b);
    var ZU = class extends I {
        g() {
            return E(this, 1)
        }
        j() {
            return E(this, 2)
        }
        B() {
            return E(this, 3)
        }
    };
    var $U = class extends I {};
    var aV = class extends I {
        getVersion() {
            return gf(this, 1)
        }
    };
    var bV = class extends I {};

    function cV(a) {
        var b = new dV;
        return z(b, 1, a)
    }
    var dV = class extends I {};
    const eV = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        fV = 6 + eV.reduce((a, b) => a + b);
    var gV = class extends I {
        g() {
            return E(this, 1)
        }
        j() {
            return E(this, 2)
        }
        B() {
            return E(this, 3)
        }
    };
    var hV = class extends I {};
    var iV = class extends I {
        getVersion() {
            return gf(this, 1)
        }
    };
    const jV = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        kV = 6 + jV.reduce((a, b) => a + b);
    var lV = class extends I {
        j() {
            return E(this, 1)
        }
        B() {
            return E(this, 2)
        }
        g() {
            return E(this, 3)
        }
    };
    var mV = class extends I {};

    function nV(a) {
        var b = new oV;
        return vf(b, 1, a)
    }
    var oV = class extends I {
        getVersion() {
            return gf(this, 1)
        }
    };
    var pV = class extends I {};

    function qV(a) {
        var b = new rV;
        return z(b, 1, a)
    }
    var rV = class extends I {};
    const sV = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        tV = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        uV = 6 + tV.reduce((a, b) => a + b);

    function vV(a, b = [1]) {
        if (a.length === 0) throw Error("Cannot decode empty USNat section string.");
        var c = a.split(".");
        if (c.length > 2) throw Error(`Expected at most 2 segments but got ${c.length} when decoding ${a}.`);
        a = wV(c[0], b);
        if (c.length === 1) a = qV(a);
        else {
            a = qV(a);
            c = c[1];
            if (c.length === 0) throw Error("Cannot decode empty GPC segment string.");
            b = HU(c, 3);
            c = FU(b.slice(0, 2));
            if (c < 0 || c > 1) throw Error(`Attempting to decode unknown GPC segment subsection type ${c}.`);
            c += 1;
            b = FU(b.charAt(2));
            var d = new pV;
            c = F(d, 2,
                c);
            c = tf(c, 1, !!b);
            a = z(a, 2, c)
        }
        return a
    }

    function wV(a, b = [1]) {
        if (a.length === 0) throw Error("Cannot decode empty core segment string.");
        var c = HU(a, uV),
            d = FU(c.slice(0, 6));
        c = c.slice(6);
        if (!b.includes(d)) throw Error(`Unable to decode unsupported USNat Section specification version ${d} - only version${b.length>1?"s":""} ${b.join(", ")} ${b.length>1?"are":"is"} supported.`);
        var e = 0,
            f = [],
            g = d === 1 ? sV : tV;
        for (let Bj = 0; Bj < g.length; Bj++) {
            let im = g[Bj];
            f.push(FU(c.slice(e, e + im)));
            e += im
        }
        if (d === 1) {
            var h = nV(d),
                k = f.shift();
            var l = F(h, 2, k);
            var m = f.shift();
            var n =
                F(l, 3, m);
            var p = f.shift();
            var q = F(n, 4, p);
            var u = f.shift();
            var w = F(q, 5, u);
            var B = f.shift();
            var G = F(w, 6, B);
            var K = f.shift();
            var H = F(G, 7, K);
            var L = f.shift();
            var S = F(H, 8, L);
            var da = f.shift();
            var Ea = F(S, 9, da);
            var ka = f.shift();
            var Da = F(Ea, 10, ka);
            var Nc = new mV,
                ad = f.shift();
            var Oc = F(Nc, 1, ad);
            var ee = f.shift();
            var ya = F(Oc, 2, ee);
            var Pc = f.shift();
            var Vg = F(ya, 3, Pc);
            var Wg = f.shift();
            var Xg = F(Vg, 4, Wg);
            var Yg = f.shift();
            var Zg = F(Xg, 5, Yg);
            var ah = f.shift();
            var bh = F(Zg, 6, ah);
            var ch = f.shift();
            var dh = F(bh, 7, ch);
            var eh = f.shift();
            var fh = F(dh, 8, eh);
            var gh = f.shift();
            var Vi = F(fh, 9, gh);
            var Wi = f.shift();
            var Xi = F(Vi, 10, Wi);
            var Yi = f.shift();
            var Zi = F(Xi, 11, Yi);
            var $i = f.shift();
            var Af = F(Zi, 12, $i);
            var aj = z(Da, 11, Af);
            var ih = new lV,
                bj = f.shift();
            var Df = F(ih, 1, bj);
            var cj = f.shift();
            var dj = F(Df, 2, cj);
            var ej = z(aj, 12, dj);
            var Ef = f.shift();
            var lh = F(ej, 13, Ef);
            var fj = f.shift();
            var nh = F(lh, 14, fj);
            var Ac = f.shift();
            var oh = F(nh, 15, Ac);
            var gj = f.shift();
            var Gf = F(oh, 16, gj)
        } else {
            var ph = nV(d),
                Hf = f.shift();
            var xc = F(ph, 2, Hf);
            var bd = f.shift();
            var Wa = F(xc,
                3, bd);
            var Vb = f.shift();
            var Ug = F(Wa, 4, Vb);
            var Ie = f.shift();
            var Ff = F(Ug, 5, Ie);
            var yc = f.shift();
            var fc = F(Ff, 6, yc);
            var $c = f.shift();
            var rd = F(fc, 7, $c);
            var Gb = f.shift();
            var zc = F(rd, 8, Gb);
            var zf = f.shift();
            var Ui = F(zc, 9, zf);
            var $g = f.shift();
            var sd = F(Ui, 10, $g);
            var hh = new mV,
                Bf = f.shift();
            var Cf = F(hh, 1, Bf);
            var fe = f.shift();
            var kh = F(Cf, 2, fe);
            var mh = f.shift();
            var jh = F(kh, 3, mh);
            var Kr = f.shift();
            var Lr = F(jh, 4, Kr);
            var Mr = f.shift();
            var Nr = F(Lr, 5, Mr);
            var Or = f.shift();
            var Pr = F(Nr, 6, Or);
            var Qr = f.shift();
            var Rr = F(Pr,
                7, Qr);
            var Sr = f.shift();
            var Tr = F(Rr, 8, Sr);
            var Ur = f.shift();
            var Vr = F(Tr, 9, Ur);
            var Wr = f.shift();
            var Xr = F(Vr, 10, Wr);
            var Yr = f.shift();
            var Zr = F(Xr, 11, Yr);
            var $r = f.shift();
            var as = F(Zr, 12, $r);
            var bs = f.shift();
            var cs = F(as, 13, bs);
            var ds = f.shift();
            var es = F(cs, 14, ds);
            var jm = f.shift();
            var km = F(es, 15, jm);
            var lm = f.shift();
            var mm = F(km, 16, lm);
            var nm = z(sd, 11, mm);
            var om = new lV,
                pm = f.shift();
            var qm = F(om, 1, pm);
            var rm = f.shift();
            var sm = F(qm, 2, rm);
            var tm = f.shift();
            var um = F(sm, 3, tm);
            var vm = z(nm, 12, um);
            var wm = f.shift();
            var xm =
                F(vm, 13, wm);
            var ym = f.shift();
            var zm = F(xm, 14, ym);
            var Am = f.shift();
            var fs = F(zm, 15, Am);
            var gs = f.shift();
            Gf = F(fs, 16, gs)
        }
        return Gf
    };
    var xV = class extends I {};
    var yV = class extends I {
        getVersion() {
            return gf(this, 1)
        }
    };
    const zV = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        AV = 6 + zV.reduce((a, b) => a + b);

    function BV(a, b) {
        return Ne(a, 1, b, gd)
    }
    var CV = class extends I {};
    var DV = class extends I {};

    function EV(a, b) {
        return Mf(a, 1, b)
    }

    function FV(a, b) {
        return Mf(a, 2, b)
    }

    function GV(a, b) {
        return Ne(a, 3, b, gd)
    }

    function HV(a, b) {
        Ne(a, 4, b, gd)
    }
    var IV = class extends I {};

    function JV(a, b) {
        return xf(a, 1, b)
    }

    function KV(a) {
        var b = Number; {
            var c = ue(a, 1, void 0, void 0, yd);
            let d = typeof c;
            c = c == null ? c : d === "bigint" ? String(Rc(64, c)) : dd(c) ? d === "string" ? ld(c) : pd(c) : void 0
        }
        b = b(c ? ? "0");
        a = gf(a, 2);
        return new Date(b * 1E3 + a / 1E6)
    }
    var LV = class extends I {};

    function MV(a, b) {
        return vf(a, 1, b)
    }

    function NV(a, b) {
        return z(a, 2, b)
    }

    function OV(a, b) {
        return z(a, 3, b)
    }

    function PV(a, b) {
        return vf(a, 4, b)
    }

    function QV(a, b) {
        return vf(a, 5, b)
    }

    function RV(a, b) {
        return vf(a, 6, b)
    }

    function SV(a, b) {
        return Kf(a, 7, b)
    }

    function TV(a, b) {
        return vf(a, 8, b)
    }

    function UV(a, b) {
        return vf(a, 9, b)
    }

    function VV(a, b) {
        return tf(a, 10, b)
    }

    function WV(a, b) {
        return tf(a, 11, b)
    }

    function XV(a, b) {
        return Mf(a, 12, b)
    }

    function YV(a, b) {
        return Mf(a, 13, b)
    }

    function ZV(a, b) {
        return Mf(a, 14, b)
    }

    function $V(a, b) {
        return tf(a, 15, b)
    }

    function aW(a, b) {
        return Kf(a, 16, b)
    }

    function bW(a, b) {
        return Ne(a, 17, b, gd)
    }

    function cW(a, b) {
        return Ne(a, 18, b, gd)
    }

    function dW(a, b) {
        return Xe(a, 19, b)
    }
    var eW = class extends I {
        getVersion() {
            return gf(this, 1)
        }
    };
    var fW = class extends I {};
    var gW = Di(Er).map(a => Number(a)),
        hW = Di(Fr).map(a => Number(a));

    function iW(a, b) {
        if (a.g + b > a.j.length) throw Error(`Requested length ${b} is past end of string.`);
        var c = a.j.substring(a.g, a.g + b);
        a.g += b;
        return parseInt(c, 2)
    }

    function jW(a) {
        a = iW(a, 36);
        var b = JV(new LV, Math.floor(a / 10));
        return vf(b, 2, a % 10 * 1E8)
    }

    function kW(a) {
        var b = () => {
            var c = iW(a, 6);
            if (c > 25 || c < 0) throw Error(`Invalid character code, expected in range [0,25], got: ${c}`);
            return String.fromCharCode(97 + c)
        };
        return b() + b()
    }

    function lW(a) {
        for (var b = iW(a, 12), c = []; b--;) {
            var d = !!iW(a, 1) === !0,
                e = iW(a, 16);
            if (d)
                for (d = iW(a, 16); e <= d; e++) c.push(e);
            else c.push(e)
        }
        c.sort((f, g) => f - g);
        return c
    }

    function mW(a, b, c) {
        var d = [];
        for (let e = 0; e < b; e++)
            if (iW(a, 1)) {
                let f = e + 1;
                if (c && c.indexOf(f) === -1) throw Error(`ID: ${f} is outside of allowed values!`);
                d.push(f)
            }
        return d
    }

    function nW(a) {
        var b = iW(a, 16);
        if (!!iW(a, 1) === !0) {
            a = lW(a);
            for (let c of a)
                if (c > b) throw Error(`ID ${c} is past MaxVendorId ${b}!`);
            return a
        }
        return mW(a, b)
    }

    function oW(a) {
        for (var b = [], c = iW(a, 12); c--;) {
            let k = iW(a, 6);
            var d = iW(a, 2),
                e = lW(a),
                f = b,
                g = f.push;
            var h = new DV;
            h = F(h, 1, k);
            d = F(h, 2, d);
            e = Ne(d, 3, e, gd);
            g.call(f, e)
        }
        return b
    }
    var pW = class {
        constructor(a) {
            this.j = a;
            this.g = 0;
            if (/[^01]/.test(this.j)) throw Error(`Input bitstring ${this.j} is malformed!`);
        }
        skip(a) {
            this.g += a
        }
    };

    function qW(a) {
        try {
            let b = Cb(a).map(d => d.toString(2).padStart(8, "0")).join(""),
                c = new pW(b);
            return iW(c, 3) !== 1 ? null : BV(new CV, nW(c))
        } catch (b) {
            return null
        }
    };

    function rW(a) {
        try {
            let b = Cb(a).map(f => f.toString(2).padStart(8, "0")).join(""),
                c = new pW(b);
            if (iW(c, 3) !== 3) return null;
            let d = FV(EV(new IV, mW(c, 24, gW)), mW(c, 24, gW)),
                e = iW(c, 6);
            e !== 0 && HV(GV(d, mW(c, e)), mW(c, e));
            return d
        } catch (b) {
            return null
        }
    };

    function sW(a) {
        try {
            let b = Cb(a).map(d => d.toString(2).padStart(8, "0")).join(""),
                c = new pW(b);
            return dW(cW(bW(aW($V(ZV(YV(XV(WV(VV(UV(TV(SV(RV(QV(PV(OV(NV(MV(new eW, iW(c, 6)), jW(c)), jW(c)), iW(c, 12)), iW(c, 12)), iW(c, 6)), kW(c)), iW(c, 12)), iW(c, 6)), !!iW(c, 1)), !!iW(c, 1)), mW(c, 12, hW)), mW(c, 24, gW)), mW(c, 24, gW)), !!iW(c, 1)), kW(c)), nW(c)), nW(c)), oW(c))
        } catch (b) {
            return null
        }
    };

    function tW(a) {
        if (!a) return null;
        a = a.split(".");
        if (a.length > 4) return null;
        var b = sW(a[0]);
        if (!b) return null;
        var c = new fW;
        b = z(c, 1, b);
        a.shift();
        for (let d of a) switch (uW(d)) {
            case 1:
                a = qW(d);
                if (!a) return null;
                z(b, 3, a);
                break;
            case 2:
                break;
            case 3:
                a = rW(d);
                if (!a) return null;
                z(b, 2, a);
                break;
            default:
                return null
        }
        return b
    }

    function uW(a) {
        try {
            let b = Cb(a).map(c => c.toString(2).padStart(8, "0")).join("");
            return iW(new pW(b), 3)
        } catch (b) {
            return -1
        }
    };

    function vW(a, b) {
        var c = {};
        if (Array.isArray(b) && b.length !== 0)
            for (let d of b) c[d] = a.indexOf(d) !== -1;
        else
            for (let d of a) c[d] = !0;
        delete c[0];
        return c
    };
    var wW = class extends I {
        g() {
            return Nf(this, 2)
        }
    };
    var xW = class extends I {
        g() {
            return Nf(this, 2)
        }
    };
    var yW = class extends I {};
    var zW = qh(class extends I {});

    function AW(a) {
        a = BW(a);
        try {
            var b = a ? zW(a) : null
        } catch (c) {
            b = null
        }
        return b ? y(b, yW, 4) || null : null
    }

    function BW(a) {
        a = tI({
            document: a,
            origin: a ? .location ? .origin,
            navigator: {
                cookieEnabled: !0
            },
            isSecureContext: !0
        }) ? (new oI(a)).get("FCCDCF", "") : "";
        if (a)
            if (a.startsWith("%")) try {
                var b = decodeURIComponent(a)
            } catch (c) {
                b = null
            } else b = a;
            else b = null;
        return b
    };

    function CW(a) {
        a.__tcfapiPostMessageReady || DW(new EW(a))
    }

    function DW(a) {
        a.g = b => {
            var c = typeof b.data === "string";
            try {
                var d = c ? JSON.parse(b.data) : b.data
            } catch (f) {
                return
            }
            var e = d.__tcfapiCall;
            e && (e.command === "ping" || e.command === "addEventListener" || e.command === "removeEventListener") && (0, a.win.__tcfapi)(e.command, e.version, (f, g) => {
                var h = {};
                h.__tcfapiReturn = e.command === "removeEventListener" ? {
                    success: f,
                    callId: e.callId
                } : {
                    returnValue: f,
                    success: g,
                    callId: e.callId
                };
                f = c ? JSON.stringify(h) : h;
                b.source && typeof b.source.postMessage === "function" && b.source.postMessage(f, b.origin);
                return f
            }, e.parameter)
        };
        a.win.addEventListener("message", a.g);
        a.win.__tcfapiPostMessageReady = !0
    }
    var EW = class {
        constructor(a) {
            this.win = a
        }
    };

    function FW(a) {
        a.__uspapiPostMessageReady || GW(new HW(a))
    }

    function GW(a) {
        a.g = b => {
            var c = typeof b.data === "string";
            try {
                var d = c ? JSON.parse(b.data) : b.data
            } catch (f) {
                return
            }
            var e = d.__uspapiCall;
            e && e.command === "getUSPData" && a.win.__uspapi(e.command, e.version, (f, g) => {
                var h = {};
                h.__uspapiReturn = {
                    returnValue: f,
                    success: g,
                    callId: e.callId
                };
                f = c ? JSON.stringify(h) : h;
                b.source && typeof b.source.postMessage === "function" && b.source.postMessage(f, b.origin);
                return f
            })
        };
        a.win.addEventListener("message", a.g);
        a.win.__uspapiPostMessageReady = !0
    }
    var HW = class {
        constructor(a) {
            this.win = a;
            this.g = null
        }
    };
    var IW = class extends I {};
    var JW = qh(class extends I {
        g() {
            return Nf(this, 1)
        }
    });

    function KW(a, b) {
        try {
            let c = a.split("."),
                d = Cb(c[0]).map(g => g.toString(2).padStart(8, "0")).join(""),
                e = new pW(d);
            a = {
                tcString: a ? ? void 0,
                gdprApplies: b
            };
            e.skip(78);
            a.cmpId = iW(e, 12);
            a.cmpVersion = iW(e, 12);
            e.skip(30);
            a.tcfPolicyVersion = iW(e, 6);
            a.isServiceSpecific = !!iW(e, 1);
            a.useNonStandardStacks = !!iW(e, 1);
            a.specialFeatureOptins = LW(mW(e, 12, hW), hW);
            a.purpose = {
                consents: LW(mW(e, 24, gW), gW),
                legitimateInterests: LW(mW(e, 24, gW), gW)
            };
            a.purposeOneTreatment = !!iW(e, 1);
            a.publisherCC = kW(e);
            a.vendor = {
                consents: LW(nW(e), null),
                legitimateInterests: LW(nW(e), null)
            };
            let f = MW(c);
            f && (a.vendor.disclosedVendors = f);
            return a
        } catch (c) {
            return null
        }
    }

    function MW(a) {
        a.shift();
        for (let b of a)
            if (a = Cb(b).map(c => c.toString(2).padStart(8, "0")).join(""), a = new pW(a), iW(a, 3) === 1) return LW(nW(a), null)
    }

    function LW(a, b) {
        var c = {};
        if (Array.isArray(b) && b.length !== 0)
            for (let d of b) c[d] = a.indexOf(d) !== -1;
        else
            for (let d of a) c[d] = !0;
        delete c[0];
        return c
    };

    function NW(a, b) {
        function c(n) {
            if (n.length < 10) return null;
            var p = h(n.slice(0, 4));
            p = k(p);
            n = h(n.slice(6, 10));
            n = l(n);
            return "1" + p + n + "N"
        }

        function d(n) {
            if (n.length < 10) return null;
            var p = h(n.slice(0, 6));
            p = k(p);
            n = h(n.slice(6, 10));
            n = l(n);
            return "1" + p + n + "N"
        }

        function e(n) {
            if (n.length < 12) return null;
            var p = h(n.slice(0, 6));
            p = k(p);
            n = h(n.slice(8, 12));
            n = l(n);
            return "1" + p + n + "N"
        }

        function f(n) {
            if (n.length < 18) return null;
            var p = h(n.slice(0, 8));
            p = k(p);
            n = h(n.slice(12, 18));
            n = l(n);
            return "1" + p + n + "N"
        }

        function g(n) {
            if (n.length < 10) return null;
            var p = h(n.slice(0, 6));
            p = k(p);
            n = h(n.slice(6, 10));
            n = l(n);
            return "1" + p + n + "N"
        }

        function h(n) {
            var p = [],
                q = 0;
            for (let u = 0; u < n.length / 2; u++) p.push(FU(n.slice(q, q + 2))), q += 2;
            return p
        }

        function k(n) {
            return n.every(p => p === 1) ? "Y" : "N"
        }

        function l(n) {
            return n.some(p => p === 1) ? "Y" : "N"
        }
        if (a.length === 0) return null;
        a = a.split(".");
        if (a.length > 2) return null;
        a = EU(a[0]);
        var m = FU(a.slice(0, 6));
        a = a.slice(6);
        if (m !== 1) return null;
        switch (b) {
            case 8:
                return c(a);
            case 10:
            case 12:
            case 9:
                return d(a);
            case 11:
                return e(a);
            case 7:
                return f(a);
            case 13:
                return g(a);
            default:
                return null
        }
    };

    function OW(a, b) {
        a === a.top && (a = new PW(a, b), QW(a), RW(a))
    }

    function QW(a) {
        !a.l || a.win.__uspapi || a.win.frames.__uspapiLocator || (a.win.__uspapiManager = "fc", TP(a.win, "__uspapiLocator"), Ba("__uspapi", (b, c, d) => {
            typeof d === "function" && b === "getUSPData" && (b = C(a.j, 3), d({
                version: 1,
                uspString: b ? a.l : "1---"
            }, !0))
        }, a.win), FW(a.win))
    }

    function RW(a) {
        !a.tcString || a.win.__tcfapi || a.win.frames.__tcfapiLocator || (a.win.__tcfapiManager = "fc", TP(a.win, "__tcfapiLocator"), a.win.__tcfapiEventListeners = a.win.__tcfapiEventListeners || [], Ba("__tcfapi", (b, c, d, e) => {
            if (typeof d === "function")
                if (c && (c > 2.3 || c <= 1)) d(null, !1);
                else {
                    var f = a.win.__tcfapiEventListeners;
                    c = a.j.g();
                    switch (b) {
                        case "ping":
                            d({
                                gdprApplies: c,
                                cmpLoaded: !0,
                                cmpStatus: "loaded",
                                displayStatus: "disabled",
                                apiVersion: "2.3",
                                cmpVersion: 2,
                                cmpId: 300
                            });
                            break;
                        case "addEventListener":
                            b = f.push(d) -
                                1;
                            a.tcString ? (e = KW(a.tcString, c), e.addtlConsent = a.g != null ? a.g : void 0, e.cmpStatus = "loaded", e.eventStatus = "tcloaded", b != null && (e.listenerId = b), b = e) : b = null;
                            d(b, !0);
                            break;
                        case "removeEventListener":
                            e !== void 0 && f[e] ? (f[e] = null, d(!0)) : d(!1);
                            break;
                        case "getInAppTCData":
                        case "getVendorList":
                            d(null, !1);
                            break;
                        case "getTCData":
                            d(null, !1)
                    }
                }
        }, a.win), CW(a.win))
    }

    function SW(a) {
        if (!a ? .g() || D(a, 1).length === 0 || Ve(a, IW, 2, De()).length === 0) return null;
        var b = D(a, 1);
        try {
            var c = IU(b.split("~")[0]);
            var d = DU(b)
        } catch (e) {
            return null
        }
        a = Ve(a, IW, 2, De()).reduce((e, f) => {
            var g = TW(e);
            g = hf(g, 1);
            g = KH(g);
            var h = TW(f);
            h = hf(h, 1);
            return g > KH(h) ? e : f
        });
        c = lf(c, 3).indexOf(gf(a, 1));
        return c === -1 || c >= d.length ? null : {
            uspString: NW(d[c], gf(a, 1)),
            Og: KV(TW(a))
        }
    }

    function UW(a) {
        a = a.find(b => b && E(b, 1) === 13);
        if (a ? .g()) try {
            return JW(D(a, 2))
        } catch (b) {}
        return null
    }

    function TW(a) {
        return ye(a, LV, 2) ? y(a, LV, 2) : JV(new LV, 0)
    }
    var PW = class {
        constructor(a, b) {
            this.win = a;
            this.j = b;
            b = BW(this.win.document);
            try {
                var c = b ? zW(b) : null
            } catch (e) {
                c = null
            }(b = c) ? (c = y(b, xW, 5) || null, b = Ve(b, wW, 7, De()), b = UW(b ? ? []), c = {
                Wi: c,
                wj: b
            }) : c = {
                Wi: null,
                wj: null
            };
            b = c;
            c = SW(b.wj);
            b = b.Wi;
            if (b ? .g() && D(b, 2).length !== 0) {
                var d = ye(b, LV, 1) ? y(b, LV, 1) : JV(new LV, 0);
                b = {
                    uspString: D(b, 2),
                    Og: KV(d)
                }
            } else b = null;
            this.l = b && c ? c.Og > b.Og ? c.uspString : b.uspString : b ? b.uspString : c ? c.uspString : null;
            this.tcString = (c = AW(a.document)) && Nf(c, 1) ? D(c, 1) : null;
            this.g = (a = AW(a.document)) && Nf(a,
                2) ? D(a, 2) : null
        }
    };

    function VW(a, b, c, d = null) {
        var e = g => {
            try {
                var h = JSON.parse(g.data)
            } catch (k) {
                return
            }!h || h.googMsgType !== b || d && /[:|%3A]javascript\(/i.test(g.data) && !d(h, g) || c(h, g)
        };
        Yj(a, "message", e);
        var f = !1;
        return () => {
            var g = !1;
            f || (f = !0, g = Zj(a, "message", e));
            return g
        }
    }

    function WW(a, b, c, d = null) {
        var e = VW(a, b, mi(c, () => e()), d);
        return e
    }

    function XW(a, b, c, d) {
        c.googMsgType = b;
        a.postMessage(JSON.stringify(c), d)
    }

    function YW(a, b, c, d, e) {
        if (!(e <= 0) && (XW(a, b, c, d), a = a.frames))
            for (let f = 0; f < a.length; ++f) e > 1 && YW(a[f], b, c, d, --e)
    };

    function ZW(a, b, c, d) {
        return VW(a, "fullscreen", d.Zb(952, (e, f) => {
            if (f.source === b) {
                if (!("eventType" in e)) throw Error(`bad message ${JSON.stringify(e)}`);
                delete e.googMsgType;
                c(e)
            }
        }))
    };
    class $W {
        constructor() {
            this.promise = new Promise((a, b) => {
                this.resolve = a;
                this.reject = b
            })
        }
    };
    async function aX(a) {
        return a.A.promise
    }
    async function bX(a) {
        return a.j.promise
    }
    async function cX(a) {
        return a.l.promise
    }

    function dX(a, b) {
        b.type = "err_st";
        b.slot = a.slotType;
        b.freq = .25;
        a.qem && (b.qem = a.qem);
        b.tag_type = a.C.Pn;
        b.version = a.C.version;
        Hm(a.F, "fullscreen_tag", b, !1, .25)
    }
    class eX extends O {
        constructor(a, b, c) {
            var d = tB,
                e = rB,
                f = {
                    Pn: 2,
                    version: aq()
                };
            super();
            this.slotType = a;
            this.pubWin = b;
            this.Mg = c;
            this.ob = d;
            this.F = e;
            this.C = f;
            this.state = 1;
            this.qem = null;
            this.A = new $W;
            this.j = new $W;
            this.l = new $W
        }
        init() {
            var a = ZW(this.pubWin, this.Mg, b => {
                if (b.eventType === "adError") this.l.resolve(), this.state = 4;
                else if (b.eventType === "adReady" && this.state === 1) this.qem = b.qem, b.slotType !== this.slotType && (dX(this, {
                        cur_st: this.state,
                        evt: b.eventType,
                        adp_tp: b.slotType
                    }), this.state = 4), this.A.resolve(),
                    this.state = 2;
                else if (b.eventType === "adClosed" && this.state === 2) this.j.resolve(b.result), this.state = 3;
                else if (b.eventType !== "adClosed" || this.state !== 3) b.eventType === "adClosed" && b.closeAfterError && (this.j.resolve(b.result), this.state = 3), dX(this, {
                    cur_st: this.state,
                    evt: b.eventType
                }), this.state = 4
            }, this.ob);
            xt(this, a)
        }
    };
    var fX = Promise;
    class gX {
        constructor(a) {
            this.l = a
        }
        g(a, b, c) {
            this.l.then(d => {
                d.g(a, b, c)
            })
        }
        j(a, b) {
            return this.l.then(c => c.j(a, b))
        }
    };
    class hX {
        constructor(a) {
            this.data = a
        }
    };

    function iX(a, b) {
        jX(a, b);
        return new kX(a)
    }
    class kX {
        constructor(a) {
            this.l = a
        }
        g(a, b, c = []) {
            var d = new MessageChannel;
            jX(d.port1, b);
            this.l.postMessage(a, [d.port2].concat(c))
        }
        j(a, b) {
            return new fX(c => {
                this.g(a, c, b)
            })
        }
    }

    function jX(a, b) {
        b && (a.onmessage = c => {
            b(new hX(c.data, iX(c.ports[0])))
        })
    };
    var lX = class {
        constructor(a) {
            this.g = a
        }
    };
    const mX = a => {
        var b = Object.create(null);
        (typeof a === "string" ? [a] : a).forEach(c => {
            if (c === "null") throw Error("Receiving from null origin not allowed without token verification. Please use NullOriginConnector.");
            b[c] = !0
        });
        return c => b[c] === !0
    };
    var oX = ({
        destination: a,
        L: b,
        origin: c,
        Qb: d = "ZNWN1d",
        onMessage: e,
        Vj: f
    }) => nX({
        destination: a,
        wf: () => b.contentWindow,
        Zm: c instanceof lX ? c : typeof c === "function" ? new lX(c) : new lX(mX(c)),
        Qb: d,
        onMessage: e,
        Vj: f
    });
    const nX = ({
        destination: a,
        wf: b,
        Zm: c,
        Dp: d,
        Qb: e,
        onMessage: f,
        Vj: g
    }) => new gX(new fX((h, k) => {
        var l = m => {
            m.source && m.source === b() && c.g(m.origin) && (m.data.n || m.data) === e && (a.removeEventListener("message", l, !1), d && m.data.t !== d ? k(Error(`Token mismatch while establishing channel "${e}". Expected ${d}, but received ${m.data.t}.`)) : (h(iX(m.ports[0], f)), g && g(m)))
        };
        a.addEventListener("message", l, !1)
    }));
    var pX = Tg(nn);
    var qX = Tg(on);
    var rX = Tg(qn);
    var sX = Tg(mn);
    var tX = Tg(pn);

    function uX() {
        var {
            promise: a,
            resolve: b
        } = new $W;
        return {
            promise: a,
            resolve: b
        }
    };

    function vX(a, b, c = () => {}) {
        b.google_llp || (b.google_llp = {});
        b = b.google_llp;
        var d = b[a];
        if (d) return d;
        d = uX();
        b[a] = d;
        c();
        return d
    }

    function wX(a, b, c) {
        return vX(a, b, () => {
            Zk(b.document, c)
        }).promise
    };
    var xX = class {
        constructor(a) {
            this.lg = a
        }
        runVideoFeed({
            win: a,
            Un: b,
            webPropertyCode: c
        }) {
            yB(1678, wX(13, a, this.lg).then(d => {
                d.runVideoFeed({
                    win: a,
                    serializedVideoFeedConfig: pg(b),
                    webPropertyCode: c
                })
            }))
        }
    };

    function yX(a, b, c, d, e, f, g = null) {
        if (e) {
            if (U($v)) var h = null;
            else try {
                h = e.getItem("google_ama_config")
            } catch (m) {
                h = null
            }
            try {
                var k = h ? WK(h) : null
            } catch (m) {
                k = null
            }
        } else k = null;
        a: {
            if (d) try {
                var l = WK(d);
                break a
            } catch (m) {
                OT(a, {
                    cfg: 1,
                    inv: 1
                })
            }
            l = null
        }
        if (d = l) {
            if (e) {
                l = new qK;
                z(d, 3, l);
                k = JH(d ? .g() ? .j()) || 1;
                k = Date.now() + 864E5 * k;
                Number.isFinite(k) && wf(l, 1, Math.round(k));
                l = ne(d);
                d.g() && (k = new pK, h = d ? .g() ? .g(), k = sf(k, 23, h), h = d ? .g() ? .B(), k = sf(k, 12, h), z(l, 15, k));
                k = UK(l);
                for (h = 0; h < k.length; h++) we(k[h], 11);
                we(l, 22);
                if (U($v)) VT(a,
                    e);
                else try {
                    e.setItem("google_ama_config", pg(l))
                } catch (m) {
                    OT(a, {
                        lserr: 1
                    })
                }
            }
            e = TT(a, Ve(d, zK, 7, De()));
            l = {};
            U(aw) || (l.jn = y(d, HK, 8) || new HK);
            e && (l.ja = e);
            e && ST(e, 3) && (l.je = [1]);
            e = l;
            fB(a, 2) && (Kl(5, [Zd(d)]), c = PT(c), f = new xX(f), l = (l = e.ja) && qf(l, 4) || "", c.google_package = l, XT(a, b, d, e, f, new dv(["google-auto-placed"], c), g));
            return !0
        }
        k && (OT(a, {
            cfg: 1,
            cl: 1
        }), e != null && VT(a, e));
        return !1
    };

    function zX(a) {
        var b = new Ct(a.dataset.adStatus || null);
        (new MutationObserver(() => {
            b.g(a.dataset.adStatus || null)
        })).observe(a, {
            attributes: !0
        });
        return Gt(b)
    };

    function AX(a) {
        a.j != null || a.B || (a.j = new MutationObserver(b => {
            for (let c of b)
                for (let d of c.addedNodes) ra(d) && d.nodeType == 1 && (b = a, d.matches('A[href]:not([href=""])') && Qt(b.l, d))
        }), a.j.observe(a.win.document.documentElement, {
            childList: !0,
            subtree: !0
        }))
    }
    var BX = class extends O {
        constructor(a) {
            super();
            this.win = a;
            this.l = new Rt;
            this.j = null;
            xt(this, () => {
                this.j ? .disconnect();
                this.j = null
            })
        }
    };

    function CX(a, b) {
        b.addEventListener("click", () => {
            var c = a.j;
            var d = b.getAttribute("href");
            c = d ? d === "#" ? Fu(Ao(4)) : d.startsWith("#") ? Fu(Ao(5)) : DX(d, c) : Hu(Error("Empty href"));
            if (Ju(c)) {
                d = c.getValue();
                c = a.g;
                var e = new Co;
                d = z(e, 1, d);
                c.call(a, d)
            } else a.l(c.g)
        })
    }
    var FX = class {
        constructor(a, b, c) {
            var d = EX();
            this.win = a;
            this.j = b;
            this.g = c;
            this.l = d
        }
        init() {
            var a = new BX(this.win);
            Array.from(a.win.document.querySelectorAll('A[href]:not([href=""])')).forEach(b => {
                CX(this, b)
            });
            AX(a);
            Ot(a.l).listen(b => {
                CX(this, b)
            })
        }
    };

    function DX(a, b) {
        return GX(a, b).map(c => GX(b).map(d => {
            if (c.protocol === "http:" || c.protocol === "https:") {
                var e = Ao(2);
                e = Kf(e, 2, `${c.host}${c.pathname}`);
                d = Kf(e, 3, `${d.host}${d.pathname}`)
            } else d = c.protocol === "javascript:" ? Ao(3) : Ao(1);
            return d
        }))
    }

    function GX(a, b) {
        return Mu(Iu(() => new URL(a, b)), () => Error("Invalid URL"))
    };

    function HX(a) {
        if (a < 0 || !Number.isInteger(a)) return Hu(Error(`Not a non-negative integer: ${a}`));
        var b = [];
        do b.push("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".charAt(a % 64)), a = Math.floor(a / 64); while (a > 0);
        return Fu(b.reverse().join(""))
    };
    class IX {
        constructor() {
            this.Hk = 5E3
        }
        Cl() {
            return 5E3
        }
    }

    function JX(a, b) {
        return a.quantizer ? Math.floor(b / 5E3) * 5E3 / a.quantizer.Hk : b
    }

    function KX(a, b) {
        b = b.map(c => JX(a, c));
        return LX(b, a.g === void 0 ? void 0 : JX(a, a.g)).map(c => {
            a: {
                var d = MX;
                let e = [];
                for (let f of c) {
                    c = d(f);
                    if (!Ju(c)) {
                        d = Hu(c.g);
                        break a
                    }
                    e.push(c.getValue())
                }
                d = Fu(e)
            }
            return d
        }).map(c => c.join(".")).map(c => NX(c, a.quantizer ? .Cl()))
    }
    var OX = class {
        constructor(a, b) {
            this.quantizer = a;
            this.g = b
        }
    };

    function MX(a) {
        var b = HX(a.value);
        if (!Ju(b)) return b;
        var c = b.getValue();
        return a.Xf === 1 ? Fu(`${c}`) : a.Xf === 2 ? Fu(`${c}~`) : Ou(HX(a.Xf - 2), d => {
            throw d;
        }).map(d => `${c}~${d}`)
    }

    function LX(a, b) {
        var c = [];
        for (let d = 0; d < a.length; d++) {
            let e = a[d] ? ? b;
            if (e === void 0) return Hu(Error("Sparse but no default"));
            c.length === 0 || e !== c[c.length - 1].value ? c.push({
                value: e,
                Xf: 1
            }) : c[c.length - 1].Xf++
        }
        return Fu(c)
    }

    function NX(a, b) {
        return a === "" ? Fu("") : PX(b).map(c => `${c}${a}`)
    }

    function PX(a) {
        return a === void 0 || a === 1 ? Fu("") : Nu(HX(a), "ComFactor: ").map(b => `~${b}.`)
    };
    var QX = class extends O {
        constructor(a) {
            super();
            this.win = a;
            this.l = new Ct(!1);
            this.j = () => {
                this.l.g(this.win.document.hasFocus())
            }
        }
        init() {
            this.win.addEventListener("focus", this.j);
            this.win.addEventListener("blur", this.j);
            xt(this, () => void this.win.removeEventListener("focus", this.j));
            xt(this, () => void this.win.removeEventListener("blur", this.j));
            this.l.g(this.win.document.hasFocus())
        }
    };

    function RX(a) {
        a.l.g(a.win.document.visibilityState === "visible")
    }
    var SX = class extends O {
        constructor(a) {
            super();
            this.win = a;
            this.l = new Ct(!1);
            this.j = () => void RX(this)
        }
        init() {
            this.win.addEventListener("visibilitychange", this.j);
            xt(this, () => void this.win.removeEventListener("visibilitychange", this.j));
            RX(this)
        }
    };

    function TX(a) {
        return a.g !== null ? a.j + a.l() - a.g : a.j
    }
    var VX = class {
        constructor(a) {
            this.win = a;
            this.j = 0;
            this.g = null;
            this.l = UX(this.win)
        }
        start() {
            this.g === null && (this.g = this.l())
        }
    };

    function UX(a) {
        return a.performance && a.performance.now ? () => a.performance.now() : () => Date.now()
    };

    function WX(a) {
        a = new XX(a);
        a.init();
        return a
    }

    function YX(a) {
        var b = bu(a.win, 1E3, () => void a.handleEvent());
        a.win.addEventListener("scroll", () => void b())
    }

    function ZX(a) {
        var b = $X(a.win),
            c = () => {
                var d = $X(a.win),
                    e = Math.abs(d.height - b.height);
                if (Math.abs(d.width - b.width) > 20 || e > 20) a.G = !0, a.win.removeEventListener("resize", c)
            };
        a.win.addEventListener("resize", c)
    }

    function aY(a) {
        a.B = !a.g.V;
        Kt(a.g, !1, () => {
            a.win.setTimeout(() => {
                a.B = !0
            }, 100)
        })
    }

    function bY(a) {
        Jt(a.g, !0, () => void a.l.start());
        Jt(a.g, !1, () => {
            var b = a.l;
            b.g !== null && (b.j += b.l() - b.g);
            b.g = null
        });
        a.O.start()
    }

    function cY(a) {
        var b = a.win.scrollY;
        var c = ls(a.win);
        b = {
            eg: Math.floor(b / 100),
            kf: Math.floor((b + c) / 100),
            wk: a.win.performance.now()
        };
        if (b.eg < 0 || b.kf < 0 || b.eg > 1E3 || b.kf > 1E3) a.D = !0, a.j = null;
        else {
            if (a.j) {
                c = a.j;
                var d = new DC(c.eg, c.kf),
                    e = new DC(b.eg, b.kf);
                var f = Math.max(d.start, e.start);
                d = Math.min(d.end, e.end);
                if (f = f <= d ? new DC(f, d) : null)
                    for (c = b.wk - c.wk, d = f.start; d <= f.end; d++) a.C[d] = (a.C[d] ? ? 0) + c
            }
            a.j = a.A.V ? b : null
        }
    }
    var XX = class {
        constructor(a) {
            this.win = a;
            this.C = [];
            this.G = this.B = this.D = !1;
            this.j = null;
            var b = this.win;
            a = new QX(b);
            a.init();
            a = Gt(a.l);
            b = new SX(b);
            b.init();
            b = Gt(b.l);
            this.A = this.g = Ft(a, b);
            this.l = new VX(this.win);
            this.O = new VX(this.win);
            this.J = new OX((new OX(new IX)).quantizer, 0)
        }
        init() {
            YX(this);
            ZX(this);
            aY(this);
            bY(this);
            this.A.listen(() => void cY(this));
            t.setInterval(() => void this.handleEvent(), 5E3);
            this.handleEvent()
        }
        handleEvent() {
            this.A.V && cY(this)
        }
    };

    function $X(a) {
        return new wi(ks(a), ls(a))
    };

    function dY(a, {
        Xa: b
    }) {
        a = new eY(a, b);
        if (!a.Xa && U(Hw)) {
            b = a.win;
            var c = fY(gY(a));
            (new FX(b, b.document.baseURI, c)).init()
        }
        hY(a)
    }

    function hY(a) {
        if (U(Iw)) {
            var b = WX(a.win);
            ar(new FB(a.win), iY(() => {
                var c = gY(a),
                    d = new Fo,
                    e = KX(b.J, b.C);
                if (!Ju(e)) throw Nu(e, "PVDC: ").g;
                var f = new Eo;
                f = vf(f, 2, 5E3);
                f = vf(f, 1, 100);
                e = e.getValue();
                e = Kf(f, 3, e);
                f = $X(b.win);
                var g = new Do;
                g = vf(g, 1, f.width);
                f = vf(g, 2, f.height);
                e = z(e, 4, f);
                f = new Do;
                f = vf(f, 1, ps(b.win).scrollWidth);
                f = vf(f, 2, ps(b.win).scrollHeight);
                e = z(e, 5, f);
                e = tf(e, 6, b.B);
                f = Math.round(TX(b.O) / 1E3);
                e = vf(e, 8, f);
                f = Math.round(TX(b.l) / 1E3);
                e = vf(e, 9, f);
                b.D && Ye(e, 7, ed, 1, fd);
                b.G && Ye(e, 7, ed, 2, fd);
                d = A(d, 2, Go,
                    e);
                c(d)
            }))
        }
    }

    function gY(a) {
        if (!a.g) {
            let b = HB();
            a.g = c => {
                VB(b, c)
            }
        }
        return a.g
    }
    var eY = class {
        constructor(a, b) {
            this.win = a;
            this.Xa = b;
            this.g = null
        }
    };

    function fY(a) {
        return b => {
            var c = new Fo;
            b = A(c, 1, Go, b);
            return void a(b)
        }
    }

    function EX() {
        return a => {
            AB(1243, a, void 0, jY("LCC"))
        }
    }

    function iY(a) {
        return () => void wB(1243, a, jY("PVC"))
    }

    function jY(a) {
        return b => {
            b.errSrc = a
        }
    };
    const kY = {
        google: 1,
        googlegroups: 1,
        gmail: 1,
        googlemail: 1,
        googleimages: 1,
        googleprint: 1
    };

    function lY(a) {
        var b = a.google_page_location || a.google_page_url;
        "EMPTY" === b && (b = a.google_page_url);
        if (!b) return !1;
        a = b.toString();
        a.indexOf("http://") == 0 ? a = a.substring(7, a.length) : a.indexOf("https://") == 0 && (a = a.substring(8, a.length));
        b = a.indexOf("/");
        b === -1 && (b = a.length);
        a = a.substring(0, b).split(".");
        b = !1;
        a.length >= 3 && (b = a[a.length - 3] in kY);
        a.length >= 2 && (b = b || a[a.length - 2] in kY);
        return b
    };

    function mY(a, b = !1) {
        try {
            return b ? (new wi(a.innerWidth, a.innerHeight)).round() : lj(a || window).round()
        } catch (c) {
            return new wi(-12245933, -12245933)
        }
    }

    function nY(a = t) {
        a = a.devicePixelRatio;
        return oc(a) ? +a.toFixed(3) : null
    }

    function oY(a, b = t) {
        a = a.scrollingElement || (a.compatMode === "CSS1Compat" ? a.documentElement : a.body);
        return new vi(b.pageXOffset || a.scrollLeft, b.pageYOffset || a.scrollTop)
    }

    function pY(a) {
        try {
            return !(!a || !(a.offsetWidth || a.offsetHeight || a.getClientRects().length))
        } catch (b) {
            return !1
        }
    };

    function qY(a, b) {
        var c = tB,
            d;
        var e;
        d = (e = (e = or()) && (d = e.initialLayoutRect) && oc(d.top) && oc(d.left) && oc(d.width) && oc(d.height) ? new Cj(d.left, d.top, d.width, d.height) : null) ? new vi(e.left, e.top) : (d = rr()) && d.rootBounds && ra(d.rootBounds) ? new vi(d.rootBounds.left + d.boundingClientRect.left, d.rootBounds.top + d.boundingClientRect.top) : null;
        if (d) return d;
        try {
            {
                let h = new vi(0, 0),
                    k = nj(ij(b));
                if (sb(k, "parent")) {
                    do {
                        if (k == a) var f = Rj(b);
                        else {
                            let l = Mj(b);
                            f = new vi(l.left, l.top)
                        }
                        d = f;
                        h.x += d.x;
                        h.y += d.y
                    } while (k && k != a && k != k.parent &&
                        (b = k.frameElement) && (k = k.parent))
                }
                var g = h
            }
            return g
        } catch (h) {
            return c.Da(888, h), new vi(-12245933, -12245933)
        }
    }

    function rY(a, b, c, d = !1) {
        a = qY(a, c);
        c = sr() || mY(b.top);
        if (!a || a.y === -12245933 || c.width === -12245933 || c.height === -12245933 || !c.height) return 0;
        var e = 0;
        try {
            let f = b.top;
            e = oY(f.document, f).y
        } catch (f) {
            return 0
        }
        b = e + c.height;
        return a.y < e ? d ? 0 : (e - a.y) / c.height : a.y > b ? (a.y - b) / c.height : 0
    };

    function sY(a) {
        a.asro = U(qx);
        V(wx) && (a.aiact = V(wx));
        V(Dx) && (a.aicct = V(Dx));
        V(Fx) && (a.ailct = V(Fx));
        a.aiactd = V(vx);
        a.aicctd = V(Cx);
        a.ailctd = V(Ex);
        a.aimartd = V(Gx);
        var b = dr(nz).l(hx.g, hx.defaultValue);
        a.aiof = b.length ? b.join("~") : void 0
    };

    function tY(a) {
        a = IQ(a, 600, "__lsa__");
        var b = V(kv);
        return a ? .length ? Math.floor((Date.now() - Math.max(...a)) / 6E4) <= b : !1
    };
    var uY = {
            oo: "google_ads_preview",
            yo: "google_anchor_debug",
            xo: "google_bottom_anchor_debug",
            INTERSTITIAL: "google_ia_debug",
            Po: "google_scr_debug",
            So: "google_ia_debug_allow_onclick",
            Xo: "googleads",
            Ik: "google_pedestal_debug",
            fp: "google_responsive_slot_preview",
            ep: "google_responsive_dummy_ad"
        },
        vY = {
            google_bottom_anchor_debug: 1,
            google_anchor_debug: 2,
            google_ia_debug: 8,
            google_scr_debug: 9,
            googleads: 2,
            google_pedestal_debug: 30
        };
    var wY = {
        INTERSTITIAL: 1,
        BOTTOM_ANCHOR: 2,
        TOP_ANCHOR: 3,
        1: "INTERSTITIAL",
        2: "BOTTOM_ANCHOR",
        3: "TOP_ANCHOR"
    };

    function xY(a, b) {
        if (!a) return !1;
        a = a.hash;
        if (!a || !a.indexOf) return !1;
        if (a.indexOf(b) != -1) return !0;
        var c = "";
        for (let d of b.split("_")) c += d.substring(0, 2);
        b = c;
        return b != "go" && a.indexOf(b) != -1 ? !0 : !1
    }

    function yY() {
        var a = t.location,
            b = !1;
        Fk(uY, c => {
            xY(a, c) && (b = !0)
        });
        return b
    }

    function zY(a, b) {
        switch (a) {
            case 1:
                return xY(b, "google_ia_debug");
            case 2:
                return xY(b, "google_bottom_anchor_debug");
            case 3:
                return xY(b, "google_anchor_debug") || xY(b, "googleads")
        }
    };

    function AY(a, b) {
        return uC({
            K: a,
            Km: 3E3,
            Sm: a.innerWidth > is ? 450 : 0,
            F: rB,
            ul: b,
            rm: U(Mv)
        })
    };

    function BY(a) {
        var b = 0;
        try {
            b |= js(a)
        } catch (c) {
            b |= 32
        }
        return b
    };

    function CY(a) {
        var b = 0;
        try {
            b |= js(a), b |= ms(a, 1E4)
        } catch (c) {
            b |= 32
        }
        return b
    };

    function DY() {
        var a = {};
        oz(Nv) && (a.bust = oz(Nv));
        return a
    };

    function EY(a) {
        return a.prerendering ? 3 : {
            visible: 1,
            hidden: 2,
            prerender: 3,
            preview: 4,
            unloaded: 5,
            "": 0
        }[a.visibilityState || a.webkitVisibilityState || a.mozVisibilityState || ""] ? ? 0
    }

    function FY(a) {
        return a.hidden != null ? a.hidden : a.mozHidden != null ? a.mozHidden : a.webkitHidden != null ? a.webkitHidden : null
    }

    function GY(a, b) {
        if (EY(b) === 3) var c = !1;
        else a(), c = !0;
        if (!c) {
            let d = () => {
                Zj(b, "prerenderingchange", d);
                a()
            };
            Yj(b, "prerenderingchange", d)
        }
    };
    Array.from({
        length: 11
    }, (a, b) => b / 10);

    function HY(a, b = !1) {
        var c = 0;
        try {
            c |= js(a);
            var d;
            if (!(d = !a.navigator)) {
                var e = a.navigator;
                d = "brave" in e && "isBrave" in e.brave || !1
            }
            c |= d || /Android 2/.test(a.navigator.userAgent) ? 1048576 : 0;
            c |= ms(a, b ? Number.MAX_SAFE_INTEGER : 2500, !0)
        } catch (f) {
            c |= 32
        }
        return c
    };
    const IY = ["body", "html"];

    function JY(a, b = null, c) {
        var d = js(a);
        vC(a.navigator ? .userAgent) && (d |= 1048576);
        var e = a.innerWidth;
        e < 1200 && (d |= 65536);
        var f = a.innerHeight;
        f < 650 && (d |= 2097152);
        b && d === 0 && (b = b === 3 ? "left" : "right", (c = KY({
            K: a,
            An: 1,
            position: b,
            ba: e,
            ga: f,
            ud: new Set,
            minWidth: 120,
            minHeight: 500,
            flags: c
        })) ? bC(a).sideRailPlasParam.set(b, `${c.width}x${c.height}_${String(b).charAt(0)}`) : d |= 16);
        return d
    }

    function LY(a) {
        a = bC(a).sideRailPlasParam;
        return [...Array.from(a.values())].join("|")
    }

    function MY(a, b) {
        return wj(a, c => c.nodeType === Node.ELEMENT_NODE && b.has(c)) !== null
    }

    function NY(a) {
        return wj(a, b => b.nodeType === Node.ELEMENT_NODE && b.hasAttribute("google-side-rail-overlap")) ? .getAttribute("google-side-rail-overlap") || null
    }

    function OY(a, b) {
        return wj(a, c => c.nodeType === Node.ELEMENT_NODE && b.getComputedStyle(c, null).position === "fixed")
    }

    function PY(a) {
        var b = [];
        for (let c of a.document.querySelectorAll("*")) {
            let d = a.getComputedStyle(c, null);
            d.position === "fixed" && d.display !== "none" && d.visibility !== "hidden" && b.push(c)
        }
        return b
    }

    function QY(a, b) {
        var {
            top: c,
            left: d,
            bottom: e,
            right: f
        } = b.getBoundingClientRect();
        return c >= 0 && d >= 0 && e <= a.innerHeight && f <= a.innerWidth
    }

    function RY(a, b, c = !1) {
        var d = NY(a);
        if (d === "true") return !0;
        if (d === "false" || c && !b.flags.Yj && !b.flags.hi) return !1;
        if (b.flags.Zj && IY.includes(a.tagName.toLowerCase())) return !0;
        if (b.flags.hi) {
            let {
                width: e,
                height: f,
                top: g
            } = a.getBoundingClientRect();
            a = f >= b.ga * .25;
            d = e >= b.ba * .9;
            return c ? d && a : d ? a ? !0 : g + (b.K.scrollY || b.K.pageYOffset) > b.ga * .15 : !1
        }
        c = a.offsetHeight >= b.ga * .25;
        return a.offsetWidth >= b.ba * .9 && c
    }

    function SY(a) {
        return Math.round(Math.round(a / 10) * 10)
    }

    function TY(a) {
        return `${a.position}-${SY(a.ba)}x${SY(a.ga)}-${SY(a.scrollY+a.Qd)}Y`
    }

    function UY(a) {
        return `f-${TY({position:a.position,Qd:a.Qd,scrollY:0,ba:a.ba,ga:a.ga})}`
    }

    function VY(a, b) {
        a = Math.min(a ? ? Infinity, b ? ? Infinity);
        return a !== Infinity ? a : 0
    }

    function WY(a, b, c) {
        var d = bC(c.K).sideRailProcessedFixedElements;
        if (!d.has(a)) {
            var e = a.getBoundingClientRect();
            if (e) {
                var f = Math.max(e.top - 10, 0),
                    g = Math.min(e.bottom + 10, c.ga),
                    h = Math.max(e.left - 10, 0);
                e = Math.min(e.right + 10, c.ba);
                for (var k = c.ba * .3; f <= g; f += 10) {
                    if (e > 0 && h < k) {
                        var l = UY({
                            position: "left",
                            Qd: f,
                            ba: c.ba,
                            ga: c.ga
                        });
                        b.set(l, VY(b.get(l), h))
                    }
                    if (h < c.ba && e > c.ba - k) {
                        l = UY({
                            position: "right",
                            Qd: f,
                            ba: c.ba,
                            ga: c.ga
                        });
                        let m = c.ba - e;
                        b.set(l, VY(b.get(l), m))
                    }
                }
                d.add(a)
            }
        }
    }

    function XY(a, b) {
        var c = b.K,
            d = b.flags,
            e = `f-${SY(b.ba)}x${SY(b.ga)}`;
        a.has(e) || (a.set(e, 0), e = PY(c), d.Cj || d.ai ? (YY(a, b, e.filter(f => QY(c, f))), ZY(c, e.filter(f => !QY(c, f)).concat(d.ai ? Array.from(c.document.querySelectorAll("[google-side-rail-overlap=false]")) : []))) : YY(a, b, e))
    }

    function YY(a, b, c) {
        var d = b.ud,
            e = b.K;
        bC(e).sideRailProcessedFixedElements.clear();
        d = new Set([...Array.from(e.document.querySelectorAll("[data-anchor-status],[data-side-rail-status]")), ...d]);
        for (let f of c) MY(f, d) || RY(f, b, !0) || WY(f, a, b)
    }

    function $Y(a) {
        if (a.ba < 1200 || a.ga < 650) return null;
        var b = bC(a.K).sideRailAvailableSpace;
        XY(b, {
            K: a.K,
            ba: a.ba,
            ga: a.ga,
            ud: a.ud,
            flags: a.flags
        });
        var c = [],
            d = a.ga * .9,
            e = ts(a.K),
            f = (a.ga - d) / 2,
            g = f,
            h = d / 7;
        for (var k = 0; k < 8; k++) {
            var l = c,
                m = l.push;
            a: {
                var n = g;
                var p = a.position,
                    q = b,
                    u = {
                        K: a.K,
                        ba: a.ba,
                        ga: a.ga,
                        ud: a.ud,
                        flags: a.flags
                    };
                let B = UY({
                        position: p,
                        Qd: n,
                        ba: u.ba,
                        ga: u.ga
                    }),
                    G = TY({
                        position: p,
                        Qd: n,
                        scrollY: e,
                        ba: u.ba,
                        ga: u.ga
                    });
                if (q.has(G)) {
                    n = VY(q.get(B), q.get(G));
                    break a
                }
                let K = p === "left" ? 20 : u.ba - 20,
                    H = K;p = u.ba * .3 / 5 * (p === "left" ?
                    1 : -1);
                let L = 0,
                    S = !1;
                for (let da = 0; da < 6; da++) {
                    var w = lC(u.K.document, {
                        x: Math.round(H),
                        y: Math.round(n)
                    });
                    let Ea = OY(w, u.K),
                        ka = MY(w, u.ud);
                    w = RY(w, u) || ka;
                    if (Ea === null || ka)
                        if (w) L = Math.round(Math.abs(H - K) + 20);
                        else if (H !== K) H -= p, p /= 2;
                    else {
                        L = 0;
                        break
                    } else {
                        q.delete(G);
                        S = !0;
                        if (!Ea || !RY(Ea, u, !0)) {
                            WY(Ea, q, u);
                            L = q.get(B) ? ? 0;
                            break
                        }
                        L = Math.round(Math.abs(H - K) + 20)
                    }
                    H += p
                }
                S || q.set(G, L);n = L
            }
            m.call(l, n);
            g += h
        }
        b = a.An;
        e = a.position;
        d = Math.round(d / 8);
        f = Math.round(f);
        g = a.minWidth;
        a = a.minHeight;
        m = [];
        h = Array(c.length).fill(0);
        for (l =
            0; l < c.length; l++) {
            for (; m.length !== 0 && c[m[m.length - 1]] >= c[l];) m.pop();
            h[l] = m.length === 0 ? 0 : m[m.length - 1] + 1;
            m.push(l)
        }
        m = [];
        k = c.length - 1;
        l = Array(c.length).fill(0);
        for (n = k; n >= 0; n--) {
            for (; m.length !== 0 && c[m[m.length - 1]] >= c[n];) m.pop();
            l[n] = m.length === 0 ? k : m[m.length - 1] - 1;
            m.push(n)
        }
        m = null;
        for (k = 0; k < c.length; k++)
            if (n = {
                    position: e,
                    width: Math.round(c[k]),
                    height: Math.round((l[k] - h[k] + 1) * d),
                    offsetY: f + h[k] * d
                }, q = n.width >= g && n.height >= a, b === 0 && q) {
                m = n;
                break
            } else b === 1 && q && (!m || n.width * n.height > m.width * m.height) && (m =
                n);
        return m
    }

    function ZY(a, b) {
        var c = bC(a);
        if (b.length && !c.g) {
            var d = new MutationObserver(() => {
                setTimeout(() => {
                    aZ(a);
                    for (let e of c.sideRailMutationCallbacks) e()
                }, 500)
            });
            for (let e of b) d.observe(e, {
                attributes: !0
            });
            c.g = d
        }
    }

    function aZ(a) {
        ({
            sideRailAvailableSpace: a
        } = bC(a));
        var b = Array.from(a.keys()).filter(c => c.startsWith("f-"));
        for (let c of b) a.delete(c)
    }

    function KY(a) {
        if (a.ob) return a.ob.Yb(1228, () => $Y(a)) || null;
        try {
            return $Y(a)
        } catch {}
        return null
    };
    const bZ = {
        [27]: 512,
        [26]: 128
    };
    var cZ = (a, b, c, d) => {
            d = sI(d);
            switch (c) {
                case 1:
                case 2:
                    return AY(a, c) === 0;
                case 3:
                case 4:
                    return JY(a, c, {
                        Cj: !0,
                        ai: !0,
                        Zj: U(Fw),
                        Yj: U(Ew),
                        hi: U(Gw)
                    }) === 0;
                case 8:
                    return HY(a, U(wv)) === 0;
                case 9:
                    return b = !(b.google_adtest === "on" || xY(a.location, "google_scr_debug")), !JQ(a, b, d);
                case 30:
                    return MS(a) === 0;
                case 26:
                    return CY(a) === 0;
                case 27:
                    return BY(a) === 0;
                case 40:
                    return !0;
                default:
                    return !1
            }
        },
        dZ = (a, b, c, d) => {
            d = d ? sI(d) : null;
            switch (c) {
                case 0:
                case 40:
                case 10:
                case 11:
                    return 0;
                case 1:
                case 2:
                    return AY(a, c);
                case 3:
                case 4:
                    return JY(a,
                        c, {
                            Cj: !1,
                            ai: !1,
                            Zj: !1,
                            Yj: U(Ew),
                            hi: U(Gw)
                        });
                case 8:
                    return HY(a, U(wv));
                case 9:
                    return JQ(a, !(b.google_adtest === "on" || xY(a.location, "google_scr_debug")), d);
                case 16:
                    return zS(b, a) ? 0 : 8388608;
                case 30:
                    return MS(a);
                case 26:
                    return CY(a);
                case 27:
                    return BY(a);
                default:
                    return 32
            }
        },
        eZ = a => {
            if (!a.hash) return null;
            var b = null;
            Fk(uY, c => {
                !b && xY(a, c) && (b = vY[c] || null)
            });
            return b
        },
        gZ = (a, b) => {
            var c = bC(a).tagSpecificState[1] || null;
            c !== null && c.debugCard == null && Fk(wY, d => {
                !c.debugCardRequested && oc(d) && zY(d, a.location) && (c.debugCardRequested = !0, fZ(a, b, e => {
                    c.debugCard = e.createDebugCard(d, a)
                }))
            })
        },
        iZ = (a, b, c) => {
            if (!b) return null;
            var d = bC(b),
                e = 0;
            Fk(Ci, f => {
                var g = bZ[f];
                g && hZ(a, b, f, c) === 0 && (e |= g)
            });
            d.wasPlaTagProcessed && (e |= 256);
            a.google_reactive_tag_first && (e |= 1024);
            return e ? `${e}` : null
        },
        jZ = (a, b, c) => {
            var d = [];
            Fk(Ci, e => {
                var f = hZ(b, a, e, c);
                f !== 0 && d.push(`${e}:${f}`)
            });
            return d.join(",") || null
        },
        kZ = a => {
            var b = [],
                c = {};
            Fk(a, (d, e) => {
                if ((e = Jr[e]) && !c[e]) {
                    c[e] = !0;
                    if (d) d = 1;
                    else if (d === !1) d = 2;
                    else return;
                    b.push(`${e}:${d}`)
                }
            });
            return b.join(",")
        };

    function lZ(a) {
        a = a.overlays;
        if (!a) return "";
        a = a.bottom;
        return pc(a) ? a ? "1" : "0" : ""
    }

    function mZ(a) {
        return (a = a.overlays) ? a["collapsed-bottom"] === !0 : !1
    }
    var hZ = (a, b, c, d) => {
            if (!b) return 256;
            var e = 0,
                f = bC(b),
                g = qs(f, c);
            if (a.google_reactive_ad_format === c || g) e |= 64;
            var h = !1;
            Fk(f.reactiveTypeDisabledByPublisher, (k, l) => {
                String(c) === String(l) && (h = !0)
            });
            return h && eZ(b.location) !== c && (e |= 128, c === 2 || c === 1 || c === 3 || c === 4 || c === 8) ? e : e | dZ(b, a, c, d)
        },
        nZ = (a, b) => {
            if (a) {
                var c = bC(a),
                    d = {};
                Fk(b, (e, f) => {
                    (f = Jr[f]) && (e === !1 || /^false$/i.test(e)) && (d[f] = !0)
                });
                Fk(Ci, e => {
                    d[hs[e]] && (c.reactiveTypeDisabledByPublisher[e] = !0)
                })
            }
        },
        oZ = (a, b, c) => {
            b = xB(b, c);
            c = { ...DY()
            };
            return wX(1, window,
                gi(a, new Map(Object.entries(c)))).then(b)
        },
        fZ = (a, b, c) => {
            c = xB(212, c);
            wX(3, a, b).then(c)
        },
        pZ = a => {
            a = a.google_reactive_ad_format;
            return Bi(a) ? `${a}` : null
        },
        qZ = a => !!pZ(a) || a.google_pgb_reactive != null,
        rZ = a => {
            a = Number(pZ(a));
            return a === 26 || a === 27 || a === 30 || a === 16 || a === 40 || a === 41
        };

    function sZ(a) {
        return oc(a.google_reactive_sra_index)
    }

    function tZ(a) {
        return U(Mx) ? (a = a.google_ama_state = a.google_ama_state || {}, (a.numAutoAdsPlaced ? ? 0) > 0 || (a.eatf ? ? !1) || (a.eatfAbg ? ? !1)) : !1
    }

    function uZ(a, b, c) {
        var d = b.K || b.pubWin,
            e = b.I,
            f = sI(c);
        c = jZ(d, e, c);
        e.google_reactive_plat = c;
        (c = kZ(a)) && (e.google_reactive_plaf = c);
        (c = lZ(a)) && (e.google_reactive_fba = c);
        vZ(a, e);
        c = eZ(b.pubWin.location);
        wZ(a, c, e);
        c ? (e.fra = c, e.google_pgb_reactive = 6) : e.google_pgb_reactive = 5;
        sY(e);
        e.fsapi = !0;
        c !== 8 && (f && FQ(f) ? (c = IQ(f, 86400, "__lsv__"), c ? .length && (c = Math.floor((Date.now() - Math.max(...c)) / 6E4), c >= 0 && (e.vmsli = c))) : e.vmsli = -1);
        mZ(a) ? e.dap = 2 : tY(f) && (e.dap = 3);
        tZ(d) && !e.dap && (e.dap = 5);
        sr() || mY(b.pubWin.top);
        c = WW(b.pubWin,
            "rsrai", xB(429, (g, h) => xZ(b, d, e.google_ad_client, a, g, h, f)), xB(430, (g, h) => ws(b.pubWin, "431", rB, h)));
        b.Ia.push(c);
        bC(d).wasReactiveTagRequestSent = !0;
        yZ(b, a, f)
    }

    function yZ(a, b, c) {
        var d = a.I,
            e = ra(b.page_level_pubvars) ? b.page_level_pubvars : {};
        b = WW(a.pubWin, "apcnf", xB(353, (f, g) => {
            var h = a.pubWin,
                k = d.google_ad_client,
                l = a.Na.lg;
            return tl(g.origin) ? yX(h, k, e, f.config, c, l, null) : !1
        }), xB(353, (f, g) => ws(a.pubWin, "353", rB, g)));
        a.Ia.push(b)
    }

    function xZ(a, b, c, d, e, f, g) {
        if (!tl(f.origin)) return !1;
        f = e.data;
        if (!Array.isArray(f)) return !1;
        if (!fB(b, 1)) return !0;
        f && Kl(6, [f]);
        e = e.amaConfig;
        var h = [],
            k = bC(b),
            l = null;
        for (let n = 0; n < f.length; n++) {
            if (!f[n]) continue;
            let p = f[n];
            var m = p.adFormat;
            k && p.enabledInAsfe && (k.reactiveTypeEnabledInAsfe[m] = !0);
            if (!p.noCreative) {
                p.google_reactive_sra_index = n;
                if (m === 9 && e && (p.pubVars = Object.assign(p.pubVars || {}, zZ(d, p)), m = new KQ, DQ(m, p) && m.A(p))) {
                    l = m;
                    continue
                }
                h.push(p)
            }
        }
        h.length && oZ(a.Na.hk, 522, n => {
            AZ(h, b, n, d, g)
        });
        e &&
            yX(b, c, d, e, g, a.Na.lg, l);
        return !0
    }

    function zZ(a, b) {
        var c = b.adFormat,
            d = b.adKey;
        delete b.adKey;
        var e = {};
        a = a.page_level_pubvars;
        ra(a) && Object.assign(e, a);
        e.google_ad_unit_key = d;
        e.google_reactive_sra_index = b.google_reactive_sra_index;
        c === 30 && (e.google_reactive_ad_format = 30);
        e.google_pgb_reactive = e.google_pgb_reactive || 5;
        return b.pubVars = e
    }

    function AZ(a, b, c, d, e) {
        for (let f = 0; f < a.length; f++) {
            let g = a[f],
                h = g.adFormat,
                k = g.adKey,
                l = c.configProcessorForAdFormat(h);
            h && l && k && (g.pubVars = zZ(d, g), delete g.google_reactive_sra_index, wB(466, () => l.verifyAndProcessConfig(b, g, e)))
        }
    }

    function vZ(a, b) {
        var c = [],
            d = !1;
        Fk(Jr, (e, f) => {
            var g;
            a.hasOwnProperty(f) && (f = a[f], f ? .google_ad_channel && (g = String(f.google_ad_channel)));
            --e;
            c[e] && c[e] !== "+" || (c[e] = g ? g.replace(/,/g, "+") : "+", d || (d = !!g))
        });
        d && (b.google_reactive_sra_channels = c.join(","))
    }

    function wZ(a, b, c) {
        if (!c.google_adtest) {
            var d = a.page_level_pubvars;
            if (a.google_adtest === "on" || d ? .google_adtest === "on" || b) c.google_adtest = "on"
        }
    };
    const BZ = /^blogger$/,
        CZ = /^wordpress(.|\s|$)/i,
        DZ = /^joomla!/i,
        EZ = /^drupal/i,
        FZ = /\/wp-content\//,
        GZ = /\/wp-content\/plugins\/advanced-ads/,
        HZ = /\/wp-content\/themes\/genesis/,
        IZ = /\/wp-content\/plugins\/genesis/;

    function JZ(a) {
        var b = a.getElementsByTagName("script"),
            c = b.length;
        for (var d = 0; d < c; ++d) {
            var e = b[d];
            if (e.hasAttribute("src")) {
                e = e.getAttribute("src") || "";
                if (GZ.test(e)) return 5;
                if (IZ.test(e)) return 6
            }
        }
        b = a.getElementsByTagName("link");
        c = b.length;
        for (d = 0; d < c; ++d)
            if (e = b[d], e.hasAttribute("href") && (e = e.getAttribute("href") || "", HZ.test(e) || IZ.test(e))) return 6;
        a = a.getElementsByTagName("meta");
        d = a.length;
        for (e = 0; e < d; ++e) {
            var f = a[e];
            if (f.getAttribute("name") == "generator" && f.hasAttribute("content")) {
                f = f.getAttribute("content") ||
                    "";
                if (BZ.test(f)) return 1;
                if (CZ.test(f)) return 2;
                if (DZ.test(f)) return 3;
                if (EZ.test(f)) return 4
            }
        }
        for (a = 0; a < c; ++a)
            if (d = b[a], d.getAttribute("rel") == "stylesheet" && d.hasAttribute("href") && (d = d.getAttribute("href") || "", FZ.test(d))) return 2;
        return 0
    };
    var KZ = class extends Error {
            constructor(a) {
                super(a)
            }
        },
        LZ = class {
            constructor(a) {
                this.reason = a
            }
        };
    class MZ {
        constructor() {
            this.g = !1
        }
    }

    function NZ(a, b) {
        a.g || (a.g = !0, a.B = b, a.l.resolve(b))
    }

    function OZ(a, b, c) {
        a.g = !0;
        a.j = b;
        c && c(a.j);
        a.l.reject(b)
    }
    class PZ extends MZ {
        constructor() {
            super(...arguments);
            this.l = new $W
        }
        get promise() {
            return this.l.promise
        }
        get lk() {
            return this.g
        }
        get error() {
            return this.j
        }
    }

    function QZ(a, b) {
        NZ(a, b)
    }

    function RZ(a, b) {
        b.then(c => {
            NZ(a, c)
        }).catch(c => {
            a.setError(c, void 0)
        })
    }
    var SZ = class extends PZ {
        setError(a, b) {
            this.g || (this.g = !0, this.B = null, this.j = a, b && b(this.j), this.l.reject(a))
        }
    };
    class TZ extends MZ {
        constructor(a) {
            super();
            this.l = a
        }
        get error() {
            return this.l.j
        }
        lk() {
            return this.l.g
        }
    }
    var UZ = class extends TZ {
        constructor(a) {
            super(a);
            this.l = a
        }
        get value() {
            return this.l.B ? ? null
        }
    };

    function VZ(a, b, c) {
        b.then(() => {
            a.notify()
        }).catch(d => {
            OZ(a, d, c)
        })
    }
    var WZ = class extends PZ {
            notify() {
                NZ(this, null)
            }
        },
        XZ = class extends SZ {
            constructor(a, b = !1) {
                super();
                a = a.map(c => c.promise.then(d => {
                    if (b || d != null) return d;
                    throw d;
                }, d => {
                    OZ(this, d);
                    return null
                }));
                ja(Promise, "any").call(Promise, a).then(c => {
                    this.g || NZ(this, c)
                }, () => {
                    this.g || NZ(this, null)
                })
            }
        };

    function YZ(a, b) {
        a.j.push({
            Ve: !1,
            Rg: b
        })
    }
    var ZZ = class extends O {
        constructor() {
            super(...arguments);
            this.l = [];
            this.j = [];
            this.A = []
        }
        Ve(a) {
            var b = this.j.find(c => c.Rg === a);
            b && (b.Ve = !0)
        }
        g() {
            this.l.length = 0;
            this.A.length = 0;
            this.j.length = 0;
            super.g()
        }
    };
    async function $Z(a, b) {
        var c = b ? a.filter(d => !d.Ve) : a;
        await Promise.all(c.map(({
            Rg: d
        }) => d.promise));
        a.length !== c.length && (a = a.filter(d => d.Ve), await Promise.race([Promise.all(a.map(({
            Rg: d
        }) => d.promise)), new Promise(d => void setTimeout(d, b))]))
    }

    function a_(a, b = new SZ) {
        a.l.l.push(b);
        return b
    }
    var b_ = class extends O {
        constructor(a, b) {
            super();
            this.id = a;
            this.G = b;
            this.timeoutMs = void 0;
            this.D = !1;
            this.l = new ZZ;
            wt(this, this.l)
        }
        async start() {
            if (!this.D) {
                this.D = !0;
                try {
                    if (await $Z(this.l.j, this.la ? ? this.timeoutMs), !this.B) {
                        let a = 0;
                        for (let b of this.l.A) {
                            if (b.l.B == null) throw Error(`missing input: ${this.id}/${a}`);
                            ++a
                        }
                        this.W()
                    }
                } catch (a) {
                    this.B || (a instanceof KZ ? this.P(a) : a instanceof Error && (this.G.Ja({
                        methodName: this.id,
                        eb: a
                    }), this.j(a)))
                }
            }
        }
        P() {}
        j(a) {
            if (this.l.l.length) {
                var b = new KZ(a.message);
                for (let c of this.l.l) c.lk ||
                    OZ(c, b)
            }
            a instanceof KZ || console ? .error(a)
        }
    };

    function c_(a) {
        var b = {};
        for (let [c, d] of Object.entries(a.Z)) b[c] = d.value;
        return b
    }

    function X(a, b) {
        if (a.D) throw Error("Invalid operation: producer has already started");
        YZ(a.l, b);
        return a
    }
    var d_ = class extends b_ {
        constructor(a, b, c, d, e) {
            super(a, c);
            this.f = b;
            this.J = e;
            a = {};
            for (let [f, g] of Object.entries(d))
                if (d = g) YZ(this.l, d), a[f] = new UZ(d);
            this.Z = a
        }
        W() {
            var a = this.f(c_(this), ...this.J);
            this.A(a)
        }
        P(a) {
            this.j(a)
        }
        reportError() {}
    };
    class e_ extends d_ {
        constructor(a, b, c, d, e, f, g) {
            super(a, b, c, d, g);
            this.qa = f;
            this.finished = new WZ;
            a = Object.keys(e);
            for (let h of a) this[h] = a_(this)
        }
        A(a) {
            for (let [b, c] of Object.entries(a)) {
                a = b;
                let d = c;
                d instanceof Error && this[a].setError(d);
                d instanceof LZ || NZ(this[a], d)
            }
            this.finished.notify()
        }
        j(a) {
            this.qa ? this.A(this.qa(a)) : super.j(a)
        }
    }

    function Y(a, b) {
        a.id = b.id;
        a.H = b.H;
        a.qa = b.qa;
        return a
    }

    function f_(a, b, c, ...d) {
        return new e_(a.id, a, b, c, a.H, a.qa, d)
    };

    function g_(a, b) {
        a = b.PygXN.map(c => {
            var d = new ok;
            d = Jf(d, 1, c.aJhyn);
            c = Pe(d, 2, Pf, Ed(c.ihulF));
            return sf(c, 4, !1)
        });
        a = a.length > 0 ? sk(pk(), a) : sk(new qk, []);
        return {
            Fe: a,
            Zf: [a]
        }
    }
    var h_ = Y(g_, {
        id: 1377,
        H: {
            Fe: void 0,
            Zf: void 0
        }
    });
    var i_ = {
        cj: [],
        Vi: 0,
        ij: [],
        Ap: !1
    };

    function j_(a, b = window, c = () => {}) {
        try {
            return b.localStorage.getItem(a)
        } catch (d) {
            return c(d), null
        }
    }

    function k_(a, b, c = window, d = () => {}) {
        return b.ha() ? j_(a, c, d) : null
    }

    function l_(a, b, c = window, d = () => {}) {
        try {
            return c.localStorage.setItem(a, b), !0
        } catch (e) {
            d(e)
        }
        return !1
    }

    function m_(a, b, c, d = window, e = () => {}) {
        return c.ha() ? l_(a, b, d, e) : !1
    }

    function n_(a, b = window, c = () => {}) {
        try {
            b.localStorage.removeItem(a)
        } catch (d) {
            c(d)
        }
    }

    function o_(a, b, c = window, d = () => {}) {
        b.ha() && n_(a, c, d)
    }

    function p_(a = window, b = () => {}) {
        try {
            return a.localStorage.length
        } catch (c) {
            b(c)
        }
        return null
    }

    function q_(a) {
        var b = window,
            c = () => {};
        return a.ha() ? p_(b, c) : null
    }

    function r_(a, b = window, c = () => {}) {
        try {
            return b.localStorage.key(a)
        } catch (d) {
            c(d)
        }
        return null
    }

    function s_(a, b) {
        var c = window,
            d = () => {};
        return b.ha() ? r_(a, c, d) : null
    }

    function t_(a = window, b = () => {}) {
        try {
            return Object.keys(a.localStorage)
        } catch (c) {
            b(c)
        }
        return null
    }

    function u_(a) {
        var b = window,
            c = () => {};
        return a.ha() ? t_(b, c) : null
    };
    class v_ {
        static vj() {
            throw Error("Must be overridden");
        }
    }
    class w_ extends v_ {
        constructor() {
            super(...arguments);
            this.g = 0
        }
    }(function() {
        var a = w_;
        a.Oc = void 0;
        a.vj = function() {
            return a.Oc ? a.Oc : a.Oc = new a
        }
    })();

    function x_(a, b, c = null, d = {}, e) {
        var f = w_.vj(),
            g = e ? .pk ? ? 1E3;
        f.g === 0 && (f.g = Math.random() < 1 / g ? 2 : 1);
        f.g === 2 && (e && Tq(e.F, y_(a, b, c, d, e.Lh, g)), zl({
            c: String(a),
            pc: String(ul(window)),
            em: c,
            lid: b,
            eids: $q().join(),
            ...d
        }, "esp"))
    }

    function y_(a, b, c = null, d = {}, e, f) {
        var g = new hq;
        a = F(g, 1, a);
        e = Yk(window, e);
        e = xf(a, 2, e);
        c = Kf(e, 3, c);
        b = Kf(c, 4, b);
        c = $q();
        b = Ne(b, 5, c, gd);
        f = vf(b, 8, f);
        d.sl && yf(f, 6, iq, Number(d.sl));
        d.url && Pe(f, 7, iq, Ed(d.url));
        return f
    };

    function z_() {
        var a = window;
        return new Promise(b => {
            var c = () => {
                b(void 0);
                Zj(a, "load", c)
            };
            Yj(a, "load", c)
        })
    }

    function A_(a) {
        var b = [],
            c = RegExp("^_GESPSK-(.+)$"),
            d = q_(a);
        for (let f = 0; f < (d ? ? 0); f++) {
            var e = s_(f, a);
            if (e === null) continue;
            (e = (c.exec(e) || [])[1]) && b.push(e)
        }
        return b
    };

    function B_() {
        C_ || (C_ = new D_);
        return C_
    }

    function E_(a) {
        var b = LH(cf(a, 3));
        if (!b) return 3;
        if (qf(a, 2) === void 0) return 4;
        a = Date.now();
        return a > b + 2592E5 ? 2 : a > b + 432E5 ? 1 : 0
    }

    function F_(a, b, c, d) {
        function e(g) {
            x_(8, b, g ? .message, {}, f)
        }
        var f;
        d ? n_(`_GESPSK-${b}`, window, e) : o_(`_GESPSK-${b}`, c, window, e);
        delete a.cache[b]
    }
    var D_ = class {
            constructor() {
                this.cache = {}
            }
            get(a, b, c, d) {
                function e(h) {
                    x_(6, a, h ? .message, {}, d);
                    f = !0
                }
                if (this.cache[a]) return {
                    U: this.cache[a],
                    success: !0
                };
                var f = !1,
                    g = `_GESPSK-${a}`;
                b = c ? j_(g, window, e) : k_(g, b, window, e);
                if (f) return {
                    U: null,
                    success: !1
                };
                if (!b) return {
                    U: null,
                    success: !0
                };
                try {
                    let h = Ck(b);
                    this.cache[a] = h;
                    return {
                        U: h,
                        success: !0
                    }
                } catch (h) {
                    return x_(5, a, h ? .message, {}, d), {
                        U: null,
                        success: !1
                    }
                }
            }
            set(a, b, c, d) {
                function e(h) {
                    x_(7, f, h ? .message, {}, d)
                }
                var f = a.hb(),
                    g = `_GESPSK-${f}`;
                Bk(a);
                if (c ? !l_(g, pg(a), window,
                        e) : !m_(g, pg(a), b, window, e)) return !1;
                this.cache[f] = a;
                return !0
            }
        },
        C_ = null;

    function G_(a, b, c) {
        return !!a.g ? .get(c) ? .get(b) ? .some(d => C(d, 4))
    }

    function H_(a, b) {
        for (let c of a.g.values())
            if (c.get(b) ? .some(d => C(d, 4))) return !0;
        return !1
    }

    function I_(a, b, c) {
        var d = new Set;
        a = a.g.get(b);
        if (!a) return d;
        for (let [e, f] of a.entries()) a = e, f.some(g => c(g)) && d.add(a);
        return d
    }

    function J_(a, b) {
        return I_(a, b, c => C(c, 4))
    }
    var K_ = class {
        constructor(a) {
            var b = new Map;
            for (let c of a) {
                a = D(c, 1);
                let d = b.get(a) ? ? new Map;
                for (let e of rk(c)) {
                    let f = e.hb();
                    d.has(f) || d.set(f, []);
                    d.get(f).push(e)
                }
                b.set(a, d)
            }
            this.g = b
        }
    };

    function L_(a, b) {
        return [].some(c => G_(b, a, c))
    };

    function M_(a, b, c, d) {
        ({
            Fe: a
        } = g_({}, a.pageState.jzoix)); {
            var e = [a];
            a = new Map;
            x_(56, "", null, void 0, d);
            var f = a;
            e = new K_(e ? ? []);
            var g = Array,
                h = g.from,
                k = [];
            let n = new Set(A_(c));
            for (var l of k)
                for (var m of J_(e, l)) n.add(m);
            l = h.call(g, n);
            for (let p of l) {
                if (f.get(p) ? .g()) continue;
                ({
                    U: l
                } = B_().get(p, c, L_(p, e), d));
                if (!l) continue;
                m = E_(l);
                if (m === 2 || m === 3) continue;
                sf(l, 9, !1);
                (m = qf(l, 2)) && m.length > 1024 && (x_(55, p, null, {
                    sl: String(m.length)
                }, d), m = l.setError(xk(108)), we(m, 2));
                f.set(p, l);
                l = qf(l, 2);
                x_(19, p, null, {
                    hs: l ?
                        "1" : "0",
                    sl: String(l ? .length ? ? -1)
                }, d)
            }
            c = new Dk;
            for (let [, p] of a) Ze(c, 2, Ak, p);
            Ve(c, Ak, 2, De()).length ? (x_(50, "", null, {
                ns: String(Ve(c, Ak, 2, De()).length)
            }, d), d = c.g(), d = Ab(d)) : d = null
        }
        d && (b.a3p = d)
    };

    function N_(a) {
        var b = {};
        b.dtd = O_((new Date).getTime(), Cr);
        return vr(b, a)
    }

    function O_(a, b, c = 1E5) {
        a -= b;
        return a >= c ? "M" : a >= 0 ? a : "-M"
    };
    const P_ = rb("script");
    var Q_ = class {
        constructor(a, b, c = null, d = null, e = null, f = null, g = null, h = null, k = null, l = null, m = null, n = null) {
            this.D = a;
            this.dc = b;
            this.ma = c;
            this.g = d;
            this.O = e;
            this.Ca = f;
            this.Cb = g;
            this.B = h;
            this.A = k;
            this.j = l;
            this.l = m;
            this.C = n
        }
        size() {
            return this.dc
        }
    };
    var R_ = class {
        constructor(a, b) {
            this.oa = a;
            this.height = b
        }
        g(a) {
            return a > 300 && this.height > 300 ? this.oa : Math.min(1200, Math.round(a))
        }
    };
    var S_ = class extends R_ {
        j() {}
    };
    const T_ = {
        "image-top": a => a <= 600 ? 284 + (a - 250) * .414 : 429,
        "image-middle": a => a <= 500 ? 196 - (a - 250) * .13 : 164 + (a - 500) * .2,
        "image-side": a => a <= 500 ? 205 - (a - 250) * .28 : 134 + (a - 500) * .21,
        "text-only": a => a <= 500 ? 187 - .228 * (a - 250) : 130,
        "in-article": a => a <= 420 ? a / 1.2 : a <= 460 ? a / 1.91 + 130 : a <= 800 ? a / 4 : 200
    };
    var U_ = {
            "image-top": 0,
            "image-middle": 1,
            "image-side": 2,
            "text-only": 3,
            "in-article": 4
        },
        V_ = class extends S_ {
            constructor(a, b) {
                super(a, b)
            }
            g() {
                return Math.min(1200, this.oa)
            }
        };

    function W_(a, b, c, d, e) {
        var f = e.google_ad_layout || "image-top";
        if (f === "in-article") {
            var g = a;
            if (e.google_full_width_responsive === "false") a = g;
            else if (a = AS(b, c, g, V(Hv), e), a !== !0) e.gfwrnwer = a, a = g;
            else if (a = ks(b))
                if (e.google_full_width_responsive_allowed = !0, c.parentElement) {
                    b: {
                        g = c;
                        for (let h = 0; h < 100 && g.parentElement; ++h) {
                            let k = g.parentElement.childNodes;
                            for (let l = 0; l < k.length; ++l) {
                                let m = k[l];
                                if (m !== g && DS(b, m)) break b
                            }
                            g = g.parentElement;
                            g.style.width = "100%";
                            g.style.height = "auto"
                        }
                    }
                    HS(b, c)
                }
            else a = g;
            else a = g
        }
        if (a <
            250) throw new qB(`Fluid responsive ads must be at least 250px wide: availableWidth=${a}`);
        a = Math.min(1200, Math.floor(a));
        if (d && f !== "in-article") {
            f = Math.ceil(d);
            if (f < 50) throw new qB(`Fluid responsive ads must be at least 50px tall: height=${f}`);
            return new Q_(11, new S_(a, f))
        }
        if (f !== "in-article" && (d = e.google_ad_layout_key)) {
            f = `${d}`;
            if (d = (c = f.match(/([+-][0-9a-z]+)/g)) && c.length)
                for (b = [], e = 0; e < d; e++) b.push(parseInt(c[e], 36) / 1E3);
            else b = null;
            if (!b) throw new qB(`Invalid data-ad-layout-key value: ${f}`);
            f = (a + -725) / 1E3;
            c = 0;
            d = 1;
            e = b.length;
            for (g = 0; g < e; g++) c += b[g] * d, d *= f;
            f = Math.ceil(c * 1E3 - -725 + 10);
            if (isNaN(f)) throw new qB(`Invalid height: height=${f}`);
            if (f < 50) throw new qB(`Fluid responsive ads must be at least 50px tall: height=${f}`);
            if (f > 1200) throw new qB(`Fluid responsive ads must be at most 1200px tall: height=${f}`);
            return new Q_(11, new S_(a, f))
        }
        d = T_[f];
        if (!d) throw new qB("Invalid data-ad-layout value: " + f);
        c = XJ(c, b);
        b = ks(b);
        b = f !== "in-article" || c || a !== b ? Math.ceil(d(a)) : Math.ceil(d(a) * 1.25);
        return new Q_(11,
            f === "in-article" ? new V_(a, b) : new S_(a, b))
    };

    function X_(a) {
        var b = window;
        return a.google_adtest === "on" || a.google_adbreak_test === "on" || b.location.host.endsWith("h5games.usercontent.goog") || b.location.host === "gamesnacks.com" ? b.document.querySelector('meta[name="h5-games-eids"]') ? .getAttribute("content") ? .split(",").map(c => Math.floor(Number(c))).filter(c => !isNaN(c) && c > 0) || [] : []
    };
    var Y_ = class {
            constructor() {
                this.B = new Date(Date.now());
                this.l = this.g = null;
                this.j = {
                    [3]: {},
                    [4]: {},
                    [5]: {}
                };
                this.j[3] = {
                    [71]: (...a) => {
                        var b = this.g;
                        var c = this.B,
                            d = Number(a[0]);
                        a = Number(a[1]);
                        b = b !== null ? Uu(`w5uHecUBa2S:${d}:${b}`) % a === Math.floor(c.valueOf() / 864E5) % a : void 0;
                        return b
                    }
                };
                this.j[4] = {
                    [15]: () => {
                        var a = Number(this.l || void 0);
                        isNaN(a) ? a = void 0 : (a = new Date(a * 1E3), a = a.getFullYear() * 1E4 + (a.getMonth() + 1) * 100 + a.getDate());
                        return a
                    }
                }
            }
        },
        Z_;

    function $_(a, b = "") {
        return a0(a, b, c => fb(Ve(c, tk, 2, De()), d => rf(d, 1) === 1))
    }

    function a0(a, b, c) {
        a = Lk(a) || a;
        var d = b0(a);
        b && (b = Br(String(b)));
        return Ai(d, (e, f) => Object.prototype.hasOwnProperty.call(d, f) && (!b || b === f) && c(e))
    }

    function b0(a) {
        a = c0(a, !1);
        var b = {};
        Fk(a, (c, d) => {
            try {
                let e = rg(wk, $d(c));
                b[d] = e
            } catch (e) {}
        });
        return b
    }

    function c0(a, b) {
        a = vU({
            win: a,
            Xa: b
        });
        return Ju(a) ? d0(a.getValue()) : {}
    }

    function d0(a) {
        try {
            let b = a.getItem("google_adsense_settings");
            if (!b) return {};
            let c = JSON.parse(b);
            return c !== Object(c) ? {} : zi(c, (d, e) => Object.prototype.hasOwnProperty.call(c, e) && x(e) && Array.isArray(d))
        } catch (b) {
            return {}
        }
    };

    function e0(a = t) {
        return a.ggeac || (a.ggeac = {})
    };

    function f0(a, b = document) {
        return !!b.featurePolicy ? .features().includes(a)
    };

    function g0(a = Uk()) {
        return b => Uu(`${b} + ${a}`) % 1E3
    };

    function h0(a, b) {
        a.g = er(14, b, () => {})
    }
    class i0 {
        constructor() {
            this.g = () => {}
        }
    }

    function j0(a) {
        dr(i0).g(a)
    };

    function k0(a = e0()) {
        fr(dr(gr), a);
        l0(a);
        h0(dr(i0), a);
        dr(nz).g()
    }

    function l0(a) {
        var b = dr(nz);
        b.j = (c, d) => er(5, a, () => !1)(c, d, 1);
        b.B = (c, d) => er(6, a, () => 0)(c, d, 1);
        b.A = (c, d) => er(7, a, () => "")(c, d, 1);
        b.C = (c, d) => er(8, a, () => [])(c, d, 1);
        b.l = (c, d) => er(17, a, () => [])(c, d, 1);
        b.g = () => {
            er(15, a, () => {})(1)
        }
    };

    function m0(a, b, c, d) {
        b = {
            [0]: g0(ul(b).toString())
        };
        if (c && d) {
            d = DI(d, c);
            Z_ || (Z_ = new Y_);
            c = Z_;
            d.gfpCookie && !c.g && (c.g = d.parsedGfpCookie.id, c.l = d.parsedGfpCookie.creationTimeSeconds);
            j0(c.j);
            let e = d.parsedGfpCookie.id;
            b[1] = f => e ? g0(e)(f) : void 0
        }
        b = hr(a, b);
        mr(QB(HB(), a, b))
    }

    function n0(a) {
        var b = $q();
        a = X_(a);
        return b.concat(a).join(",")
    }

    function o0(a) {
        var b = Tl();
        b && (a.debug_experiment_id = b)
    };
    var p0 = {
        google_ad_block: "ad_block",
        google_ad_client: "client",
        google_ad_intent_query: "ait_q",
        google_ad_intent_rs_token: "afdt",
        google_ad_output: "output",
        google_ad_height: "h",
        google_ad_resize: "twa",
        google_ad_slot: "slotname",
        google_language: "hl",
        google_max_num_ads: "num_ads",
        google_ad_unit_key: "adk",
        google_ad_dom_fingerprint: "adf",
        google_ad_intents_encoded_verticals4_ids: "ait_v",
        google_ad_intents_encoded_browseonomy_ids: "ait_b",
        google_ad_intents_format: "ait_f",
        google_ad_intents_in_drawer_format: "ait_df",
        google_ad_intents_ad_position: "ait_pos",
        google_placement_id: "pi",
        google_daaos_ts: "daaos",
        google_erank: "epr",
        google_ad_width: "w",
        google_content_recommendation_columns_num: "cr_col",
        google_content_recommendation_rows_num: "cr_row",
        google_ctr_threshold: "ctr_t",
        gfwrnwer: "fwrn",
        gfwrnher: "fwrnh",
        google_last_modified_time: "lmt",
        google_enable_content_recommendations: "ecr",
        google_reactive_plaf: "plaf",
        google_reactive_plat: "plat",
        google_reactive_fba: "fba",
        google_reactive_sra_channels: "plach",
        google_responsive_auto_format: "rafmt",
        armr: "armr",
        google_video_play_muted: "vpmute",
        google_source_type: "src_type",
        google_restrict_data_processing: "rdp",
        google_tag_for_child_directed_treatment: "tfcd",
        google_tag_for_under_age_of_consent: "tfua",
        google_tag_for_age_treatment: "tfat",
        google_tag_origin: "to",
        google_ad_semantic_area: "sem",
        google_package: "pwprc",
        google_tag_partner: "tp",
        fra: "fpla",
        google_ml_rank: "mlr",
        google_ad_channel: "channel",
        google_ad_type: "ad_type",
        google_ad_format: "format",
        google_color_bg: "color_bg",
        google_color_border: "color_border",
        google_color_link: "color_link",
        google_color_text: "color_text",
        google_color_url: "color_url",
        google_page_url: "url",
        google_ad_section: "region",
        google_encoding: "oe",
        google_safe: "adsafe",
        google_font_face: "f",
        google_font_size: "fs",
        google_ad_host: "host",
        google_ad_host_channel: "h_ch",
        google_kw: "kw",
        google_adtest: "adtest",
        google_alternate_color: "alt_color",
        google_cust_age: "cust_age",
        google_cust_gender: "cust_gender",
        google_country: "gl",
        google_alternate_ad_url: "alternate_ad_url",
        google_region: "gr",
        google_image_size: "image_size",
        google_video_doc_id: "video_doc_id",
        google_content_recommendation_ui_type: "crui",
        sso: "sso",
        google_color_line: "color_line",
        google_full_width_responsive_allowed: "fwr",
        google_full_width_responsive: "fwrattr",
        google_tfs: "tfs",
        efwr: "efwr",
        google_pgb_reactive: "pra",
        rc: "rc",
        google_resizing_allowed: "rs",
        google_resizing_height: "rh",
        google_resizing_width: "rw",
        rpe: "rpe",
        google_responsive_formats: "resp_fmts",
        google_safe_for_responsive_override: "sfro",
        aiof: "aiof",
        asro: "asro",
        vmsli: "itsi",
        dap: "dap",
        aiact: "aiact",
        aiactd: "aiactd",
        aicct: "aicct",
        aicctd: "aicctd",
        ailct: "ailct",
        ailctd: "ailctd",
        aimartd: "aimartd",
        aieuf: "aieuf",
        aicrs: "aicrs"
    };

    function q0(a) {
        a.g === -1 && (a.g = a.data.reduce((b, c, d) => b + (c ? 2 ** d : 0), 0));
        return a.g
    }
    var r0 = class {
        constructor() {
            this.data = [];
            this.g = -1
        }
        set(a, b = !0) {
            0 <= a && a < 52 && Number.isInteger(a) && this.data[a] !== b && (this.data[a] = b, this.g = -1)
        }
        get(a) {
            return !!this.data[a]
        }
    };

    function s0() {
        var a = new r0;
        "SVGElement" in t && "createElementNS" in t.document && a.set(0);
        var b = il();
        b["allow-top-navigation-by-user-activation"] && a.set(1);
        b["allow-popups-to-escape-sandbox"] && a.set(2);
        t.crypto && t.crypto.subtle && a.set(3);
        "TextDecoder" in t && "TextEncoder" in t && a.set(4);
        return q0(a)
    };

    function t0(a, b, {
        nn: c,
        on: d
    }) {
        return C(b, 17) && (!c && b.ha() || !d) && vI(a) ? !0 : !1
    };
    var u0 = class {
        constructor() {
            this.g = tB
        }
        Ja(a) {
            var b = a.eb;
            this.g.Da(a.methodName ? ? 0, b instanceof Error ? b : Error(String(b)))
        }
    };
    var v0 = function(a) {
        return b => Hg(b, a)
    }(zU);
    var w0 = () => {
        var a = new Map;
        a.set(1, "All in One SEO (AIOSEO)");
        a.set(2, "All in One SEO Pro (AIOSEO)");
        a.set(3, "AMP for WP");
        a.set(4, "Site Kit by Google");
        a.set(5, "Elementor");
        a.set(6, "Powered by WPBakery Page Builder - drag and drop page builder for WordPress.");
        return a
    };
    var x0 = () => {
        var a = new Map;
        a.set(1, "WordPress");
        a.set(2, "Drupal");
        a.set(3, "MediaWiki");
        a.set(4, "Blogger");
        a.set(5, "SEOmatic");
        a.set(7, "Flutter");
        a.set(8, "Joomla! - Open Source Content Management");
        a.set(9, "React");
        a.set(10, "Angular");
        a.set(11, "Vue");
        return a
    };

    function y0(a) {
        return a.querySelector("[ng-version]") != null || a.querySelector('[class*="_ngcontent-"]') != null
    };

    function z0(a, {
        Lj: b
    }) {
        return Array.from(a.querySelectorAll("div")).slice(0, b).some(c => Object.keys(c).some(d => d.startsWith("__react")))
    };

    function A0(a, {
        Mj: b
    }) {
        return Array.from(a.querySelectorAll("*")).slice(0, b).some(c => Object.keys(c).some(d => d.startsWith("__vue")))
    };

    function B0(a = document) {
        var b = {
                Lj: V(Cw),
                Tl: U(zw),
                Mj: V(Jw)
            },
            c = [],
            d = [];
        for (var e of Array.from(a.querySelectorAll("meta[name=generator][content]"))) {
            if (!e) continue;
            var f = e.getAttribute("content") ? ? "";
            let [, l, m] = /^([^0-9]+)(?:\s([0-9]+(?:\.[0-9]+){0,2})[.0-9]*)?[^0-9]*$/.exec(f) ? ? [];
            var g = new yU;
            m && Jf(g, 3, m.substring(0, 20));
            var h = void 0;
            let n;
            if (l) {
                for (let [p, q] of x0().entries()) {
                    var k = p;
                    if (q === l.trim()) {
                        h = k;
                        break
                    }
                }
                for (let [p, q] of w0().entries())
                    if (k = p, q === l.trim()) {
                        n = k;
                        break
                    }
            }
            n ? (f = Lf(g, 1, 1), Lf(f, 2,
                n)) : h ? Lf(g, 1, h) : (k = Lf(g, 1, 0), we(k, 3), d.push({
                content: f,
                name: l,
                version: m
            }));
            c.push(g)
        }
        e = [];
        b.Lj > 0 && e.push({
            label: 9,
            sh: z0
        });
        b.Tl && e.push({
            label: 10,
            sh: y0
        });
        (b.Mj ? ? !1) && e.push({
            label: 11,
            sh: A0
        });
        for (let l of e) l.sh(a, b) && (e = c, g = e.push, h = new yU, h = Lf(h, 1, l.label), g.call(e, h));
        return {
            labels: c,
            Ep: d
        }
    };
    var C0 = class extends O {
        constructor() {
            super();
            this.value = null
        }
        get() {
            return this.value
        }
    };
    const D0 = new Map([
            ["navigate", 1],
            ["reload", 2],
            ["back_forward", 3],
            ["prerender", 4]
        ]),
        E0 = new Map([
            [0, 1],
            [1, 2],
            [2, 3]
        ]);

    function F0(a) {
        try {
            let b = a.performance ? .getEntriesByType("navigation") ? .[0];
            if (b ? .type) return D0.get(b.type) ? ? null
        } catch {}
        return E0.get(a.performance ? .navigation ? .type) ? ? null
    };

    function G0(a, b) {
        Array.isArray(b) || (b = [b]);
        b = b.map(function(c) {
            return typeof c === "string" ? c : c.property + " " + c.duration + "s " + c.timing + " " + c.delay + "s"
        });
        Fj(a, "transition", b.join(","))
    }
    const H0 = oi(function() {
        var a = oj(document, "DIV"),
            b = xb ? "-webkit" : vb ? "-moz" : null,
            c = "transition:opacity 1s linear;";
        b && (c += b + "-transition:opacity 1s linear;");
        Li(a, di("div", {
            style: c
        }));
        return Kj(a.firstChild, "transition") != ""
    });

    function I0(a, b, c) {
        a.j[b].indexOf(c) < 0 && (a.j[b] += c)
    }

    function J0(a, b) {
        a.g.indexOf(b) >= 0 || (a.g = b + a.g)
    }

    function K0(a, b) {
        a.errors.indexOf(b) < 0 && (a.errors = b + a.errors)
    }

    function L0(a, b, c, d) {
        return a.errors != "" || b ? null : a.g.replace(M0, "") == "" ? c != null && a.j[0] || d != null && a.j[1] ? !1 : !0 : !1
    }

    function N0(a) {
        var b = L0(a, "", null, 0);
        if (b === null) return "XS";
        b = b ? "C" : "N";
        a = a.g;
        return a.indexOf("a") >= 0 ? b + "A" : a.indexOf("f") >= 0 ? b + "F" : b + "S"
    }
    var O0 = class {
        constructor(a, b) {
            this.j = ["", ""];
            this.g = a || "";
            this.errors = b || ""
        }
        toString() {
            return [this.j[0], this.j[1], this.g, this.errors].join("|")
        }
    };

    function P0(a) {
        var b = a.Z;
        a.O = () => {};
        Q0(a, a.C, b);
        var c = a.C.parentElement;
        if (!c) return a.g;
        for (var d = !0, e = null; c;) {
            try {
                e = /^head|html$/i.test(c.nodeName) ? null : al(c, b)
            } catch (g) {
                K0(a.g, "c")
            }
            let f = R0(a, b, c, e);
            c.classList.contains("adsbygoogle") && e && (/^\-.*/.test(e["margin-left"]) || /^\-.*/.test(e["margin-right"])) && (a.W = !0);
            if (d && !f && S0(e)) {
                J0(a.g, "l");
                a.G = c;
                break
            }
            d = d && f;
            if (e && T0(a, e)) break;
            c = c.parentElement;
            if (!c) {
                if (b === a.pubWin) break;
                try {
                    if (c = b.frameElement, b = b.parent, !Ik(b)) {
                        J0(a.g, "c");
                        break
                    }
                } catch (g) {
                    J0(a.g,
                        "c");
                    break
                }
            }
        }
        a.D && a.A && U0(a);
        return a.g
    }

    function V0(a) {
        function b(m) {
            for (let n = 0; n < m.length; n++) Fj(k, m[n], "0px")
        }

        function c() {
            W0(d, g, h);
            !k || l || h || (b(X0), b(Y0))
        }
        var d = a.C;
        d.style.overflow = a.Re ? "visible" : "hidden";
        a.D && (a.G ? (G0(d, Z0()), G0(a.G, Z0())) : G0(d, "opacity 1s cubic-bezier(.4, 0, 1, 1), width .2s cubic-bezier(.4, 0, 1, 1) .3s, height .5s cubic-bezier(.4, 0, 1, 1)"));
        a.P !== null && (d.style.opacity = String(a.P));
        var e = a.width != null && a.l != null && (a.Wf || a.l > a.width) ? a.l : null,
            f = a.height != null && a.j != null && (a.Wf || a.j > a.height) ? a.j : null;
        if (a.J) {
            let m =
                a.J.length;
            for (let n = 0; n < m; n++) W0(a.J[n], e, f)
        }
        var g = a.l,
            h = a.j,
            k = a.G,
            l = a.W;
        a.D ? t.setTimeout(c, 1E3) : c()
    }

    function $0(a) {
        if (a.A && !a.la || a.l == null && a.j == null && a.P == null && a.A) return a.g;
        var b = a.A;
        a.A = !1;
        P0(a);
        a.A = b;
        if (!b || a.check != null && !L0(a.g, a.check, a.l, a.j)) return a.g;
        a.g.g.indexOf("n") >= 0 && (a.width = null, a.height = null);
        if (a.width == null && a.l !== null || a.height == null && a.j !== null) a.D = !1;
        (a.l == 0 || a.j == 0) && a.g.g.indexOf("l") >= 0 && (a.l = 0, a.j = 0);
        b = a.g;
        b.j[0] = "";
        b.j[1] = "";
        b.g = "";
        b.errors = "";
        V0(a);
        return P0(a)
    }

    function T0(a, b) {
        var c = !1;
        b.display == "none" && (J0(a.g, "n"), a.A && (c = !0));
        b.visibility != "hidden" && b.visibility != "collapse" || J0(a.g, "v");
        b.overflow == "hidden" && J0(a.g, "o");
        b.position == "absolute" ? (J0(a.g, "a"), c = !0) : b.position == "fixed" && (J0(a.g, "f"), c = !0);
        return c
    }

    function Q0(a, b, c) {
        var d = 0;
        if (!b || !b.parentElement) return !0;
        var e = !1,
            f = 0,
            g = b.parentElement.childNodes;
        for (let k = 0; k < g.length; k++) {
            var h = g[k];
            h == b ? e = !0 : (h = a1(a, h, c), d |= h, e && (f |= h))
        }
        f & 1 && (d & 2 && I0(a.g, 0, "o"), d & 4 && I0(a.g, 1, "o"));
        return !(d & 1)
    }

    function R0(a, b, c, d) {
        var e = null;
        try {
            e = c.style
        } catch (w) {
            K0(a.g, "s")
        }
        var f = c.getAttribute("width"),
            g = dl(f),
            h = c.getAttribute("height"),
            k = dl(h),
            l = d && /^block$/.test(d.display) || e && /^block$/.test(e.display);
        b = Q0(a, c, b);
        var m = d && d.width,
            n = d && d.height,
            p = e && e.width,
            q = e && e.height,
            u = el(m) == a.width && el(n) == a.height;
        m = u ? m : p;
        q = u ? n : q;
        p = el(m);
        u = el(q);
        g = a.width !== null && (p !== null && a.width >= p || g !== null && a.width >= g);
        u = a.height !== null && (u !== null && a.height >= u || k !== null && a.height >= k);
        k = !b && S0(d);
        u = b || u || k || !(f || m || d && (!b1(String(d.minWidth)) ||
            !c1(String(d.maxWidth))));
        l = b || g || k || l || !(h || q || d && (!b1(String(d.minHeight)) || !c1(String(d.maxHeight))));
        d1(a, 0, u, c, "width", f, a.width, a.l);
        e1(a, 0, "d", u, e, d, "width", m, a.width, a.l);
        e1(a, 0, "m", u, e, d, "minWidth", e && e.minWidth, a.width, a.l);
        e1(a, 0, "M", u, e, d, "maxWidth", e && e.maxWidth, a.width, a.l);
        a.li ? (c = /^html|body$/i.test(c.nodeName), f = el(n), h = d ? d.overflowY === "auto" || d.overflowY === "scroll" : !1, h = a.j != null && d && f && Math.round(f) !== a.j && !h && d.minHeight !== "100%", a.A && !c && h && (e.setProperty("height", "auto", "important"),
            d && !b1(String(d.minHeight)) && e.setProperty("min-height", "0px", "important"), d && !c1(String(d.maxHeight)) && a.j && Math.round(f) < a.j && e.setProperty("max-height", "none", "important"))) : (d1(a, 1, l, c, "height", h, a.height, a.j), e1(a, 1, "d", l, e, d, "height", q, a.height, a.j), e1(a, 1, "m", l, e, d, "minHeight", e && e.minHeight, a.height, a.j), e1(a, 1, "M", l, e, d, "maxHeight", e && e.maxHeight, a.height, a.j));
        return b
    }

    function U0(a) {
        function b() {
            if (c > 0) {
                var l = al(e, d) || {
                    width: 0,
                    height: 0
                };
                let m = el(l.width);
                l = el(l.height);
                m !== null && f !== null && h && h(0, f - m);
                l !== null && g !== null && h && h(1, g - l);
                --c
            } else t.clearInterval(k), h && (h(0, 0), h(1, 0))
        }
        var c = 31.25,
            d = a.Z,
            e = a.C,
            f = a.l,
            g = a.j,
            h = a.O,
            k;
        t.setTimeout(() => {
            k = t.setInterval(b, 16)
        }, 990)
    }

    function a1(a, b, c) {
        if (b.nodeType == 3) return /\S/.test(b.data) ? 1 : 0;
        if (b.nodeType == 1) {
            if (/^(head|script|style)$/i.test(b.nodeName)) return 0;
            let d = null;
            try {
                d = al(b, c)
            } catch (e) {}
            if (d) {
                if (d.display == "none" || d.position == "fixed") return 0;
                if (d.position == "absolute") {
                    if (!a.B.boundingClientRect || d.visibility == "hidden" || d.visibility == "collapse") return 0;
                    c = null;
                    try {
                        c = b.getBoundingClientRect()
                    } catch (e) {
                        return 0
                    }
                    return (c.right > a.B.boundingClientRect.left ? 2 : 0) | (c.bottom > a.B.boundingClientRect.top ? 4 : 0)
                }
            }
            return 1
        }
        return 0
    }

    function d1(a, b, c, d, e, f, g, h) {
        if (h != null) {
            if (x(f)) {
                if (f == "100%" || !f) return;
                f = dl(f);
                f == null && (K0(a.g, "n"), I0(a.g, b, "d"))
            }
            if (f != null)
                if (c) {
                    if (a.A)
                        if (a.D) {
                            let k = Math.max(f + h - (g || 0), 0),
                                l = a.O;
                            a.O = (m, n) => {
                                m == b && Mi(d, e, String(k - n));
                                l && l(m, n)
                            }
                        } else Mi(d, e, String(h))
                } else I0(a.g, b, "d")
        }
    }

    function e1(a, b, c, d, e, f, g, h, k, l) {
        if (l != null) {
            f = f && f[g];
            !x(f) || (c == "m" ? b1(f) : c1(f)) || (f = el(f), f == null ? J0(a.g, "p") : k != null && J0(a.g, f == k ? "E" : "e"));
            if (x(h)) {
                if (c == "m" ? b1(h) : c1(h)) return;
                h = el(h);
                h == null && (K0(a.g, "p"), I0(a.g, b, c))
            }
            if (h != null)
                if (d && e) {
                    if (a.A)
                        if (a.D) {
                            let m = Math.max(h + l - (k || 0), 0),
                                n = a.O;
                            a.O = (p, q) => {
                                p == b && (e[g] = W(m - q));
                                n && n(p, q)
                            }
                        } else e[g] = W(l)
                } else I0(a.g, b, c)
        }
    }
    var j1 = class {
        constructor(a, b, c, d, e, f, g) {
            this.pubWin = a;
            this.C = b;
            this.J = c;
            this.G = this.O = null;
            this.W = !1;
            this.B = new f1(this.C);
            this.Z = (a = this.C.ownerDocument) && (a.defaultView || a.parentWindow);
            this.B = new f1(this.C);
            this.A = g;
            this.la = g1(this.B, d.fg, d.height, d.Ce);
            this.width = this.A ? this.B.boundingClientRect ? this.B.boundingClientRect.right - this.B.boundingClientRect.left : null : e;
            this.height = this.A ? this.B.boundingClientRect ? this.B.boundingClientRect.bottom - this.B.boundingClientRect.top : null : f;
            this.l = h1(d.width);
            this.j = h1(d.height);
            this.P = this.A ? h1(d.opacity) : null;
            this.check = d.check;
            this.Ce = !!d.Ce;
            this.D = d.fg == "animate" && !i1(this.B, this.j, this.Ce) && H0();
            this.Re = !!d.Re;
            this.g = new O0;
            i1(this.B, this.j, this.Ce) && J0(this.g, "r");
            e = this.B;
            e.g && e.j >= e.ga && J0(this.g, "b");
            this.Wf = !!d.Wf;
            this.li = !!d.li
        }
    };

    function i1(a, b, c) {
        var d;
        (d = a.g) && !(d = !a.visible) && (c ? (b = a.j + Math.min(b, h1(a.getHeight())), a = a.g && b >= a.ga) : a = a.g && a.j >= a.ga, d = a);
        return d
    }
    var f1 = class {
        constructor(a) {
            this.boundingClientRect = null;
            var b = a && a.ownerDocument,
                c = b && (b.defaultView || b.parentWindow);
            c = c && Lk(c);
            this.g = !!c;
            if (a) try {
                this.boundingClientRect = a.getBoundingClientRect()
            } catch (g) {}
            for (var d = a, e = 0, f = this.boundingClientRect; d;) try {
                f && (e += f.top);
                let g = d.ownerDocument,
                    h = g && (g.defaultView || g.parentWindow);
                (d = h && h.frameElement) && (f = d.getBoundingClientRect())
            } catch (g) {
                break
            }
            this.j = e;
            c = c || t;
            this.ga = (c.document.compatMode == "CSS1Compat" ? c.document.documentElement : c.document.body).clientHeight;
            b = b && EY(b);
            this.visible = !!a && !(b == 2 || b == 3) && !(this.boundingClientRect && this.boundingClientRect.top >= this.boundingClientRect.bottom && this.boundingClientRect.left >= this.boundingClientRect.right)
        }
        isVisible() {
            return this.visible
        }
        getWidth() {
            return this.boundingClientRect ? this.boundingClientRect.right - this.boundingClientRect.left : null
        }
        getHeight() {
            return this.boundingClientRect ? this.boundingClientRect.bottom - this.boundingClientRect.top : null
        }
    };

    function g1(a, b, c, d) {
        switch (b) {
            case "no_rsz":
                return !1;
            case "force":
            case "animate":
                return !0;
            default:
                return i1(a, c, d)
        }
    }

    function S0(a) {
        return !!a && /^left|right$/.test(a.cssFloat || a.styleFloat)
    }

    function k1(a, b, c, d) {
        return $0(new j1(a, b, d, c, null, null, !0))
    }
    var l1 = new O0("s", ""),
        M0 = RegExp("[lonvafrbpEe]", "g");

    function c1(a) {
        return !a || /^(auto|none|100%)$/.test(a)
    }

    function b1(a) {
        return !a || /^(0px|auto|none|0%)$/.test(a)
    }

    function W0(a, b, c) {
        b !== null && dl(a.getAttribute("width")) !== null && a.setAttribute("width", String(b));
        c !== null && dl(a.getAttribute("height")) !== null && a.setAttribute("height", String(c));
        b !== null && (a.style.width = W(b));
        c !== null && (a.style.height = W(c))
    }
    var X0 = "margin-left margin-right padding-left padding-right border-left-width border-right-width".split(" "),
        Y0 = "margin-top margin-bottom padding-top padding-bottom border-top-width border-bottom-width".split(" ");

    function Z0() {
        var a = "opacity 1s cubic-bezier(.4, 0, 1, 1), width .2s cubic-bezier(.4, 0, 1, 1), height .3s cubic-bezier(.4, 0, 1, 1) .2s",
            b = X0;
        for (var c = 0; c < b.length; c++) a += ", " + b[c] + " .2s cubic-bezier(.4, 0, 1, 1)";
        b = Y0;
        for (c = 0; c < b.length; c++) a += ", " + b[c] + " .3s cubic-bezier(.4, 0, 1, 1) .2s";
        return a
    }

    function h1(a) {
        return x(a) ? dl(a) : oc(a) && isFinite(a) ? a : null
    };

    function m1(a) {
        if (a = a.navigator ? .userActivation) {
            var b = 0;
            a ? .hasBeenActive && (b |= 1);
            a ? .isActive && (b |= 2);
            return b
        }
    };
    const n1 = /[+, ]/;

    function o1(a) {
        try {
            if (a.parentNode) return a.parentNode
        } catch {
            return null
        }
        if (a.nodeType === 9) a: {
            try {
                let c = nj(a);
                if (c) {
                    let d = c.frameElement;
                    if (d && Ik(c.parent)) {
                        var b = d;
                        break a
                    }
                }
            } catch {}
            b = null
        }
        else b = null;
        return b
    }

    function p1(a, b) {
        var c = n0(a.pubWin);
        a.I.saaei && (c += (c === "" ? "" : ",") + a.I.saaei);
        b.eid = c
    }

    function q1(a, b) {
        a = (a = Lk(a.pubWin)) && a.document ? oY(a.document, a) : new vi(-12245933, -12245933);
        b.scr_x = Math.round(a.x);
        b.scr_y = Math.round(a.y)
    }

    function r1(a) {
        try {
            let b = t.top.location.hash;
            if (b) {
                let c = b.match(a);
                return c && c[1] || ""
            }
        } catch {}
        return ""
    }

    function s1(a, b, c) {
        var d = a.I,
            e = a.pubWin,
            f = a.K,
            g = Mk(window);
        d.fsapi && (b.fsapi = !0);
        b.ref = d.google_referrer_url;
        b.loc = d.google_page_location;
        var h;
        (h = or(e)) && h.data && ra(h.data) && x(h.data.type) ? (h = h.data.type.toLowerCase(), h = h === "doubleclick" || h === "adsense" ? null : h) : h = null;
        h && (b.apn = h.substr(0, 10));
        g = Hk(g);
        b.url || b.loc || !g.url || (b.url = g.url, g.Jh || (b.usrc = 1));
        g.url != (b.loc || b.url) && (b.top = g.url);
        a.Kc && (b.etu = a.Kc);
        (c = iZ(d, f, c)) && (b.fc = c);
        if (!zr(d)) {
            c = a.pubWin.document;
            g = "";
            if (c.documentMode && (h = xj(new hj(c),
                    "IFRAME"), h.frameBorder = "0", h.style.height = 0, h.style.width = 0, h.style.position = "absolute", c.body)) {
                c.body.appendChild(h);
                try {
                    let ya = h.contentWindow.document;
                    ya.open();
                    var k = Mh("<!DOCTYPE html>");
                    ya.write(Nh(k));
                    ya.close();
                    g += ya.documentMode
                } catch (ya) {}
                c.body.removeChild(h)
            }
            b.docm = g
        }
        try {
            var l = e.screenX;
            var m = e.screenY
        } catch (ya) {}
        try {
            var n = e.outerWidth;
            var p = e.outerHeight
        } catch (ya) {}
        try {
            var q = e.innerWidth;
            var u = e.innerHeight
        } catch (ya) {}
        try {
            var w = e.screenLeft;
            var B = e.screenTop
        } catch (ya) {}
        try {
            q = e.innerWidth,
                u = e.innerHeight
        } catch (ya) {}
        try {
            var G = e.screen.availWidth;
            var K = e.screen.availTop
        } catch (ya) {}
        b.brdim = [w, B, l, m, G, K, n, p, q, u].join();
        k = 0;
        t.postMessage === void 0 && (k |= 1);
        k > 0 && (b.osd = k);
        b.vis = EY(e.document);
        a = a.ca;
        e = qZ(d) ? l1 : $0(new j1(e, a, null, {
            width: 0,
            height: 0
        }, d.google_ad_width, d.google_ad_height, !1));
        b.rsz = e.toString();
        b.abl = N0(e);
        if (!qZ(d) && (e = Ar(d), e !== null)) {
            a = 0;
            a: {
                try {
                    {
                        var H = d.google_async_iframe_id;
                        let ya = window.document;
                        if (H) var L = ya.getElementById(H);
                        else {
                            var S = ya.getElementsByTagName("script"),
                                da = S[S.length - 1];
                            L = da && da.parentNode || null
                        }
                    }
                    if (L) {
                        d = [];
                        H = 0;
                        for (var Ea = Date.now(); ++H <= 100 && Date.now() - Ea < 50 && (L = o1(L));) L.nodeType === 1 && d.push(L);
                        var ka = d;
                        b: {
                            for (Ea = 0; Ea < ka.length; Ea++) {
                                c: {
                                    var Da = ka[Ea];
                                    try {
                                        if (Da.parentNode && Da.offsetWidth > 0 && Da.offsetHeight > 0 && Da.style && Da.style.display !== "none" && Da.style.visibility !== "hidden" && (!Da.style.opacity || Number(Da.style.opacity) !== 0)) {
                                            let ya = Da.getBoundingClientRect();
                                            var Nc = ya.right > 0 && ya.bottom > 0;
                                            break c
                                        }
                                    } catch (ya) {}
                                    Nc = !1
                                }
                                if (!Nc) {
                                    var ad = !1;
                                    break b
                                }
                            }
                            ad = !0
                        }
                        if (ad) {
                            b: {
                                let ya = Date.now();ad = /^html|body$/i;Nc = /^fixed/i;
                                for (Da = 0; Da < ka.length && Date.now() - ya < 50; Da++) {
                                    let Pc = ka[Da];
                                    if (!ad.test(Pc.tagName) && Nc.test(Pc.style.position || Lj(Pc, "position"))) {
                                        var Oc = Pc;
                                        break b
                                    }
                                }
                                Oc = null
                            }
                            break a
                        }
                    }
                } catch {}
                Oc = null
            }
            Oc && Oc.offsetWidth * Oc.offsetHeight <= e.width * e.height * 4 && (a = 1);
            b.pfx = a
        }
        a: {
            if (Math.random() < .05 && f) try {
                let ya = f.document.getElementsByTagName("head")[0];
                var ee = ya ? JZ(ya) : 0;
                break a
            } catch (ya) {}
            ee = 0
        }
        f = ee;
        f !== 0 && (b.cms = f)
    }

    function t1(a, b) {
        var c = 0;
        a.location && a.location.ancestorOrigins ? c = a.location.ancestorOrigins.length : Jk(() => {
            c++;
            return !1
        }, a);
        c && (b.nhd = c)
    }

    function u1(a, b) {
        var c = MA(b, 8, {});
        b = MA(b, 9, {});
        var d = a.google_ad_section,
            e = a.google_ad_format;
        a = a.google_ad_slot;
        e ? c[d] = c[d] ? c[d] + `,${e}` : e : a && (b[d] = b[d] ? b[d] + `,${a}` : a)
    }

    function v1(a, b, c, d) {
        var e = a.I,
            f = a.I;
        b.dt = Cr;
        f.google_async_iframe_id && f.google_bpp && (b.bpp = f.google_bpp);
        a: {
            try {
                var g = t.performance;
                if (g && g.timing && g.now) {
                    var h = g.timing.navigationStart + Math.round(g.now()) - g.timing.domLoading;
                    break a
                }
            } catch (m) {}
            h = null
        }(f = (f = h) ? O_(f, t.Date.now() - Cr, 1E6) : null) && (b.bdt = f);
        b.idt = O_(a.B, Cr);
        f = a.I;
        b.shv = a.pageState.jTCuI;
        a.Sc && (b.mjsv = a.Sc);
        f.google_loader_used === "sd" ? b.ptt = 5 : f.google_loader_used === "aa" && (b.ptt = 9);
        /^\w{1,3}$/.test(f.google_loader_used) && (b.saldr = f.google_loader_used);
        if (f = or(a.pubWin)) b.is_amp = 1, b.amp_v = pr(f), (f = qr(f)) && (b.act = f);
        f = a.pubWin;
        f === f.top && (b.abxe = 1);
        (f = d.get("__gads", c)) ? b.cookie = f: (f = a.pubWin, c.ha() && vI(f) && (b.cookie_enabled = "1"));
        f = d.get("__gpi", c);
        h = d.get("__gpi_opt_out", c);
        f && !f.includes("&") && (b.gpic = f);
        h === "1" && (b.pdopt = "1");
        (d = (c = t0(a.pubWin, c, {
            nn: !1,
            on: !a.zb
        })) && d.get("__eoi")) ? b.eo_id_str = d: c && (b.eoidce = "1");
        d = HA();
        f = MA(d, 8, {});
        c = e.google_ad_section;
        f[c] && (b.prev_fmts = f[c]);
        f = MA(d, 9, {});
        f[c] && (b.prev_slotnames = f[c].toLowerCase());
        u1(e, d);
        c = MA(d, 15, 0);
        c > 0 && (b.nras = String(c));
        (f = or(window)) ? (f ? (c = f.pageViewId, f = f.clientId, x(f) && (c += f.replace(/\D/g, "").substring(0, 6))) : c = null, c = +c) : (c = Mk(window), f = c.google_global_correlator, f || (c.google_global_correlator = f = 1 + Math.floor(Math.random() * 8796093022208)), c = f);
        b.correlator = MA(d, 7, c);
        U(ay) && (b.rume = 1);
        if (e.google_ad_channel) {
            c = MA(d, 10, {});
            f = "";
            h = e.google_ad_channel.split(n1);
            for (g = 0; g < h.length; g++) {
                var k = h[g];
                c[k] ? f += k + "+" : c[k] = !0
            }
            b.pv_ch = f
        }
        if (e.google_ad_host_channel) {
            c = e.google_ad_host_channel;
            f = MA(d, 11, []);
            h = c.split("|");
            d = -1;
            c = [];
            for (g = 0; g < h.length; g++) {
                k = h[g].split(n1);
                f[g] || (f[g] = {});
                let m = "";
                for (let n = 0; n < k.length; n++) {
                    let p = k[n];
                    p !== "" && (f[g][p] ? m += "+" + p : f[g][p] = !0)
                }
                m = m.slice(1);
                c[g] = m;
                m !== "" && (d = g)
            }
            f = "";
            if (d > -1) {
                for (h = 0; h < d; h++) f += c[h] + "|";
                f += c[d]
            }
            b.pv_h_ch = f
        }
        b.frm = e.google_iframing;
        b.ife = e.google_iframing_environment;
        a: {
            d = e.google_ad_client;
            try {
                let m = Mk(window),
                    n = m.google_prev_clients;
                n || (n = m.google_prev_clients = {});
                if (d in n) {
                    var l = 1;
                    break a
                }
                n[d] = !0;
                l = 2;
                break a
            } catch {
                l = 0;
                break a
            }
            l =
            void 0
        }
        b.pv = l;
        U(Dw) && a.pubWin.location.host.endsWith("h5games.usercontent.goog") && (b.cdm = a.pubWin.location.host);
        t1(a.pubWin, b);
        (a = e.google_ad_layout) && U_[a] >= 0 && (b.rplot = U_[a])
    }

    function w1(a, b) {
        a = a.R;
        var c = HA();
        MA(c, 26) && (b.npa = 1);
        a && (ef(a, 3) != null && (b.gdpr = a.g() ? "1" : "0"), (c = qf(a, 1)) && (b.us_privacy = c), (c = qf(a, 2)) && (b.gdpr_consent = c), (c = qf(a, 4)) && (b.addtl_consent = c), (c = rf(a, 7)) && (b.tcfe = c), (c = D(a, 11)) && (b.gpp = c), (a = df(a, 10)) && a.length > 0 && (b.gpp_sid = a.join(",")))
    }

    function x1(a, b) {
        var c = a.I;
        w1(a, b);
        Fk(p0, (d, e) => {
            e !== "google_source_type" && (b[d] = c[e])
        });
        qZ(c) && (a = pZ(c), b.fa = a);
        b.pi || c.google_ad_slot == null || (a = YL(c), Ju(a) && (a = Xu(a.getValue()), b.pi = a))
    }

    function y1(a, b) {
        var c = sr() || mY(a.pubWin.top);
        c && (b.biw = c.width, b.bih = c.height);
        c = a.pubWin;
        c !== c.top && (a = mY(a.pubWin)) && (b.isw = a.width, b.ish = a.height)
    }

    function z1(a, b) {
        var c = a.pubWin;
        c !== null && c != c.top ? (a = [c.document.URL], c.name && a.push(c.name), c = mY(c, !1), a.push(c.width.toString()), a.push(c.height.toString()), a = Uu(a.join(""))) : a = 0;
        a !== 0 && (b.ifk = a)
    }

    function A1(a, b) {
        (a = PA()[a.I.google_ad_client]) && (b.psts = a.join())
    }

    function B1(a, b) {
        (a = a.pageState.AyxaY) && a >= 0 && (b.tmod = a)
    }

    function C1(a, b) {
        if (a = a.pubWin.google_user_agent_client_hint) {
            let c = [],
                d = 0;
            for (let e = 0; e < a.length; e++) {
                let f = a.charCodeAt(e);
                f > 255 && (c[d++] = f & 255, f >>= 8);
                c[d++] = f
            }
            a = Ab(c);
            b.uach = a
        }
    }

    function D1(a, b) {
        if (a.Ta.OSwJs !== 2) {
            var c = a.Ta.QJRox.kxiJd.VbBrq;
            a = a.Ta.QJRox.kxiJd.hZGxt;
            c >= 0 && (b.pubf = c);
            a >= 0 && (b.pvtf = a)
        }
    }

    function E1(a, b) {
        var c = Number(a.I.google_traffic_source);
        c && Object.values(Ga).includes(c) && (b.trt = a.I.google_traffic_source)
    }

    function F1(a, b) {
        if (x(a.I.google_privacy_treatments)) {
            var c = new Map([
                ["disablePersonalization", 1]
            ]);
            a = a.I.google_privacy_treatments.split(",");
            var d = [];
            for (let [e, f] of c.entries()) c = f, a.includes(e) && d.push(c);
            d.length && (b.ppt = d.join("~"))
        }
    }

    function G1(a, b) {
        if (a.g) {
            a.g.zm && (b.xatf = 1);
            try {
                a.g.uh ? .disconnect(), a.g.uh = void 0
            } catch {}
        }
    }

    function H1(a, b = document) {
        if (U(Cv)) try {
            let {
                labels: c
            } = B0(b);
            c.length && (a.pgls = c.map(d => {
                d = v0(d);
                return Ab(d)
            }).join("~"))
        } catch (c) {
            tB.Da(1278, c)
        }
    }

    function I1(a, b) {
        U(Bv) && (a = a.Ib ? .get(), b.bisch = a ? .charging, b.blev = a ? .level)
    }

    function J1(a, b, c) {
        var d = {};
        x1(a, d);
        C1(a, d);
        a.Ta.mqAVR.crjDQ && (d.abgtt = a.Ta.mqAVR.crjDQ);
        v1(a, d, b, c);
        d.u_tz = -(new Date).getTimezoneOffset();
        try {
            var e = Cl.history.length
        } catch (f) {
            e = 0
        }
        d.u_his = e;
        d.u_h = Cl.screen ? .height;
        d.u_w = Cl.screen ? .width;
        d.u_ah = Cl.screen ? .availHeight;
        d.u_aw = Cl.screen ? .availWidth;
        d.u_cd = Cl.screen ? .colorDepth;
        d.u_sd = nY(a.pubWin);
        d.dmc = a.pubWin.navigator ? .deviceMemory;
        wB(889, () => {
            if (a.K === null) d.adx = -12245933, d.ady = -12245933;
            else {
                var f = a.ca.parentElement,
                    g = f ? .style.display,
                    h = U(Ux) &&
                    f && getComputedStyle(f).display === "none";
                h && f.style.setProperty("display", "block", "important");
                var k = qY(a.K, a.ca);
                d.adx && d.adx !== -12245933 && d.ady && d.ady !== -12245933 || (d.adx = Math.round(k.x), d.ady = Math.round(k.y));
                pY(a.ca) || (d.adx = -12245933, d.ady = -12245933, a.j |= 32768);
                h && (f.style.display = g || "");
                f = a.I.override_ady;
                oc(f) && (d.ady = f);
                f = a.I.override_adx;
                oc(f) && (d.adx = f)
            }
        });
        y1(a, d);
        z1(a, d);
        q1(a, d);
        p1(a, d);
        d.oid = 2;
        A1(a, d);
        U(Fv) && (c = V(Tv), M_(a, d, b, c > 0 ? {
            F: oB,
            Lh: new u0,
            pk: c
        } : void 0));
        d.pvsid = ul(a.pubWin, tB);
        B1(a,
            d);
        d.uas = m1(a.pubWin);
        (c = F0(a.pubWin)) && (d.nvt = c);
        a.l && (d.scar = a.l);
        G1(a, d);
        s1(a, d, b);
        d.fu = a.j;
        d.bc = s0();
        a.pageState.xujKL && (o0(d), d.creatives = r1(/\b(?:creatives)=([\d,]+)/), d.adgroups = r1(/\b(?:adgroups)=([\d,]+)/), d.adgroups || d.sso) && (d.adtest = "on", d.disable_budget_throttling = !0, d.use_budget_filtering = !1, d.retrieve_only = !0, d.disable_fcap = !0);
        Il() && (d.atl = !0);
        a.Ta.OSwJs === 1 && (d.pucrd = a.Ta.QJRox.ZGVTR);
        (b = LY(a.K || a.pubWin)) && (d.plas = b);
        a.Ta.OSwJs === 1 && (d.cust_params = a.Ta.QJRox.zUuKK);
        d.bz = Rk(a.pubWin);
        D1(a, d);
        E1(a, d);
        F1(a, d);
        String(a.I.google_special_category_data) === "true" && (d.scd = 1);
        H1(d, a.pubWin.document);
        I1(a, d);
        return d
    }
    const K1 = /YtLoPri/;

    function L1(a) {
        var b = HA(),
            c = a.google_ad_section;
        qZ(a) && OA(b, 15);
        if (zr(a)) {
            if (OA(b, 5) > 100) return !1
        } else if (OA(b, 6) - MA(b, 15, 0) > 100 && c === "") return !1;
        return !0
    }
    var M1 = Y(function(a, b) {
        var c = b.I,
            d = b.Na,
            e = b.pubWin,
            f = a.R;
        a = a.Ua;
        var g = "";
        if (sZ(c)) g = (f.ha() ? d.Gk : d.Fk).toString() + "#" + (encodeURIComponent("RS-" + c.google_reactive_sra_index + "-") + "&" + wr({
            adk: c.google_ad_unit_key,
            client: c.google_ad_client,
            fa: c.google_reactive_ad_format
        })), u1(c, HA()), L1(c);
        else if ((d = c.google_pgb_reactive === 5 && !!c.google_reactive_ads_config) || (d = c.google_reactive_ad_format, d = !(!c.google_reactive_ads_config && qZ(c) && d !== 16 && d !== 10 && d !== 11 && d !== 40 && d !== 41 && d !== 42)), d || (d = c.google_reactive_ad_format,
                Bi(d) ? (e = Lk(e)) && cZ(e, c, d, f) ? (e = bC(e), qs(e, d) ? d = !1 : (e.adCount[d] || (e.adCount[d] = 0), e.adCount[d]++, d = !0)) : d = !1 : d = !1), d && L1(c)) {
            d = g = b.I;
            var h = b.pubWin;
            e = {};
            let u = h.document;
            var k = {
                xk: Mk(h),
                xh: !1,
                Bj: "",
                hh: 1
            };
            a: {
                var l = d.google_ad_width || h.google_ad_width,
                    m = d.google_ad_height || h.google_ad_height;
                if (h && h.top === h) var n = !1;
                else {
                    n = h.document;
                    var p = n.documentElement;
                    if (l && m) {
                        let w = 1,
                            B = 1;
                        h.innerHeight ? (w = h.innerWidth, B = h.innerHeight) : p && p.clientHeight ? (w = p.clientWidth, B = p.clientHeight) : n.body && (w = n.body.clientWidth,
                            B = n.body.clientHeight);
                        if (B > 2 * m || w > 2 * l) {
                            n = !1;
                            break a
                        }
                    }
                    n = !0
                }
            }
            k.xh = n;
            n = k.xh;
            p = Hk(k.xk).Jh;
            l = wl(h);
            m = 4;
            n || l !== 1 ? n || l !== 2 ? n && l === 1 ? m = 7 : n && l === 2 && (m = 8) : m = 6 : m = 5;
            p && (m |= 16);
            k.Bj = String(m);
            k.hh = GA(h);
            p = k;
            k = p.xk;
            n = p.xh;
            l = !!d.google_page_url;
            e.google_iframing = p.Bj;
            p.hh !== 0 && (e.google_iframing_environment = p.hh);
            if (!l && u.domain === "ad.yieldmanager.com") {
                for (p = u.URL.substring(u.URL.lastIndexOf("http")); p.indexOf("%") > -1;) try {
                    p = decodeURIComponent(p)
                } catch (w) {
                    break
                }
                d.google_page_url = p;
                l = !!p
            }
            l ? (e.google_page_url =
                d.google_page_url, e.google_page_location = (n ? u.referrer : u.URL) || "EMPTY") : (n && Ik(h.top) && u.referrer && h.top.document.referrer === u.referrer ? e.google_page_url = h.top.document.URL : e.google_page_url = n ? u.referrer : u.URL, e.google_page_location = null);
            if (u.URL === e.google_page_url) try {
                var q = Math.round(Date.parse(u.lastModified) / 1E3) || null
            } catch {
                q = null
            } else q = null;
            e.google_last_modified_time = q;
            q = k === k.top ? k.document.referrer : (q = or()) && q.referrer || "";
            e.google_referrer_url = q;
            FA(e, g);
            q = f.ha() ? lY(g) ? "pagead2.googlesyndication.com" :
                "googleads.g.doubleclick.net" : "pagead2.googlesyndication.com";
            f = J1(b, f, a);
            a = b.I;
            e = a.google_ad_channel;
            d = "/pagead/ads?";
            a.google_ad_client === "ca-pub-6219811747049371" && K1.test(e) && (d = "/pagead/lopri?");
            g = vr(f, `https://${q}${d}` + (b.pageState.xujKL && g.google_debug_params ? g.google_debug_params : ""))
        }
        Kl(2, [c, g]);
        return {
            Va: g,
            ra: !g
        }
    }, {
        id: 1437,
        H: {
            Va: void 0,
            ra: void 0
        }
    });
    var N1 = Y(function(a, b, c, d, e) {
        var f = a.Bh;
        if (!f) return {
            Va: "",
            zc: ""
        };
        if (!b.google_async_iframe_id) {
            var g = c;
            g = tr(or(g)) || g;
            g.google_unique_id = (g.google_unique_id || 0) + 1
        }
        var h = yr(b);
        g = c === d ? "a!" + h.toString(36) : `${h.toString(36)}.${Math.floor(Math.random()*2147483648).toString(36)+Math.abs(Math.floor(Math.random()*2147483648)^Date.now()).toString(36)}`;
        c = rY(d, c, e, !0) > 0;
        d = {
            ifi: h,
            uci: g
        };
        c && (c = HA(), d.btvi = MA(c, 21, 1), OA(c, 21));
        f = vr(d, f);
        jl() && !sZ(b) && (f = Dm(f, "fsb", 1));
        return a.Ga ? {
            Va: Dm(f, "fca", "1"),
            zc: g
        } : {
            Va: f,
            zc: g
        }
    }, {
        id: 1438,
        H: {
            Va: void 0,
            zc: void 0
        }
    });
    var O1 = Y(function(a) {
        var b = a.url;
        if (a.ra) return {
            Va: ""
        };
        a = b;
        a.length > 61440 && (a = a.substring(0, 61432), a = a.replace(/%\w?$/, ""), a = a.replace(/&[^=]*=?$/, ""), a += "&trunc=1");
        if (a !== b) {
            let c = b.lastIndexOf("&", 61432);
            c === -1 && (c = b.lastIndexOf("?", 61432));
            zB("trn", {
                ol: b.length,
                tr: c === -1 ? "" : b.substring(c + 1),
                url: b
            }, .01)
        }
        return {
            Va: a
        }
    }, {
        id: 1374,
        H: {
            Va: void 0
        }
    });
    var P1 = class extends d_ {
        constructor(a, b, c, d, e, f) {
            super(a, b, c, d, f);
            this.qa = e;
            this.output = a_(this, new SZ);
            this.complete = new WZ
        }
        A(a) {
            a.then(b => {
                b instanceof LZ || (NZ(this.output, b), this.complete.notify())
            }, b => {
                this.qa ? NZ(this.output, this.qa(b)) : this.output.setError(new KZ(`output error: ${b.message}`), () => {
                    this.G.Ja({
                        methodName: this.id,
                        eb: b
                    })
                });
                this.complete.notify()
            })
        }
        j(a) {
            this.qa ? (NZ(this.output, this.qa(a)), this.complete.notify()) : super.j(a)
        }
    };

    function Q1(a, b) {
        a.id = b.id;
        a.qa = b.qa;
        return a
    }

    function R1(a, b, c, ...d) {
        return new P1(a.id, a, b, c, a.qa, d)
    };

    function S1(a, b) {
        wt(a, b);
        a.P.push(b);
        return b
    }

    function Z(a, b, c, ...d) {
        return S1(a, f_(b, a.C, c, ...d))
    }

    function T1(a, b, c, ...d) {
        return S1(a, R1(b, a.C, c, ...d))
    }

    function U1(a, b) {
        a.W.push(b);
        wt(a, b);
        return b
    }
    async function V1(a) {
        a.A.length && await Promise.all(a.A.map(d => d.Z.promise));
        if (await a.la()) {
            for (var b of a.P) b.start();
            for (var c of a.W) V1(c);
            if (a.D && (b = Object.keys(a.D), b.length)) {
                c = await Promise.all(Object.values(a.D).map(e => e.promise));
                let d = 0;
                for (let e of b) a.Ba[e] = c[d++]
            }
        }
        a.Z.resolve(a.Ba)
    }
    var W1 = class extends O {
        constructor(a) {
            super();
            this.C = a;
            this.P = [];
            this.W = [];
            this.Ba = {};
            this.A = [];
            this.Z = new $W;
            this.D = {}
        }
        async la() {
            return !0
        }
        g() {
            super.g();
            this.P.length = 0;
            this.W.length = 0;
            this.A.length = 0
        }
    };
    var X1 = class extends W1 {
        constructor(a, b, c, d, e, f) {
            super(a);
            a = X(Z(this, M1, {
                R: c,
                Ua: f
            }, b), d);
            b = Z(this, N1, {
                Bh: a.Va,
                Ga: e
            }, b.I, b.pubWin, b.K, b.ca);
            this.j = {
                bn: Z(this, O1, {
                    ra: a.ra,
                    url: b.Va
                }).Va,
                ra: a.ra,
                zc: b.zc
            }
        }
    };
    var Y1 = Y(function(a, b) {
        return {
            R: b.R
        }
    }, {
        id: 1462,
        H: {
            R: void 0
        }
    });
    var Z1 = Y(function(a, b, c, d) {
        b = a.zb;
        return a.R.ha() || b ? {
            Vd: !0
        } : (zB("afc_noc_req", {
            client: c.google_ad_client,
            isGdprCountry: d.OSCLM.UWEfJ.toString()
        }, V(Ov)), {
            Vd: !1
        })
    }, {
        id: 1381,
        H: {
            Vd: void 0
        }
    });

    function $1(a, b, c, d, e) {
        var f = VW(a, "gpi-uoo", (g, h) => {
            h.source === c && (h = uk(g.userOptOut ? "1" : "0"), h = wf(h, 2, 2147483647), h = Jf(h, 3, "/"), h = Jf(h, 4, a.location.hostname), b && (e.set("__gpi_opt_out", h, b), g.userOptOut || g.clearAdsData)) && (e.delete("__gads", b), e.delete("__gpi", b))
        });
        d.push(f)
    };
    var a2 = Y(function(a, b) {
        var c = a.R;
        a = a.Ua;
        if (c.ha()) {
            b = b.location.hostname;
            var d = a.get("__gpi_opt_out", c);
            d && (d = uk(d), d = wf(d, 2, 2147483647), d = Jf(d, 3, "/"), b = Jf(d, 4, b), a.set("__gpi_opt_out", b, c))
        }
        return {}
    }, {
        id: 1382,
        H: {}
    });
    var b2 = Y(function(a, b) {
        var c = a.R;
        a = a.Ua;
        m0(20, b, c, a);
        m0(17, b, c, a);
        return {}
    }, {
        id: 1433,
        H: {}
    });
    var c2 = Y(function(a, b) {
        U(cx) && (b.aieuf = !0, b.aicrs = !0, sY(b));
        return {}
    }, {
        id: 1449,
        H: {}
    });
    var d2 = Y(function(a, b) {
        var c = b.I.google_reactive_ads_config;
        if (!c) return {};
        a = a.R;
        nZ(b.K, c);
        uZ(c, b, a);
        c = c.page_level_pubvars;
        ra(c) && Gi(b.I, c);
        return {}
    }, {
        id: 1434,
        H: {}
    });
    var e2 = Y(function(a, b) {
        a = a.R;
        a: {
            var c = [t.top];
            var d = [];
            let f = 0,
                g;
            for (; g = c[f++];) {
                d.push(g);
                try {
                    if (g.frames)
                        for (let h = 0; h < g.frames.length && c.length < 1024; ++h) c.push(g.frames[h])
                } catch {}
            }
            c = d;
            for (d = 0; d < c.length; d++) try {
                var e = c[d].frames.google_esf;
                if (e) {
                    Bl = e;
                    break a
                }
            } catch (h) {}
            Bl = null
        }
        if (Bl) return {};
        e = $k("IFRAME");
        e.id = "google_esf";
        e.name = "google_esf";
        Ii(e, a.ha() ? b.Gk : b.Fk);
        e.style.display = "none";
        e && document.documentElement.appendChild(e);
        return {}
    }, {
        id: 1441,
        H: {}
    });
    var f2 = Q1(async function(a, b) {
        return b.g ? .Ll || Promise.resolve()
    }, {
        id: 1436
    });
    var g2 = class extends W1 {
        async la() {
            var a = await this.j();
            a || this.l();
            return a
        }
    };
    async function h2(a, b, c) {
        a = new i2(b.id, b, a, c, b.qa);
        await a.start();
        b = await a.C.promise;
        a.dispose();
        return b
    }
    class i2 extends d_ {
        constructor(a, b, c, d, e) {
            super(a, b, c, d, []);
            this.qa = e;
            this.C = ja(Promise, "withResolvers").call(Promise)
        }
        W() {
            var a = this.f(c_(this), ...this.J);
            this.C.resolve(a)
        }
        A() {}
        j(a) {
            this.qa !== void 0 ? this.C.resolve(this.qa(a)) : super.j(a)
        }
    }

    function j2(a, b) {
        a.id = b.id;
        a.qa = b.qa;
        return a
    };
    const k2 = j2(function(a) {
        return a.Wa
    }, {
        id: 1464
    });
    var l2 = class extends g2 {
        constructor(a, b, c, d, e, f) {
            super(a);
            this.ea = a;
            this.Wa = d;
            a = X(Z(this, e2, {
                R: c
            }, b.Na), e);
            f = X(Z(this, b2, {
                R: c,
                Ua: f
            }, b.pubWin), a.finished);
            c = X(Z(this, d2, {
                R: c
            }, b), f.finished);
            c = X(T1(this, f2, {}, b), c.finished);
            this.G = X(Z(this, c2, {}, b.I), c.complete).finished
        }
        async j() {
            return h2(this.ea, k2, {
                Wa: this.Wa
            })
        }
        l() {
            this.G.notify()
        }
    };
    var m2 = Y(function(a, b) {
        return U(Rx) && b.pageState.uNjDc ? {
            Ga: !1
        } : {
            Ga: U(Px) && !!b.pubWin.fetch && !sZ(b.I) && !qZ(b.I)
        }
    }, {
        id: 1488,
        H: {
            Ga: void 0
        }
    });
    var n2 = Y(function(a, b) {
        var c = b.pubWin,
            d = b.ca,
            e = b.I,
            f = b.Sc;
        a = V(Xx);
        e = !rs(e.google_reactive_ad_format) && (qZ(e) || e.google_reactive_ads_config);
        if (b.g ? .uh || a <= 0 || Lk(c) || !t.IntersectionObserver || e) return {};
        b.g = {};
        var g = V(Yx),
            h = new Yq(f),
            k = Ul();
        c = new Promise(l => {
            var m = 0,
                n = b.g,
                p = new t.IntersectionObserver(xB(1236, q => {
                    if (q = q.find(u => u.target === d)) h.Xb.hc.Qe.g.g.Td({
                        Zc: Ul() - k,
                        Sn: ++m
                    }), n.zm = q.isIntersecting && q.intersectionRatio >= g, l()
                }), {
                    threshold: [g]
                });
            p.observe(d);
            n.uh = p
        });
        b.g.Ll = Promise.race([c, vl(a, null)]).then(l => {
            h.Xb.hc.Qe.g.j.Td({
                Zc: Ul() - k,
                status: l === null ? "TIMEOUT" : "OK"
            })
        });
        return {}
    }, {
        id: 1345,
        H: {}
    });

    function o2(a, b, c, d) {
        a.F ? .Xb.hc.Rk.Fl.wa({
            Mk: b,
            El: c,
            Ym: d,
            da: 1
        })
    }
    var p2 = class extends O {
        constructor(a, b, c) {
            var d = ["__eoi", "__gads", "__gpi", "__gpi_opt_out"],
                e = kB(100) ? oB : void 0;
            super();
            this.win = b;
            this.ea = c;
            this.F = e;
            this.j = new Map;
            this.l = !1;
            for (let g of d) this.j.set(g, void 0);
            if (b.cookieStore && b.cookieStore.addEventListener && a.ha() && (!Va() || wl(this.win) !== 2) && b.origin !== "null") {
                this.cookieStore = b.cookieStore;
                var f = g => {
                    if (!this.B) {
                        for (let h of g.changed) h.name && this.j.has(h.name) && this.j.set(h.name, h.value);
                        for (let h of g.deleted) h.name && this.j.has(h.name) && this.j.set(h.name,
                            void 0)
                    }
                };
                this.cookieStore.addEventListener("change", f);
                xt(this, () => {
                    this.cookieStore ? .removeEventListener("change", f)
                });
                this.cookieStore.getAll().then(g => {
                    if (!this.B && this.cookieStore) {
                        for (let h of g) h.name && this.j.has(h.name) && this.j.set(h.name, h.value);
                        this.l = !0
                    }
                }).catch(g => {
                    this.ea.Ja({
                        methodName: 1607,
                        eb: g
                    })
                })
            }
        }
        get(a, b) {
            if (b && !b.ha()) return null;
            if (!this.l) return o2(this, "safe_storage", a, "read"), xI(a, this.win);
            o2(this, "cookie_store", a, "read");
            return this.j.get(a) ? ? null
        }
        set(a, b, c) {
            if (!c || c.ha()) this.l &&
                this.cookieStore ? (b = {
                    name: a,
                    value: b.getValue(),
                    expires: KH(hf(b, 2)) * 1E3,
                    domain: D(b, 4) || void 0,
                    path: D(b, 3) || void 0,
                    sameSite: "none"
                }, o2(this, "cookie_store", a, "write"), this.cookieStore.set(b).catch(d => {
                    d instanceof Error && (d.message = `${d.message} (Cookie: ${a})`);
                    this.ea.Ja({
                        methodName: 1608,
                        eb: d
                    })
                })) : (c = KH(hf(b, 2)) - Date.now() / 1E3, c = {
                    Kf: Math.max(c, 0),
                    path: D(b, 3),
                    domain: D(b, 4),
                    secure: !1
                }, o2(this, "safe_storage", a, "write"), yI(a, b.getValue(), c, this.win))
        }
        delete(a, b) {
            if (b.ha())
                for (let c of xr(this.win.location.hostname)) this.l &&
                    this.cookieStore ? (b = {
                        name: a,
                        path: "/",
                        domain: c
                    }, o2(this, "cookie_store", a, "delete"), this.cookieStore.delete(b).catch(d => {
                        d instanceof Error && (d.message = `${d.message} (Cookie: ${a})`);
                        this.ea.Ja({
                            methodName: 1609,
                            eb: d
                        })
                    })) : (o2(this, "safe_storage", a, "delete"), zI(a, this.win, c))
        }
    };
    let q2 = null;
    var r2 = Y(function(a, b, c) {
        q2 || (q2 = new p2(a.R, b, c));
        return {
            gj: q2
        }
    }, {
        id: 1638,
        H: {
            gj: void 0
        }
    });
    var s2 = Y(function(a, b, c) {
        var d = a.ia;
        d && d.setAttribute("data-google-container-id", a.zc);
        a = b.iaaso;
        a != null && (b = c.parentElement, (b && mz.test(b.className) ? b : c).setAttribute("data-auto-ad-size", a));
        d.setAttribute("tabindex", "0");
        d.setAttribute("title", "Advertisement");
        d.setAttribute("aria-label", "Advertisement");
        return {}
    }, {
        id: 1418,
        H: {}
    });
    var t2 = Y(function(a) {
        return {
            ia: a.Ga ? a.bm : a.Xn
        }
    }, {
        id: 1489,
        H: {
            ia: void 0
        }
    });

    function u2(a, b) {
        var c = $k("STYLE", a);
        c.textContent = Ph(Qh `* { pointer-events: none; }`);
        a ? .head.appendChild(c);
        setTimeout(() => {
            a ? .head.removeChild(c)
        }, b)
    }

    function v2(a, b, c) {
        if (!a.body) return null;
        var d = new w2;
        d.apply(a, b);
        return () => {
            var e = c || 0;
            e > 0 && u2(b.document, e);
            Fj(a.body, {
                filter: d.g,
                webkitFilter: d.g,
                overflow: d.l,
                position: d.B,
                top: d.A
            });
            b.scrollTo(0, d.j)
        }
    }
    class w2 {
        constructor() {
            this.g = this.A = this.B = this.l = null;
            this.j = 0
        }
        apply(a, b) {
            this.l = a.body.style.overflow;
            this.B = a.body.style.position;
            this.A = a.body.style.top;
            this.g = a.body.style.filter ? a.body.style.filter : a.body.style.webkitFilter;
            this.j = ts(b);
            Fj(a.body, "top", `${-this.j}px`)
        }
    };

    function x2(a, b) {
        var c;
        if (!a.l)
            for (a.l = [], c = a.j.parentElement; c;) {
                a.l.push(c);
                if (a.P(c)) break;
                c = c.parentNode && c.parentNode.nodeType === 1 ? c.parentNode : null
            }
        c = a.l.slice();
        var d, e;
        for (d = 0; d < c.length; ++d)(e = c[d]) && b.call(a, e, d, c)
    }
    var y2 = class extends O {
        constructor(a, b, c) {
            super();
            this.j = a;
            this.Z = b;
            this.G = c;
            this.l = null;
            xt(this, () => this.l = null)
        }
        P(a) {
            return this.G === a
        }
    };

    function z2(a, b) {
        var c = a.G;
        c && (b ? (FD(a.J), J(c, {
            display: "block"
        }), a.D.body && !a.A && (a.A = v2(a.D, a.Z, a.la)), c.setAttribute("tabindex", "0"), c.setAttribute("aria-hidden", "false"), a.D.body.setAttribute("aria-hidden", "true")) : (GD(a.J), J(c, {
            display: "none"
        }), a.A && (a.A(), a.A = null), a.D.body.setAttribute("aria-hidden", "false"), c.setAttribute("aria-hidden", "true")))
    }

    function A2(a, b) {
        Qk(a.W) <= 1 || (Fj(b, {
            overflow: "scroll",
            "max-width": "100vw"
        }), ol(b, void 0, a.C))
    }

    function B2(a) {
        z2(a, !1);
        var b = a.G;
        if (b) {
            var c = C2(a.W);
            x2(a, d => {
                J(d, c);
                xs(d, a.C)
            });
            a.j.setAttribute("width", "");
            a.j.setAttribute("height", "");
            Fj(a.j, c);
            Fj(a.j, D2);
            Fj(b, E2);
            Fj(b, {
                background: "transparent"
            });
            J(b, {
                display: "none",
                position: "fixed"
            });
            xs(b, a.C);
            xs(a.j, a.C);
            A2(a, b)
        }
    }
    var F2 = class extends y2 {
            constructor(a, b, c, d, e = !1) {
                super(a, b, c);
                this.W = b;
                this.la = d;
                this.C = e;
                this.A = null;
                this.D = b.document;
                this.J = zD(new ED(b), 2147483646)
            }
        },
        E2 = {
            backgroundColor: "white",
            opacity: "1",
            position: "fixed",
            left: "0px",
            top: "0px",
            margin: "0px",
            padding: "0px",
            display: "none",
            zIndex: "2147483647"
        },
        D2 = {
            left: "0",
            position: "absolute",
            top: "0"
        };

    function C2(a) {
        a = Qk(a);
        a = 100 * (a < 1 ? 1 : a);
        return {
            width: `${a}vw`,
            height: `${a}vh`
        }
    };
    var G2 = class extends F2 {
        constructor(a, b, c) {
            super(b, a, c, V(Wx), U(Ev));
            B2(this)
        }
        P(a) {
            return a.classList ? a.classList.contains("adsbygoogle") : hb(a.classList ? a.classList : (typeof a.className == "string" ? a.className : a.getAttribute && a.getAttribute("class") || "").match(/\S+/g) || [], "adsbygoogle")
        }
    };
    const H2 = {
        [1]: "closed",
        [2]: "viewed",
        [3]: "dismissed"
    };
    async function I2(a, b, c, d, e) {
        a = new J2(a, b, c, d, e);
        await a.init();
        return a
    }

    function K2(a) {
        return setTimeout(xB(728, () => {
            L2(() => {
                a.C.reject()
            });
            a.dispose()
        }), V(Vx) * 1E3)
    }

    function M2(a, b) {
        var c = aX(a.j).then(() => {
            clearTimeout(b);
            a.C.resolve()
        });
        yB(1005, c);
        c = bX(a.j).then(d => {
            N2(a, H2[d.status], d.payload)
        });
        yB(1006, c);
        c = cX(a.j).then(() => {
            N2(a, "error")
        });
        yB(1004, c)
    }

    function O2(a) {
        a.win.location.hash !== "" && zB("pub_hash", {
            o_url: a.win.location.href
        }, .1);
        a.win.location.hash = "goog_fullscreen_ad";
        var b = xB(950, c => {
            c.oldURL.endsWith("#goog_fullscreen_ad") && (a.l === 10 ? (N2(a, "closed"), a.win.removeEventListener("hashchange", b)) : (a.win.location.hash = "goog_fullscreen_ad", XW(a.j.Mg, "fullscreen", {
                eventType: "backButton"
            }, "*")))
        });
        a.win.addEventListener("hashchange", b);
        xt(a, () => {
            a.win.removeEventListener("hashchange", b);
            a.win.location.hash === "#goog_fullscreen_ad" && a.win.history.back()
        })
    }

    function L2(a) {
        try {
            a()
        } catch (b) {}
    }

    function N2(a, b, c) {
        z2(a.G, !1);
        a.A && (c && b === "viewed" ? L2(() => {
            a.A({
                status: b,
                reward: c
            })
        }) : L2(() => {
            a.A({
                status: b
            })
        }));
        a.l === 11 && zB("fs_ad", {
            tgorigin: a.I.google_tag_origin,
            client: a.I.google_ad_client,
            url: a.I.google_page_url ? ? "",
            slot: a.I.google_ad_slot ? ? "0",
            ratype: a.l,
            clostat: b
        }, 1);
        a.dispose()
    }
    var J2 = class extends O {
        constructor(a, b, c, d, e) {
            super();
            this.win = a;
            this.D = b;
            this.J = c;
            this.l = d;
            this.I = e;
            this.A = null;
            this.G = new G2(a, c, b);
            a = new eX(this.l === 10 ? 1 : 2, this.win, this.J.contentWindow);
            a.init();
            this.j = a;
            this.C = new $W;
            this.D.dataset["slotcar" + (this.l === 10 ? "Interstitial" : "Rewarded")] = "true"
        }
        async init() {
            var a = K2(this);
            M2(this, a);
            xt(this, () => {
                this.j.dispose();
                clearTimeout(a);
                pj(this.D)
            });
            await this.C.promise
        }
        show(a) {
            this.B || (this.A = a, z2(this.G, !0), t.IntersectionObserver || XW(this.j.Mg, "fullscreen", {
                eventType: "visible"
            }, "*"), O2(this))
        }
        disposeAd() {
            this.dispose()
        }
    };
    var P2 = Y(function(a, b, c, d) {
        a = a.ia;
        if (!b.google_acr) return {};
        if (b.google_wrap_fullscreen_ad) {
            let e = b.google_acr;
            I2(c, d.parentElement, a, b.google_reactive_ad_format, b).then(e).catch(() => {
                e(null)
            })
        } else b.google_acr(a);
        return {}
    }, {
        id: 1354,
        H: {}
    });
    const Q2 = (a, b) => {
        try {
            let p = C(b, 6) === void 0 ? !0 : C(b, 6);
            var c = lk(E(b, 2)),
                d = D(b, 3);
            a: switch (E(b, 4)) {
                case 1:
                    var e = "pt";
                    break a;
                case 2:
                    e = "cr";
                    break a;
                default:
                    e = ""
            }
            var f = new nk(c, d, e),
                g = y(b, jk, 5) ? .g() ? ? "";
            f.Rc = g;
            f.j = p;
            var h = !!C(b, 7);
            f.Ac = h;
            var k = !!C(b, 8);
            f.Kb = k;
            var l = !!C(b, 9);
            f.g = l;
            var m = !!C(b, 10);
            f.l = m;
            f.win = a;
            var n = f.build();
            ik(n)
        } catch {}
    };

    function R2(a, b) {
        a.goog_sdr_l || (Object.defineProperty(a, "goog_sdr_l", {
            value: !0
        }), a.document.readyState === "complete" ? Q2(a, b) : Yj(a, "load", () => void Q2(a, b)))
    };
    var S2 = Y(function(a, b, c, d) {
        a = a.R;
        var e = HB();
        e.g && (e.state.tar += 1);
        e.Pa = b.google_page_url;
        b = new kk;
        e = new jk;
        var f = String(ul(c));
        e = Kf(e, 1, f);
        b = z(b, 5, e);
        b = F(b, 4, 1);
        b = F(b, 2, 1);
        d = Kf(b, 3, d.jTCuI);
        a = a.ha();
        d = tf(d, 6, a);
        d = tf(d, 7, !0);
        d = tf(d, 8, !0);
        R2(c, d);
        return {}
    }, {
        id: 1347,
        H: {}
    });

    function T2(a, b, c) {
        var d = b.parentElement ? .classList.contains("adsbygoogle") ? b.parentElement : b;
        c.addEventListener("load", () => {
            U2(d)
        });
        return WW(a, "adpnt", (e, f) => {
            if (ss(f, c.contentWindow)) {
                e = vs(e).qid;
                try {
                    c.setAttribute("data-google-query-id", e), a.googletag ? ? (a.googletag = {
                        cmd: []
                    }), a.googletag.queryIds = a.googletag.queryIds ? ? [], a.googletag.queryIds.push(e), a.googletag.queryIds.length > 500 && a.googletag.queryIds.shift()
                } catch {}
                d.dataset.adStatus = "filled";
                e = !0
            } else e = !1;
            return e
        })
    }

    function U2(a) {
        setTimeout(() => {
            var b = a.dataset.adStatus;
            b !== "filled" && b !== "unfill-optimized" && (a.dataset.adStatus = "unfilled")
        }, 1E3)
    };
    var V2 = Y(function(a, b, c, d) {
        a = a.ia;
        b && d.push(T2(b, c, a));
        return {}
    }, {
        id: 1423,
        H: {}
    });

    function W2(a) {
        if (a.location ? .ancestorOrigins) return a.location.ancestorOrigins.length;
        var b = 0;
        Jk(() => {
            b++;
            return !1
        }, a);
        return b
    }

    function X2(a, b, c, d = "//tpc.googlesyndication.com") {
        var e = c;
        e && (e = "?" + e);
        b = d + ("/safeframe/" + b + "/html/container.html" + e);
        (a = W2(a)) && (b += `${c?"&":"?"}n=${a}`);
        return `https:${b}`
    };
    var Y2 = {
        Gm: function(a) {
            if (!x(a.version)) throw new TypeError("version is not a string");
            if (!/^[0-9]+-[0-9]+-[0-9]+$/.test(a.version)) throw new RangeError(`Invalid version: ${a.version}`);
            if (!x(a.gg)) throw new TypeError("subdomain is not a string");
            if (!/^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$/.test(a.gg)) throw new RangeError(`Invalid subdomain: ${a.gg}`);
            return Sh(`https://${a.gg}.safeframe.googlesyndication.com/safeframe/${a.version}/html/container.html`)
        },
        Bp(a) {
            return fi `https://tpc.googlesyndication.com/safeframe/${a}/html/container.html`
        }
    };

    function Z2(a) {
        return `//${a}.safeframe.googlesyndication.com`
    }

    function $2(a, b) {
        return (b = W2(b)) ? gi(a, new Map([
            ["n", String(b)]
        ])) : a
    }
    var b3 = oi(a3);

    function a3() {
        var a = "";
        for (let b of c3()) b <= 15 && (a += "0"), a += b.toString(16);
        return a
    }

    function c3() {
        if (typeof window.crypto ? .getRandomValues === "function") {
            var a = new Uint8Array(16);
            window.crypto.getRandomValues(a);
            return a
        }
        a = window;
        if (typeof a.msCrypto ? .getRandomValues === "function") {
            var b = new Uint8Array(16);
            a.msCrypto.getRandomValues(b);
            return b
        }
        a = Array(16);
        for (b = 0; b < a.length; b++) a[b] = Math.floor(Math.random() * 255);
        return a
    };

    function d3(a, b, c) {
        try {
            if (!e3(a, c.origin) || !ss(c, a.j.contentWindow)) return
        } catch (f) {
            return
        }
        var d = b.msg_type,
            e = null;
        x(d) && (e = a.messageHandlers[d]) && a.ob.Yb(168, () => {
            e.call(a, b, c)
        })
    }

    function e3(a, b) {
        return a.Kk.includes(b) || tl(b)
    }
    var f3 = class extends O {
        constructor(a, b) {
            var c = tB,
                d = rB,
                e = U(Px) ? [`https:${Z2(b3())}`] : [];
            super();
            this.l = a;
            this.j = b;
            this.ob = c;
            this.F = d;
            this.Kk = e;
            this.messageHandlers = {};
            this.la = [];
            this.Gb = this.ob.Zb(168, (f, g) => void d3(this, f, g));
            this.Ii = this.ob.Zb(169, (f, g) => ws(this.l, "ras::xsf", this.F, g));
            this.init({})
        }
        init() {
            this.Z(this.messageHandlers);
            this.la.push(VW(this.l, "sth", this.Gb, this.Ii))
        }
        g() {
            for (let a of this.la) a();
            this.la.length = 0;
            super.g()
        }
    };
    var g3 = class extends f3 {};

    function h3(a, b, c, d, e = null) {
        return new i3(a, b, c, d, e)
    }
    var i3 = class extends g3 {
        constructor(a, b, c, d, e) {
            super(a, b);
            this.Xa = c;
            this.Ua = d;
            this.R = e;
            this.ea = HB();
            this.A = () => {};
            Yj(this.j, "load", this.A)
        }
        g() {
            Zj(this.j, "load", this.A);
            super.g()
        }
        Z(a) {
            a["adsense-labs"] = b => {
                if (b = vs(b).settings)
                    if (b = rg(wk, JSON.parse(b)), Nf(b, 1)) {
                        var c = b.aa;
                        if (Ue(b, c, c[v] | 0, vk, 4, 3).length > 0) {
                            var d = Ve(b, vk, 4, De(kc)),
                                e = d;
                            c = this.ea;
                            let h = new Ho;
                            for (var f of e) switch (f.getVersion()) {
                                case 1:
                                    sf(h, 1, !0);
                                    break;
                                case 2:
                                    sf(h, 2, !0)
                            }
                            f = new Io;
                            f = A(f, 1, Jo, h);
                            WB(c, f);
                            f = d;
                            c = this.R;
                            d = this.Ua;
                            if (!MA(HA(),
                                    37, !1)) {
                                if (c)
                                    for (var g of f) switch (g.getVersion()) {
                                        case 1:
                                            d.set("__gads", g, c);
                                            break;
                                        case 2:
                                            d.set("__gpi", g, c)
                                    }
                                NA(HA(), 37, !0)
                            }
                            we(b, 4)
                        }
                        if (g = y(b, vk, 5)) f = this.Ua, MA(HA(), 40, !1) || (f.set("__eoi", g), NA(HA(), 40, !0));
                        we(b, 5);
                        g = this.l;
                        f = D(b, 1) || "";
                        c = this.Xa;
                        if (Ju(vU({
                                win: g,
                                Xa: c
                            }))) {
                            c = c0(g, c);
                            b !== null && (c[f] = Zd(b));
                            try {
                                g.localStorage.setItem("google_adsense_settings", JSON.stringify(c))
                            } catch (h) {}
                        }
                    }
            }
        }
    };
    var j3 = Y(function(a, b, c) {
        var d = a.ia,
            e = a.Ea,
            f = a.R;
        a = a.Ua;
        b && e(h3(b, d, c.OSCLM.UWEfJ, a, f));
        return {}
    }, {
        id: 1424,
        H: {}
    });
    var k3 = Y(function(a, b, c, d) {
        return {
            Ea: e => {
                e && d.push(() => {
                    e.dispose()
                })
            },
            Sa: b && (!qZ(c) || rZ(c))
        }
    }, {
        id: 1425,
        H: {
            Ea: void 0,
            Sa: void 0
        }
    });
    var l3 = Y(function(a, b, c) {
        $1(b, a.R, a.ia.contentWindow, c, a.Ua);
        return {}
    }, {
        id: 1429,
        H: {}
    });

    function m3(a) {
        var b = a.J.getBoundingClientRect(),
            c = b.top + b.height < 0;
        return !(b.top > a.j.innerHeight) && !c
    }
    var n3 = class extends O {
        constructor(a, b, c) {
            super();
            this.j = a;
            this.C = b;
            this.J = c;
            this.D = 0;
            this.A = m3(this);
            var d = qi(this.G, this);
            this.l = xB(433, () => {
                Cl.requestAnimationFrame ? Cl.requestAnimationFrame(d) : d()
            });
            Yj(this.j, "scroll", this.l, Vj)
        }
        G() {
            var a = m3(this);
            if (a && !this.A) {
                var b = {
                    rr: "vis-bcr"
                };
                let c = this.C.contentWindow;
                c && (YW(c, "ig", b, "*", 2), ++this.D >= 10 && this.dispose())
            }
            this.A = a
        }
        dispose() {
            this.l && Zj(this.j, "scroll", this.l, Vj)
        }
    };
    var o3 = Y(function(a, b, c) {
        var d = a.ia,
            e = a.Sa;
        a = a.Ea;
        b && e && a(b.IntersectionObserver ? null : new n3(b, d, c));
        return {}
    }, {
        id: 1427,
        H: {}
    });
    var p3 = Y(function(a, b) {
        if (U(Dv) || U(uv)) {
            if (t.MutationObserver === void 0 || t.DOMRect === void 0) return {};
            let c = b.ca.parentElement || null;
            c && mz.test(c.className) && zX(c).j(d => {
                (U(xv) || d !== "unfill-optimized") && b.Ob ? .Z(c);
                d !== null && b.Ob ? .la(c, d, b.I)
            })
        }
        return {}
    }, {
        id: 1512,
        H: {}
    });

    function q3(a, b) {
        var c = a.pubWin,
            d = a.I.google_ad_client,
            e = PA(),
            f = null,
            g = VW(c, "pvt", (h, k) => {
                x(h.token) && k.source === b.contentWindow && (f = h.token, g(), e[d] = e[d] || [], e[d].push(f), e[d].length > 100 && e[d].shift())
            });
        a.Ia.push(g);
        return () => {
            f && Array.isArray(e[d]) && (ib(e[d], f), e[d].length || delete e[d], f = null)
        }
    };
    var r3 = Y(function(a, b) {
        return {
            Ye: q3(b, a.ia)
        }
    }, {
        id: 1430,
        H: {
            Ye: void 0
        }
    });
    var s3 = class extends I {},
        t3 = qh(s3);
    var w3 = class extends g3 {
        constructor(a, b, c, d, e) {
            super(a, b);
            this.ca = c;
            this.I = d;
            this.Nb = e
        }
        Z(a) {
            a["resize-me"] = (b, c) => {
                if (this.Nb && this.l ? .location ? .hash ? .match(/\bgoog_cpmi=([^&]*)/)) {
                    var d = this.I.google_ad_client;
                    if (!x(d)) throw new qB(`Invalid property code ${d}`);
                    c = this.Nb;
                    b = new s3;
                    b = Kf(b, 2, d);
                    u3(c, b)
                } else {
                    this.Nb && (d = vs(b), d.r_affa && d.r_affa !== "" && (d = t3(d.r_affa), v3(this.Nb, d)));
                    b = vs(b);
                    var e = b.r_chk;
                    if (e == null || e === "") {
                        d = dl(b.r_nw);
                        var f = dl(b.r_nh),
                            g = dl(b.r_no);
                        g != null || d !== 0 && f !== 0 || (g = 0);
                        var h =
                            b.r_str;
                        h = h ? h : null; {
                            var k = /^true$/.test(b.r_ao),
                                l = /^true$/.test(b.r_ifr),
                                m = /^true$/.test(b.r_cab);
                            let q = window;
                            if (q)
                                if (h === "no_rsz") b.err = "7", d = !0;
                                else {
                                    var n = new f1(this.j);
                                    if (n.g) {
                                        var p = n.getWidth();
                                        p != null && (b.w = p);
                                        p = n.getHeight();
                                        p != null && (b.h = p);
                                        g1(n, h, f, m) ? (n = this.ca, e = k1(q, n, {
                                                width: d,
                                                height: f,
                                                opacity: g,
                                                check: e,
                                                fg: h,
                                                Re: k,
                                                Wf: l,
                                                Ce: m
                                            }, [this.j]), b.r_cui && /^true$/.test(b.r_cui.toString()) && J(n, {
                                                height: `${f===null?0:f-48}px`,
                                                top: "24px"
                                            }), d != null && (b.nw = d), f != null && (b.nh = f), b.rsz = e.toString(), b.abl =
                                            N0(e), b.frsz = (h === "force").toString(), b.err = "0", d = !0) : (b.err = "1", d = !1)
                                    } else b.err = "3", d = !1
                                }
                            else b.err = "2", d = !1
                        }
                        XW(c.source, "sth", {
                            msg_type: "resize-result",
                            r_str: h,
                            r_status: d
                        }, "*");
                        this.j.dataset.googleQueryId || this.j.setAttribute("data-google-query-id", b.qid)
                    }
                }
            }
        }
    };
    var x3 = Y(function(a, b, c, d) {
        var e = a.ia,
            f = a.Sa,
            g = a.Ea;
        a = a.Nb;
        b && f && !c.no_resize && g(new w3(b, e, d, c, a));
        return {}
    }, {
        id: 1426,
        H: {}
    });

    function y3(a) {
        return b => !!(b.ma() & a)
    }
    var z3 = class extends S_ {
        constructor(a, b, c, d = !1) {
            super(a, b);
            this.B = c;
            this.l = d
        }
        ma() {
            return this.B
        }
        Fh() {
            return this.l
        }
        j(a, b, c) {
            c.style.height = `${this.height}px`;
            b.rpe = !0
        }
    };
    const A3 = {
            image_stacked: 1 / 1.91,
            image_sidebyside: 1 / 3.82,
            mobile_banner_image_sidebyside: 1 / 3.82,
            pub_control_image_stacked: 1 / 1.91,
            pub_control_image_sidebyside: 1 / 3.82,
            pub_control_image_card_stacked: 1 / 1.91,
            pub_control_image_card_sidebyside: 1 / 3.74,
            pub_control_text: 0,
            pub_control_text_card: 0
        },
        B3 = {
            image_stacked: 80,
            image_sidebyside: 0,
            mobile_banner_image_sidebyside: 0,
            pub_control_image_stacked: 80,
            pub_control_image_sidebyside: 0,
            pub_control_image_card_stacked: 85,
            pub_control_image_card_sidebyside: 0,
            pub_control_text: 80,
            pub_control_text_card: 80
        },
        C3 = {
            pub_control_image_stacked: 100,
            pub_control_image_sidebyside: 200,
            pub_control_image_card_stacked: 150,
            pub_control_image_card_sidebyside: 250,
            pub_control_text: 100,
            pub_control_text_card: 150
        };

    function D3(a) {
        var b = 0;
        a.ub && b++;
        a.lb && b++;
        a.mb && b++;
        if (b < 3) return {
            jc: "Tags data-matched-content-ui-type, data-matched-content-columns-num and data-matched-content-rows-num should be set together."
        };
        b = a.ub.split(",");
        var c = a.mb.split(",");
        a = a.lb.split(",");
        if (b.length !== c.length || b.length !== a.length) return {
            jc: 'Lengths of parameters data-matched-content-ui-type, data-matched-content-columns-num and data-matched-content-rows-num must match. Example: \n data-matched-content-rows-num="4,2"\ndata-matched-content-columns-num="1,6"\ndata-matched-content-ui-type="image_stacked,image_card_sidebyside"'
        };
        if (b.length > 2) return {
            jc: `The parameter length of attribute data-matched-content-ui-type, data-matched-content-columns-num and data-matched-content-rows-num is too long. At most 2 parameters for each attribute are needed: one for mobile and one for desktop, while you are providing ${b.length} parameters. Example: ${'\n data-matched-content-rows-num="4,2"\ndata-matched-content-columns-num="1,6"\ndata-matched-content-ui-type="image_stacked,image_card_sidebyside"'}.`
        };
        var d = [],
            e = [];
        for (let g = 0; g < b.length; g++) {
            var f =
                Number(c[g]);
            if (Number.isNaN(f) || f === 0) return {
                jc: `Wrong value '${c[g]}' for data-matched-content-rows-num.`
            };
            d.push(f);
            f = Number(a[g]);
            if (Number.isNaN(f) || f === 0) return {
                jc: `Wrong value '${a[g]}' for data-matched-content-columns-num.`
            };
            e.push(f)
        }
        return {
            mb: d,
            lb: e,
            Hj: b
        }
    }

    function E3(a) {
        return a >= 1200 ? {
            width: 1200,
            height: 600
        } : a >= 850 ? {
            width: a,
            height: Math.floor(a * .5)
        } : a >= 550 ? {
            width: a,
            height: Math.floor(a * .6)
        } : a >= 468 ? {
            width: a,
            height: Math.floor(a * .7)
        } : {
            width: a,
            height: Math.floor(a * 3.44)
        }
    }

    function F3(a, b) {
        return a * A3[b] + B3[b]
    }

    function G3(a, b, c, d) {
        b = Math.floor(F3((a - 8 * b - 8) / b, d) * c + 8 * c + 8);
        return a > 1500 ? {
            width: 0,
            height: 0,
            Fn: `Calculated slot width is too large: ${a}`
        } : b > 1500 ? {
            width: 0,
            height: 0,
            Fn: `Calculated slot height is too large: ${b}`
        } : {
            width: a,
            height: b
        }
    }

    function H3(a, b) {
        var c = a - 8 - 8;
        --b;
        return {
            width: a,
            height: Math.floor(c / 1.91 + 70) + Math.floor(F3(c, "mobile_banner_image_sidebyside") * b + 8 * b + 8)
        }
    };
    const I3 = ["google_content_recommendation_ui_type", "google_content_recommendation_columns_num", "google_content_recommendation_rows_num"];
    var J3 = class extends S_ {
        constructor(a, b) {
            super(a, b)
        }
        g(a) {
            return Math.min(1200, Math.max(this.oa, Math.round(a)))
        }
    };

    function K3(a, b) {
        L3(a, b);
        if (b.google_content_recommendation_ui_type === "pedestal" && !U(ov)) return new Q_(9, new J3(a, Math.floor(a * 2.189)));
        if (U(rv)) {
            var c = Nk(),
                d = V(sv),
                e = V(qv),
                f = V(pv);
            a < 468 ? c ? (a = H3(a, d), a = {
                Aa: a.width,
                za: a.height,
                lb: 1,
                mb: d,
                ub: "mobile_banner_image_sidebyside"
            }) : (a = G3(a, 1, d, "image_sidebyside"), a = {
                Aa: a.width,
                za: a.height,
                lb: 1,
                mb: d,
                ub: "image_sidebyside"
            }) : (a = E3(a), e === 1 && (a.height = Math.floor(a.height * .5)), a = {
                Aa: a.width,
                za: a.height,
                lb: f,
                mb: e,
                ub: "image_stacked"
            })
        } else U(ov) ? (d = E3(a), e = 4, f = 2,
            a < 468 && (e = 1, f = 6, d = {
                width: a,
                height: Math.floor(F3(a, "image_stacked") * f + 8 * f + 8)
            }), a = {
                Aa: d.width,
                za: d.height,
                lb: e,
                mb: f,
                ub: "image_stacked"
            }) : (d = Nk(), a < 468 ? d ? (a = H3(a, 12), a = {
            Aa: a.width,
            za: a.height,
            lb: 1,
            mb: 12,
            ub: "mobile_banner_image_sidebyside"
        }) : (a = E3(a), a = {
            Aa: a.width,
            za: a.height,
            lb: 1,
            mb: 13,
            ub: "image_sidebyside"
        }) : (a = E3(a), a = {
            Aa: a.width,
            za: a.height,
            lb: 4,
            mb: 2,
            ub: "image_stacked"
        }));
        M3(b, a);
        return new Q_(9, new J3(a.Aa, a.za))
    }

    function N3(a, b) {
        L3(a, b); {
            let f = D3({
                mb: b.google_content_recommendation_rows_num,
                lb: b.google_content_recommendation_columns_num,
                ub: b.google_content_recommendation_ui_type
            });
            if (f.jc) a = {
                Aa: 0,
                za: 0,
                lb: 0,
                mb: 0,
                ub: "image_stacked",
                jc: f.jc
            };
            else {
                var c = f.Hj.length === 2 && a >= 468 ? 1 : 0;
                var d = f.Hj[c];
                d = d.indexOf("pub_control_") === 0 ? d : "pub_control_" + d;
                var e = C3[d];
                let g = f.lb[c];
                for (; a / g < e && g > 1;) g--;
                e = g;
                c = f.mb[c];
                a = G3(a, e, c, d);
                a = {
                    Aa: a.width,
                    za: a.height,
                    lb: e,
                    mb: c,
                    ub: d
                }
            }
        }
        if (a.jc) throw new qB(a.jc);
        M3(b, a);
        return new Q_(9,
            new J3(a.Aa, a.za))
    }

    function L3(a, b) {
        if (a <= 0) throw new qB(`Invalid responsive width from Matched Content slot ${b.google_ad_slot}: ${a}. Please ensure to put this Matched Content slot into a non-zero width div container.`);
    }

    function M3(a, b) {
        a.google_content_recommendation_ui_type = b.ub;
        a.google_content_recommendation_columns_num = b.lb;
        a.google_content_recommendation_rows_num = b.mb
    };
    var O3 = class extends S_ {
        constructor(a, b) {
            super(a, b)
        }
        g() {
            return this.oa
        }
        j(a, b, c) {
            HS(a, c);
            c.style.height = `${this.height}px`;
            b.rpe = !0
        }
    };
    var P3 = [{
            oa: 970,
            height: 90,
            ma: 2
        }, {
            oa: 728,
            height: 90,
            ma: 2
        }, {
            oa: 468,
            height: 60,
            ma: 2
        }, {
            oa: 336,
            height: 280,
            ma: 1
        }, {
            oa: 320,
            height: 100,
            ma: 2
        }, {
            oa: 320,
            height: 50,
            ma: 2
        }, {
            oa: 300,
            height: 600,
            ma: 4
        }, {
            oa: 300,
            height: 250,
            ma: 1
        }, {
            oa: 250,
            height: 250,
            ma: 1
        }, {
            oa: 234,
            height: 60,
            ma: 2
        }, {
            oa: 200,
            height: 200,
            ma: 1
        }, {
            oa: 180,
            height: 150,
            ma: 1
        }, {
            oa: 160,
            height: 600,
            ma: 4
        }, {
            oa: 125,
            height: 125,
            ma: 1
        }, {
            oa: 120,
            height: 600,
            ma: 4
        }, {
            oa: 120,
            height: 240,
            ma: 4
        }, {
            oa: 120,
            height: 120,
            ma: 1,
            Fh: !0
        }].map(a => new z3(a.oa, a.height, a.ma, a.Fh ? ? !1)),
        Q3 = [6, 12, 3, 0, 7, 14, 1, 8,
            10, 4, 15, 2, 11, 5, 13, 9, 16
        ].map(a => P3[a]);
    const R3 = 2 / 3;

    function S3(a) {
        return b => b.oa <= a
    }

    function T3(a) {
        return b => b.height <= a
    }

    function U3(a, b) {
        return b.tg && b.Eh ? Math.max(250, ls(a) * R3) : 250
    }

    function V3(a, b, c) {
        var d = c.ka && XJ(b, a),
            e = U3(a, {
                tg: c.tg,
                Eh: c.Eh
            });
        return f => !(d && f.height >= e)
    };

    function W3(a) {
        return b => {
            for (let c = a.length - 1; c >= 0; --c)
                if (!a[c](b)) return !1;
            return !0
        }
    }

    function X3(a, b) {
        var c = Q3.length,
            d = null;
        for (let e = 0; e < c; ++e) {
            let f = Q3[e];
            if (a(f)) {
                if (b == null || b(f)) return f;
                d === null && (d = f)
            }
        }
        return d
    };

    function Y3(a, b, c, d, e) {
        e.google_full_width_responsive === "false" ? c = {
            gb: a,
            Ca: 1
        } : b === "autorelaxed" && e.google_full_width_responsive || Z3(b) || e.google_ad_resize ? (b = BS(a, c, d, e), c = b !== !0 ? {
            gb: a,
            Ca: b
        } : {
            gb: ks(c) || a,
            Ca: !0
        }) : c = {
            gb: a,
            Ca: 2
        };
        var {
            gb: f,
            Ca: g
        } = c;
        return g !== !0 ? {
            gb: a,
            Ca: g
        } : d.parentElement ? {
            gb: f,
            Ca: g
        } : {
            gb: a,
            Ca: g
        }
    }

    function $3(a, b, c, d, e) {
        var {
            gb: f,
            Ca: g
        } = wB(247, () => Y3(a, b, c, d, e)), h = g === !0, k = el(d.style.width), l = el(d.style.height), {
            dc: m,
            Cb: n,
            ma: p,
            Gj: q
        } = a4(f, b, c, d, e, h);
        h = b4(b, p);
        var u, w = (u = UJ(d, c, "marginLeft")) ? `${u}px` : "",
            B = (u = UJ(d, c, "marginRight")) ? `${u}px` : "";
        u = ZJ(d, c) || "";
        return new Q_(h, m, p, null, q, g, n, w, B, l, k, u)
    }

    function Z3(a) {
        return a === "auto" || /^((^|,) *(horizontal|vertical|rectangle) *)+$/.test(a)
    }

    function a4(a, b, c, d, e, f) {
        b = c4(c, a, b);
        var g = ks(c) < 488,
            h = g ? TJ(d, c) : void 0,
            k = [S3(a), y3(b)];
        U(Rv) || k.push(V3(c, d, {
            ka: g,
            tg: !(!h || !XJ(d, c)),
            Eh: yr(c) === 0
        }));
        e.google_max_responsive_height != null && k.push(T3(e.google_max_responsive_height));
        g = [p => !p.Fh()];
        if (h) {
            let p = YJ(c, d);
            g.push(T3(p))
        }
        var l = X3(W3(k), W3(g));
        if (!l) throw new qB(`No slot size for availableWidth=${a}`);
        var {
            dc: m,
            Cb: n
        } = wB(248, () => {
            var p;
            a: if (f) {
                if (e.gfwrnh && (p = el(e.gfwrnh))) {
                    p = {
                        dc: new O3(a, p),
                        Cb: !0
                    };
                    break a
                }
                if (e.google_resizing_allowed || e.google_full_width_responsive ===
                    "true") p = Infinity;
                else {
                    p = d;
                    let u = Infinity;
                    do {
                        var q = UJ(p, c, "height");
                        q && (u = Math.min(u, q));
                        (q = UJ(p, c, "maxHeight")) && (u = Math.min(u, q))
                    } while (p.parentElement && (p = p.parentElement) && p.tagName !== "HTML");
                    p = u
                }!(U(Kv) && p <= a * 2) && (p = Math.min(a, p), p < a * .5 || p < 100) && (p = a);
                p = {
                    dc: new O3(a, Math.floor(p)),
                    Cb: p < a ? 102 : !0
                }
            } else p = {
                dc: l,
                Cb: 100
            };
            return p
        });
        return e.google_ad_layout === "in-article" ? {
            dc: d4(a, c, d, m, e),
            Cb: !1,
            ma: b,
            Gj: h
        } : {
            dc: m,
            Cb: n,
            ma: b,
            Gj: h
        }
    }

    function b4(a, b) {
        if (a === "auto") return 1;
        switch (b) {
            case 2:
                return 2;
            case 1:
                return 3;
            case 4:
                return 4;
            case 3:
                return 5;
            case 6:
                return 6;
            case 5:
                return 7;
            case 7:
                return 8;
            default:
                throw Error("bad mask");
        }
    }

    function c4(a, b, c) {
        if (c === "auto") c = Math.min(1200, ks(a)), b = b / c <= .25 ? 4 : 3;
        else {
            b = 0;
            for (let d in wS) c.indexOf(d) !== -1 && (b |= wS[d])
        }
        return b
    }

    function d4(a, b, c, d, e) {
        var f = e.google_ad_height || UJ(c, b, "height");
        b = W_(a, b, c, f, e).size();
        return b.oa * b.height > a * d.height ? new z3(b.oa, b.height, 1) : d
    };

    function e4(a, b, c, d, e) {
        var f;
        (f = ks(b)) ? ks(b) < 488 ? b.innerHeight >= b.innerWidth ? (e.google_full_width_responsive_allowed = !0, HS(b, c), f = {
            gb: f,
            Ca: !0
        }) : f = {
            gb: a,
            Ca: 5
        } : f = {
            gb: a,
            Ca: 4
        }: f = {
            gb: a,
            Ca: 10
        };
        var {
            gb: g,
            Ca: h
        } = f;
        if (h !== !0 || a === g) return new Q_(12, new S_(a, d), null, null, !0, h, 100);
        var {
            dc: k,
            Cb: l,
            ma: m
        } = a4(g, "auto", b, c, e, !0);
        return new Q_(1, k, m, 2, !0, h, l)
    };

    function f4(a) {
        var b = a.google_ad_format;
        if (b === "autorelaxed") {
            a: {
                if (a.google_content_recommendation_ui_type !== "pedestal")
                    for (let c of I3)
                        if (a[c] != null) {
                            a = !0;
                            break a
                        }
                a = !1
            }
            return a ? 9 : 5
        }
        if (Z3(b)) return 1;
        if (b === "link") return 4;
        if (b === "fluid") return a.google_ad_layout === "in-article" ? (g4(a), 1) : 8;
        if (a.google_reactive_ad_format === 27) return g4(a), 1
    }

    function h4(a, b, c, d, e = !1) {
        var f = b.offsetWidth || (c.google_ad_resize || e) && UJ(b, d, "width") || c.google_ad_width || 0;
        a === 4 && (c.google_ad_format = "auto", a = 1);
        e = (e = i4(a, f, b, c, d)) ? e : $3(f, c.google_ad_format, d, b, c);
        e.size().j(d, c, b);
        e.ma != null && (c.google_responsive_formats = e.ma);
        e.O != null && (c.google_safe_for_responsive_override = e.O);
        e.Ca != null && (e.Ca === !0 ? c.google_full_width_responsive_allowed = !0 : (c.google_full_width_responsive_allowed = !1, c.gfwrnwer = e.Ca));
        e.Cb != null && e.Cb !== !0 && (c.gfwrnher = e.Cb);
        d = e.l || c.google_ad_width;
        d != null && (c.google_resizing_width = d);
        d = e.j || c.google_ad_height;
        d != null && (c.google_resizing_height = d);
        d = e.size().g(f);
        var g = e.size().height;
        c.google_ad_width = d;
        c.google_ad_height = g;
        var h = e.size();
        c.google_ad_format = `${h.g(f)}x${h.height}`;
        c.google_responsive_auto_format = e.D;
        e.g != null && (c.armr = e.g);
        c.google_ad_resizable = !0;
        c.google_override_format = 1;
        c.google_loader_features_used = 128;
        e.Ca === !0 && (c.gfwrnh = `${e.size().height}px`);
        e.B != null && (c.gfwroml = e.B);
        e.A != null && (c.gfwromr = e.A);
        e.j != null && (c.gfwroh =
            e.j);
        e.l != null && (c.gfwrow = e.l);
        e.C != null && (c.gfwroz = e.C);
        f = Lk(window) || window;
        xY(f.location, "google_responsive_dummy_ad") && (hb([1, 2, 3, 4, 5, 6, 7, 8], e.D) || e.g === 1) && e.g !== 2 && (f = JSON.stringify({
            googMsgType: "adpnt",
            key_value: [{
                key: "qid",
                value: "DUMMY_AD"
            }]
        }), c.dash = `<${P_}>window.top.postMessage('${f}', '*'); 
          </${P_}> 
          <div id="dummyAd" style="width:${d}px;height:${g}px; 
            background:#ddd;border:3px solid #f00;box-sizing:border-box; 
            color:#000;"> 
            <p>Requested size:${d}x${g}</p> 
            <p>Rendered size:${d}x${g}</p> 
          </div>`);
        a !== 1 && (a = e.size().height, b.style.height = `${a}px`)
    }

    function i4(a, b, c, d, e) {
        var f = d.google_ad_height || UJ(c, e, "height") || 0;
        switch (a) {
            case 5:
                let {
                    gb: g,
                    Ca: h
                } = wB(247, () => Y3(b, d.google_ad_format, e, c, d));
                h === !0 && b !== g && HS(e, c);
                h === !0 ? d.google_full_width_responsive_allowed = !0 : (d.google_full_width_responsive_allowed = !1, d.gfwrnwer = h);
                return K3(g, d);
            case 9:
                return U(ov) ? K3(b, d) : N3(b, d);
            case 8:
                return W_(b, e, c, f, d);
            case 10:
                return e4(b, e, c, f, d)
        }
    }

    function g4(a) {
        a.google_ad_format = "auto";
        a.armr = 3
    };

    function j4(a, b) {
        a.google_resizing_allowed = !0;
        a.google_ad_format = "auto";
        a.iaaso = !0;
        a.armr = b
    };
    var k4 = {
        "120x90": !0,
        "160x90": !0,
        "180x90": !0,
        "200x90": !0,
        "468x15": !0,
        "728x15": !0
    };

    function l4(a, b) {
        if (b == 15) {
            if (a >= 728) return 728;
            if (a >= 468) return 468
        } else if (b == 90) {
            if (a >= 200) return 200;
            if (a >= 180) return 180;
            if (a >= 160) return 160;
            if (a >= 120) return 120
        }
        return null
    };

    function m4(a, b) {
        var c = Lk(b);
        if (c) {
            c = ks(c);
            let d = al(a, b) || {},
                e = d.direction;
            if (d.width === "0px" && d.cssFloat !== "none") return -1;
            if (e === "ltr" && c) return Math.floor(Math.min(1200, c - a.getBoundingClientRect().left));
            if (e === "rtl" && c) return a = b.document.body.getBoundingClientRect().right - a.getBoundingClientRect().right, Math.floor(Math.min(1200, c - a - Math.floor((c - b.document.body.clientWidth) / 2)))
        }
        return -1
    };

    function n4(a, b) {
        switch (a) {
            case "google_reactive_ad_format":
                return Dr(b);
            default:
                return b
        }
    }

    function o4(a) {
        if (U(px) && Number(a.google_ad_intents_in_drawer_format) === 1) switch (Number(a.google_ad_intents_format)) {
            case 4:
                return 22;
            case 5:
                return 25;
            default:
                return 21
        }
        switch (Number(a.google_ad_intents_format)) {
            case 4:
                return 18;
            case 5:
                return 23;
            default:
                return 17
        }
    }

    function p4(a, b) {
        if (a = or(a)) switch (a.data && a.data.autoFormat) {
            case "rspv":
                return 13;
            case "mcrspv":
                return 15;
            default:
                return 14
        } else {
            if (b.google_ad_intents_format)
                if (b.google_ad_intent_query) b = o4(b);
                else a: switch (Number(b.google_ad_intents_format)) {
                    case 4:
                        b = 20;
                        break a;
                    case 5:
                        b = 24;
                        break a;
                    default:
                        b = 19
                } else b = 12;
            return b
        }
    };

    function q4(a, b, c) {
        a.dataset.adsbygoogleStatus = "reserved";
        a.className += " adsbygoogle-noablate";
        c.adsbygoogle || (c.adsbygoogle = [], Zk(c.document, fi `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js`));
        c.adsbygoogle.push({
            element: a,
            params: b,
            ...null
        })
    };

    function r4(a, b) {
        if (!zS(b, a)) return () => {};
        a = s4(b, a);
        if (!a) return () => {};
        var c = SA();
        b = Ei(b);
        var d = {
            Xc: a,
            I: b,
            offsetWidth: a.offsetWidth
        };
        c.push(d);
        return () => ib(c, d)
    }

    function s4(a, b) {
        a = b.document.getElementById(a.google_async_iframe_id);
        if (!a) return null;
        for (a = a.parentElement; a && !mz.test(a.className);) a = a.parentElement;
        return a
    }

    function t4(a, b) {
        for (let c = 0; c < a.childNodes.length; c++) {
            let d = {},
                e = a.childNodes[c];
            xS(e.style, d);
            if (d.google_ad_width == b.google_ad_width && d.google_ad_height == b.google_ad_height) return e
        }
        return null
    }

    function u4(a, b) {
        a.style.display = b ? "inline-block" : "none";
        var c = a.parentElement;
        b ? c.dataset.adStatus = a.dataset.adStatus : (a.dataset.adStatus = c.dataset.adStatus, delete c.dataset.adStatus)
    }

    function v4(a, b) {
        var c = b.innerHeight >= b.innerWidth ? 1 : 2;
        if (a.j != c) {
            a.j = c;
            a = SA();
            for (let d of a)
                if (d.Xc.offsetWidth != d.offsetWidth || d.I.google_full_width_responsive_allowed) d.offsetWidth = d.Xc.offsetWidth, wB(467, () => {
                    var e = d.Xc,
                        f = d.I,
                        g = t4(e, f);
                    f.google_full_width_responsive_allowed && (e.style.marginLeft = f.gfwroml || "", e.style.marginRight = f.gfwromr || "", e.style.height = f.gfwroh ? `${f.gfwroh}px` : "", e.style.width = f.gfwrow ? `${f.gfwrow}px` : "", e.style.zIndex = f.gfwroz || "", delete f.google_full_width_responsive_allowed);
                    delete f.google_ad_format;
                    delete f.google_ad_width;
                    delete f.google_ad_height;
                    delete f.google_content_recommendation_ui_type;
                    delete f.google_content_recommendation_rows_num;
                    delete f.google_content_recommendation_columns_num;
                    if (e.getAttribute("src")) {
                        var h = e.getAttribute("src") || "",
                            k = Fm(h, "client");
                        k && (f.google_ad_client = n4("google_ad_client", k));
                        (h = Fm(h, "host")) && (f.google_ad_host = n4("google_ad_host", h))
                    }
                    for (var l of e.attributes) /data-/.test(l.name) && (h = Ka(l.name.replace("data-matched-content", "google_content_recommendation").replace("data",
                        "google").replace(/-/g, "_")), f.hasOwnProperty(h) || (k = n4(h, l.value), k !== null && (f[h] = k)));
                    f.google_ad_intents_format && !f.google_ad_intent_query && (f.google_reactive_ad_format = 40);
                    if (b.document && b.document.body && !f4(f) && !f.google_reactive_ad_format && !f.google_ad_intent_query && (k = parseInt(e.style.width, 10), h = m4(e, b), h > 0 && k > h)) {
                        l = parseInt(e.style.height, 10);
                        k = !!k4[k + "x" + l];
                        let m = h;
                        if (k) {
                            let n = l4(h, l);
                            if (n) m = n, f.google_ad_format = n + "x" + l + "_0ads_al";
                            else throw new qB("No slot size for availableWidth=" + h);
                        }
                        f.google_ad_resize = !0;
                        f.google_ad_width = m;
                        k || (f.google_ad_format = null, f.google_override_format = !0);
                        h = m;
                        e.style.width = `${h}px`;
                        j4(f, 4)
                    }
                    if (U(tv) || ks(b) < 488) {
                        h = Lk(b) || b;
                        l = e.offsetWidth || UJ(e, b, "width") || f.google_ad_width || 0;
                        k = f.google_ad_client;
                        if (h = xY(h.location, "google_responsive_slot_preview") || $_(h, k)) b: if (f.google_reactive_ad_format || f.google_ad_resize || f4(f) || yS(e, f)) h = !1;
                            else {
                                for (h = e; h; h = h.parentElement) {
                                    k = al(h, b);
                                    if (!k) {
                                        f.gfwrnwer = 18;
                                        h = !1;
                                        break b
                                    }
                                    if (!hb(["static", "relative"], k.position)) {
                                        f.gfwrnwer =
                                            17;
                                        h = !1;
                                        break b
                                    }
                                }
                                if (!U(Sv) && (h = V(Iv), l = AS(b, e, l, h, f), l !== !0)) {
                                    f.gfwrnwer = l;
                                    h = !1;
                                    break b
                                }
                                h = b === b.top ? !0 : !1
                            }
                        h ? (j4(f, 1), l = !0) : l = !1
                    } else l = !1;
                    if (h = f4(f)) h4(h, e, f, b, l);
                    else {
                        if (yS(e, f)) {
                            if (l = al(e, b)) e.style.width = l.width, e.style.height = l.height, xS(l, f);
                            f.google_ad_width || (f.google_ad_width = e.offsetWidth);
                            f.google_ad_height || (f.google_ad_height = e.offsetHeight);
                            f.google_loader_features_used = 256;
                            f.google_responsive_auto_format = p4(b, f)
                        } else xS(e.style, f);
                        b.location && b.location.hash === "#gfwmrp" || f.google_responsive_auto_format ===
                            12 && f.google_full_width_responsive === "true" ? h4(10, e, f, b, !1) : Math.random() < .01 && f.google_responsive_auto_format === 12 && (l = BS(e.offsetWidth || parseInt(e.style.width, 10) || f.google_ad_width, b, e, f), l !== !0 ? (f.efwr = !1, f.gfwrnwer = l) : f.efwr = !0)
                    }
                    l = t4(e, f);
                    !l && g && e.childNodes.length == 1 ? (u4(g, !1), f.google_reactive_ad_format = 16, f.google_ad_section = "responsive_resize", q4(e, f, b)) : l && g && l != g && (u4(g, !1), u4(l, !0))
                })
        }
    }
    var w4 = class extends O {
        constructor() {
            super(...arguments);
            this.j = null
        }
        init(a) {
            var b = HA();
            if (!MA(b, 27, !1)) {
                NA(b, 27, !0);
                this.j = a.innerHeight >= a.innerWidth ? 1 : 2;
                var c = () => {
                    v4(this, a)
                };
                Yj(a, "resize", c);
                xt(this, () => {
                    Zj(a, "resize", c)
                })
            }
        }
    };
    var x4 = Y(function(a, b, c, d) {
        b && (d.push(r4(b, c)), dr(w4).init(b));
        return {}
    }, {
        id: 1417,
        H: {}
    });

    function y4(a) {
        a.C = a.D;
        a.G.style.transition = "height 500ms";
        a.A.style.transition = "height 500ms";
        a.j.style.transition = "height 500ms";
        z4(a)
    }

    function A4(a, b) {
        XW(a.j.contentWindow, "sth", {
            msg_type: "expand-on-scroll-result",
            eos_success: !0,
            eos_amount: b
        }, "*")
    }

    function z4(a) {
        var b = `rect(0px, ${a.j.width}px, ${a.C}px, 0px)`;
        a.j.style.clip = b;
        a.A.style.clip = b;
        a.j.setAttribute("height", a.C.toString());
        a.j.style.height = `${a.C}px`;
        a.A.setAttribute("height", a.C.toString());
        a.A.style.height = `${a.C}px`;
        a.G.style.height = `${a.C}px`
    }

    function B4(a, b) {
        b = dl(b.r_nh);
        a.D = b == null ? 0 : b;
        if (a.D <= 0) return "1";
        a.P = Rj(a.G).y;
        a.J = ts(a.l);
        if (a.P + a.C < a.J) return "2";
        if (a.P > os(a.l) - a.l.innerHeight) return "3";
        b = a.J;
        a.j.setAttribute("height", a.D.toString());
        a.j.style.height = `${a.D}px`;
        a.A.style.overflow = "hidden";
        a.G.style.position = "relative";
        a.G.style.transition = "height 100ms";
        a.A.style.transition = "height 100ms";
        a.j.style.transition = "height 100ms";
        b = Math.min(b + a.l.innerHeight - a.P, a.C);
        Fj(a.A, {
            position: "relative",
            top: "auto",
            bottom: "auto"
        });
        b = `rect(0px, ${a.j.width}px, ${b}px, 0px)`;
        Fj(a.j, {
            clip: b
        });
        Fj(a.A, {
            clip: b
        });
        return "0"
    }
    var C4 = class extends g3 {
        constructor(a, b) {
            super(a.K, b);
            this.Me = this.Hi = !1;
            this.Ba = this.J = this.D = 0;
            this.A = a.ca;
            this.G = this.A.parentElement && this.A.parentElement.classList.contains("adsbygoogle") ? this.A.parentElement : this.A;
            this.C = parseInt(this.A.style.height, 10);
            this.Lk = this.C / 5;
            this.P = Rj(this.G).y;
            this.Jk = ri(xB(651, () => {
                this.P = Rj(this.G).y;
                var c = this.J;
                this.J = ts(this.l);
                this.C < this.D ? (c = this.J - c, c > 0 && (this.Ba += c, this.Ba >= this.Lk ? (y4(this), A4(this, this.D)) : (this.C = Math.min(this.D, this.C + c), A4(this,
                    c), z4(this)))) : Zj(this.l, "scroll", this.W)
            }), 63, this);
            this.W = () => {
                var c = this.Jk;
                Cl.requestAnimationFrame ? Cl.requestAnimationFrame(c) : c()
            }
        }
        Z(a) {
            a["expand-on-scroll"] = (b, c) => {
                b = vs(b);
                this.Hi || (this.Hi = !0, b = B4(this, b), b === "0" && Yj(this.l, "scroll", this.W, Vj), XW(c.target, "sth", {
                    msg_type: "expand-on-scroll-result",
                    eos_success: b === "0"
                }, "*"))
            };
            a["expand-on-scroll-force-expand"] = () => {
                this.Me || (this.Me = !0, y4(this), Zj(this.l, "scroll", this.W))
            }
        }
        g() {
            this.W && Zj(this.l, "scroll", this.W, Vj);
            super.g()
        }
    };
    var D4 = Y(function(a, b) {
        var c = a.ia,
            d = a.Sa;
        a = a.Ea;
        b.K && d && a(new C4(b, c));
        return {}
    }, {
        id: 1428,
        H: {}
    });

    function u3(a, b) {
        var c = a.j.getBoundingClientRect();
        if (E4(c)) {
            var d = document.createElement("div");
            d.dataset.googleAdEfd = "true";
            V(Lx) > 0 && (d.className = "google-aiuf");
            J(d, {
                width: `${c.width}px`,
                display: "flex",
                "flex-wrap": "wrap",
                "justify-content": "center",
                "align-items": "center",
                "align-content": "center",
                gap: "10px",
                "font-size": "initial"
            });
            c.bottom < 0 || c.top >= window.innerHeight ? (J(d, {
                height: "auto",
                "max-height": W(a.j.offsetHeight)
            }), J(a.j.parentElement, {
                height: "auto"
            }), J(a.j.parentElement.parentElement, {
                height: "auto",
                "background-color": "transparent"
            })) : J(d, {
                height: `${c.height}px`
            });
            c = a.j.parentElement;
            c.replaceChild(d, a.j);
            (c.parentElement ? .classList.contains("adsbygoogle") ? c.parentElement : c).dataset.adStatus = "unfill-optimized";
            iJ(a.pubWin, a.l, a.I, b, a.R, a.sb, d)
        } else a = a.j.closest("INS"), hC(a) && W0(a, 0, 0)
    }

    function v3(a, b) {
        iJ(a.pubWin, a.l, a.I, b, a.R, a.sb, a.j, !0)
    }

    function F4(a, b) {
        a.j.parentElement && (b = vs(b), b.r_affa && b.r_affa !== "" && (b = t3(b.r_affa), hy(Te(b, iy, 1)).filter(c => D(c, 12)).length >= V(tx) ? u3(a, b) : v3(a, b)))
    }

    function E4(a) {
        if (V(Lx) <= 0) return !0;
        var b = V(Lx) * window.innerHeight,
            c = document.getElementsByClassName("google-aiuf");
        if (c.length === 0) return !0;
        for (let d of c)
            if (c = d.getBoundingClientRect(), a.bottom <= c.top && c.top - a.bottom <= b || a.top >= c.bottom && a.top - c.bottom <= b) return !1;
        return !0
    }
    var G4 = class extends g3 {
        constructor(a, b, c, d, e, f, g) {
            super(a, b);
            this.I = c;
            this.pubWin = d;
            this.Ia = e;
            this.R = f;
            this.sb = g
        }
        Z(a) {
            a["unfill-fb"] = b => {
                F4(this, b)
            }
        }
    };
    var H4 = Y(function(a, b, c, d, e, f) {
        var g = a.ia,
            h = a.Sa,
            k = a.Ea;
        a = a.R;
        if (c && h) {
            if (!(h = U(cx))) try {
                h = !!c ? .location ? .hash ? .match(/\bgoog_uffb/)
            } catch (l) {
                h = !1
            }(b = h ? new G4(c, g, d, b, e, a, f.SLqBY ? ? "") : null) && k(b);
            return {
                Nb: b
            }
        }
        return {
            Nb: null
        }
    }, {
        id: 1422,
        H: {
            Nb: void 0
        }
    });

    function I4(a, b) {
        return new IntersectionObserver(b, a)
    }

    function J4(a, b, c) {
        Yj(a, b, c);
        return () => Zj(a, b, c)
    }
    let K4 = null;

    function L4() {
        K4 = Ul()
    }

    function M4(a, b) {
        return b ? K4 === null ? (Yj(a, "mousemove", L4, {
            passive: !0
        }), Yj(a, "scroll", L4, {
            passive: !0
        }), L4(), !1) : Ul() - K4 >= b * 1E3 : !1
    }

    function N4({
        win: a,
        element: b,
        Rn: c,
        Mn: d,
        Ln: e = 0,
        Jb: f,
        Vl: g,
        options: h = {},
        Lm: k = !0,
        xp: l = I4
    }) {
        var m, n = !1,
            p = !1,
            q = [],
            u = l(h, (w, B) => {
                try {
                    let G = () => {
                        q.length || (d && (q.push(J4(b, "mouseenter", () => {
                            n = !0;
                            G()
                        })), q.push(J4(b, "mouseleave", () => {
                            n = !1;
                            G()
                        }))), q.push(J4(a.document, "visibilitychange", () => G())));
                        var K = M4(a, e),
                            H = FY(a.document);
                        if (p && !n && !K && !H) m = m || a.setTimeout(() => {
                            M4(a, e) ? G() : (f(), B.disconnect())
                        }, c * 1E3);
                        else if (k || n || K || H) a.clearTimeout(m), m = void 0
                    };
                    ({
                        isIntersecting: p
                    } = w[w.length - 1]);
                    G()
                } catch (G) {
                    g && g(G)
                }
            });
        u.observe(b);
        return () => {
            u.disconnect();
            for (let w of q) w();
            m != null && a.clearTimeout(m)
        }
    };

    function O4(a, b, c, d, e) {
        return new P4(a, b, c, d, e)
    }

    function Q4(a, b, c) {
        var d = a.j,
            e = a.D;
        if (e != null && d != null && ss(c, d.contentWindow) && (b = b.config, x(b))) {
            try {
                var f = JSON.parse(b);
                if (!Array.isArray(f)) return;
                a.A = rg(Ek, f)
            } catch (g) {
                return
            }
            a.dispose();
            f = gf(a.A, 1);
            f <= 0 || (a.C = N4({
                win: a.l,
                element: e,
                Rn: f - .2,
                Mn: !Nk(),
                Ln: gf(a.A, 3),
                Jb: () => void R4(a, e),
                Vl: g => kr.Da(1223, g, void 0, void 0),
                options: {
                    threshold: jf(a.A, 2, 1)
                },
                Lm: !0
            }))
        }
    }

    function R4(a, b) {
        a.G();
        setTimeout(kr.Zb(1224, () => {
            var c = Number(a.I.rc);
            a.I.rc = c ? c + 1 : 1;
            c = b.parentElement || null;
            c && mz.test(c.className) || (c = oj(document, "INS"), c.className = "adsbygoogle", b.parentNode && b.parentNode.insertBefore(c, b.nextSibling));
            U(Aw) ? (S4(a, c, b), a.I.no_resize = !0, Kt(zX(c), "filled", () => {
                pj(b)
            })) : pj(b);
            q4(c, a.I, a.l)
        }), 200)
    }

    function S4(a, b, c) {
        a.l.getComputedStyle(b).position === "static" && (b.style.position = "relative");
        c.style.position = "absolute";
        c.style.top = "0";
        c.style.left = "0";
        delete b.dataset.adsbygoogleStatus;
        delete b.dataset.adStatus;
        b.classList.remove("adsbygoogle-noablate")
    }
    var P4 = class extends g3 {
        constructor(a, b, c, d, e) {
            super(a, b);
            this.I = c;
            this.D = d;
            this.G = e;
            this.A = this.C = null;
            (b = (b = b.contentWindow) && b.parent) && a !== b && this.la.push(VW(b, "sth", this.Gb, this.Ii))
        }
        Z(a) {
            a.av_ref = (b, c) => {
                Q4(this, b, c)
            }
        }
        g() {
            super.g();
            this.D = null;
            this.C && this.C()
        }
    };
    var T4 = Y(function(a, b, c, d, e) {
        var f = a.ia,
            g = a.Sa,
            h = a.Ea,
            k = a.Ye;
        b && g && b.IntersectionObserver && h(O4(b, f, c, d, xB(1225, () => {
            k();
            for (let l of e) l();
            e.length = 0
        })));
        return {}
    }, {
        id: 1421,
        H: {}
    });
    var U4 = class extends W1 {
        constructor(a, b, c, d, e, f) {
            super(a);
            a = X(Z(this, k3, {
                ia: d
            }, b.K, b.I, b.Ia), e);
            e = X(Z(this, r3, {
                ia: d
            }, b), a.finished);
            var g = X(Z(this, l3, {
                ia: d,
                R: c,
                Ua: f
            }, b.pubWin, b.Ia), e.finished);
            g = X(Z(this, H4, {
                ia: d,
                Sa: a.Sa,
                Ea: a.Ea,
                R: c
            }, b.pubWin, b.K, b.I, b.Ia, b.pageState), g.finished);
            g = X(Z(this, x3, {
                ia: d,
                Sa: a.Sa,
                Ea: a.Ea,
                Nb: g.Nb
            }, b.K, b.I, b.ca), g.finished);
            g = X(Z(this, D4, {
                ia: d,
                Sa: a.Sa,
                Ea: a.Ea
            }, b), g.finished);
            g = X(Z(this, o3, {
                ia: d,
                Sa: a.Sa,
                Ea: a.Ea
            }, b.K, b.ca), g.finished);
            e = X(Z(this, T4, {
                    ia: d,
                    Sa: a.Sa,
                    Ea: a.Ea,
                    Ye: e.Ye
                },
                b.K, b.I, b.ca, b.Ia), g.finished);
            c = X(Z(this, j3, {
                ia: d,
                Ea: a.Ea,
                R: c,
                Ua: f
            }, b.K, b.pageState), e.finished);
            c = X(Z(this, x4, {
                ia: d
            }, b.K, b.I, b.Ia), c.finished);
            d = X(Z(this, V2, {
                ia: d
            }, b.K, b.ca, b.Ia), c.finished);
            U(yv) ? this.j = d.finished : this.j = X(Z(this, p3, {}, b), d.finished).finished
        }
    };
    var V4 = Y(function(a, b, c) {
        var d = or(b);
        if (d)
            if (d.container === "AMP-STICKY-AD") {
                let e = f => {
                    f.data === "fill_sticky" && d.renderStart ? .()
                };
                Yj(b, "message", xB(616, e));
                c.push(() => {
                    Zj(b, "message", e)
                })
            } else d.renderStart ? .();
        return {}
    }, {
        id: 1419,
        H: {}
    });
    var W4 = Y(function(a) {
        var b = a.ia;
        a = a.Kd;
        var c = () => {
            b && b.setAttribute("data-load-complete", "true")
        };
        a ? a.then(c) : Yj(b, "load", c);
        return {}
    }, {
        id: 1416,
        H: {}
    });
    var X4 = class extends O {
        constructor(a, b) {
            super();
            this.value = a;
            xt(this, b)
        }
    };

    function Y4(a, b) {
        var c = Z4(a.getBoundingClientRect()),
            d = new Ct(c),
            e = $4(a, b, f => {
                d.g(Z4(f.boundingClientRect))
            });
        return new X4(Gt(d), () => void e.disconnect())
    }

    function $4(a, b, c) {
        b = new IntersectionObserver(d => {
            d.filter(e => e.target === a).forEach(c)
        }, {
            root: b
        });
        b.observe(a);
        return b
    }

    function Z4(a) {
        return a.height > 0 || a.width > 0
    };
    var a5 = {
        Ro: 0,
        kp: 1,
        cp: 2,
        0: "INITIAL_RENDER",
        1: "UNRENDER",
        2: "RENDER_BACK"
    };

    function b5(a, b, c) {
        var d = [1, 2],
            e = Y4(b, c),
            f = e.value,
            g = new Rt;
        Kt(f, !0, () => void c5(a, f, g, d));
        return new X4(Ot(g), () => void e.dispose())
    }

    function c5(a, b, c, d) {
        var e = new VX(a),
            f = new VX(a);
        e.start();
        f.start();
        var g = 0,
            h = k => {
                k = {
                    type: k,
                    Uj: ++g,
                    Nm: TX(f),
                    Mm: TX(e)
                };
                f = new VX(a);
                f.start();
                return k
            };
        d && !d.includes(0) || Qt(c, h(0));
        b.listen(k => {
            k = k ? 2 : 1;
            d && !d.includes(k) || Qt(c, h(k))
        })
    };

    function d5(a, b) {
        var c = HB();
        wB(1282, () => void e5(a, b, c))
    }

    function e5(a, b, c) {
        var d = f5(a);
        if (!d) throw Error("No adsbygoogle INS found");
        var e = b5(a.pubWin, b, d);
        e.value.listen(f => {
            g5(f, d, c, () => void e.dispose())
        })
    }

    function f5(a) {
        return (a = a.ca.parentElement) && mz.test(a.className) ? a : null
    }

    function g5(a, b, c, d) {
        if (a.Uj > 5) d();
        else {
            var e = a.type === 1;
            d = a.type === 2;
            if (!e && !d) throw Error(`Unsupported event type: ${a5[a.type]}`);
            var f = og(rX());
            f = wf(f, 1, a.Nm);
            f = wf(f, 2, a.Mm);
            a = wf(f, 3, a.Uj);
            f = b.dataset.vignetteLoaded;
            var g = og(pX());
            g = Jf(g, 1, b.dataset.adStatus);
            g = Jf(g, 2, b.dataset.sideRailStatus);
            g = Jf(g, 3, b.dataset.anchorStatus);
            f = sf(g, 4, f !== void 0 ? f === "true" : void 0);
            b = getComputedStyle(b);
            g = og(sX());
            g = Jf(g, 1, b.display);
            g = Jf(g, 2, b.position);
            g = Jf(g, 3, b.width);
            b = Jf(g, 4, b.height);
            b = oe(b);
            b = z(f, 5, b);
            b = oe(b);
            a = z(a, 4, b);
            e = e ? tX() : void 0;
            e = A(a, 5, rn, e);
            d = d ? qX() : void 0;
            d = A(e, 6, rn, d);
            d = qg(og(oe(d)));
            XB(c, d)
        }
    };
    var h5 = Y(function(a, b) {
        a = a.ia;
        U(Av) && "IntersectionObserver" in window && d5(b, a);
        return {}
    }, {
        id: 1420,
        H: {}
    });
    const i5 = j2(function(a) {
        return !a.ra && a.Wa
    }, {
        id: 1460
    });
    var j5 = class extends g2 {
        constructor(a, b, c, d, e, f, g, h, k) {
            super(a);
            this.ea = a;
            this.G = h;
            this.J = new WZ;
            this.ra = g.ra;
            this.Wa = g.Wa;
            g = f.yf;
            f = f.dm;
            ({
                ia: b
            } = Z(this, t2, {
                Ga: this.G.Ga,
                bm: this.G.pe,
                Xn: b
            }));
            g = X(X(Z(this, S2, {
                R: e
            }, d.I, d.pubWin, d.pageState), g), f);
            f = Z(this, P2, {
                ia: b
            }, d.I, d.pubWin, d.ca);
            X(f, g.finished);
            g = Z(this, W4, {
                ia: b,
                Kd: this.G.Kd
            });
            X(g, f.finished);
            a = U1(this, new U4(a, d, e, b, g.finished, k));
            c = Z(this, s2, {
                ia: b,
                zc: c
            }, d.I, d.ca);
            X(c, a.j);
            a = Z(this, V4, {}, d.pubWin, d.Ia);
            X(a, c.finished);
            d = Z(this, h5, {
                ia: b
            }, d);
            X(d,
                a.finished);
            this.J = d.finished
        }
        async j() {
            return h2(this.ea, i5, {
                ra: this.ra,
                Wa: this.Wa
            })
        }
        l() {
            this.J.notify()
        }
    };

    function k5(a, b) {
        b.allow = b.allow && b.allow.length > 0 ? b.allow + ("; " + a) : a
    }

    function l5(a) {
        var b = $k("IFRAME");
        Fk(a, (c, d) => {
            c != null && b.setAttribute(d, c)
        });
        return b
    };
    var m5 = Y(function(a, b) {
        a = a.jd;
        f0("attribution-reporting", b) && k5("attribution-reporting", a);
        f0("run-ad-auction", b) && k5("run-ad-auction", a);
        return {
            we: a
        }
    }, {
        id: 1380,
        H: {
            we: void 0
        }
    });
    var n5 = Y(function(a, b, c) {
        a = a.Bh;
        var d = c.google_async_iframe_id,
            e = c.google_ad_width,
            f = c.google_ad_height;
        b = sZ(c);
        d = {
            id: d,
            name: d,
            style: b ? `width:${e}px !IMPORTANT;height:${f}px !IMPORTANT;` : `left:0;position:absolute;top:0;border:0;width:${e}px;height:${f}px;`
        };
        d.style += "min-height:auto;max-height:none;min-width:auto;max-width:none;";
        jl() && (d.sandbox = hl(["allow-top-navigation", "allow-modals", "allow-orientation-lock", "allow-presentation", "allow-pointer-lock"]).join(" "));
        c.google_video_play_muted === !1 &&
            k5("autoplay", d);
        return {
            jd: d,
            adUrl: a,
            Dd: b
        }
    }, {
        id: 1346,
        H: {
            jd: void 0,
            adUrl: void 0,
            Dd: void 0
        }
    });

    function o5(a, b, c, d, e, f, g) {
        var h = d.K,
            k = d.pubWin;
        return a.google_reactive_ad_format === 9 && vj(e, null, "fsi_container") ? (e.appendChild(f), Promise.resolve(f)) : oZ(b.hk, 525, l => {
            e.appendChild(f);
            l.createAdSlot(h, a, f, e.parentElement, pg(c), k, g);
            return f
        })
    }
    var p5 = Q1(async function(a, b) {
        var c = a.kh,
            d = a.R;
        if (!a.Dd) return null;
        var e = b.I,
            f = b.Gi,
            g = b.ca,
            h = b.Na;
        b = b.Ta;
        var k = f.K;
        f = f.pubWin;
        c.src = a.Va;
        a = l5(c);
        return o5(e, h, d, {
            K: k,
            pubWin: f
        }, g, a, b)
    }, {
        id: 1396
    });
    var q5 = Y(function(a, b) {
        var c = a.kh;
        if (a.Dd) return {
            Je: null
        };
        var d = b.ca,
            e = b.Ia;
        b = b.Gi.pubWin;
        c.src = N_(a.Va);
        a = b === b.top;
        c = l5(c);
        a && e.push(ur(b, c));
        for (d.style.visibility = "visible"; e = d.firstChild;) d.removeChild(e);
        d.appendChild(c);
        return {
            Je: c
        }
    }, {
        id: 1397,
        H: {
            Je: void 0
        }
    });
    var r5 = Y(function(a, b, c, d) {
        if (!b.rpe) return {};
        k1(c, d, {
            height: b.google_ad_height,
            fg: "force",
            Re: !0,
            li: !0,
            pg: b.google_ad_client
        });
        return {}
    }, {
        id: 1398,
        H: {}
    });
    var s5 = Y(function(a) {
        var b = a.rn;
        return b ? {
            og: b
        } : {
            og: a.Je
        }
    }, {
        id: 1402,
        H: {
            og: void 0
        }
    });
    var t5 = Y(function(a, b) {
        a = a.jd;
        var c = b.google_ad_width;
        b = b.google_ad_height;
        c != null && (a.width = String(c));
        b != null && (a.height = String(b));
        a.frameborder = "0";
        a.marginwidth = "0";
        a.marginheight = "0";
        a.vspace = "0";
        a.hspace = "0";
        a.allowtransparency = "true";
        a.scrolling = "no";
        return {
            we: a
        }
    }, {
        id: 1373,
        H: {
            we: void 0
        }
    });
    const u5 = j2(function(a) {
        return !a.ra && a.Wa && !a.Ga
    }, {
        id: 1461
    });
    var v5 = class extends g2 {
        constructor(a, b, c, d, e, f, g, h) {
            super(a);
            this.ea = a;
            this.ra = f;
            this.Wa = g;
            this.Ga = h;
            var {
                jd: k,
                adUrl: l,
                Dd: m
            } = Z(this, n5, {
                Bh: b,
                R: d
            }, c.pubWin, c.I);
            ({
                we: a
            } = Z(this, t5, {
                jd: k
            }, c.I));
            ({
                we: e
            } = Z(this, m5, {
                jd: a
            }, e.document));
            d = T1(this, p5, {
                kh: e,
                Va: l,
                Dd: m,
                R: d
            }, {
                I: c.I,
                Gi: {
                    pubWin: c.pubWin,
                    K: c.K
                },
                ca: c.ca,
                Na: c.Na,
                Ia: c.Ia,
                Ta: c.Ta
            });
            e = Z(this, q5, {
                kh: e,
                Va: l,
                Dd: m
            }, {
                I: c.I,
                Gi: {
                    pubWin: c.pubWin,
                    K: c.K
                },
                ca: c.ca,
                Na: c.Na,
                Ia: c.Ia,
                Ta: c.Ta
            });
            d = Z(this, s5, {
                rn: d.output,
                Je: e.Je
            });
            this.G = d.og;
            c = Z(this, r5, {}, c.I, c.pubWin,
                c.ca);
            X(c, d.finished);
            this.yf = c.finished
        }
        async j() {
            return h2(this.ea, u5, {
                Ga: this.Ga,
                ra: this.ra,
                Wa: this.Wa
            })
        }
        l() {
            this.yf.notify();
            NZ(this.G, null)
        }
    };
    var w5 = Y(function(a) {
        if (!a.L) return {};
        var b = a.tb.Kn;
        if (b) {
            var c = a.L;
            b = Wh(b);
            c.srcdoc = Nh(b)
        }
        Ni(a.L, "allowtransparency", "true");
        Ni(a.L, "vspace", "0");
        Ni(a.L, "hspace", "0");
        return {}
    }, {
        id: 1455,
        H: {}
    });
    var x5 = Y(function(a) {
        if (!a.L) return {};
        var b = a.tb.Dc,
            c = a.tb.Cc;
        a.L.style.top = "0";
        a.L.style.left = "0";
        a.L.style.position = "absolute";
        a.L.style.width = `${b}px`;
        a.L.style.height = `${c}px`;
        a.L.style.minHeight = "auto";
        a.L.style.maxHeight = "none";
        a.L.style.minWidth = "auto";
        a.L.style.maxWidth = "none";
        a.L.style.removeProperty("vertical-align");
        return {}
    }, {
        id: 1456,
        H: {}
    });
    var y5 = Y(function(a, b, c) {
        var d = c.google_async_iframe_id,
            e = c.google_ad_width,
            f = c.google_ad_height,
            g = c.google_video_play_muted === !1;
        c = c.dash || "";
        var h = pz(Sx),
            k = [];
        for (let l = 0; l < h.length; l += 2) Cm(h[l], h[l + 1], k);
        return {
            tb: {
                zd: d,
                Dc: e,
                Cc: f,
                ca: b,
                gl: g,
                Kn: c,
                pd: k.join("&"),
                Ya: a.Ya
            }
        }
    }, {
        id: 1482,
        H: {
            tb: void 0
        }
    });

    function z5(a) {
        var b = $k("IFRAME");
        A5(b, a);
        return b
    }

    function A5(a, b = {}) {
        var c = {
            frameborder: 0,
            allowTransparency: "true",
            style: "border:0;vertical-align:bottom;",
            src: "about:blank"
        };
        Gi(c, b);
        jj(a, c)
    };

    function B5({
        Ka: a,
        size: b,
        Ih: c
    }) {
        c || (a.style.width = Sj(b.width), a.style.height = Sj(b.height))
    }

    function C5(a) {
        B5(a);
        var b = a.L,
            c = a.Ka,
            d = a.pd,
            e = a.Um,
            f = a.zd,
            g = a.wh,
            h = a.qm,
            k = a.content,
            l = a.Vb,
            m = a.Ih,
            n = a.size,
            p = m || !b;
        k = JSON.stringify({
            creative: m || !b ? k ? ? "" : ""
        });
        var q = null;
        a.De && (q = a.De);
        a = D5(f, k, n, g, h, l, p, q == null ? null : q.join(" "), d ? ? "", e ? `//${e}.safeframe.googlesyndication.com` : "//tpc.googlesyndication.com", c);
        m ? (c.removeChild(b), A5(b, a), m = b) : b ? (m = b, A5(b, a)) : m = z5(a);
        c.appendChild(m);
        return m
    }

    function D5(a, b, c, d = "3rd party ad content", e = "Advertisement", f, g, h, k, l, m) {
        a = {
            id: a,
            title: d,
            name: b,
            scrolling: "no",
            marginWidth: "0",
            marginHeight: "0",
            width: String(c.width),
            height: String(c.height),
            "data-is-nameframe": "true"
        };
        g && (g = nj(ij(m)), k && (k = "?" + k), l = l + "/nameframe.html" + k, (g = W2(g)) && (l += `${k?"&":"?"}n=${g}`), a.src = `https:${l}`);
        h !== null && (a.sandbox = h);
        f && (a.allow = f);
        a["aria-label"] = e;
        a.tabIndex = 0;
        return a
    };

    function E5(a, b, c) {
        a.D[b] = c
    }

    function F5(a, b, c) {
        var d = {};
        d.c = a.Qb;
        d.i = a.A;
        d.s = b;
        d.p = c;
        try {
            a.C.postMessage(JSON.stringify(d), a.l)
        } catch (e) {}
    }
    class G5 extends O {
        constructor(a, b, c) {
            super();
            this.Qb = a;
            this.status = 1;
            this.C = b;
            this.l = c;
            this.Cd = !1;
            this.A = Math.random();
            this.D = {};
            this.j = null;
            this.G = za(this.J, this);
            this.Eb = void 0
        }
        J(a) {
            if (!(this.l !== "*" && a.origin !== this.l || !this.Cd && a.source != this.C)) {
                var b = null;
                try {
                    b = JSON.parse(a.data)
                } catch (c) {}
                if (ra(b) && (a = b.i, b.c === this.Qb && a != this.A)) {
                    if (this.status !== 2) try {
                        this.status = 2, a = {}, a.c = this.Qb, a.i = this.A, this.Eb && (a.e = this.Eb), this.C.postMessage(JSON.stringify(a), this.l), this.j && (this.j(), this.j = null)
                    } catch (c) {}
                    a =
                        b.s;
                    b = b.p;
                    if (typeof a === "string" && (typeof b === "string" || ra(b)) && this.D.hasOwnProperty(a)) this.D[a](b)
                }
            }
        }
        connect(a) {
            a && (this.j = a);
            Yj(window, "message", this.G)
        }
        g() {
            this.status = 3;
            Zj(window, "message", this.G);
            super.g()
        }
    };
    var H5 = class {
        constructor(a) {
            this.uid = a;
            this.l = null;
            this.A = this.status = 0;
            this.g = null;
            this.Qb = `sfchannel${a}`
        }
        Dh() {
            return this.A === 2
        }
    };

    function I5(a) {
        var b = {};
        ab(a, c => {
            b[c.g()] = c.j()
        });
        return b
    };

    function J5(a) {
        var b = b || window;
        var c = b.screenX || b.screenLeft || 0,
            d = b.screenY || b.screenTop || 0;
        b = new zj(d, c + (b.outerWidth || document.documentElement.clientWidth || 0), d + (b.outerHeight || document.documentElement.clientHeight || 0), c);
        c = Rj(a);
        d = Tj(a);
        var e = new Cj(c.x, c.y, d.width, d.height);
        c = Dj(e);
        d = String(Lj(a, "zIndex"));
        var f = new zj(0, Infinity, Infinity, 0);
        for (var g = Ti(a), h = g.g.body, k = g.g.documentElement, l = mj(g.g); a = Qj(a);)
            if ((!xb || a.clientHeight != 0 || a != h) && a != h && a != k && Lj(a, "overflow") != "visible") {
                var m = Rj(a);
                let n = new vi(a.clientLeft, a.clientTop);
                m.x += n.x;
                m.y += n.y;
                f.top = Math.max(f.top, m.y);
                f.right = Math.min(f.right, m.x + a.clientWidth);
                f.bottom = Math.min(f.bottom, m.y + a.clientHeight);
                f.left = Math.max(f.left, m.x)
            }
        a = l.scrollLeft;
        l = l.scrollTop;
        f.left = Math.max(f.left, a);
        f.top = Math.max(f.top, l);
        g = g.ua();
        g = lj(g || window);
        f.right = Math.min(f.right, a + g.width);
        f.bottom = Math.min(f.bottom, l + g.height);
        l = (f = (f = f.top >= 0 && f.left >= 0 && f.bottom > f.top && f.right > f.left ? f : null) ? new Cj(f.left, f.top, f.right - f.left, f.bottom - f.top) : null) ?
            Ej(e, f) : null;
        g = a = 0;
        l && !(new wi(l.width, l.height)).isEmpty() && (a = l.width / e.width, g = l.height / e.height);
        l = new zj(0, 0, 0, 0);
        if (h = f)(h = Ej(e, f)) ? (k = Dj(f), m = Dj(h), e = m.right !== k.left && k.right !== m.left, k = m.bottom !== k.top && k.bottom !== m.top, h = (h.width !== 0 || e) && (h.height !== 0 || k)) : h = !1;
        h && (l = new zj(Math.max(c.top - f.top, 0), Math.max(f.left + f.width - c.right, 0), Math.max(f.top + f.height - c.bottom, 0), Math.max(c.left - f.left, 0)));
        return new K5(b, c, d, l, a, g)
    }

    function L5(a) {
        return JSON.stringify({
            windowCoords_t: a.l.top,
            windowCoords_r: a.l.right,
            windowCoords_b: a.l.bottom,
            windowCoords_l: a.l.left,
            frameCoords_t: a.j.top,
            frameCoords_r: a.j.right,
            frameCoords_b: a.j.bottom,
            frameCoords_l: a.j.left,
            styleZIndex: a.B,
            allowedExpansion_t: a.g.top,
            allowedExpansion_r: a.g.right,
            allowedExpansion_b: a.g.bottom,
            allowedExpansion_l: a.g.left,
            xInView: a.A,
            yInView: a.C
        })
    }
    var K5 = class {
        constructor(a, b, c, d, e, f) {
            this.B = c;
            this.A = e;
            this.C = f;
            this.l = Aj(a);
            this.j = Aj(b);
            this.g = Aj(d)
        }
    };
    var M5 = class {
        constructor(a) {
            this.g = a
        }
        getValue(a, b) {
            a = this.g[a];
            if (a == null) return null;
            b = a[b];
            return b === null || b === void 0 ? null : b
        }
    };
    var N5 = class {
        constructor(a, b) {
            this.mf = a;
            this.nf = b;
            this.j = this.g = !1
        }
    };
    var O5 = class {
        constructor(a, b, c, d, e, f, g, h = []) {
            this.uid = a;
            this.W = b;
            this.D = c;
            this.permissions = d;
            this.metadata = e;
            this.g = f;
            this.Cd = g;
            this.hostpageLibraryTokens = h;
            this.Eb = ""
        }
    };

    function P5(a) {
        return oc(a) || x(a)
    }
    var Q5 = class {
            constructor(a, b) {
                this.uid = a;
                this.Eb = b
            }
            g(a) {
                this.Eb && a && (a.sentinel = this.Eb);
                return JSON.stringify(a)
            }
        },
        R5 = class extends Q5 {
            constructor(a, b, c = "") {
                super(a, c);
                this.version = b
            }
            g() {
                return super.g({
                    uid: this.uid,
                    version: this.version
                })
            }
        },
        S5 = class extends Q5 {
            constructor(a, b, c, d = "") {
                super(a, d);
                this.l = b;
                this.j = c
            }
            g() {
                return super.g({
                    uid: this.uid,
                    initialWidth: this.l,
                    initialHeight: this.j
                })
            }
        },
        T5 = class extends Q5 {
            constructor(a, b, c = "") {
                super(a, c);
                this.description = b
            }
            g() {
                return super.g({
                    uid: this.uid,
                    description: this.description
                })
            }
        },
        U5 = class extends Q5 {
            constructor(a, b, c, d = "") {
                super(a, d);
                this.j = b;
                this.push = c
            }
            g() {
                return super.g({
                    uid: this.uid,
                    expand_t: this.j.top,
                    expand_r: this.j.right,
                    expand_b: this.j.bottom,
                    expand_l: this.j.left,
                    push: this.push
                })
            }
        },
        V5 = class extends Q5 {
            constructor(a, b = "") {
                super(a, b)
            }
            g() {
                return super.g({
                    uid: this.uid
                })
            }
        },
        W5 = class extends Q5 {
            constructor(a, b, c = "") {
                super(a, c);
                this.l = b
            }
            g() {
                var a = {
                    uid: this.uid,
                    newGeometry: L5(this.l)
                };
                return super.g(a)
            }
        },
        X5 = class extends W5 {
            constructor(a, b, c, d, e) {
                super(a, c, "");
                this.success =
                    b;
                this.j = d;
                this.push = e
            }
            g() {
                var a = {
                    uid: this.uid,
                    success: this.success,
                    newGeometry: L5(this.l),
                    expand_t: this.j.top,
                    expand_r: this.j.right,
                    expand_b: this.j.bottom,
                    expand_l: this.j.left,
                    push: this.push
                };
                this.Eb && (a.sentinel = this.Eb);
                return JSON.stringify(a)
            }
        },
        Y5 = class extends Q5 {
            constructor(a, b, c, d = "") {
                super(a, d);
                this.width = b;
                this.height = c
            }
            g() {
                return super.g({
                    uid: this.uid,
                    width: this.width,
                    height: this.height
                })
            }
        };
    var Z5 = ["allow-modals", "allow-orientation-lock", "allow-presentation", "allow-pointer-lock"],
        $5 = ["allow-top-navigation"],
        a6 = ["allow-same-origin"],
        b6 = hl([...Z5, ...$5]);
    hl([...Z5, ...a6]);
    hl([...Z5, ...$5, ...a6]);

    function c6(a) {
        var b = null;
        a.De && (b = a.De);
        return b == null ? null : b.join(" ")
    }

    function d6({
        Ka: a,
        size: b,
        Ih: c
    }) {
        b === 1 || c || (a.style.width = Sj(b.width), a.style.height = Sj(b.height))
    }

    function e6(a, {
        L: b,
        content: c,
        zd: d,
        size: e,
        wh: f = "3rd party ad content",
        qm: g = "Advertisement",
        Vb: h,
        Ih: k
    }) {
        var l = k || !b,
            m = {
                shared: {
                    sf_ver: a.Ya,
                    ck_on: pI() ? 1 : 0,
                    flash_ver: "0"
                }
            };
        c = k || !b ? c ? ? "" : "";
        var n = a.Ya,
            p = c.length;
        m = new O5(a.uid, a.W, a.D, a.permissions, new M5(m), a.Ab, a.Cd, a.hostpageLibraryTokens);
        var q = m.uid,
            u = m.W,
            w = L5(m.D);
        var B = m.permissions;
        B = JSON.stringify({
            expandByOverlay: B.mf,
            expandByPush: B.nf,
            readCookie: B.g,
            writeCookie: B.j
        });
        q = {
            uid: q,
            hostPeerName: u,
            initialGeometry: w,
            permissions: B,
            metadata: JSON.stringify(m.metadata.g),
            reportCreativeGeometry: m.g,
            isDifferentSourceWindow: m.Cd,
            goog_safeframe_hlt: I5(m.hostpageLibraryTokens)
        };
        m.Eb && (q.Eb = m.Eb);
        m = JSON.stringify(q);
        u = q = 0;
        e !== 1 && (q = e.width, u = e.height);
        d = {
            id: d,
            title: f,
            name: `${n};${p};${c}${m}`,
            scrolling: "no",
            marginWidth: "0",
            marginHeight: "0",
            width: String(q),
            height: String(u),
            "data-is-safeframe": "true"
        };
        l && (d.src = X2(nj(ij(a.Ka)), a.Ya, a.pd, a.hostname));
        a.sandbox !== null && (d.sandbox = a.sandbox);
        h && (d.allow = h);
        d["aria-label"] = g;
        d.tabIndex = 0;
        k ? (a.Ka.removeChild(b), A5(b, d), a.L = b) :
            b ? (a.L = b, jj(a.L, d)) : a.L = z5(d);
        a.Ka.appendChild(a.L)
    }

    function f6(a) {
        if (a.status === 1 || a.status === 2) switch (a.B) {
            case 0:
                g6(a);
                h6(a);
                a.B = 1;
                break;
            case 1:
                a.B = 2;
                break;
            case 2:
                a.B = 2
        }
    }

    function i6(a) {
        a.g = new G5(a.Qb, a.L.contentWindow, a.Gb);
        E5(a.g, "init_done", b => {
            a.Z(b)
        });
        E5(a.g, "register_done", b => {
            a.Ba(b)
        });
        E5(a.g, "report_error", b => {
            a.reportError(b)
        });
        E5(a.g, "expand_request", b => {
            a.J(b)
        });
        E5(a.g, "collapse_request", b => {
            a.O(b)
        });
        E5(a.g, "creative_geometry_update", b => {
            a.G(b)
        });
        a.Ab && a.ke ? .Xb.hc.xf.Ab.lf.wa({
            dg: 2,
            da: a.me
        });
        a.g.connect(() => {
            a.la()
        })
    }

    function g6(a) {
        a.l = J5(a.L);
        F5(a.g, "geometry_update", (new W5(a.uid, a.l)).g())
    }

    function h6(a) {
        a.P = window.setTimeout(() => {
            if (a.status === 1 || a.status === 2) switch (a.B) {
                case 0:
                case 1:
                    a.B = 0;
                    break;
                case 2:
                    g6(a), h6(a), a.B = 1
            }
        }, 1E3)
    }
    var j6 = class extends H5 {
        constructor(a) {
            super(a.uniqueId);
            this.P = -1;
            this.ea = a.ea;
            this.ke = a.ke;
            this.me = a.me ? ? 1;
            (this.Ab = a.size === 1) && this.ke ? .Xb.hc.xf.Ab.lf.wa({
                dg: 1,
                da: this.me
            });
            this.permissions = new N5(a.permissions.mf && !this.Ab, a.permissions.nf && !this.Ab);
            this.Ka = a.Ka;
            this.hostpageLibraryTokens = a.hostpageLibraryTokens ? ? [];
            var {
                protocol: b,
                host: c
            } = window.location;
            this.W = b === "file:" ? "*" : `${b}//${c}`;
            this.Cd = !!a.Cd;
            this.hostname = a.nk ? Z2(a.nk) : "//tpc.googlesyndication.com";
            this.Gb = a.L ? "*" : `https:${this.hostname}`;
            this.sandbox = c6(a);
            this.j = new Pz;
            d6(a);
            this.l = this.D = J5(a.Ka);
            this.Ya = a.Ya || "0-0-0";
            this.pd = a.pd ? ? "";
            this.L = null;
            e6(this, a);
            this.C = eL(412, () => {
                f6(this)
            }, a.oc);
            this.B = 0;
            var d = eL(415, () => {
                this.L && (this.L.name = "", a.Wj && a.Wj(), Zj(this.L, "load", d))
            }, a.oc);
            Yj(this.L, "load", d);
            this.Z = eL(413, this.Z, a.oc);
            this.Ba = eL(417, this.Ba, a.oc);
            this.reportError = eL(419, this.reportError, a.oc);
            this.J = eL(411, this.J, a.oc);
            this.O = eL(409, this.O, a.oc);
            this.G = eL(410, this.G, a.oc);
            this.la = eL(416, this.la, a.oc);
            i6(this)
        }
        la() {
            Yj(window,
                "resize", this.C);
            Yj(window, "scroll", this.C)
        }
        Z(a) {
            try {
                if (this.status !== 0) throw Error("Container already initialized");
                if (!x(a)) throw Error("Could not parse serialized message");
                let c = JSON.parse(a);
                if (!(ra(c) && P5(c.uid) && x(c.version))) throw Error("Cannot parse JSON message");
                var b = new R5(c.uid, c.version, c.sentinel || "");
                if (this.uid !== b.uid || this.Ya !== b.version) throw Error("Wrong source container");
                this.status = 1
            } catch (c) {
                this.ea ? .error(`Invalid INITIALIZE_DONE message. Reason: ${c.message}`)
            }
        }
        Ba(a) {
            try {
                if (this.status !==
                    1) throw Error("Container not initialized");
                if (!x(a)) throw Error("Could not parse serialized message");
                let b = JSON.parse(a);
                if (!(ra(b) && P5(b.uid) && oc(b.initialWidth) && oc(b.initialHeight))) throw Error("Cannot parse JSON message");
                if (this.uid !== (new S5(b.uid, b.initialWidth, b.initialHeight, b.sentinel || "")).uid) throw Error("Wrong source container");
                this.status = 2
            } catch (b) {
                this.ea ? .error(`Invalid REGISTER_DONE message. Reason: ${b.message}`)
            }
        }
        reportError(a) {
            try {
                if (!x(a)) throw Error("Could not parse serialized message");
                let c = JSON.parse(a);
                if (!(ra(c) && P5(c.uid) && x(c.description))) throw Error("Cannot parse JSON message");
                var b = new T5(c.uid, c.description, c.sentinel || "");
                if (this.uid !== b.uid) throw Error("Wrong source container");
                this.ea ? .info(`Ext reported an error. Description: ${b.description}`)
            } catch (c) {
                this.ea ? .error(`Invalid REPORT_ERROR message. Reason: ${c.message}`)
            }
        }
        J(a) {
            try {
                if (this.status !== 2) throw Error("Container is not registered");
                if (this.A !== 0) throw Error("Container is not collapsed");
                if (!x(a)) throw Error("Could not parse serialized message");
                let H = JSON.parse(a);
                if (!(ra(H) && P5(H.uid) && oc(H.expand_t) && oc(H.expand_r) && oc(H.expand_b) && oc(H.expand_l) && pc(H.push))) throw Error("Cannot parse JSON message");
                var b = new U5(H.uid, new zj(H.expand_t, H.expand_r, H.expand_b, H.expand_l), H.push, H.sentinel || "");
                if (this.uid !== b.uid) throw Error("Wrong source container");
                if (!(b.j.top >= 0 && b.j.left >= 0 && b.j.bottom >= 0 && b.j.right >= 0)) throw Error("Invalid expansion amounts");
                var c;
                if (c = b.push && this.permissions.nf || !b.push && this.permissions.mf) {
                    var d = b.j,
                        e = b.push,
                        f = this.l = J5(this.L);
                    if (d.top <= f.g.top && d.right <= f.g.right && d.bottom <= f.g.bottom && d.left <= f.g.left) {
                        if (!e)
                            for (let L = this.L.parentNode; L && L.style; L = L.parentNode) Mz(this.j, L, "overflowX", "visible", "important"), Mz(this.j, L, "overflowY", "visible", "important");
                        var g = Dj(new Cj(0, 0, this.l.j.getWidth(), this.l.j.getHeight()));
                        ra(d) ? (g.top -= d.top, g.right += d.right, g.bottom += d.bottom, g.left -= d.left) : (g.top -= d, g.right += Number(void 0), g.bottom += Number(void 0), g.left -= Number(void 0));
                        Mz(this.j, this.Ka, "position", "relative");
                        Mz(this.j, this.L, "position", "absolute");
                        if (e) {
                            var h = this.j,
                                k = this.Ka,
                                l = g.getWidth();
                            Mz(h, k, "width", W(l));
                            var m = this.j,
                                n = this.Ka,
                                p = g.getHeight();
                            Mz(m, n, "height", W(p))
                        } else Mz(this.j, this.L, "zIndex", "10000");
                        var q = this.j,
                            u = this.L,
                            w = g.getWidth();
                        Mz(q, u, "width", W(w));
                        var B = this.j,
                            G = this.L,
                            K = g.getHeight();
                        Mz(B, G, "height", W(K));
                        Mz(this.j, this.L, "left", W(g.left));
                        Mz(this.j, this.L, "top", W(g.top));
                        this.A = 2;
                        this.l = J5(this.L);
                        c = !0
                    } else c = !1
                }
                a = c;
                F5(this.g, "expand_response", (new X5(this.uid, a, this.l, b.j, b.push)).g());
                if (!a) throw Error("Viewport or document body not large enough to expand into.");
            } catch (H) {
                this.ea ? .error(`Invalid EXPAND_REQUEST message. Reason: ${H.message}`)
            }
        }
        O(a) {
            try {
                if (this.status !== 2) throw Error("Container is not registered");
                if (!this.Dh()) throw Error("Container is not expanded");
                if (!x(a)) throw Error("Could not parse serialized message");
                let b = JSON.parse(a);
                if (!ra(b) || !P5(b.uid)) throw Error("Cannot parse JSON message");
                if (this.uid !== (new V5(b.uid, b.sentinel || "")).uid) throw Error("Wrong source container");
                this.collapse();
                F5(this.g, "collapse_response", (new W5(this.uid, this.l)).g())
            } catch (b) {
                this.ea ? .error(`Invalid COLLAPSE_REQUEST message. Reason: ${b.message}`)
            }
        }
        collapse() {
            Oz(this.j);
            this.A = 0;
            this.L && (this.l = J5(this.L))
        }
        G(a) {
            try {
                if (!x(a)) throw Error("Could not parse serialized message");
                let c = JSON.parse(a);
                if (!(ra(c) && P5(c.uid) && oc(c.width) && oc(c.height)) || c.sentinel && !x(c.sentinel)) throw Error("Cannot parse JSON message");
                var b = new Y5(c.uid, c.width, c.height, c.sentinel || "");
                if (this.uid !== b.uid) throw Error("Wrong source container");
                let d = String(b.height);
                this.Ab ? (this.ke ? .Xb.hc.xf.Ab.lf.wa({
                    dg: 3,
                    da: this.me
                }), d !== this.L.height && (this.L.height = d, this.ke ? .Xb.hc.xf.Ab.lf.wa({
                    dg: 4,
                    da: this.me
                }), f6(this))) : this.ea ? .error("Got CreativeGeometryUpdate message in non-fluidcontainer. The container is not resized.")
            } catch (c) {
                this.ea ? .error(`Invalid CREATIVE_GEOMETRY_UPDATE message. Reason: ${c.message}`)
            }
        }
        destroy() {
            this.status !== 100 && (this.Dh() && (Oz(this.j), this.A = 0), window.clearTimeout(this.P), this.P = -1, this.B = 3, this.g && (this.g.dispose(),
                this.g = null), Zj(window, "resize", this.C), Zj(window, "scroll", this.C), this.Ka && this.L && this.Ka === (this.L.parentElement || null) && this.Ka.removeChild(this.L), this.Ka = this.L = null, this.status = 100)
        }
    };

    function k6(a, b, c, d) {
        var e = a.zd,
            f = a.Dc,
            g = a.Cc;
        a = a.ca;
        var {
            promise: h,
            resolve: k
        } = ja(Promise, "withResolvers").call(Promise), l = C5({
            Ka: a,
            zd: e,
            wh: e,
            size: new wi(f, g),
            content: b,
            De: c ? ? void 0,
            Um: b3(),
            Vb: d ? .join(";")
        }), m = eL(415, () => {
            k();
            Zj(l, "load", m)
        });
        Yj(l, "load", m);
        return {
            pe: l,
            Kd: h
        }
    }
    var l6 = Y(function(a) {
        if (U(Qx)) var b = k6(a.tb, a.Ji, a.Ud, a.Vb);
        else {
            var c = a.tb;
            b = a.Ji;
            var d = a.Ud;
            a = a.Vb;
            let e = c.zd,
                f = c.Dc,
                g = c.Cc,
                h = c.ca,
                k = c.pd;
            c = c.Ya;
            let {
                promise: l,
                resolve: m
            } = ja(Promise, "withResolvers").call(Promise);
            b = {
                pe: (new j6({
                    Ka: h,
                    zd: e,
                    wh: e,
                    size: new wi(f, g),
                    content: b,
                    Wj: m,
                    uniqueId: e,
                    De: d ? ? void 0,
                    permissions: {
                        mf: !1,
                        nf: !1
                    },
                    nk: b3(),
                    pd: k,
                    Vb: a ? .join(";"),
                    Ya: c
                })).L,
                Kd: l
            }
        }
        return b
    }, {
        id: 1453,
        H: {
            pe: void 0,
            Kd: void 0
        }
    });
    var m6 = Y(function() {
        return jl() ? {
            Ud: b6
        } : {
            Ud: void 0
        }
    }, {
        id: 1475,
        H: {
            Ud: void 0
        }
    });
    const n6 = ["run-ad-auction", "attribution-reporting"];
    var o6 = Y(function(a, b) {
        a = a.tb.gl;
        var c = n6.filter(d => f0(d, b));
        a && c.push("autoplay");
        return {
            Vb: c
        }
    }, {
        id: 1476,
        H: {
            Vb: void 0
        }
    });
    var p6 = class extends W1 {
        constructor(a, b, c, d) {
            super(a);
            this.Lh = a;
            this.j = new WZ;
            ({
                tb: a
            } = Z(this, y5, {
                Ya: d
            }, b.ca, b.I, b.pubWin));
            ({
                Ud: d
            } = Z(this, m6, {}));
            ({
                Vb: b
            } = Z(this, o6, {
                tb: a
            }, b.pubWin.document));
            var {
                pe: e,
                Kd: f
            } = Z(this, l6, {
                Ji: c,
                Ud: d,
                Vb: b,
                tb: a
            });
            c = Z(this, w5, {
                L: e,
                tb: a
            });
            c = X(Z(this, x5, {
                L: e,
                tb: a
            }), c.finished);
            this.l = e;
            this.G = f;
            this.j = c.finished
        }
    };

    function q6(a, b) {
        var c = window,
            d = e => {
                e.blockedURI === a && e.disposition === "enforce" && (ZB(1), c.removeEventListener("securitypolicyviolation", d))
            };
        c.addEventListener("securitypolicyviolation", d);
        xt(b, () => {
            c.removeEventListener("securitypolicyviolation", d)
        });
        return d
    }

    function r6(a, b) {
        var c = new MutationObserver((d, e) => {
            a.isConnected || (e.disconnect(), b.abort())
        });
        c.observe(document.body, {
            childList: !0,
            subtree: !0
        });
        return c
    }
    var s6 = Q1(async function(a, b, c) {
        var d = a.tm;
        a = N_(a.adUrl);
        var e;
        V(Ox) > 0 && (e = q6(a, c));
        c = !1;
        if (!b.isConnected) return {
            error: Error("Iframe wrapper element is not in the DOM at request time."),
            redirected: c
        };
        var f = new AbortController;
        b = r6(b, f);
        try {
            let g = await fetch(a, {
                credentials: d ? "include" : "omit",
                redirect: V(Ox) > 0 ? "manual" : "follow",
                signal: f.signal
            });
            if (g.type === "opaqueredirect" || g.status >= 300 && g.status < 400) {
                c = !0;
                let h = g.headers.get("Location") || a;
                g = await fetch(h, {
                    credentials: d ? "include" : "omit",
                    signal: f.signal
                })
            }
            return {
                response: g,
                redirected: c
            }
        } catch (g) {
            return {
                error: g,
                redirected: c
            }
        } finally {
            b.disconnect(), e && setTimeout(() => {
                window.removeEventListener("securitypolicyviolation", e)
            }, 0)
        }
    }, {
        id: 1452
    });

    function t6() {
        var a = oz(Tx) || "0-0-0",
            b = a.split("-").map(d => Number(d)),
            c = ["0", "0", "0"].map(d => Number(d));
        for (let d = 0; d < b.length; d++) {
            if (b[d] > c[d]) return a;
            if (b[d] < c[d]) break
        }
        return "0-0-0"
    }
    var u6 = Y(function() {
        return {
            Ya: t6()
        }
    }, {
        id: 1477,
        H: {
            Ya: void 0
        }
    });
    var v6 = Y(function(a, b) {
        a = a.R.ha();
        b = !lY(b.I);
        return {
            output: a && b
        }
    }, {
        id: 1474,
        H: {
            output: void 0
        }
    });

    function w6(a, b) {
        var c = $k("IFRAME");
        Ii(c, b);
        c.style.visibility = "hidden";
        c.style.display = "none";
        a = a.getElementsByTagName("script");
        a.length && (a = a[a.length - 1], a.parentNode && a.parentNode.insertBefore(c, a.nextSibling));
        return c
    }

    function x6(a, b, c) {
        if (!a.g[c.toString()]) {
            a.g[c.toString()] = 1;
            var d = w6(b.document, c);
            d.addEventListener("load", () => {
                d.remove()
            })
        }
    }

    function y6(a, b, c, d, e = []) {
        c = $2(Y2.Gm({
            version: d,
            gg: c
        }), b);
        if (e.length) {
            d = new Map;
            for (let f = 0; f < e.length; f += 2) d.set(e[f], e[f + 1]);
            c = gi(c, d)
        }
        x6(a, b, c)
    }

    function z6(a, b) {
        var c = new A6;
        if (!x(b)) throw new TypeError("subdomain is not a string");
        if (!/^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$/.test(b)) throw new RangeError(`Invalid subdomain: ${b}`);
        b = Sh(`https://${b}.safeframe.googlesyndication.com/nameframe.html`);
        b = $2(b, a);
        x6(c, a, b)
    }
    var A6 = class {
        constructor() {
            this.g = {}
        }
    };

    function B6(a, b, c, d) {
        var e = f => {
            f.blockedURI.startsWith(`https://${a}`) && f.disposition === "enforce" && (c(), b.removeEventListener("securitypolicyviolation", e))
        };
        b.addEventListener("securitypolicyviolation", e);
        xt(d, () => {
            b.removeEventListener("securitypolicyviolation", e)
        })
    }
    var C6 = Y(function(a, b, c, d) {
        if (b.GLnKw || b.FJPve) return {};
        var e = b3();
        V(Ox) > 0 && B6(e, c, () => {
            ZB(3)
        }, d);
        U(Qx) ? (z6(c, e), b.GLnKw = !0) : (y6(new A6, c, e, a.Ya, pz(Sx)), b.FJPve = !0);
        return {}
    }, {
        id: 1575,
        H: {}
    });
    const D6 = ["Failed to fetch", "Load failed"];
    var E6 = Y(function(a) {
        var b = a.rf.error;
        a = a.rf.redirected;
        b && (AB(1610, b), V(Ox) > 0 && b instanceof TypeError && D6.includes(b.message) && a && ZB(2));
        return {}
    }, {
        id: 1610,
        H: {}
    });
    var F6 = class extends Error {
        constructor(a) {
            super(a)
        }
    };
    F6.prototype.name = "NetworkError";
    var G6 = Q1(async function(a) {
        var b = Promise.resolve(null);
        (a = a.rf.response) && (a.status >= 300 ? AB(1454, new F6(`Received non-200 response from BOW, status: ${a.status}`)) : b = a.text());
        return b
    }, {
        id: 1454
    });
    var H6 = class extends W1 {
        constructor(a, b) {
            super(a);
            ({
                output: a
            } = T1(this, G6, {
                rf: b
            }));
            Z(this, E6, {
                rf: b
            });
            this.j = a
        }
    };
    const I6 = j2(function(a) {
        return a.Ga && !a.ra && a.Wa
    }, {
        id: 1487
    });
    var J6 = class extends g2 {
        constructor(a, b, c, d, e) {
            super(a);
            this.ea = a;
            this.Ga = e.Ga;
            this.ra = e.ra;
            this.rh = e.rh;
            ({
                Ya: e
            } = Z(this, u6, {}));
            Z(this, C6, {
                Ya: e
            }, c.pageState, c.pubWin, this);
            ({
                output: d
            } = Z(this, v6, {
                R: d
            }, c));
            ({
                output: b
            } = T1(this, s6, {
                tm: d,
                adUrl: b
            }, c.ca, this));
            ({
                j: b
            } = U1(this, new H6(a, b)));
            var {
                l: f,
                G: g,
                j: h
            } = U1(this, new p6(a, c, b, e));
            this.G = f;
            this.Gb = g;
            this.J = h
        }
        async j() {
            return h2(this.ea, I6, {
                Ga: this.Ga,
                ra: this.ra,
                Wa: this.rh
            })
        }
        l() {
            NZ(this.G, null);
            NZ(this.Gb, null);
            this.J.notify()
        }
    };
    var K6 = class extends W1 {
        constructor(a, b, c, d) {
            super(a);
            var {
                R: e
            } = X(Z(this, Y1, {}, b), c), f = X(Z(this, r2, {
                R: e
            }, b.pubWin, a), c);
            c = X(Z(this, n2, {}, b), c);
            f = f.gj;
            c = X(Z(this, a2, {
                R: e,
                Ua: f
            }, b.pubWin), c.finished);
            d = X(Z(this, Z1, {
                R: e,
                zb: d
            }, b.pubWin, b.I, b.pageState), c.finished);
            var g = U1(this, new l2(a, b, e, d.Vd, d.finished, f));
            c = X(Z(this, m2, {}, b), g.G).Ga;
            var h = U1(this, new X1(a, b, e, g.G, c, f)),
                k = h.j.bn;
            g = h.j.ra;
            h = h.j.zc;
            var l = U1(this, new J6(a, k, b, e, {
                Ga: c,
                ra: g,
                rh: d.Vd
            }));
            k = U1(this, new v5(a, k, b, e, b.pubWin, g, d.Vd, c));
            this.j =
                U1(this, new j5(a, k.G, h, b, e, {
                    yf: k.yf,
                    dm: l.J
                }, {
                    ra: g,
                    Wa: d.Vd
                }, {
                    Ga: c,
                    pe: l.G
                }, f)).J
        }
    };
    var L6 = Y(function(a, b) {
        b.j |= a.qf;
        return {
            tk: b
        }
    }, {
        id: 1412,
        H: {
            tk: void 0
        }
    });
    const M6 = (a, b) => {
            b = b.listener;
            (a = (0, a.__gpp)("addEventListener", b)) && b(a, !0)
        },
        N6 = (a, b) => {
            (0, a.__gpp)("removeEventListener", b.listener, b.listenerId)
        },
        O6 = {
            If: a => a.listener,
            se: (a, b) => ({
                __gppCall: {
                    callId: b,
                    command: "addEventListener",
                    version: "1.1"
                }
            }),
            Ld: (a, b) => {
                b = b.__gppReturn;
                a(b.returnValue, b.success)
            }
        },
        P6 = {
            If: a => a.listener,
            se: (a, b) => ({
                __gppCall: {
                    callId: b,
                    command: "removeEventListener",
                    version: "1.1",
                    parameter: a.listenerId
                }
            }),
            Ld: (a, b) => {
                b = b.__gppReturn;
                var c = b.returnValue.data;
                a ? .(c, b.success)
            }
        };

    function Q6(a) {
        var b = {};
        x(a.data) ? b = JSON.parse(a.data) : b = a.data;
        return {
            payload: b,
            ei: b.__gppReturn.callId
        }
    }

    function R6(a, b, c) {
        var d = !(b.includes(2) && c ? .idpcApplies),
            e = !1,
            f = !1;
        if (a && !a.startsWith("GPP_ERROR_STRING_")) {
            let t7 = IU(a.split("~")[0]),
                u7 = DU(a),
                uF = lf(t7, 3);
            for (let Rm = 0; Rm < uF.length; ++Rm) {
                let vF = uF[Rm];
                if (!b.includes(vF)) continue;
                let Kb = u7[Rm];
                switch (vF) {
                    case 2:
                        if (c ? .supportTcfeu) {
                            a: {
                                let na = tW(Kb);
                                if (!na || !Kb) {
                                    var g = null;
                                    break a
                                }
                                let jb = y(na, eW, 1),
                                    Sm = y(na, IV, 2) || new IV,
                                    wF = {
                                        consents: vW(lf(jb, 17)),
                                        legitimateInterests: vW(lf(jb, 18))
                                    };
                                if (ye(na, CV, 3)) {
                                    var h = y(na, CV, 3);
                                    var k = lf(h, 1);
                                    wF.disclosedVendors =
                                        vW(k)
                                }
                                var l = gf(jb, 9),
                                    m = gf(jb, 4),
                                    n = gf(jb, 5),
                                    p = C(jb, 10),
                                    q = C(jb, 11),
                                    u = D(jb, 16),
                                    w = C(jb, 15),
                                    B = {
                                        consents: vW(nf(jb, 13), gW),
                                        legitimateInterests: vW(nf(jb, 14), gW)
                                    },
                                    G = vW(nf(jb, 12), hW),
                                    K = Ve(jb, DV, 19, De());
                                let Tm = {};
                                for (let dt of K) {
                                    let et = E(dt, 1);
                                    Tm[et] = Tm[et] || {};
                                    for (let v7 of lf(dt, 3)) Tm[et][v7] = E(dt, 2)
                                }
                                g = {
                                    tcString: Kb,
                                    tcfPolicyVersion: l,
                                    gdprApplies: !0,
                                    cmpId: m,
                                    cmpVersion: n,
                                    isServiceSpecific: p,
                                    useNonStandardStacks: q,
                                    publisherCC: u,
                                    purposeOneTreatment: w,
                                    purpose: B,
                                    vendor: wF,
                                    specialFeatureOptins: G,
                                    publisher: {
                                        restrictions: Tm,
                                        consents: vW(nf(Sm, 1), gW),
                                        legitimateInterests: vW(nf(Sm, 2), gW),
                                        customPurposes: {
                                            consents: vW(lf(Sm, 3)),
                                            legitimateInterests: vW(lf(Sm, 4))
                                        }
                                    }
                                }
                            }
                            let va = g;
                            if (!va) throw Error("Cannot decode TCF V2 section string.");d = iQ(va);!lQ(va) && (e = !0)
                        }
                        break;
                    case 7:
                        let xF = vV(Kb, c ? .supportUsnatV2 ? [1, 2] : [1]),
                            Um = y(xF, oV, 1),
                            yF = y(Um, lV, 12);
                        E(Um, 8) !== 1 && E(Um, 9) !== 1 && E(Um, 10) !== 1 && yF ? .j() !== 1 && yF ? .g() !== 1 || (e = !0);
                        var H = y(xF, oV, 1);
                        let zF = y(H, lV, 12) ? .B();
                        zF !== 1 && zF !== 2 || (f = !0);
                        break;
                    case 8:
                        if (Kb.length === 0) throw Error("Cannot decode empty USCA section string.");
                        let Nj = Kb.split(".");
                        if (Nj.length > 2) throw Error(`Expected at most 1 sub-section but got ${Nj.length-1} when decoding ${Kb}.`);
                        var L = void 0,
                            S = void 0,
                            da = void 0,
                            Ea = void 0,
                            ka = void 0,
                            Da = void 0,
                            Nc = void 0,
                            ad = void 0,
                            Oc = void 0,
                            ee = void 0,
                            ya = void 0,
                            Pc = void 0,
                            Vg = void 0,
                            Wg = void 0,
                            Xg = void 0,
                            Yg = void 0,
                            Zg = void 0,
                            ah = void 0,
                            bh = void 0,
                            ch = void 0,
                            dh = void 0,
                            eh = void 0,
                            fh = void 0,
                            gh = Nj[0];
                        if (gh.length === 0) throw Error("Cannot decode empty core segment string.");
                        let Vm = HU(gh, RU),
                            ft = FU(Vm.slice(0, 6));
                        Vm = Vm.slice(6);
                        if (ft !==
                            1) throw Error(`Unable to decode unsupported USCA Section specification version ${ft} - only version 1 is supported.`);
                        let gt = 0,
                            Xa = [];
                        for (let va = 0; va < QU.length; va++) {
                            let na = QU[va];
                            Xa.push(FU(Vm.slice(gt, gt + na)));
                            gt += na
                        }
                        var Vi = new MU;
                        fh = vf(Vi, 1, ft);
                        var Wi = Xa.shift();
                        eh = F(fh, 2, Wi);
                        var Xi = Xa.shift();
                        dh = F(eh, 3, Xi);
                        var Yi = Xa.shift();
                        ch = F(dh, 4, Yi);
                        var Zi = Xa.shift();
                        bh = F(ch, 5, Zi);
                        var $i = Xa.shift();
                        ah = F(bh, 6, $i);
                        var Af = new LU,
                            aj = Xa.shift();
                        Zg = F(Af, 1, aj);
                        var ih = Xa.shift();
                        Yg = F(Zg, 2, ih);
                        var bj = Xa.shift();
                        Xg =
                            F(Yg, 3, bj);
                        var Df = Xa.shift();
                        Wg = F(Xg, 4, Df);
                        var cj = Xa.shift();
                        Vg = F(Wg, 5, cj);
                        var dj = Xa.shift();
                        Pc = F(Vg, 6, dj);
                        var ej = Xa.shift();
                        ya = F(Pc, 7, ej);
                        var Ef = Xa.shift();
                        ee = F(ya, 8, Ef);
                        var lh = Xa.shift();
                        Oc = F(ee, 9, lh);
                        ad = z(ah, 7, Oc);
                        var fj = new KU,
                            nh = Xa.shift();
                        Nc = F(fj, 1, nh);
                        var Ac = Xa.shift();
                        Da = F(Nc, 2, Ac);
                        ka = z(ad, 8, Da);
                        var oh = Xa.shift();
                        Ea = F(ka, 9, oh);
                        var gj = Xa.shift();
                        da = F(Ea, 10, gj);
                        var Gf = Xa.shift();
                        S = F(da, 11, Gf);
                        var ph = Xa.shift();
                        let AF = L = F(S, 12, ph);
                        if (Nj.length === 1) var Hf = OU(AF);
                        else {
                            var xc = OU(AF),
                                bd = void 0,
                                Wa =
                                void 0,
                                Vb = void 0,
                                Ug = Nj[1];
                            if (Ug.length === 0) throw Error("Cannot decode empty GPC segment string.");
                            let va = HU(Ug, 3),
                                na = FU(va.slice(0, 2));
                            if (na < 0 || na > 1) throw Error(`Attempting to decode unknown GPC segment subsection type ${na}.`);
                            Vb = na + 1;
                            let jb = FU(va.charAt(2));
                            var Ie = new NU;
                            Wa = F(Ie, 2, Vb);
                            bd = tf(Wa, 1, !!jb);
                            Hf = z(xc, 2, bd)
                        }
                        let BF = Hf,
                            CF = y(BF, MU, 1);
                        E(CF, 5) !== 1 && E(CF, 6) !== 1 || (e = !0);
                        var Ff = y(BF, MU, 1);
                        let Wm = y(Ff, KU, 8);
                        Wm ? .g() !== 1 && Wm ? .g() !== 2 && Wm ? .j() !== 1 && Wm ? .j() !== 2 || (f = !0);
                        break;
                    case 9:
                        if (Kb.length === 0) throw Error("Cannot decode empty USVA section string.");
                        let Xm = HU(Kb, AV),
                            ht = FU(Xm.slice(0, 6));
                        Xm = Xm.slice(6);
                        if (ht !== 1) throw Error(`Unable to decode unsupported USVA Section specification version ${ht} - only version 1 is supported.`);
                        let it = 0,
                            wb = [];
                        for (let va = 0; va < zV.length; va++) {
                            let na = zV[va];
                            wb.push(FU(Xm.slice(it, it + na)));
                            it += na
                        }
                        var yc = ht,
                            fc = new yV,
                            $c = vf(fc, 1, yc),
                            rd = wb.shift(),
                            Gb = F($c, 2, rd),
                            zc = wb.shift(),
                            zf = F(Gb, 3, zc),
                            Ui = wb.shift(),
                            $g = F(zf, 4, Ui),
                            sd = wb.shift(),
                            hh = F($g, 5, sd),
                            Bf = wb.shift();
                        var Cf = F(hh, 6, Bf);
                        var fe = new xV,
                            kh = wb.shift(),
                            mh = F(fe, 1, kh),
                            jh =
                            wb.shift(),
                            Kr = F(mh, 2, jh),
                            Lr = wb.shift(),
                            Mr = F(Kr, 3, Lr),
                            Nr = wb.shift(),
                            Or = F(Mr, 4, Nr),
                            Pr = wb.shift(),
                            Qr = F(Or, 5, Pr),
                            Rr = wb.shift(),
                            Sr = F(Qr, 6, Rr),
                            Tr = wb.shift(),
                            Ur = F(Sr, 7, Tr),
                            Vr = wb.shift();
                        var Wr = F(Ur, 8, Vr);
                        var Xr = z(Cf, 7, Wr),
                            Yr = wb.shift(),
                            Zr = F(Xr, 8, Yr),
                            $r = wb.shift(),
                            as = F(Zr, 9, $r),
                            bs = wb.shift(),
                            cs = F(as, 10, bs),
                            ds = wb.shift();
                        let jt = F(cs, 11, ds);
                        E(jt, 5) !== 1 && E(jt, 6) !== 1 || (e = !0);
                        let DF = E(jt, 8);
                        DF !== 1 && DF !== 2 || (f = !0);
                        break;
                    case 10:
                        if (Kb.length === 0) throw Error("Cannot decode empty USCO section string.");
                        let Oj = Kb.split(".");
                        if (Oj.length > 2) throw Error(`Expected at most 2 segments but got ${Oj.length} when decoding ${Kb}.`);
                        var es = void 0,
                            jm = void 0,
                            km = void 0,
                            lm = void 0,
                            mm = void 0,
                            nm = void 0,
                            om = void 0,
                            pm = void 0,
                            qm = void 0,
                            rm = void 0,
                            sm = void 0,
                            tm = void 0,
                            um = void 0,
                            vm = void 0,
                            wm = void 0,
                            xm = void 0,
                            ym = void 0,
                            zm = void 0,
                            Am = Oj[0];
                        if (Am.length === 0) throw Error("Cannot decode empty core segment string.");
                        let Ym = HU(Am, YU),
                            kt = FU(Ym.slice(0, 6));
                        Ym = Ym.slice(6);
                        if (kt !== 1) throw Error(`Unable to decode unsupported USCO Section specification version ${kt} - only version 1 is supported.`);
                        let lt = 0,
                            Lb = [];
                        for (let va = 0; va < XU.length; va++) {
                            let na = XU[va];
                            Lb.push(FU(Ym.slice(lt, lt + na)));
                            lt += na
                        }
                        var fs = new TU;
                        zm = vf(fs, 1, kt);
                        var gs = Lb.shift();
                        ym = F(zm, 2, gs);
                        var Bj = Lb.shift();
                        xm = F(ym, 3, Bj);
                        var im = Lb.shift();
                        wm = F(xm, 4, im);
                        var w7 = Lb.shift();
                        vm = F(wm, 5, w7);
                        var x7 = Lb.shift();
                        um = F(vm, 6, x7);
                        var y7 = new SU,
                            z7 = Lb.shift();
                        tm = F(y7, 1, z7);
                        var A7 = Lb.shift();
                        sm = F(tm, 2, A7);
                        var B7 = Lb.shift();
                        rm = F(sm, 3, B7);
                        var C7 = Lb.shift();
                        qm = F(rm, 4, C7);
                        var D7 = Lb.shift();
                        pm = F(qm, 5, D7);
                        var E7 = Lb.shift();
                        om = F(pm, 6, E7);
                        var F7 = Lb.shift();
                        nm = F(om, 7, F7);
                        mm = z(um, 7, nm);
                        var G7 = Lb.shift();
                        lm = F(mm, 8, G7);
                        var H7 = Lb.shift();
                        km = F(lm, 9, H7);
                        var I7 = Lb.shift();
                        jm = F(km, 10, I7);
                        var J7 = Lb.shift();
                        let EF = es = F(jm, 11, J7);
                        if (Oj.length === 1) var FF = VU(EF);
                        else {
                            var K7 = VU(EF),
                                GF = void 0,
                                HF = void 0,
                                IF = void 0,
                                JF = Oj[1];
                            if (JF.length === 0) throw Error("Cannot decode empty GPC segment string.");
                            let va = HU(JF, 3),
                                na = FU(va.slice(0, 2));
                            if (na < 0 || na > 1) throw Error(`Attempting to decode unknown GPC segment subsection type ${na}.`);
                            IF = na + 1;
                            let jb = FU(va.charAt(2));
                            var L7 = new UU;
                            HF = F(L7, 2, IF);
                            GF = tf(HF, 1, !!jb);
                            FF = z(K7, 2, GF)
                        }
                        let KF = FF,
                            LF = y(KF, TU, 1);
                        E(LF, 5) !== 1 && E(LF, 6) !== 1 || (e = !0);
                        var M7 = y(KF, TU, 1);
                        let MF = E(M7, 8);
                        MF !== 1 && MF !== 2 || (f = !0);
                        break;
                    case 12:
                        if (Kb.length === 0) throw Error("Cannot decode empty usct section string.");
                        let Pj = Kb.split(".");
                        if (Pj.length > 2) throw Error(`Expected at most 2 segments but got ${Pj.length} when decoding ${Kb}.`);
                        var N7 = void 0,
                            NF = void 0,
                            OF = void 0,
                            PF = void 0,
                            QF = void 0,
                            RF = void 0,
                            SF = void 0,
                            TF = void 0,
                            UF = void 0,
                            VF = void 0,
                            WF = void 0,
                            XF = void 0,
                            YF = void 0,
                            ZF =
                            void 0,
                            $F = void 0,
                            aG = void 0,
                            bG = void 0,
                            cG = void 0,
                            dG = void 0,
                            eG = void 0,
                            fG = void 0,
                            gG = void 0,
                            hG = Pj[0];
                        if (hG.length === 0) throw Error("Cannot decode empty core segment string.");
                        let Zm = HU(hG, fV),
                            mt = FU(Zm.slice(0, 6));
                        Zm = Zm.slice(6);
                        if (mt !== 1) throw Error(`Unable to decode unsupported USCT Section specification version ${mt} - only version 1 is supported.`);
                        let nt = 0,
                            gb = [];
                        for (let va = 0; va < eV.length; va++) {
                            let na = eV[va];
                            gb.push(FU(Zm.slice(nt, nt + na)));
                            nt += na
                        }
                        var O7 = new aV;
                        gG = vf(O7, 1, mt);
                        var P7 = gb.shift();
                        fG = F(gG,
                            2, P7);
                        var Q7 = gb.shift();
                        eG = F(fG, 3, Q7);
                        var R7 = gb.shift();
                        dG = F(eG, 4, R7);
                        var S7 = gb.shift();
                        cG = F(dG, 5, S7);
                        var T7 = gb.shift();
                        bG = F(cG, 6, T7);
                        var U7 = new $U,
                            V7 = gb.shift();
                        aG = F(U7, 1, V7);
                        var W7 = gb.shift();
                        $F = F(aG, 2, W7);
                        var X7 = gb.shift();
                        ZF = F($F, 3, X7);
                        var Y7 = gb.shift();
                        YF = F(ZF, 4, Y7);
                        var Z7 = gb.shift();
                        XF = F(YF, 5, Z7);
                        var $7 = gb.shift();
                        WF = F(XF, 6, $7);
                        var a8 = gb.shift();
                        VF = F(WF, 7, a8);
                        var b8 = gb.shift();
                        UF = F(VF, 8, b8);
                        TF = z(bG, 7, UF);
                        var c8 = new ZU,
                            d8 = gb.shift();
                        SF = F(c8, 1, d8);
                        var e8 = gb.shift();
                        RF = F(SF, 2, e8);
                        var f8 = gb.shift();
                        QF = F(RF, 3, f8);
                        PF = z(TF, 8, QF);
                        var g8 = gb.shift();
                        OF = F(PF, 9, g8);
                        var h8 = gb.shift();
                        NF = F(OF, 10, h8);
                        var i8 = gb.shift();
                        let iG = N7 = F(NF, 11, i8);
                        if (Pj.length === 1) var jG = cV(iG);
                        else {
                            var j8 = cV(iG),
                                kG = void 0,
                                lG = void 0,
                                mG = void 0,
                                nG = Pj[1];
                            if (nG.length === 0) throw Error("Cannot decode empty GPC segment string.");
                            let va = HU(nG, 3),
                                na = FU(va.slice(0, 2));
                            if (na < 0 || na > 1) throw Error(`Attempting to decode unknown GPC segment subsection type ${na}.`);
                            mG = na + 1;
                            let jb = FU(va.charAt(2));
                            var k8 = new bV;
                            lG = F(k8, 2, mG);
                            kG = tf(lG, 1, !!jb);
                            jG = z(j8, 2, kG)
                        }
                        let oG = jG,
                            ot = y(oG, aV, 1),
                            pG = y(ot, ZU, 8);
                        E(ot, 5) !== 1 && E(ot, 6) !== 1 && pG ? .j() !== 1 && pG ? .B() !== 1 || (e = !0);
                        var l8 = y(oG, aV, 1);
                        let qG = y(l8, ZU, 8);
                        qG ? .g() !== 1 && qG ? .g() !== 2 || (f = !0);
                        break;
                    case 13:
                        if (Kb.length === 0) throw Error("Cannot decode empty USFL section string.");
                        let $m = HU(Kb, kV),
                            pt = FU($m.slice(0, 6));
                        $m = $m.slice(6);
                        if (pt !== 1) throw Error(`Unable to decode unsupported USFL Section specification version ${pt} - only version 1 is supported.`);
                        let qt = 0,
                            Ya = [];
                        for (let va = 0; va < jV.length; va++) {
                            let na = jV[va];
                            Ya.push(FU($m.slice(qt, qt + na)));
                            qt += na
                        }
                        var m8 = pt,
                            n8 = new iV,
                            o8 = vf(n8, 1, m8),
                            p8 = Ya.shift(),
                            q8 = F(o8, 2, p8),
                            r8 = Ya.shift(),
                            s8 = F(q8, 3, r8),
                            t8 = Ya.shift(),
                            u8 = F(s8, 4, t8),
                            v8 = Ya.shift(),
                            w8 = F(u8, 5, v8),
                            x8 = Ya.shift();
                        var y8 = F(w8, 6, x8);
                        var z8 = new hV,
                            A8 = Ya.shift(),
                            B8 = F(z8, 1, A8),
                            C8 = Ya.shift(),
                            D8 = F(B8, 2, C8),
                            E8 = Ya.shift(),
                            F8 = F(D8, 3, E8),
                            G8 = Ya.shift(),
                            H8 = F(F8, 4, G8),
                            I8 = Ya.shift(),
                            J8 = F(H8, 5, I8),
                            K8 = Ya.shift(),
                            L8 = F(J8, 6, K8),
                            M8 = Ya.shift(),
                            N8 = F(L8, 7, M8),
                            O8 = Ya.shift();
                        var P8 = F(N8, 8, O8);
                        var Q8 = z(y8, 7, P8);
                        var R8 = new gV,
                            S8 = Ya.shift(),
                            T8 = F(R8, 1, S8),
                            U8 = Ya.shift(),
                            V8 = F(T8, 2, U8),
                            W8 = Ya.shift();
                        var X8 = F(V8, 3, W8);
                        var Y8 = z(Q8, 8, X8),
                            Z8 = Ya.shift(),
                            $8 = F(Y8, 9, Z8),
                            a9 = Ya.shift(),
                            b9 = F($8, 10, a9),
                            c9 = Ya.shift(),
                            d9 = F(b9, 11, c9),
                            e9 = Ya.shift();
                        let an = F(d9, 12, e9),
                            rG = y(an, gV, 8);
                        E(an, 5) !== 1 && E(an, 6) !== 1 && rG ? .j() !== 1 && rG ? .B() !== 1 || (e = !0);
                        let sG = y(an, gV, 8) ? .g();
                        sG !== 1 && sG !== 2 || (f = !0)
                }
            }
        }
        return {
            Nn: d,
            Tj: e,
            aj: f
        }
    }
    var V6 = class extends O {
        constructor(a) {
            ({
                timeoutMs: b
            } = {});
            var b;
            super();
            this.caller = new YP(a, "__gppLocator", c => typeof c.__gpp === "function", Q6);
            this.caller.D.set("addEventListener", M6);
            this.caller.C.set("addEventListener", O6);
            this.caller.D.set("removeEventListener", N6);
            this.caller.C.set("removeEventListener", P6);
            this.timeoutMs = b ? ? 500
        }
        g() {
            this.caller.dispose();
            super.g()
        }
        addEventListener(a) {
            var b = pi(() => {
                    a(S6, !0)
                }),
                c = this.timeoutMs === -1 ? void 0 : setTimeout(() => {
                    b()
                }, this.timeoutMs);
            XP(this.caller, "addEventListener", {
                listener: (d, e) => {
                    clearTimeout(c);
                    try {
                        if (d.pingData ? .gppVersion === void 0 || d.pingData.gppVersion === "1" || d.pingData.gppVersion === "1.0") {
                            this.removeEventListener(d.listenerId);
                            var f = {
                                eventName: "signalStatus",
                                data: "ready",
                                pingData: {
                                    internalErrorState: 1,
                                    gppString: "GPP_ERROR_STRING_IS_DEPRECATED_SPEC",
                                    applicableSections: [-1]
                                }
                            }
                        } else Array.isArray(d.pingData.applicableSections) ? f = d : (this.removeEventListener(d.listenerId), f = {
                            eventName: "signalStatus",
                            data: "ready",
                            pingData: {
                                internalErrorState: 2,
                                gppString: "GPP_ERROR_STRING_EXPECTED_APPLICATION_SECTION_ARRAY",
                                applicableSections: [-1]
                            }
                        });
                        a(f, e)
                    } catch {
                        if (d ? .listenerId) try {
                            this.removeEventListener(d.listenerId)
                        } catch {
                            a(T6, !0);
                            return
                        }
                        a(U6, !0)
                    }
                }
            })
        }
        removeEventListener(a) {
            XP(this.caller, "removeEventListener", {
                listener: () => {},
                listenerId: a
            })
        }
    };
    const U6 = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                internalErrorState: 2,
                gppString: "GPP_ERROR_STRING_UNAVAILABLE",
                applicableSections: [-1]
            },
            listenerId: -1
        },
        S6 = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                gppString: "GPP_ERROR_STRING_LISTENER_REGISTRATION_TIMEOUT",
                internalErrorState: 2,
                applicableSections: [-1]
            },
            listenerId: -1
        },
        T6 = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                gppString: "GPP_ERROR_STRING_REMOVE_EVENT_LISTENER_ERROR",
                internalErrorState: 2,
                applicableSections: [-1]
            },
            listenerId: -1
        };

    function W6(a) {
        return !a || a.length === 1 && a[0] === -1
    };

    function X6(a) {
        a = new V6(a);
        if (!VP(a.caller)) return Promise.resolve(null);
        var b = HA(),
            c = MA(b, 35);
        if (c) return Promise.resolve(c);
        var d = new Promise(e => {
            e = {
                resolve: e
            };
            var f = MA(b, 36, []);
            f.push(e);
            NA(b, 36, f)
        });
        c || c === null || (NA(b, 35, null), a.addEventListener(e => {
            if (e.pingData.signalStatus === "ready" || W6(e.pingData.applicableSections)) {
                e = e.pingData;
                NA(b, 35, e);
                for (let f of MA(b, 36, [])) f.resolve(e);
                NA(b, 36, [])
            }
        }));
        return d
    };

    function Y6(a) {
        a = new rQ(a, {
            timeoutMs: -1,
            nd: !0
        });
        if (!nQ(a)) return Promise.resolve(null);
        var b = HA(),
            c = RA(b);
        if (c) return Promise.resolve(c);
        var d = new Promise(e => {
            e = {
                resolve: e
            };
            var f = MA(b, 25, []);
            f.push(e);
            NA(b, 25, f)
        });
        c || c === null || (NA(b, 24, null), a.addEventListener(e => {
            if (hQ(e)) {
                NA(b, 24, e);
                for (let f of MA(b, 25, [])) f.resolve(e);
                NA(b, 25, [])
            } else NA(b, 24, null)
        }));
        return d
    };
    const Z6 = (a, b) => {
            (0, a.__uspapi)("getUSPData", 1, (c, d) => {
                b.Jb({
                    ce: c ? ? void 0,
                    oj: d ? void 0 : 2
                })
            })
        },
        $6 = {
            If: a => a.Jb,
            se: (a, b) => ({
                __uspapiCall: {
                    callId: b,
                    command: "getUSPData",
                    version: 1
                }
            }),
            Ld: (a, b) => {
                b = b.__uspapiReturn;
                a({
                    ce: b.returnValue ? ? void 0,
                    oj: b.success ? void 0 : 2
                })
            }
        };

    function a7(a) {
        a = x(a.data) ? JSON.parse(a.data) : a.data;
        return {
            payload: a,
            ei: a.__uspapiReturn.callId
        }
    }

    function b7(a, b) {
        var c = {};
        if (VP(a.caller)) {
            var d = pi(() => {
                b(c)
            });
            XP(a.caller, "getDataWithCallback", {
                Jb: e => {
                    e.oj || (c = e.ce);
                    d()
                }
            });
            setTimeout(d, a.timeoutMs)
        } else b(c)
    }
    var c7 = class extends O {
        constructor(a) {
            super();
            this.timeoutMs = {}.timeoutMs ? ? 500;
            this.caller = new YP(a, "__uspapiLocator", b => typeof b.__uspapi === "function", a7);
            this.caller.D.set("getDataWithCallback", Z6);
            this.caller.C.set("getDataWithCallback", $6)
        }
        g() {
            this.caller.dispose();
            super.g()
        }
    };

    function d7(a) {
        var b = new c7(a);
        return new Promise(c => {
            b7(b, d => {
                d && x(d.uspString) ? c(d.uspString) : c(null)
            })
        })
    }

    function e7(a, {
        Qn: b,
        Tn: c,
        om: d
    }) {
        var e = new pU;
        var f = U(Nx) ? ef(d, 5) != null ? d.ha() : ef(b, 5) != null ? b.ha() : a.ha() : ef(b, 5) != null ? b.ha() : a.ha();
        e = nU(e, f);
        f = ef(b, 17) != null ? C(b, 17) : C(a, 17);
        e = sf(e, 17, f);
        a = ef(a, 14);
        a = sf(e, 14, a);
        f = ef(b, 3);
        a = sf(a, 3, f);
        f = Fd(ue(b, 2));
        a = Jf(a, 2, f);
        f = Fd(ue(b, 4));
        a = Jf(a, 4, f);
        f = fd(ue(b, 7));
        a = Lf(a, 7, f);
        b = ef(b, 9);
        b = sf(a, 9, b);
        a = Fd(ue(c, 1));
        b = Jf(b, 1, a);
        c = ef(c, 13);
        c = sf(b, 13, c);
        b = Fd(ue(d, 11));
        c = Jf(c, 11, b);
        b = df(d, 10);
        c = Ne(c, 10, b, kd);
        oU(c, ef(d, 12));
        return e
    }
    async function f7(a, {
        Xa: b = !1,
        Cm: c
    }) {
        var [d, e, f] = await Promise.all([Y6(a.pubWin), d7(a.pubWin), X6(a.pubWin)]), g = nU(new pU, !b);
        c = sf(g, 14, c && navigator.globalPrivacyControl);
        c = sf(c, 17, !0);
        g = new pU;
        if (d) {
            var h = nU(g, iQ(d, {
                idpcApplies: b
            }));
            h = Jf(h, 2, d.tcString);
            h = Jf(h, 4, d.addtlConsent || "");
            h = Lf(h, 7, d.internalErrorState);
            var k = !lQ(d);
            h = sf(h, 9, k);
            sf(h, 17, d.gdprApplies ? d.vendor ? d.vendor.disclosedVendors === void 0 ? !0 : kQ(d.vendor.consents, "755") || kQ(d.vendor.legitimateInterests, "755") || kQ(d.vendor.disclosedVendors,
                "755") : !1 : !0);
            d.gdprApplies != null && sf(g, 3, d.gdprApplies)
        }
        h = new pU;
        if (e) {
            k = Jf(h, 1, e);
            var l = e.toUpperCase();
            if (l.length == 4 && (l.indexOf("-") == -1 || l.substring(1) === "---") && l[0] >= "1" && l[0] <= "9" && BU.hasOwnProperty(l[1]) && BU.hasOwnProperty(l[2]) && BU.hasOwnProperty(l[3])) {
                var m = new AU;
                m = vf(m, 1, parseInt(l[0], 10));
                m = F(m, 2, BU[l[1]]);
                m = F(m, 3, BU[l[2]]);
                l = F(m, 4, BU[l[3]])
            } else l = null;
            l = l ? .nm() === 2;
            sf(k, 13, l)
        }
        k = new pU;
        if (f)
            if (f.internalErrorState) Jf(k, 11, f.gppString);
            else if (W6(f.applicableSections)) oU(Ne(k, 10, f.applicableSections,
            kd), !1), U(Nx) && nU(k, !0);
        else if (l = Ne(k, 10, f.applicableSections, kd), Jf(l, 11, f.gppString), U(Nx)) try {
            let q = R6(f.gppString, f.applicableSections, {
                idpcApplies: b,
                supportTcfeu: !0,
                supportUsnatV2: !0
            });
            var n = oU(nU(k, q.Nn), q.Tj);
            sf(n, 16, q.aj)
        } catch (q) {
            AB(1182, q), b = oU(nU(k, !b), !1), sf(b, 16, !1)
        } else try {
            let q = R6(f.gppString, f.applicableSections, {
                idpcApplies: b,
                supportUsnatV2: !0
            });
            var p = oU(k, q.Tj);
            sf(p, 16, q.aj)
        } catch (q) {
            AB(1182, q), b = oU(k, !1), sf(b, 16, !1)
        }
        a.R = e7(c, {
            Qn: g,
            Tn: h,
            om: k
        })
    };
    var g7 = Tg(class extends I {
        g() {
            return C(this, 1)
        }
    });
    async function h7(a) {
        var b = Ul(),
            c = a.pageState;
        PB(f => {
            E(f, 1) === 0 && (f = tf(f, 2, !!c.OSCLM.UWEfJ), f = tf(f, 6, !!c.OmOVT), F(f, 1, 1))
        });
        OW(a.pubWin, i7(c.OSCLM));
        j7(a.I.google_ad_client);
        PB(f => {
            E(f, 1) === 1 && F(f, 1, 2)
        });
        var d = new eQ(a.pubWin);
        await (bQ(d, (c.SLqBY || "") === ".google.cn") ? cQ(d) : Promise.resolve(null));
        PB(f => {
            E(f, 1) === 2 && (f = tf(f, 3, !0), F(f, 1, 3))
        });
        await f7(a, {
            Xa: c.OSCLM.UWEfJ,
            Cm: c.OSCLM.YguOd
        });
        var e = Ul();
        PB(f => {
            if (E(f, 1) === 3) {
                f = tf(f, 3, e - b > 500);
                var g = !!a.R ? .g();
                f = tf(f, 4, g);
                g = !!a.R ? .ha();
                f = tf(f, 5, g);
                g = !!a.R ? .j();
                f = tf(f, 7, g);
                g = !!a.R ? .B();
                f = tf(f, 8, g);
                F(f, 1, 4)
            }
        })
    }

    function i7(a) {
        var b = og(g7());
        b = sf(b, 1, a.UWEfJ);
        b = sf(b, 2, a.YguOd);
        a = sf(b, 3, a.SVQEK);
        return oe(a)
    }

    function j7(a) {
        var b = kl(t.top, "googlefcPresent");
        t.googlefc && !b && zB("adsense_fc_has_namespace_but_no_iframes", {
            publisherId: a
        }, 1)
    };
    var k7 = Q1(async function(a) {
        return h7(a.He)
    }, {
        id: 1404
    });

    function l7(a) {
        var b = RegExp("^https?://[^/#?]+/?$");
        return !!a && !b.test(a)
    }

    function m7(a) {
        if (a === a.top || Ik(a.top)) return Promise.resolve({
            status: 4
        });
        a: {
            try {
                var b = (a.top ? .frames ? ? {}).google_ads_top_frame;
                break a
            } catch (d) {}
            b = null
        }
        if (!b) return Promise.resolve({
            status: 2
        });
        if (a.parent === a.top && l7(a.document.referrer)) return Promise.resolve({
            status: 3
        });
        var c = new $W;
        a = new MessageChannel;
        a.port1.onmessage = d => {
            d.data.msgType === "__goog_top_url_resp" && c.resolve({
                Kc: d.data.topUrl,
                status: d.data.topUrl ? 0 : 1
            })
        };
        b.postMessage({
            msgType: "__goog_top_url_req"
        }, "*", [a.port2]);
        return c.promise
    };

    function n7(a) {
        var b = Ul();
        return Promise.race([m7(a), vl(200)]).then(c => {
            zB("afc_etu", {
                etus: c ? .status ? ? 100,
                sig: Ul() - b,
                tms: 200
            });
            return c ? .Kc
        })
    }
    var o7 = Q1(async function(a, b) {
        return n7(b)
    }, {
        id: 1411
    });
    var p7 = Y(function(a, b, c, d) {
        a = 0;
        Mk(b) !== b && (a |= 4);
        EY(b.document) === 3 && (a |= 32);
        var e;
        if (e = c) e = ks(c), e = !(ps(c).scrollWidth <= e);
        e && (a |= 1024);
        b.Prototype ? .Version && (a |= 16384);
        d && (a |= d);
        return {
            qf: a
        }
    }, {
        id: 1379,
        H: {
            qf: void 0
        }
    });
    var q7 = Y(function(a) {
        var b = a.He;
        b.Kc = a.Kc || "";
        return {
            Jn: b
        }
    }, {
        id: 1406,
        H: {
            Jn: void 0
        }
    });

    function r7(a, b, c, d) {
        var e = new $W,
            f = "",
            g = k => {
                try {
                    let l = typeof k.data === "object" ? k.data : JSON.parse(k.data);
                    f === l.paw_id && (Zj(a, "message", g), l.error ? e.reject(Error(l.error)) : e.resolve(d(l)))
                } catch (l) {}
            };
        var h = typeof a.gmaSdk ? .getQueryInfo === "function" ? a.gmaSdk : void 0;
        if (h) return Yj(a, "message", g), f = c(h), e.promise;
        c = typeof a.webkit ? .messageHandlers ? .getGmaQueryInfo ? .postMessage === "function" || typeof a.webkit ? .messageHandlers ? .getGmaSig ? .postMessage === "function" ? a.webkit.messageHandlers : void 0;
        return c ?
            (f = String(Math.floor(Uk() * 2147483647)), Yj(a, "message", g), b(c, f), e.promise) : null
    }

    function s7(a) {
        return r7(a, (b, c) => void(b.getGmaQueryInfo ? ? b.getGmaSig) ? .postMessage(c), b => b.getQueryInfo(), b => b.signal)
    }(function(a) {
        return nc(b => {
            if (!rc(b)) return !1;
            for (let [c, d] of Object.entries(a)) {
                let e = c,
                    f = d;
                if (!(e in b)) {
                    if (f.Fm === !0) continue;
                    return !1
                }
                if (!f(b[e])) return !1
            }
            return !0
        })
    })({
        vc: x,
        pn: x,
        eid: sc(),
        vnm: sc(),
        js: x
    }, "RawGmaSdkStaticSignalObject");

    function f9(a) {
        var b = V(Lv);
        if (b <= 0) return null;
        var c = Ul(),
            d = s7(a.pubWin);
        if (!d) return null;
        a.l = "0";
        return Promise.race([d, vl(b, "0")]).then(e => {
            zB("adsense_paw", {
                time: Ul() - c
            });
            e ? .length > 1E4 ? AB(809, Error(`ML:${e.length}`)) : a.l = e
        }).catch(e => {
            AB(809, e)
        })
    }
    var g9 = Q1(async function(a) {
        return f9(a.He)
    }, {
        id: 1405
    });
    var h9 = class extends W1 {
        constructor(a, b, c, d) {
            super(a);
            var e = b.I.google_loader_features_used;
            e = Z(this, p7, {}, b.pubWin, b.K, e ? e : null);
            d && X(e, d);
            ({
                tk: e
            } = Z(this, L6, {
                qf: e.qf
            }, b));
            var f = T1(this, k7, {
                    He: e
                }),
                g = T1(this, o7, {}, b.pubWin);
            X(g, f.complete);
            d = T1(this, g9, {
                He: e
            });
            X(d, f.complete);
            e = Z(this, q7, {
                He: e,
                Kc: g.output
            });
            X(e, d.complete);
            this.j = U1(this, new K6(a, b, e.finished, c)).j
        }
    };
    var i9 = Y(function(a, b) {
        m0(13, b);
        m0(11, b);
        return {}
    }, {
        id: 1486,
        H: {}
    });
    var j9 = Y(function(a, b, c) {
        b.googFloatingToolbarManagerAsyncPositionUpdate = !0;
        c && c !== b && (c.googFloatingToolbarManagerAsyncPositionUpdate = !0);
        return {}
    }, {
        id: 1483,
        H: {}
    });
    var k9 = Y(function() {
        return or() || Ta() ? {
            Ha: !0,
            Jg: new LZ
        } : {
            Ha: new LZ,
            Jg: !0
        }
    }, {
        id: 1502,
        H: {
            Ha: void 0,
            Jg: void 0
        }
    });

    function l9() {
        if (!t.IntersectionObserver) return {
            hidden: 0,
            visible: -1
        };
        var a = V(Pv),
            b = V(Qv);
        return {
            hidden: 0,
            visible: Nk() ? a : b
        }
    };
    var m9 = Y(function(a, b) {
        var c = b.ca,
            d = b.I;
        a = b.pubWin;
        b = b.K;
        var e = l9().visible;
        if (!c || e < 0 || !rs(d.google_reactive_ad_format) && (qZ(d) || d.google_reactive_ads_config) || !pY(c) || rY(b, a, c) <= e) return {
            Ha: !0,
            Ke: new LZ
        };
        b = HA();
        c = MA(b, 8, {});
        b = MA(b, 9, {});
        d = d.google_ad_section || d.google_ad_region || "";
        a = !!a.google_apltlad;
        return c[d] || b[d] || a ? {
            Ha: new LZ,
            Ke: !0
        } : {
            Ha: !0,
            Ke: new LZ
        }
    }, {
        id: 1499,
        H: {
            Ha: void 0,
            Ke: void 0
        }
    });
    var n9 = Y(function(a, b, c) {
        a = l9();
        return a.hidden < 0 && a.visible < 0 || !c ? {
            Ha: !0,
            Lg: new LZ
        } : {
            Ha: new LZ,
            Lg: !0
        }
    }, {
        id: 1491,
        H: {
            Ha: void 0,
            Lg: void 0
        }
    });
    var o9 = Y(function(a) {
        return a.result
    }, {
        id: 1498,
        H: {
            Sb: void 0,
            Kg: void 0
        }
    });
    var p9 = Y(function(a) {
        return a.result
    }, {
        id: 1496,
        H: {
            Sb: void 0,
            Ha: void 0
        }
    });
    var q9 = Q1(async function(a, b, c) {
        c.notify();
        return new Promise(d => {
            b.ca.addEventListener("adsbygoogle-close-to-visible-event", () => {
                d(!0)
            })
        })
    }, {
        id: 1501
    });
    var r9 = Q1(async function(a, b, c) {
        c.notify();
        return new Promise(d => {
            var e = b.ca,
                f = l9().visible;
            f = new t.IntersectionObserver((g, h) => {
                ab(g, k => {
                    k.intersectionRatio <= 0 || (h.unobserve(k.target), d(!0))
                })
            }, {
                rootMargin: `${f*100}%`
            });
            b.A = f;
            f.observe(e)
        })
    }, {
        id: 1500
    });
    var s9 = Q1(async function(a, b, c) {
        var d = b.pubWin.document,
            e = EY(d) === 3;
        return new Promise(f => {
            e ? (c.notify(), GY(xB(332, () => {
                f({
                    Sb: !0,
                    Kg: new LZ
                })
            }), d)) : f({
                Sb: new LZ,
                Kg: !0
            })
        })
    }, {
        id: 1494
    });
    var t9 = Q1(async function(a, b, c) {
        var d = b.I,
            e = b.pubWin;
        if (!d.google_pause_ad_requests) return !0;
        c.notify();
        var f = t.setTimeout(() => {
            zB("abg:cmppar", {
                client: d.google_ad_client,
                url: d.google_page_url
            })
        }, 1E4);
        return new Promise(g => {
            var h = xB(450, () => {
                d.google_pause_ad_requests = !1;
                t.clearTimeout(f);
                e.removeEventListener("adsbygoogle-pub-unpause-ad-requests-event", h);
                g(!0)
            });
            e.addEventListener("adsbygoogle-pub-unpause-ad-requests-event", h)
        })
    }, {
        id: 1492
    });
    var u9 = Q1(async function(a, b, c, d) {
        return new Promise(e => {
            var f = b.pubWin,
                g = b.K,
                h = b.ca,
                k = f.document;
            if (FY(k))
                if (rY(g, f, h) <= l9().hidden) e({
                    Sb: new LZ,
                    Ha: !0
                });
                else {
                    var l = xB(332, () => {
                        !FY(k) && l && (Zj(k, d, l), e({
                            Sb: !0,
                            Ha: new LZ
                        }), l = null)
                    });
                    Yj(k, d, l) ? c.notify() : e({
                        Sb: new LZ,
                        Ha: !0
                    })
                }
            else e({
                Sb: !0,
                Ha: new LZ
            })
        })
    }, {
        id: 1493
    });
    var v9 = class extends W1 {
        constructor(a, b, c) {
            super(a);
            this.j = new WZ;
            a = X(Z(this, k9, {}), c);
            c = X(T1(this, t9, {}, b, this.j), a.Jg);
            c = X(T1(this, s9, {}, b, this.j), c.output);
            var d = Z(this, o9, {
                result: c.output
            });
            c = b.pubWin.document;
            var e;
            c.visibilityState ? e = "visibilitychange" : c.mozVisibilityState ? e = "mozvisibilitychange" : c.webkitVisibilityState && (e = "webkitvisibilitychange");
            c = e;
            e = X(Z(this, n9, {}, b, c), d.Kg);
            c = X(T1(this, u9, {}, b, this.j, c), e.Lg);
            c = Z(this, p9, {
                result: c.output
            });
            d = new XZ([d.Sb, c.Sb]);
            d = X(Z(this, m9, {}, b), d);
            var f = X(T1(this, r9, {}, b, this.j), d.Ke);
            b = X(T1(this, q9, {}, b, this.j), d.Ke);
            b = new XZ([f.output, b.output]);
            this.fi = new XZ([a.Ha, e.Ha, d.Ha, c.Ha, b])
        }
    };
    var w9 = Y(function(a, b, c, d) {
        var e = HA(),
            f = MA(e, 23, !1);
        f || NA(e, 23, !0);
        if (!f) {
            a = a.km;
            try {
                var g = a ? JK(a) : null
            } catch (h) {
                g = null
            }
            b = new xU(b, d.google_ad_client, g, !!c.OSCLM ? .UWEfJ, c.OmOVT);
            b.j = !0;
            c = b.B;
            if (b.j && (d = b.g, b.l && !FP(c) ? (g = new kU, g = Lf(g, 1, 1)) : g = null, g)) {
                g = pg(g);
                try {
                    d.localStorage.setItem("google_auto_fc_cmp_setting", g)
                } catch (h) {}
            }
            d = FP(c) && (b.l || b.C);
            c && d && IP(new JP(b.g, new uQ(b.g, b.A), c, new ED(b.g)))
        }
        return {}
    }, {
        id: 1485,
        H: {}
    });
    var x9 = Y(function(a, b) {
        a = a.zb;
        b.zb = a;
        return {
            zb: a
        }
    }, {
        id: 1484,
        H: {
            zb: void 0
        }
    });
    var y9 = Y(function(a, b, c) {
        a = c.google_tag_partner;
        b = (a ? [a] : []).concat(eB(b).tag_partners || []).join("+");
        c.google_tag_partner = b;
        return {}
    }, {
        id: 1444,
        H: {}
    });
    var z9 = Y(function(a, b, c) {
        b && gZ(b, gi(c.Il, new Map(Object.entries(DY()))));
        return {}
    }, {
        id: 1447,
        H: {}
    });
    var A9 = Y(function(a, b) {
        a = b.I;
        a.google_ad_output == null && (a.google_ad_output = "html");
        a.google_ad_client != null && (a.google_ad_client = Br(String(a.google_ad_client)));
        a.google_ad_slot != null && (a.google_ad_slot = String(a.google_ad_slot));
        a.google_ad_section = a.google_ad_section || a.google_ad_region || "";
        a.google_country = a.google_country || a.google_gl || "";
        var c = (new Date).getTime(),
            d = "google_color_bg google_color_text google_color_link google_color_url google_color_border google_color_line".split(" ");
        for (let f of d)
            if (Array.isArray(a[f])) {
                d =
                    b;
                var e = a[f];
                d.j |= 2;
                a[f] = e[c % e.length]
            }
        return {}
    }, {
        id: 1446,
        H: {}
    });
    var B9 = Y(function(a, b, c, d, e, f) {
        wB(326, () => {
            if (yr(d) === 1) {
                var g = U(ey);
                if ((g || U(dy)) && b === c) {
                    var h = new El;
                    let m = new Fl;
                    var k = h.setCorrelator(ul(b));
                    var l = n0(b);
                    k = Kf(k, 5, l);
                    F(k, 2, 1);
                    h = z(m, 1, h);
                    k = new Dl;
                    k = tf(k, 10, !0);
                    l = U(Zx);
                    k = tf(k, 8, l);
                    l = U($x);
                    k = tf(k, 12, l);
                    l = U(cy);
                    k = tf(k, 7, l);
                    l = U(by);
                    k = tf(k, 13, l);
                    z(h, 2, k);
                    b.google_rum_config = Zd(m);
                    Zk(b.document, f.xujKL && g ? e.sn : e.un)
                } else am(uB)
            }
        });
        return {}
    }, {
        id: 1443,
        H: {}
    });
    var C9 = Y(function(a, b, c) {
        if (!b || eB(b).ads_density_stats_processed || or(b)) return {};
        eB(b).ads_density_stats_processed = !0;
        if (U(Bw) || Uk() < .01) {
            let d = () => {
                if (b) {
                    var e = TS(OS(b), c.google_ad_client, b.location.hostname, n0(c).split(","));
                    zB("ama_stats", e, 1)
                }
            };
            ak(b, () => {
                t.setTimeout(d, 1E3)
            })
        }
        return {}
    }, {
        id: 1445,
        H: {}
    });
    var D9 = Y(function(a, b) {
        qZ(b) && (yY() && (b.google_adtest = b.google_adtest || "on"), b.google_pgb_reactive = b.google_pgb_reactive || 3);
        return {}
    }, {
        id: 1448,
        H: {}
    });
    var E9 = Y(function(a, b) {
        a = b.google_start_time;
        oc(a) && (Cr = a, b.google_start_time = null);
        return {}
    }, {
        id: 1463,
        H: {}
    });
    var F9 = class extends W1 {
        constructor(a, b, c) {
            super(a);
            this.j = new WZ;
            var d = c.zb;
            c = c.fi;
            var e = Z(this, B9, {}, b.pubWin, b.K, b.I, b.Na, b.pageState);
            c && X(e, c);
            c = X(Z(this, y9, {}, b.pubWin, b.I), e.finished);
            c = X(Z(this, C9, {}, b.K, b.I), c.finished);
            c = X(Z(this, E9, {}, b.I), c.finished);
            c = X(Z(this, A9, {}, b), c.finished);
            c = X(Z(this, z9, {}, b.K, b.Na), c.finished);
            c = X(Z(this, D9, {}, b.I), c.finished);
            this.j = U1(this, new h9(a, b, d, c.finished)).j
        }
    };
    var G9 = class extends W1 {
        constructor(a, b, c) {
            super(a);
            this.j = new SZ;
            if (/_sdo/.test(b.I.google_ad_format)) NZ(this.j, null);
            else {
                var d = Z(this, i9, {}, b.pubWin);
                X(d, c);
                var e = new SZ;
                c = new SZ;
                RZ(e, b.pageState.EGzMj);
                RZ(c, b.pageState.tYcft);
                d = X(Z(this, x9, {
                    zb: e
                }, b), d.finished);
                c = X(Z(this, w9, {
                    km: c
                }, b.pubWin, b.pageState, b.I), d.finished);
                c = X(Z(this, j9, {}, b.pubWin, b.K), c.finished);
                c = U1(this, new v9(a, b, c.finished));
                a = U1(this, new F9(a, b, {
                    zb: d.zb,
                    fi: c.fi
                }));
                this.j = new XZ([c.j, a.j], !0)
            }
        }
    };
    var H9 = Y(function(a, b, c, d, e, f) {
        var g = a.Ib,
            h = a.Ob,
            k = d(b, c.stavq, c.jTCuI, c.xVQAt || "");
        f.google_sa_impl = l => e({
            Na: k,
            Sc: b,
            slot: l,
            pageState: c,
            Ib: g,
            Ob: h
        });
        f.google_process_slots ? .();
        return {}
    }, {
        id: 1338,
        H: {}
    });
    var I9 = Y(function(a, b) {
        a = (b.Prototype || {}).Version;
        a != null && zB("prtpjs", {
            version: a
        });
        return {}
    }, {
        id: 1339,
        H: {}
    });
    var J9 = class extends C0 {
        constructor(a) {
            super();
            this.promise = a;
            a.then(b => {
                this.value = b
            })
        }
        j() {
            return Promise.race([this.promise, vl(V(lv), null)]).then(a => {
                this.value = a
            })
        }
    };
    var K9 = Y(function() {
        return U(Bv) ? {
            Ib: new J9(navigator.getBattery ? .() ? ? Promise.resolve(null))
        } : {
            Ib: new J9(Promise.resolve(null))
        }
    }, {
        id: 1413,
        H: {
            Ib: void 0
        }
    });
    var L9 = fi `https://pagead2.googlesyndication.com/pagead/s/eeframe.html`;
    var M9 = Y(function(a) {
        var b = !1,
            c = !1;
        for (let d of rk(a.Fe)) Of(d, 5) && (c = !0, C(d, 4) && (b = !0));
        if (!b && !a.R.ha() || !c) return {
            L: void 0
        };
        a = document.createElement("iframe");
        a.name = "goog_ee_frame";
        a.style.display = "none";
        Ii(a, L9);
        document.documentElement.appendChild(a);
        return {
            L: a
        }
    }, {
        id: 1389,
        H: {
            L: void 0
        }
    });
    var N9 = Y(function(a) {
        return (a = a.Bn) ? {
            Be: rk(a).map(b => {
                var c = Of(b, 2) ? D(b, Be(b, Pf, 2)) : D(b, Be(b, Pf, 5)),
                    d = b.hb();
                c = c && (c.startsWith(location.protocol) || c.startsWith("data:") && c.length <= 80) ? Sh(c === null ? "null" : c === void 0 ? "undefined" : c) : void 0;
                return {
                    Bl: d,
                    url: c,
                    Bm: C(b, 4),
                    Am: Of(b, 5)
                }
            })
        } : {
            Be: []
        }
    }, {
        id: 1040,
        H: {
            Be: void 0
        }
    });
    var P9 = Y(O9, {
        id: 1041,
        H: {}
    });

    function O9(a, b, c) {
        if (!a.U) return {};
        B_().set(a.U, a.R, b) && a.U.g() && x_(27, a.U.hb(), null, {}, c);
        return {}
    };
    var Q9 = Y(function(a) {
        return E_(a.U) !== 0 ? {
            U: a.U
        } : {
            U: new LZ
        }
    }, {
        id: 1036,
        H: {
            U: void 0
        }
    });

    function R9() {
        return t.googletag ? ? (t.googletag = {
            cmd: []
        })
    };

    function S9(a, b) {
        a.g() && (b = gi(b, {
            gdpr: "1"
        }));
        var c = D(a, 2);
        c && (b = gi(b, {
            gdpr_consent: c
        }));
        (c = D(a, 11)) && (b = gi(b, {
            gpp: c
        }));
        (a = df(a, 10).map(d => d.toString()).join(",")) && (b = gi(b, {
            gpp_sid: a
        }));
        return b.toString()
    }
    var T9 = Q1(async function(a, b, c, d) {
        if (c) {
            var e = a.U.hb();
            b = S9(a.R, b);
            x_(59, e, null, {
                url: b
            }, d);
            var f = (new URL(L9.toString())).origin;
            c = oX({
                destination: window,
                L: c,
                origin: f,
                Qb: "echo-endpoint-channel"
            });
            var {
                data: g
            } = await c.j({
                id: e,
                url: b
            });
            switch (g.kind) {
                case 0:
                    R9().secureSignalProviders ? .push({
                        id: e,
                        collectorFunction: () => Promise.resolve(g.data)
                    });
                    break;
                case 1:
                    return x_(60, e, g.error, {}, d), a.U.setError(xk(114));
                default:
                    Qc(g, void 0)
            }
        }
    }, {
        id: 1391
    });
    var U9 = Q1(async function(a, b, c, d) {
        var e = a.U.hb(),
            f = b.toString();
        x_(30, e, null, {
            url: f
        }, d);
        var g = document.createElement("script");
        g.setAttribute("esp-signal", "true");
        Ki(g, b);
        var {
            promise: h,
            resolve: k
        } = ja(Promise, "withResolvers").call(Promise), l = () => {
            x_(31, e, null, {
                url: f
            }, d);
            k(a.U.setError(xk(109)));
            Zj(g, "error", l)
        };
        document.head.appendChild(g);
        Yj(g, "error", l);
        return h
    }, {
        id: 1035
    });
    var V9 = Y(function(a, b, c, d, e, f) {
        ({
            U: a
        } = B_().get(b, d, c, f));
        if (a) return {
            Za: a,
            La: new LZ("CACHED_ENTRY")
        };
        a = Bk(zk(b));
        return {
            Za: a,
            La: a.setError(xk(100))
        }
    }, {
        id: 1027,
        H: {
            Za: void 0,
            La: void 0
        }
    });
    var X9 = Y(W9, {
        id: 1028,
        H: {
            bb: void 0
        }
    });

    function W9(a, b) {
        var c = a.U.hb();
        bf(a.U, 3) != null || x_(35, c, null, {}, b);
        return {
            bb: a.U
        }
    };
    var Y9 = class extends W1 {
        constructor(a, b, c, d, e, f, g, h) {
            super(g);
            var k = Z(this, V9, {}, a, c, f, g, h);
            S1(this, k);
            a = new SZ;
            NZ(a, f);
            Z(this, P9, {
                U: k.La,
                R: a
            }, c, h);
            f = Z(this, Q9, {
                U: k.Za
            });
            f = Z(this, X9, {
                U: f.U
            }, h);
            d ? {
                output: b
            } = T1(this, T9, {
                U: f.bb,
                R: a
            }, b, e, h) : {
                output: b
            } = T1(this, U9, {
                U: f.bb
            }, b, g, h);
            Z(this, P9, {
                U: b,
                R: a
            }, c, h)
        }
    };
    var Z9 = new Set,
        $9 = Y(function(a, b, c, d, e) {
            var f = a.Be;
            c = a.Rb;
            a = a.Ul;
            if (!f ? .length) return {};
            var g = c.ha();
            for (let {
                    Bl: h,
                    url: k,
                    Bm: l,
                    Am: m
                } of f) {
                if (!k || !g && !l || Z9.has(k.toString())) continue;
                Z9.add(k.toString());
                f = new Y9(h, k, l, m, a, c, b, e);
                wt(d, f);
                V1(f)
            }
            return {}
        }, {
            id: 813,
            H: {}
        });
    var a$ = class extends W1 {
        constructor(a, b, c, d) {
            super(a);
            this.l = b;
            this.j = c;
            ({
                L: b
            } = Z(this, M9, {
                R: this.j,
                Fe: this.l
            }));
            ({
                Be: c
            } = Z(this, N9, {
                Bn: this.l
            }));
            Z(this, $9, {
                Be: c,
                Rb: this.j,
                Ul: b
            }, a, {}, this, d)
        }
    };
    var b$ = Y(function(a) {
        var b = a.R;
        if (a = a.bd)
            for (var c of a)
                for (let d of rk(c)) C(d, 4) && F_(B_(), d.hb(), b, !0);
        if (b.ha()) {
            if (b) {
                c = u_(b) ? ? [];
                for (let d of c) d.startsWith("_GESPSK") && o_(d, b)
            }
            C_ = new D_
        }
        return {}
    }, {
        id: 1094,
        H: {}
    });
    var c$ = Y(function(a, b, c) {
        var d = a.U;
        a = e => {
            x_(e, d.hb(), null, {
                tic: String(Math.round((Date.now() - LH(cf(d, 3))) / 6E4))
            }, c)
        };
        switch (E_(d)) {
            case 0:
                return a(24), {
                    mc: new LZ("FRESH_ENTRY"),
                    Hc: new LZ("FRESH_ENTRY")
                };
            case 1:
                return a(25), {
                    mc: new LZ("STALE_ENTRY"),
                    Hc: d
                };
            case 2:
                return a(26), {
                    mc: d,
                    Hc: new LZ("EXPIRED_ENTRY")
                };
            case 3:
                return x_(9, d.hb(), null, {}, c), {
                    mc: d,
                    Hc: new LZ("ERROR_ENTRY")
                };
            case 4:
                return a(23), {
                    mc: d,
                    Hc: new LZ("NEW_ENTRY")
                };
            default:
                return {
                    mc: new LZ("DEFAULT_ENTRY"),
                    Hc: new LZ("DEFAULT_ENTRY")
                }
        }
    }, {
        id: 1048,
        H: {
            mc: void 0,
            Hc: void 0
        }
    });
    var e$ = Y(d$, {
        id: 1046,
        H: {
            bb: void 0
        }
    });

    function d$(a) {
        return {
            bb: a.Za
        }
    };
    var f$ = Y(function(a) {
        var b = a.Ti;
        a = a.U;
        return b.La ? {
            zi: a.setError(b.La),
            Za: new LZ,
            signal: new LZ
        } : {
            Za: b.Za,
            zi: new LZ,
            signal: b.signal
        }
    }, {
        id: 1479,
        H: {
            Za: void 0,
            zi: void 0,
            signal: void 0
        }
    });

    function g$(a) {
        return x(a) ? a : a instanceof Error ? a.message : null
    }
    var h$ = Q1(async function(a, b, c) {
        var d = Ul(),
            e = Fd(ue(a.U, 1));
        x_(18, e, null, {}, c);
        try {
            return b().then(f => {
                x_(29, e, null, {
                    delta: String(Ul() - d)
                }, c);
                return {
                    Za: Jf(a.U, 2, f),
                    La: null,
                    signal: f
                }
            }).catch(f => {
                x_(28, e, g$(f), {}, c);
                return {
                    Za: null,
                    La: xk(106),
                    signal: null
                }
            })
        } catch (f) {
            return x_(1, e, g$(f), {}, c), {
                Za: null,
                La: xk(107),
                signal: null
            }
        }
    }, {
        id: 1478
    });
    var j$ = Y(i$, {
        id: 1050,
        H: {
            bb: void 0
        }
    });

    function i$(a, b, c) {
        var d = a.U.hb();
        if (a.signal == null) return x_(41, d, null, {}, c), a.U.setError(xk(111)), {
            bb: a.U
        };
        if (!x(a.signal)) return x_(21, d, null, {}, c), {
            bb: a.U.setError(xk(113))
        };
        if (a.signal.length > b) return x_(12, d, null, {
            sl: String(a.signal.length)
        }, c), b = a.U.setError(xk(108)), we(b, 2), {
            bb: a.U
        };
        a.signal.length || x_(20, d, null, {}, c);
        we(a.U, 10);
        return {
            bb: a.U
        }
    };
    var k$ = class {
        constructor(a, b) {
            this.output = new WZ;
            VZ(this.output, a, c => void b.Ja({
                methodName: 1046,
                eb: c
            }))
        }
    };
    var l$ = class extends k$ {};
    var m$ = class extends W1 {
        constructor(a, b, c, d, e, f) {
            super(e);
            this.j = new SZ;
            var g = Z(this, V9, {}, a, b, d, e),
                h = new SZ;
            NZ(h, d);
            Z(this, P9, {
                U: g.La,
                R: h
            }, b, f);
            d = Z(this, X9, {
                U: g.Za
            }, f);
            g = Z(this, c$, {
                U: d.bb
            }, e, f);
            d = T1(this, h$, {
                U: g.mc
            }, c, f);
            var {
                signal: k,
                Za: l,
                zi: m
            } = Z(this, f$, {
                Ti: d.output,
                U: g.mc
            });
            Z(this, P9, {
                U: m,
                R: h
            }, b, f);
            d = Z(this, j$, {
                U: l,
                signal: k
            }, 1024, f);
            Z(this, P9, {
                U: d.bb,
                R: h
            }, b, f);
            e = new l$(z_(), e);
            e = X(Z(this, e$, {
                Za: g.Hc
            }), e.output);
            c = T1(this, h$, {
                U: e.bb
            }, c, f);
            ({
                Za: c
            } = Z(this, f$, {
                Ti: c.output,
                U: e.bb
            }));
            Z(this, P9, {
                U: c,
                R: h
            }, b, f);
            b = d.bb.promise.then(n => ({
                id: a,
                collectorGeneratedData: n ? .j() ? ? null
            })).catch(() => ({
                id: a,
                collectorGeneratedData: null
            }));
            RZ(this.j, b)
        }
    };
    var n$ = Q1(async function(a, b, c, d, e) {
        var f = new K_(a.Zf ? ? []),
            g = a.Db.id;
        d = a.Db.collectorFunction;
        var h = a.Db.networkCode ? ? g;
        f = !!g && !!H_(f, g);
        if (!a.R.ha() && !f) return new LZ("Storage consent not granted.");
        x_(42, h, null, {
            ea: String(Number(b))
        }, e);
        a = new m$(h, f, d, a.R, c, e);
        V1(a);
        return a.j.promise
    }, {
        id: 1059
    });
    var o$ = Y(function(a, b, c, d = i_, e) {
        if (!b) return x_(39, "UNKNOWN_COLLECTOR_ID", null, {}, e), {
            La: zk("UNKNOWN_COLLECTOR_ID").setError(xk(110)),
            Db: new LZ
        };
        if (typeof b !== "object") return x_(46, "UNKNOWN_COLLECTOR_ID", null, {}, e), {
            La: zk("UNKNOWN_COLLECTOR_ID").setError(xk(112)),
            Db: new LZ
        };
        a = b.id;
        c = b.networkCode;
        a && c && (delete b.id, x_(47, `${a};${c}`, null, {}, e));
        a = c ? ? a;
        return x(a) ? typeof b.collectorFunction !== "function" ? (x_(14, a, null, {}, e), {
            La: zk(a).setError(xk(105)),
            Db: new LZ
        }) : d.ij.includes(a) ? (x_(22, a, null, {}, e), {
            La: zk(a).setError(xk(104)),
            Db: new LZ
        }) : {
            La: null,
            Db: b
        } : (x_(37, "INVALID_COLLECTOR_ID", null, {
            ii: JSON.stringify(a)
        }, e), {
            La: zk("INVALID_COLLECTOR_ID").setError(xk(102)),
            Db: new LZ
        })
    }, {
        id: 1057,
        H: {
            La: void 0,
            Db: void 0
        }
    });

    function p$(a, b) {
        a.g.g.push(b)
    }
    var r$ = class {
        constructor(a, b, c, d = document, e, f, g = i_, h) {
            this.B = b;
            this.J = c;
            this.C = d;
            this.P = e;
            this.D = f;
            this.l = g;
            this.j = h;
            this.G = [];
            this.O = [];
            this.g = new q$;
            this.A = 0;
            for (let k of a) this.push(k)
        }
        push(a) {
            this.J || this.P();
            var b = new W1(this.g);
            a = Z(b, o$, {}, a, this.g, this.l, this.j);
            var c = a.Db;
            Z(b, P9, {
                U: a.La,
                R: this.B
            }, void 0, this.j);
            a = T1(b, n$, {
                Db: c,
                R: this.B,
                Zf: void 0
            }, this.J, this.g, this.l, this.j).output.promise;
            V1(b);
            this.G.push(a);
            for (let d of this.O) a.then(d)
        }
        addOnSignalResolveCallback(a) {
            this.O.push(a);
            for (let b of this.G) b.then(a)
        }
        clearAllCache() {
            var a =
                this.C.currentScript instanceof HTMLScriptElement ? this.C.currentScript.src : "";
            if (this.A === 1) x_(49, "", null, {
                url: a
            }, this.j);
            else if (this.l.cj.includes(String(Uu(a ? ? "")))) x_(48, "", null, {
                url: a
            }, this.j);
            else {
                this.D && this.D();
                var b = new W1(this.g),
                    c = Z(b, b$, {
                        R: this.B,
                        bd: void 0
                    }, this.g);
                V1(b);
                this.A = 1;
                setTimeout(() => {
                    this.A = 0
                }, this.l.Vi * 1E3);
                x_(43, "", null, {
                    url: a
                }, this.j);
                return c.finished.promise
            }
        }
    };
    class q$ {
        constructor() {
            this.g = []
        }
        Ja(a) {
            this.g.forEach(b => void b.Ja(a))
        }
    }
    var s$ = class {
        constructor(a) {
            this.push = b => {
                a.push(b)
            };
            this.addOnSignalResolveCallback = b => {
                a.addOnSignalResolveCallback(b)
            };
            this.addErrorHandler = b => {
                p$(a, {
                    Ja: ({
                        methodName: c,
                        eb: d
                    }) => void b(c, d)
                })
            };
            this.clearAllCache = () => {
                a.clearAllCache()
            }
        }
    };

    function t$(a, b, c, d, e, f = i_, g) {
        if (!u$(a, "encryptedSignalProviders", c) || !u$(a, "secureSignalProviders", c)) {
            x_(38, "", null, {}, g);
            var h = {
                Ja: ({
                    methodName: k,
                    eb: l
                }) => void c(k, l)
            };
            v$(a, "encryptedSignalProviders", b, f, h, d, e, g);
            v$(a, "secureSignalProviders", b, f, h, () => {}, e, g)
        }
    }

    function u$(a, b, c) {
        if (a[b] === void 0 || a[b] instanceof Array) return !1;
        a[b].addErrorHandler(c);
        return !0
    }

    function v$(a, b, c, d, e, f, g, h) {
        c = new r$(a[b] ? ? [], c, b === "secureSignalProviders", document, f, g, d, h);
        a[b] = new s$(c);
        p$(c, e)
    }

    function w$(a, b, c, d, e, f = i_, g) {
        var h = new SZ;
        NZ(h, b);
        t$(a, h, c, d, e, f, g)
    };
    var y$ = Y(x$, {
        id: 1049,
        H: {}
    });

    function x$(a, b) {
        var c = new Set,
            d = new Set(A_(a.Rb));
        for (var e of a.bd ? ? [])
            for (let f of rk(e)) C(f, 4) && (d.add(f.hb()), c.add(f.hb()));
        for (let f of Array.from(d)) {
            ({
                U: d
            } = B_().get(f, a.Rb, c.has(f), b));
            if (!d) continue;
            e = E_(d);
            if (e === 2 || e === 3) F_(B_(), Fd(ue(d, 1)) ? ? "", a.Rb, c.has(f)), x_(40, f, null, {}, b)
        }
        return {}
    };
    const A$ = j2(function(a) {
        return a.Rb.ha() || z$(a.bd)
    }, {
        id: 1415
    });
    var B$ = class extends g2 {
        constructor(a, b, c, d) {
            super(c);
            this.Rb = a;
            this.bd = b;
            c = new l$(z_(), c);
            X(Z(this, y$, {
                Rb: a,
                bd: b
            }, d), c.output)
        }
        async j() {
            return h2(this.C, A$, {
                Rb: this.Rb,
                bd: this.bd
            })
        }
        l() {}
    };

    function z$(a) {
        return a.some(b => rk(b).some(c => C(c, 4)))
    };

    function C$(a, b, c, d) {
        return e => {
            if (Ju(e) && ((c.gjPrg ? ? "") === b || (c.zeuLy ? ? "") === b && a.location.host && (c.ANqoe ? ? "") === a.location.host)) {
                var f = new u0;
                w$(R9(), e.getValue(), (l, m) => void f.Ja({
                    methodName: l,
                    eb: m
                }), () => void t.console.warn("Using deprecated googletag.encryptedSignalProviders. Please usegoogletag.secureSignalProviders instead."), () => void t.console.warn("Calling this method may reduce the likelihood of signals being included in ad requests for the current and potentially later page views. Due to this, it should only be called when meaningful state changes occur, such as events that indicate a new user log in, log out, sign up, etc."), {
                    cj: pz(nv),
                    Vi: V(mv),
                    ij: pz(vv)
                }, d);
                var g = new SZ;
                QZ(g, e.getValue());
                e = new W1(f);
                var {
                    Fe: h,
                    Zf: k
                } = Z(e, h_, {}, c.jzoix);
                U1(e, new a$(f, h, g, d));
                U1(e, new B$(g, k, f, d));
                V1(e)
            }
        }
    };
    var D$ = Y(function(a, b, c, d, e) {
        if (!U(Fv)) return {};
        a = V(Tv);
        tU({
            Jb: C$(window, gB(window), b, a > 0 ? {
                F: d,
                Lh: e,
                pk: a
            } : void 0),
            win: c,
            Xa: b.OSCLM.UWEfJ
        });
        return {}
    }, {
        id: 1378,
        H: {}
    });
    var E$ = class {
        constructor() {
            this.g = new Zs;
            this.j = new tt
        }
        compare(a, b) {
            a = Us(this.g, a);
            b = Us(this.g, b);
            if (!a || !b) throw Error("Failed to get html nodes for stacking comparison");
            return this.j.compare(a, b)
        }
    };

    function F$(a, b) {
        var c = !U(xv);
        return new ju(a, b, c ? G$ : H$)
    }

    function I$(a) {
        return Gt(a.j(), (b, c) => b.top === c.top && b.left === c.left && b.right === c.right && b.bottom === c.bottom)
    }

    function H$(a, b) {
        return J$(a, b, b.getBoundingClientRect())
    }

    function G$(a, b) {
        var c = b.dataset.adStatus;
        c === "unfilled" && (b.dataset.adStatus = "unfill-optimized");
        var d = b.getBoundingClientRect();
        a = J$(a, b, d);
        b.dataset.adStatus = c;
        return a
    }

    function J$(a, b, c) {
        return c.top === 0 && c.right === 0 && c.bottom === 0 && c.left === 0 ? c : new DOMRect(c.x + a.scrollX - Dr(b.style.left), c.y + a.scrollY - Dr(b.style.top), c.width, c.height)
    };

    function K$(a) {
        a.l || (a.j.style.position = "relative", a.j.style.zIndex = `${Math.max(Dr(a.C.style.zIndex)+1,Dr(a.j.style.zIndex))}`, a.l = a.A.j(b => {
            var c = a.j,
                d = b.first;
            b = b.second;
            c.style.top = `${Math.round(b.top-d.top)}px`;
            c.style.left = `${Math.round(b.left-d.left+(b.width-d.width)/2)}px`
        }))
    }
    var L$ = class extends O {
        constructor(a, b, c, d) {
            super();
            this.j = a;
            this.C = b;
            this.A = Et(c, d)
        }
        g() {
            super.g();
            this.stop()
        }
        stop() {
            this.l && (this.l(), this.j.style.removeProperty("top"), this.j.style.removeProperty("left"), this.j.style.removeProperty("position"))
        }
    };
    const M$ = ["auto", "scroll", "hidden", "clip"],
        N$ = ["overflow-x", "overflow-y"];

    function O$(a, b, c, d) {
        var e = {
            top: a.scrollY,
            bottom: a.innerHeight + a.scrollY,
            left: a.scrollX,
            right: a.innerWidth + a.scrollX
        };
        return P$(0, b, c, { ...e,
            bottom: e.bottom + 50
        }, d, (f, g) => {
            if (f.Sd === g) var h = 0;
            else h = f.Sd || f, h = Q$(h).bottom < e.top ? R$(h, g, e) ? 0 : 2 : 3;
            if (h !== 0) f = h;
            else {
                if (S$(f, g))
                    if (T$(f, g)) f = !0;
                    else {
                        h = U$(Q$(f));
                        var k = Number(g.I.google_ad_height);
                        k = isNaN(k) || k < h;
                        !U(Uv) && k ? f = !1 : (g = g.slot, f = U$(Q$(f)), f = $0(new j1(a, g, null, {
                            width: 0,
                            height: 0
                        }, null, f, !1)), f = !!L0(f, "", null, h))
                    }
                else f = !1;
                f = f ? 0 : 1
            }
            return f
        }, (f, g) => !T$(f,
            g))
    }

    function V$(a, b, c, d) {
        var e = {
            top: a.scrollY,
            bottom: a.innerHeight + a.scrollY,
            left: a.scrollX,
            right: a.innerWidth + a.scrollX
        };
        return P$(1, b, c, { ...e,
            top: e.top - 50
        }, d, (f, g) => {
            if (!U(xv) && g.slot.dataset.adStatus !== "unfill-optimized") return 10;
            var h = f.Sd === g ? 0 : f.Sd ? Q$(f.Sd).top > e.bottom ? R$(g, f.Sd, e) && R$(f, g, e) ? 0 : 2 : 4 : Q$(f).bottom < e.top ? R$(f, g, e) ? 0 : 2 : 3;
            return h !== 0 ? h : S$(f, g) && T$(f, g) ? 0 : 1
        })
    }

    function P$(a, b, c, d, e, f, g) {
        var h = [],
            k = [];
        W$(c, a);
        c.filter(l => {
            var m;
            if (m = !X$(Q$(l))) l = Q$(l), m = d.left <= l.right && l.left <= d.right && d.top <= l.bottom && l.top <= d.bottom;
            return m
        }).sort((l, m) => Q$(l).top - Q$(m).top).forEach(l => {
            var [m, n] = aaa(b, k, l, f, e);
            if (m.length === 0) a === 0 ? l.ak = n : l.bk = n;
            else {
                var p = m[0];
                h.push({
                    Ma: l,
                    Wb: p,
                    Dn: g ? .(p, l) ? ? !1,
                    En: a === 0
                });
                k.push(p)
            }
        });
        return h
    }

    function W$(a, b) {
        a.forEach(c => {
            X$(Q$(c)) && (b === 0 ? c.ak = [9] : c.bk = [9])
        })
    }

    function aaa(a, b, c, d, e) {
        var f = [];
        return [a.filter(g => {
            if (X$(Q$(g))) return f.push(8), !1;
            if (b.includes(g)) return f.push(5), !1;
            var h = d(g, c);
            return h !== 0 ? (f.push(h), !1) : e && e.compare(g.slot, c.slot) < 0 ? (f.push(6), !1) : baa(g.slot, c.slot) ? !0 : (f.push(7), !1)
        }).sort((g, h) => Q$(g).top - Q$(h).top), f]
    }

    function S$(a, b) {
        return Y$(Q$(b)) >= Y$(Q$(a))
    }

    function T$(a, b) {
        return U$(Q$(b)) >= U$(Q$(a))
    }

    function R$(a, b, c) {
        return Q$(b).top - Q$(a).bottom > U$(c)
    }

    function U$(a) {
        return a.bottom - a.top
    }

    function Y$(a) {
        return a.right - a.left
    }

    function Q$(a) {
        return a.Lb.j().V
    }

    function X$(a) {
        return a.top === 0 && a.right === 0 && a.bottom === 0 && a.left === 0
    }

    function baa(a, b) {
        b = qj(a, b);
        for (a = a.parentElement; a && a !== b;) {
            let c = al(a, window);
            if (N$.some(d => M$.includes(c ? .getPropertyValue(d) ? ? ""))) return !1;
            a = a.parentElement
        }
        return !0
    };

    function caa(a, b) {
        if (U(Dv) || U(uv)) {
            var c = a.C <= b.scrollY ? O$(b, [...a.j.values()], [...a.l.values()], a.G) : V$(b, [...a.j.values()], [...a.l.values()], a.G);
            U(uv) && c.length > 0 && !a.J && (a.D ? .B(), a.J = !0);
            a.A.filter(d => !c.find(e => e.Ma.slot === d.Ma.slot && e.Wb.slot === d.Wb.slot)).forEach(d => {
                d.Ma.xe ? .dispose();
                d.Ma.xe = void 0
            });
            c.filter(d => !a.A.find(e => e.Ma.slot === d.Ma.slot && e.Wb.slot === d.Wb.slot)).forEach(d => {
                if (U(Dv)) {
                    d.Ma.xe = new L$(d.Wb.slot, d.Ma.slot, I$(d.Wb.Lb), I$(d.Ma.Lb));
                    if (d.Dn) {
                        let e = d.Wb.Lb.j().V;
                        k1(a.K,
                            d.Ma.slot, {
                                height: e.bottom - e.top,
                                fg: "force"
                            });
                        J(d.Ma.slot, {
                            height: d.Ma.slot.style.height
                        })
                    }!U(xv) && d.En && (d.Ma.slot.dataset.adStatus = "unfill-optimized");
                    K$(d.Ma.xe)
                }
                d.Wb.Sd = d.Ma
            });
            c.forEach(d => {
                d.Ma.qe = d.Ma.Lb.j().V;
                d.Wb.Vn = !0
            });
            a.C = b.scrollY;
            a.A = c
        }
    }

    function daa(a) {
        return Sp(Tp(new Up, [...a.l.values()].filter(b => b.slot.isConnected).map(b => {
            var c = b.Lb.j().V;
            var d = new Rp;
            d = Mf(d, 3, b.bk ? ? []);
            d = Mf(d, 4, b.ak ? ? []);
            c = Op(Np(Mp(Lp(new Pp, c.top), c.bottom), c.left), c.right);
            c = z(d, 2, c);
            b.qe && (b = Op(Np(Mp(Lp(new Pp, b.qe.top), b.qe.bottom), b.qe.left), b.qe.right), z(c, 1, b));
            return c
        })), [...a.j.values()].filter(b => b.slot.isConnected).map(b => {
            var c = b.Lb.j().V,
                d = new Qp;
            b = tf(d, 1, b.Vn ? ? !1);
            c = Op(Np(Mp(Lp(new Pp, c.top), c.bottom), c.left), c.right);
            return z(b, 2, c)
        }))
    }

    function Z$(a, b, c) {
        var d = F$(b, c);
        xt(a, () => {
            d.dispose()
        });
        return d
    }
    var eaa = class extends O {
        constructor(a) {
            var b = new E$,
                c = HB();
            super();
            this.K = a;
            this.G = b;
            this.D = c;
            this.j = new Map;
            this.l = new Map;
            this.A = [];
            this.P = !1;
            this.C = 0;
            this.J = !1
        }
        la(a, b, c) {
            var d = this.K,
                e = U(zv),
                f;
            if (f = Nk()) c.google_ad_format === "0x0" ? f = !1 : (f = c.google_reactive_ad_format, f = !f || f === 27 || f === 40 || f === 0);
            if (f) {
                if (!e) a: {
                    for (let g of a.children)
                        if (e = g.lastElementChild, e ? .tagName === "IFRAME" && al(e, d) ? .display !== "none") {
                            e = !0;
                            break a
                        }
                    e = !1
                }
                f = e
            }
            if (f) switch (b) {
                case "filled":
                    c = this.K;
                    this.j.has(a) || this.j.set(a, {
                        slot: a,
                        Lb: Z$(this, c, a)
                    });
                    break;
                case "unfilled":
                    b = this.K, this.l.has(a) || this.l.set(a, {
                        slot: a,
                        Lb: Z$(this, b, a),
                        I: c
                    })
            }
        }
        Z(a) {
            var b = this.j.get(a);
            b && (this.j.delete(a), b.Lb.dispose());
            if (b = this.l.get(a)) b.xe ? .dispose(), b.xe = void 0, this.l.delete(a), b.Lb.dispose()
        }
        W(a) {
            if (!this.P && (this.P = !0, a.Yb(1473, () => {
                    if (MA(HA(), 43, !1)) throw Error("SlotOverlayManager is already initialized.");
                    NA(HA(), 43, !0);
                    return !0
                }))) {
                this.C = this.K.scrollY;
                var b = ri(a.Zb(1480, () => {
                    caa(this, this.K)
                }), 50);
                Yj(this.K, "scroll", b);
                xt(this, () => Zj(this.K,
                    "scroll", b));
                this.D ? .A(() => daa(this))
            }
        }
    };
    var faa = Y(function(a, b, c) {
        a = Lk(b);
        if (!a) return {
            Ob: void 0
        };
        a = new eaa(a);
        a ? .W(c);
        return {
            Ob: a
        }
    }, {
        id: 1511,
        H: {
            Ob: void 0
        }
    });

    function gaa(a, b, c, d) {
        var e = tB,
            f = haa,
            g = {
                Ja: k => {
                    var l = k.eb;
                    e.Da(k.methodName ? ? 0, l instanceof Error ? l : Error(String(l)))
                }
            },
            h = new W1(g);
        Z(h, D$, {}, a, t, d, g);
        ({
            Ib: d
        } = Z(h, K9, {}));
        g = U(yv) ? void 0 : Z(h, faa, {}, t, e) ? .Ob;
        a = Z(h, H9, {
            Ib: d,
            Ob: g
        }, b, a, c, f, t);
        X(Z(h, I9, {}, t), a.finished);
        V1(h)
    };
    var iaa = Q1(async function(a, b) {
        !U(Bv) || V(lv) <= 0 || await b.Ib ? .j()
    }, {
        id: 1390
    });
    var jaa = class {
        constructor(a, b) {
            this.K = a;
            this.Xc = b;
            this.g = null;
            this.l = 0
        }
        j() {
            ++this.l >= 10 && t.clearInterval(this.g);
            var a = FS(this.K, this.Xc);
            GS(this.K, this.Xc, a);
            a = VJ(this.Xc, this.K);
            a != null && a.x === 0 || t.clearInterval(this.g)
        }
    };
    var kaa = Y(function(a, b) {
        wB(639, () => {
            var c;
            var d = b.I;
            (c = b.K) && d.google_responsive_auto_format === 1 && d.google_full_width_responsive_allowed === !0 ? (d = (d = c.document.getElementById(d.google_async_iframe_id)) ? vj(d, "INS", "adsbygoogle") : null) ? (c = new jaa(c, d), c.g = t.setInterval(za(c.j, c), 500), c.j(), c = !0) : c = !1 : c = !1;
            return c
        });
        return {}
    }, {
        id: 1357,
        H: {}
    });
    var laa = Y(function(a, b, c) {
        a = new Map;
        for (var d of Object.keys(b)) {
            var e = a,
                f = e.set;
            var g = b[d];
            g = g === void 0 ? 1 : g === null ? 2 : g === !1 ? 3 : g === 0 ? 4 : g === "" ? 5 : Array.isArray(g) && g.length === 0 ? 6 : typeof g === "object" && Object.keys(g).length === 0 ? 7 : 8;
            f.call(e, d, g)
        }
        c.g && (b = c.F, c = LB(c, c.win.performance.now()), d = new vo, qe(d), a.forEach(Me, Le(d, 1, void 0, Jd)), a = d.setLocation(1), a = A(c, 21, Xp, a), Sq(b, a));
        return {}
    }, {
        id: 1576,
        H: {}
    });
    var maa = Y(function(a, b, c, d) {
        QA() && t.setTimeout(xB(1244, () => void dY(b || c, {
            Xa: !!d.OSCLM.UWEfJ
        })), 1E3);
        return {}
    }, {
        id: 1385,
        H: {}
    });
    async function $$(a, b, c, d, e, f, g) {
        await dJ(a, b, c, d, e, f, g)
    }
    var naa = Y(function(a, b, c, d, e, f) {
        var g = b.K,
            h = b.pubWin;
        g ? .location ? .hash ? .match(/\bgoog_cpmi=([^&]*)/) ? yB(1008, $$(h, g, c, d, pg(new ky), e, f.SLqBY || ""), k => {
            k.es = gJ(null)
        }) : WW(h, "affa", k => {
            yB(1008, $$(h, g, c, d, k.config, e, f.SLqBY || ""), l => {
                l.es = gJ(null)
            });
            return !0
        });
        return {}
    }, {
        id: 1384,
        H: {}
    });

    function oaa(a) {
        var b = tB,
            c = {
                Ja: f => {
                    var g = f.eb;
                    b.Da(f.methodName ? ? 0, g instanceof Error ? g : Error(String(g)))
                }
            },
            d = new W1(c);
        Z(d, laa, {}, a.I, HB());
        var e = T1(d, iaa, {}, a);
        c = U1(d, new G9(c, a, e.complete));
        e = X(X(Z(d, kaa, {}, a), c.j), e.complete);
        e = X(Z(d, maa, {}, a.K, a.pubWin, a.pageState), e.finished);
        a = X(Z(d, naa, {}, {
            K: a.K,
            pubWin: a.pubWin
        }, a.I, a.Ia, a.R, a.pageState), e.finished);
        V1(d);
        return a.finished.promise
    };
    var paa = class {
        constructor(a) {
            this.j = 0;
            this.R = this.A = null;
            this.B = 0;
            this.Ia = [];
            this.Kc = this.l = "";
            this.zb = !1;
            this.K = a.K;
            this.pubWin = a.pubWin;
            this.I = a.I;
            this.Na = a.Na;
            this.Sc = a.Sc;
            this.ca = a.ca;
            this.pageState = a.pageState;
            this.Ta = a.Ta
        }
    };

    function qaa(a) {
        tB.l(b => {
            b.shv = String(a);
            b.mjsv = aq();
            b.eid = n0(t)
        })
    };
    async function haa({
        Na: a,
        Sc: b,
        slot: c,
        pageState: d,
        Ib: e,
        Ob: f
    }) {
        var g = c.vars,
            h = Lk(c.pubWin),
            k = c.innerInsElement;
        if (!k) throw Error("no_wrapper_element_in_loader_provided_slot");
        a = new paa({
            K: h,
            pubWin: c.pubWin,
            I: g,
            Na: a,
            Sc: b,
            ca: k,
            pageState: d,
            Ta: c.KCuMo
        });
        a.B = Date.now();
        a.Ib = e;
        a.Ob = f;
        Kl(1, [a.I]);
        try {
            await oaa(a)
        } catch (l) {
            if (!AB(159, l)) throw l;
        }
        return a
    };
    (function(a, b) {
        wB(843, () => {
            if (!t.google_sa_impl) {
                var c = null;
                c = c ? ? new cr(a);
                try {
                    Jb(e => {
                        jB(c, 1192, e)
                    })
                } catch (e) {}
                var d = t.adsbygoogle && "pageState" in t.adsbygoogle && t.adsbygoogle.pageState ? t.adsbygoogle.pageState : {
                    stavq: 0,
                    jTCuI: "",
                    OmOVT: !1,
                    xujKL: !1,
                    AyxaY: void 0,
                    SLqBY: "",
                    xVQAt: "",
                    OSCLM: {
                        UWEfJ: !1,
                        YguOd: !1,
                        SVQEK: !1
                    },
                    jzoix: {
                        PygXN: []
                    },
                    FJPve: !1,
                    GLnKw: !1,
                    tYcft: Promise.resolve(void 0),
                    EGzMj: Promise.resolve(!0),
                    uNjDc: !1
                };
                qaa(d.jTCuI);
                k0(e0(t));
                gaa(d, a, b, c)
            }
        })
    })(aq(), function(a, b, c, d) {
        b = b > 2012 ? `_fy${b}` : "";
        return {
            un: fi `https://pagead2.googlesyndication.com/pagead/js/${c}/${d}/rum${b}.js`,
            sn: fi `https://pagead2.googlesyndication.com/pagead/js/${c}/${d}/rum_debug${b}.js`,
            hk: fi `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/reactive_library${b}.js`,
            Il: fi `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/debug_card_library${b}.js`,
            Cp: fi `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/slotcar_library${b}.js`,
            lg: fi `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/video_feed${b}.js`,
            Gk: fi `https://googleads.g.doubleclick.net/pagead/html/${c}/${d}/zrt_lookup${b}.html`,
            Fk: fi `https://pagead2.googlesyndication.com/pagead/html/${c}/${d}/zrt_lookup${b}.html`
        }
    });
}).call(this, "");